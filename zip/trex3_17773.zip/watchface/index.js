﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
		let normal_date_img_date_week_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_bio_charge_icon_img = ''
        let normal_bio_charge_text_text_img = ''
        let normal_bio_charge_text_separator_img = ''
        let normal_bio_charge_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
		let idle_date_text_date_week = ''
		let time=false
		let normal_date_text_date_week = '';
		
		let weekday=["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 1
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_step_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_zona2 = ''
        let zona2_num = 0
        let zona2_all = 1
		
		function click_zona2() {
		  zona2_num = (zona2_num + 1) % (zona2_all + 1);
          if (zona2_num == 0) {		
		    normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona2_num == 1) {
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let btn_zona3 = ''
        let zona3_num = 0
        let zona3_all = 1
		
		function click_zona3() {
		  zona3_num = (zona3_num + 1) % (zona3_all + 1);
          if (zona3_num == 0) {		
		    normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_bio_charge_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_bio_charge_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_bio_charge_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_bio_charge_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona3_num == 1) {
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_bio_charge_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_bio_charge_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_bio_charge_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_bio_charge_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
				
		function setLang(){
				const lang = DeviceRuntimeCore.HmUtils.getLanguage();
				if(lang=='en-US'){
					
					weekday=["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];
				}
				if(lang=='uk-UA'){
					weekday=["ПОН", "ВІВ", "СРД", "ЧТВ", "П'ЯТ", "СБТ", "НДЛ"];										
				}
				if(lang=='ru-RU'){
					weekday=["ПОН","ВТР","СРД","ЧТВ","ПТН","СБТ","ВСК"];					
				}				
			}			
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			/*            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 140,
              y: 89,
              week_en: ["A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png"],
              week_tc: ["A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png"],
              week_sc: ["A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });*/
			
			normal_date_text_date_week = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 75,
              y: 65,
			  w:80,
			  h:30,
			  color: 0xffffff,
			  text_size: 26,
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.CENTER_V,
			  text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			time = hmSensor.createSensor(hmSensor.id.TIME);
			
			time.addEventListener(time.event.DAYCHANGE, function() {
				setTextData();
			});
			
			function setTextData(){
				if(typeof normal_date_text_date_week !== 'string'){
					normal_date_text_date_week.setProperty(hmUI.prop.TEXT,weekday[time.week-1]);
				}
				if(typeof idle_date_text_date_week !== 'string'){
					idle_date_text_date_week.setProperty(hmUI.prop.TEXT,weekday[time.week-1]);
				}		
			}

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 150,
              day_startY: 67,
              day_sc_array: ["battnum_0.png","battnum_1.png","battnum_2.png","battnum_3.png","battnum_4.png","battnum_5.png","battnum_6.png","battnum_7.png","battnum_8.png","battnum_9.png"],
              day_tc_array: ["battnum_0.png","battnum_1.png","battnum_2.png","battnum_3.png","battnum_4.png","battnum_5.png","battnum_6.png","battnum_7.png","battnum_8.png","battnum_9.png"],
              day_en_array: ["battnum_0.png","battnum_1.png","battnum_2.png","battnum_3.png","battnum_4.png","battnum_5.png","battnum_6.png","battnum_7.png","battnum_8.png","battnum_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 170,
              y: 422,
              image_array: ["wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png","wind_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 425,
              font_array: ["battnum_0.png","battnum_1.png","battnum_2.png","battnum_3.png","battnum_4.png","battnum_5.png","battnum_6.png","battnum_7.png","battnum_8.png","battnum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'windpower.png',
              unit_tc: 'windpower.png',
              unit_en: 'windpower.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND_SPEED,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 180,
              y: 422,
              image_array: ["weatheraod_0.png","weatheraod_1.png","weatheraod_2.png","weatheraod_3.png","weatheraod_4.png","weatheraod_5.png","weatheraod_6.png","weatheraod_7.png","weatheraod_8.png","weatheraod_9.png","weatheraod_10.png","weatheraod_11.png","weatheraod_12.png","weatheraod_13.png","weatheraod_14.png","weatheraod_15.png","weatheraod_16.png","weatheraod_17.png","weatheraod_18.png","weatheraod_19.png","weatheraod_20.png","weatheraod_21.png","weatheraod_22.png","weatheraod_23.png","weatheraod_24.png","weatheraod_25.png","weatheraod_26.png","weatheraod_27.png","weatheraod_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 425,
              font_array: ["battnum_0.png","battnum_1.png","battnum_2.png","battnum_3.png","battnum_4.png","battnum_5.png","battnum_6.png","battnum_7.png","battnum_8.png","battnum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'gradus.png',
              unit_tc: 'gradus.png',
              unit_en: 'gradus.png',
              negative_image: 'minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 16,
              font_array: ["battnum_0.png","battnum_1.png","battnum_2.png","battnum_3.png","battnum_4.png","battnum_5.png","battnum_6.png","battnum_7.png","battnum_8.png","battnum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'unit.png',
              unit_tc: 'unit.png',
              unit_en: 'unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 226,
              font_array: ["stepnum_0.png","stepnum_1.png","stepnum_2.png","stepnum_3.png","stepnum_4.png","stepnum_5.png","stepnum_6.png","stepnum_7.png","stepnum_8.png","stepnum_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 44,
              y: 225,
              src: 'disticon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 226,
              font_array: ["stepnum_0.png","stepnum_1.png","stepnum_2.png","stepnum_3.png","stepnum_4.png","stepnum_5.png","stepnum_6.png","stepnum_7.png","stepnum_8.png","stepnum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 44,
              y: 224,
              src: 'stepicon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 33,
              y: 266,
              image_array: ["step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png","step_10.png","step_11.png","step_12.png","step_13.png"],
              image_length: 13,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 65,
              y: 355,
              src: 'biolvlicon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 323,
              font_array: ["stepnum_0.png","stepnum_1.png","stepnum_2.png","stepnum_3.png","stepnum_4.png","stepnum_5.png","stepnum_6.png","stepnum_7.png","stepnum_8.png","stepnum_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'nonestep.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 45,
              y: 322,
              src: 'bioicon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 65,
              y: 355,
              image_array: ["biolvl_1.png","biolvl_2.png","biolvl_3.png","biolvl_4.png","biolvl_5.png","biolvl_6.png","biolvl_7.png","biolvl_8.png","biolvl_9.png"],
              image_length: 9,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 61,
              y: 365,
              src: 'zoneicon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 323,
              font_array: ["stepnum_0.png","stepnum_1.png","stepnum_2.png","stepnum_3.png","stepnum_4.png","stepnum_5.png","stepnum_6.png","stepnum_7.png","stepnum_8.png","stepnum_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'nonestep.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 45,
              y: 322,
              src: 'heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 61,
              y: 365,
              image_array: ["h_1.png","h_2.png","h_3.png","h_4.png"],
              image_length: 4,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 125,
              font_array: ["stepnum_0.png","stepnum_1.png","stepnum_2.png","stepnum_3.png","stepnum_4.png","stepnum_5.png","stepnum_6.png","stepnum_7.png","stepnum_8.png","stepnum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 34,
              y: 166,
              image_array: ["kcal_1.png","kcal_2.png","kcal_3.png","kcal_4.png","kcal_5.png","kcal_6.png","kcal_7.png","kcal_8.png","kcal_9.png","kcal_10.png","kcal_11.png","kcal_12.png"],
              image_length: 12,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 214,
              hour_startY: 70,
              hour_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              hour_zero: 1,
              hour_space: -15,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 245,
              minute_startY: 198,
              minute_array: ["13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              minute_zero: 1,
              minute_space: -15,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 330,
              second_startY: 360,
              second_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 317,
              month_startY: 398,
              month_sc_array: ["battnum_0.png","battnum_1.png","battnum_2.png","battnum_3.png","battnum_4.png","battnum_5.png","battnum_6.png","battnum_7.png","battnum_8.png","battnum_9.png"],
              month_tc_array: ["battnum_0.png","battnum_1.png","battnum_2.png","battnum_3.png","battnum_4.png","battnum_5.png","battnum_6.png","battnum_7.png","battnum_8.png","battnum_9.png"],
              month_en_array: ["battnum_0.png","battnum_1.png","battnum_2.png","battnum_3.png","battnum_4.png","battnum_5.png","battnum_6.png","battnum_7.png","battnum_8.png","battnum_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 265,
              day_startY: 398,
              day_sc_array: ["battnum_0.png","battnum_1.png","battnum_2.png","battnum_3.png","battnum_4.png","battnum_5.png","battnum_6.png","battnum_7.png","battnum_8.png","battnum_9.png"],
              day_tc_array: ["battnum_0.png","battnum_1.png","battnum_2.png","battnum_3.png","battnum_4.png","battnum_5.png","battnum_6.png","battnum_7.png","battnum_8.png","battnum_9.png"],
              day_en_array: ["battnum_0.png","battnum_1.png","battnum_2.png","battnum_3.png","battnum_4.png","battnum_5.png","battnum_6.png","battnum_7.png","battnum_8.png","battnum_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });
			
			/*            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 140,
              y: 94,
              week_en: ["A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png"],
              week_tc: ["A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png"],
              week_sc: ["A100_036.png","A100_037.png","A100_038.png","A100_039.png","A100_040.png","A100_041.png","A100_042.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });*/
			
			idle_date_text_date_week = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 187,
              y: 396,
			  w:80,
			  h:30,
			  color: 0xffffff,
			  text_size: 26,
			  align_h: hmUI.align.CENTER_H,
			  align_v: hmUI.align.CENTER_V,
			  text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 32,
              font_array: ["battnum_0.png","battnum_1.png","battnum_2.png","battnum_3.png","battnum_4.png","battnum_5.png","battnum_6.png","battnum_7.png","battnum_8.png","battnum_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'unit.png',
              unit_tc: 'unit.png',
              unit_en: 'unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 70,
              y: 225,
              font_array: ["stepnum_0.png","stepnum_1.png","stepnum_2.png","stepnum_3.png","stepnum_4.png","stepnum_5.png","stepnum_6.png","stepnum_7.png","stepnum_8.png","stepnum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 285,
              font_array: ["stepnum_0.png","stepnum_1.png","stepnum_2.png","stepnum_3.png","stepnum_4.png","stepnum_5.png","stepnum_6.png","stepnum_7.png","stepnum_8.png","stepnum_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'nonestep.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 70,
              y: 165,
              font_array: ["stepnum_0.png","stepnum_1.png","stepnum_2.png","stepnum_3.png","stepnum_4.png","stepnum_5.png","stepnum_6.png","stepnum_7.png","stepnum_8.png","stepnum_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 214,
              hour_startY: 85,
              hour_array: ["34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png","43.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 214,
              minute_startY: 220,
              minute_array: ["44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 60,
              y: 220,
              text: '',
              w: 130,
              h: 70,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "activityAppScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 65,
              y: 120,
              w: 100,
              h: 70,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_zona3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 60,
              y: 320,
              text: '',
              w: 130,
              h: 70,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona3();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "heart_app_Screen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona3.setProperty(hmUI.prop.VISIBLE, true);
			normal_bio_charge_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_bio_charge_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_bio_charge_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_bio_charge_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

            btn_zona2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 185,
              y: 415,
              text: '',
              w: 100,
              h: 60,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona2();
             },
			  longpress_func: () => {
             hmApp.startApp({ url: "WeatherScreen", native: true });
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona2.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 230,
              w: 100,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 350,
              w: 75,
              h: 70,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 270,
              y: 95,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 55,
              w: 100,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
			   console.log('resume_call()');
                setLang();
				setTextData();
              }),
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}