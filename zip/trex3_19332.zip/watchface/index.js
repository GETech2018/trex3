﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

       let analogTime_num = 0
       let analogTime_all = 1
		function click_analogTime() {
		  analogTime_num = (analogTime_num + 1) % (analogTime_all + 1);
          if (analogTime_num == 0) {	
		  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, true);	 
          normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, true);			  
	      normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);	  
    
          };
          if (analogTime_num == 1) {			  
		  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, false);	  
		  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, false);
		  normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false); 
          };	  		  
		}		

        let DataColor = "0xFFfe8664"
		let bg_img = "bg-1.png"
		let bio_icon = "bg_niz_danye1.png"
		let heart_icon = "bg_verh_danye1.png"
		let bio_pointer = "pravaya-duga1.png"
		let heart_pointer = "levaya-duga1.png"
		let image_img = "bg1-up.png"
		let top_img = "bg1-up2.png"
		let hour = "pointer_hour1.png"
		let minute = "pointer_minut1.png"
		let second = "pointer_sec1.png"

				
        let tap_dannye = 0;
        /* функция смены цветов массива данных */
            function click_dannye() {
            tap_dannye = (tap_dannye + 1) % 2;

        switch (tap_dannye) {
	
        case 0:
        /* кейс для первого цвета */
        DataColor = "0xFFfe8664"
		bg_img = "bg-1.png";
        bio_icon = "bg_niz_danye1.png";	
		heart_icon = "bg_verh_danye1.png";
		bio_pointer = "pravaya-duga1.png";
		heart_pointer = "levaya-duga1.png";
		image_img = "bg1-up.png";
		top_img = "bg1-up2.png";
		hour = "pointer_hour1.png";
		minute = "pointer_minut1.png";
		second = "pointer_sec1.png";
        break;

        case 1:
        /* кейс для второго цвета */
        DataColor = "0xFF27759a"
		bg_img = "bg-2.png";
        bio_icon = "bg_niz_danye2.png";	
        heart_icon = "bg_verh_danye2.png";
        bio_pointer = "pravaya-duga2.png";
        heart_pointer = "levaya-duga2.png";	
        image_img = "bg2-up.png";
        top_img = "bg2-up2.png";
        hour = "pointer_hour2.png";	
        minute = "pointer_minut2.png";	
        second = "pointer_sec2.png";		
        break;

        default:
        /* кейс для цвета по умолчанию/первого */	
        DataColor = "0xFFfe8664"
		bg_img = "bg-1.png";	
        bio_icon = "bg_niz_danye1.png";	
        heart_icon = "bg_verh_danye1.png";	
        bio_pointer = "pravaya-duga1.png";
        heart_pointer = "levaya-duga1.png";	
        image_img = "bg1-up.png";	
        top_img = "bg1-up2.png";
        hour = "pointer_hour2.png";	
        minute = "pointer_minut2.png";
        second = "pointer_sec2.png";		
}

            normal_background_bg_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: bg_img,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              src: image_img,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            image_top_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              src: top_img,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_circle_scale.setProperty(hmUI.prop.MORE, {
              center_x: 240,
              center_y: 240,
              start_angle: 263,
              end_angle: 161,
              radius: 199,
              line_width: 18,
              corner_flag: 3,
              type: hmUI.data_type.BIO_CHARGE,
              color: DataColor,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

            normal_heart_rate_circle_scale_2.setProperty(hmUI.prop.MORE, {
              center_x: 240,
              center_y: 240,
              start_angle: -83,
              end_angle: 19,
              radius: 199,
              line_width: 18,
              corner_flag: 3,
              type: hmUI.data_type.HEART,
              color: DataColor,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_icon_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              src: bio_icon,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

            normal_heart_rate_icon_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              src: heart_icon,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });			

            normal_bio_charge_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: bio_pointer,
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: 263,
              end_angle: 161,
              invalid_visible: false,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: heart_pointer,
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -83,
              end_angle: 19,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: hour,
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 20,
              hour_posY: 134,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: minute,
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 15,
              minute_posY: 190,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: second,
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 175,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
		}	

       let battemp_num = 0
       let battemp_all = 1
		function click_battemp() {
		  battemp_num = (battemp_num + 1) % (battemp_all + 1);
          if (battemp_num == 0) {	
		  normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, true);	 
          normal_widget_text_1.setProperty(hmUI.prop.VISIBLE, true);	
          normal_battery_linear_scale.setProperty(hmUI.prop.VISIBLE, true);		  
	      normal_body_temp_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_widget_text_2.setProperty(hmUI.prop.VISIBLE, false);		  
    
          };
          if (battemp_num == 1) {			  
		  normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, false);	  
		  normal_widget_text_1.setProperty(hmUI.prop.VISIBLE, false);
		  normal_battery_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
		  normal_body_temp_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_widget_text_2.setProperty(hmUI.prop.VISIBLE, true);	  
          };	  		  
		}				
		
       let baro_num = 0
       let baro_all = 2
		function click_baro() {
		  baro_num = (baro_num + 1) % (baro_all + 1);
          if (baro_num == 0) {
          normal_temperature_max_min_text_font.setProperty(hmUI.prop.VISIBLE, true);			  
		  normal_altimeter_current_text_font.setProperty(hmUI.prop.VISIBLE, false);	 
          normal_widget_text_8.setProperty(hmUI.prop.VISIBLE, false);			  
	      normal_pressure_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_widget_text_9.setProperty(hmUI.prop.VISIBLE, false);		     
          };
          if (baro_num == 1) {
          normal_temperature_max_min_text_font.setProperty(hmUI.prop.VISIBLE, false);			  
		  normal_altimeter_current_text_font.setProperty(hmUI.prop.VISIBLE, true);	  
		  normal_widget_text_8.setProperty(hmUI.prop.VISIBLE, true);
		  normal_pressure_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_widget_text_9.setProperty(hmUI.prop.VISIBLE, false);	  
          };	  
          if (baro_num == 2) {
          normal_temperature_max_min_text_font.setProperty(hmUI.prop.VISIBLE, false);			  
		  normal_altimeter_current_text_font.setProperty(hmUI.prop.VISIBLE, false);	  
		  normal_widget_text_8.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pressure_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_widget_text_9.setProperty(hmUI.prop.VISIBLE, true);	  
          };		  
		}						
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_bio_charge_circle_scale = ''
        let normal_bio_charge_icon_img = ''
        let normal_bio_charge_pointer_progress_img_pointer = ''
        let normal_bio_charge_current_text_font = ''
        let normal_heart_rate_circle_scale_2 = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_font = ''
        let normal_image_img = ''
        let normal_step_current_text_font = ''
        let normal_pressure_text_font = ''
        let normal_altimeter_current_text_font = ''
        let normal_temperature_max_min_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_date_img_date_week_img = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['ЯНВ', 'ФЕВ', 'МРТ', 'АПР', 'МАЙ', 'ИЮН', 'ИЮЛ', 'АВГ', 'СЕН', 'ОКТ', 'НОЯ', 'ДЕК', ];
        let normal_day_text_font = ''
        let normal_widget_text_1 = ''
        let normal_widget_text_2 = ''
        let normal_widget_text_3 = ''
        let normal_widget_text_4 = ''
        let normal_widget_text_5 = ''
        let normal_widget_text_6 = ''
        let normal_widget_text_7 = ''
        let normal_widget_text_8 = ''
        let normal_widget_text_9 = ''
        let normal_battery_linear_scale = ''
        let normal_battery_current_text_font = ''
        let normal_body_temp_current_text_font = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_bio_charge_current_text_font = ''
        let idle_heart_rate_text_font = ''
        let idle_image_img = ''
        let idle_step_current_text_font = ''
        let idle_altimeter_current_text_font = ''
        let idle_temperature_max_min_text_font = ''
        let idle_temperature_current_text_font = ''
        let idle_date_img_date_week_img = ''
        let idle_month_name_font = ''
        let idle_Month_Array = ['ЯНВ', 'ФЕВ', 'МРТ', 'АПР', 'МАЙ', 'ИЮН', 'ИЮЛ', 'АВГ', 'СЕН', 'ОКТ', 'НОЯ', 'ДЕК', ];
        let idle_day_text_font = ''
        let idle_widget_text_1 = ''
        let idle_widget_text_2 = ''
        let idle_widget_text_3 = ''
        let idle_widget_text_4 = ''
        let idle_widget_text_5 = ''
        let idle_widget_text_6 = ''
        let idle_battery_linear_scale = ''
        let idle_battery_current_text_font = ''
        let idle_body_temp_current_text_font = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let image_top_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: allfontASm_01-regular.ttf; FontSize: 33
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 492,
              h: 57,
              text_size: 33,
              char_space: 1,
              line_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: NotoSansMedium_ASm_01.ttf; FontSize: 36
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 470,
              h: 62,
              text_size: 36,
              char_space: -1,
              line_space: 0,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFBEBEBE,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: NotoSansMedium_ASm_01.ttf; FontSize: 27; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 32,
              h: 32,
              text_size: 27,
              char_space: -1,
              line_space: 0,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFBEBEBE,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: NotoSansMedium_ASm_01.ttf; FontSize: 31
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 410,
              h: 52,
              text_size: 31,
              char_space: -1,
              line_space: 0,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: FHSZeppASm-Regular.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 514,
              h: 50,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFBEBEBE,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: FHSZeppASm-Regular.ttf; FontSize: 32
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 414,
              h: 40,
              text_size: 32,
              char_space: 0,
              line_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: FHSZeppASm-Regular.ttf; FontSize: 29
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 368,
              h: 36,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFBEBEBE,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: FHSZeppASm-Regular.ttf; FontSize: 46
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 596,
              h: 58,
              text_size: 46,
              char_space: 0,
              line_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFBEBEBE,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: NotoSansMedium_ASm_01.ttf; FontSize: 32
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 414,
              h: 56,
              text_size: 32,
              char_space: -1,
              line_space: 0,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFBEBEBE,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: allfontASm_01-regular.ttf; FontSize: 32
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 411,
              h: 56,
              text_size: 32,
              char_space: -1,
              line_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFBEBEBE,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg-1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 263,
              end_angle: 161,
              radius: 199,
              line_width: 18,
              corner_flag: 3,
              type: hmUI.data_type.BIO_CHARGE,
              color: 0xFFFE8664,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_niz_danye1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pravaya-duga1.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: 263,
              end_angle: 161,
              invalid_visible: false,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 53,
              y: 53,
              w: 374,
              h: 374,
              text_size: 33,
              char_space: 1,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 206,
              end_angle: 242,
              mode: 1,
              // radius: 187,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -83,
              end_angle: 19,
              radius: 199,
              line_width: 18,
              corner_flag: 3,
              type: hmUI.data_type.HEART,
              color: 0xFFFE8664,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg_verh_danye1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'levaya-duga1.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -83,
              end_angle: 19,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 55,
              y: 55,
              w: 370,
              h: 370,
              text_size: 33,
              char_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -63,
              end_angle: -28,
              mode: 0,
              // radius: 185,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg1-up.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 59,
              y: 213,
              w: 117,
              h: 70,
              text_size: 36,
              char_space: -1,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pressure_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 199,
              y: 318,
              w: 81,
              h: 70,
              text_size: 36,
              char_space: -1,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            const baroSensor = hmSensor.createSensor(hmSensor.id.BARO);

            normal_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 199,
              y: 318,
              w: 81,
              h: 70,
              text_size: 36,
              char_space: -1,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 163,
              y: 319,
              w: 153,
              h: 70,
              text_size: 36,
              char_space: -1,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 199,
              y: 278,
              w: 81,
              h: 70,
              text_size: 36,
              char_space: -1,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 172,
              y: 68,
              week_en: ["week1-1.png","week1-2.png","week1-3.png","week1-4.png","week1-5.png","week1-6.png","week1-7.png"],
              week_tc: ["week1-1.png","week1-2.png","week1-3.png","week1-4.png","week1-5.png","week1-6.png","week1-7.png"],
              week_sc: ["week1-1.png","week1-2.png","week1-3.png","week1-4.png","week1-5.png","week1-6.png","week1-7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 198,
              y: 121,
              w: 81,
              h: 49,
              text_size: 27,
              char_space: -1,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ЯНВ, ФЕВ, МРТ, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ, ДЕК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 198,
              y: 82,
              w: 81,
              h: 70,
              text_size: 31,
              char_space: -1,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 336,
              y: 186,
              w: 91,
              h: 60,
              text_size: 40,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'Z',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 336,
              y: 186,
              w: 91,
              h: 60,
              text_size: 40,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'T',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 111,
              y: 297,
              w: 91,
              h: 60,
              text_size: 40,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'B',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 107,
              y: 295,
              w: 91,
              h: 60,
              text_size: 40,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'B',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_5 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 109,
              y: 134,
              w: 91,
              h: 60,
              text_size: 32,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'P',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_6 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 106,
              y: 131,
              w: 91,
              h: 60,
              text_size: 29,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'P',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_7 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 72,
              y: 183,
              w: 91,
              h: 60,
              text_size: 46,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'S',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_8 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 194,
              y: 364,
              w: 91,
              h: 60,
              text_size: 40,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'G',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_9 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 194,
              y: 364,
              w: 91,
              h: 60,
              text_size: 40,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'M',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 363,
              // start_y: 210,
              // color: 0xFF242424,
              // lenght: 31,
              // line_width: 15,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 331,
              y: 214,
              w: 96,
              h: 70,
              text_size: 32,
              char_space: -1,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_body_temp_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 331,
              y: 214,
              w: 96,
              h: 70,
              text_size: 32,
              char_space: -1,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'pointer_hour1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 20,
              hour_posY: 134,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'pointer_minut1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 15,
              minute_posY: 190,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'pointer_sec1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 175,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg-AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 76,
              y: 342,
              w: 80,
              h: 53,
              text_size: 33,
              char_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 76,
              y: 84,
              w: 80,
              h: 53,
              text_size: 33,
              char_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg1-up.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 59,
              y: 213,
              w: 117,
              h: 70,
              text_size: 36,
              char_space: -1,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 335,
              y: 331,
              w: 81,
              h: 70,
              text_size: 33,
              char_space: -1,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_max_min_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 163,
              y: 319,
              w: 153,
              h: 70,
              text_size: 36,
              char_space: -1,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 199,
              y: 278,
              w: 81,
              h: 70,
              text_size: 36,
              char_space: -1,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 172,
              y: 68,
              week_en: ["week1-1.png","week1-2.png","week1-3.png","week1-4.png","week1-5.png","week1-6.png","week1-7.png"],
              week_tc: ["week1-1.png","week1-2.png","week1-3.png","week1-4.png","week1-5.png","week1-6.png","week1-7.png"],
              week_sc: ["week1-1.png","week1-2.png","week1-3.png","week1-4.png","week1-5.png","week1-6.png","week1-7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 198,
              y: 121,
              w: 81,
              h: 49,
              text_size: 27,
              char_space: -1,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ЯНВ, ФЕВ, МРТ, АПР, МАЙ, ИЮН, ИЮЛ, АВГ, СЕН, ОКТ, НОЯ, ДЕК,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 198,
              y: 82,
              w: 81,
              h: 70,
              text_size: 31,
              char_space: -1,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 336,
              y: 186,
              w: 91,
              h: 60,
              text_size: 40,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'Z',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 322,
              y: 122,
              w: 91,
              h: 60,
              text_size: 40,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'T',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 71,
              y: 305,
              w: 91,
              h: 60,
              text_size: 40,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'B',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 71,
              y: 122,
              w: 91,
              h: 60,
              text_size: 29,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'P',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_5 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 72,
              y: 183,
              w: 91,
              h: 60,
              text_size: 46,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'S',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_6 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 330,
              y: 303,
              w: 91,
              h: 60,
              text_size: 40,
              char_space: 0,
              font: 'fonts/FHSZeppASm-Regular.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'G',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 363,
              // start_y: 210,
              // color: 0xFF242424,
              // lenght: 31,
              // line_width: 15,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 331,
              y: 214,
              w: 96,
              h: 70,
              text_size: 32,
              char_space: -1,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_body_temp_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 316,
              y: 75,
              w: 96,
              h: 70,
              text_size: 32,
              char_space: -1,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFBEBEBE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'pointer_hour1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 20,
              hour_posY: 134,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'pointer_minut1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 15,
              minute_posY: 190,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg1-up2.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 220,
              y: 220,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_analogTime();
vibro(23);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 198,
              y: 304,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_baro();
vibro(23);
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
vibro(23);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 78,
              y: 199,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
vibro(23);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 420,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_dannye();
vibro(23);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 352,
              y: 210,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_battemp();
vibro(23);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 97,
              y: 106,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
vibro(23);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

        if (screenType != hmSetting.screen_type.AOD) {	
	      normal_body_temp_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_widget_text_2.setProperty(hmUI.prop.VISIBLE, false);
		  normal_altimeter_current_text_font.setProperty(hmUI.prop.VISIBLE, false);	 
          normal_widget_text_8.setProperty(hmUI.prop.VISIBLE, false);			  
	      normal_pressure_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_widget_text_9.setProperty(hmUI.prop.VISIBLE, false);		  
		};	
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('month font');
              if (updateHour) {
                let idle_Month_Str = idle_Month_Array[timeSensor.month-1];
                idle_month_name_font.setProperty(hmUI.prop.TEXT, idle_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');
              // Pressure Font
              let pressureValue = baroSensor.pressure;
              let normal_pressure_font = '-';
              if (pressureValue) normal_pressure_font = Math.round(pressureValue * 0.75006375541921).toString();
              normal_pressure_text_font.setProperty(hmUI.prop.TEXT, normal_pressure_font);

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 394;
                  let start_y_normal_battery = 210;
                  let lenght_ls_normal_battery = -31;
                  let line_width_ls_normal_battery = 15;
                  let color_ls_normal_battery = 0xFF242424;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 394;
                  let start_y_idle_battery = 210;
                  let lenght_ls_idle_battery = -31;
                  let line_width_ls_idle_battery = 15;
                  let color_ls_idle_battery = 0xFF242424;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}