/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_month_imageset2 = '';
		let normal_date_imagecombo3 = '';
		let normal_week_imageset4 = '';
		let normal_temperature_current_imagecombo6 = '';
		let normal_current_city_text7 = '';
		let normal_battery_progress9 = '';
		let normal_heart_rate_progress11 = '';
		let normal_img12 = '';
		let normal_hour_rotary14 = '';
		let timeInterval;
		let normal_minute_rotary15 = '';
		let normal_second_rotary16 = '';
		let idle_img19 = '';
		let idle_month_imageset21 = '';
		let idle_date_imagecombo22 = '';
		let idle_week_imageset23 = '';
		let idle_temperature_current_imagecombo25 = '';
		let idle_current_city_text26 = '';
		let idle_battery_progress28 = '';
		let idle_heart_rate_progress30 = '';
		let idle_img31 = '';
		let idle_hour_rotary33 = '';
		let idle_minute_rotary34 = '';
		let idle_second_rotary35 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				const batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
				const heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
				const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset2 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 283,
					month_startY: 253,
					month_sc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png"],
					month_tc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png"],
					month_en_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo3 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 314,
					day_startY: 227,
					day_sc_array: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
					day_tc_array: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
					day_en_array: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset4 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 260,
					y: 164,
					week_en: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
					week_tc: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
					week_sc: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo6 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 210,
					y: 356,
					font_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0043.png"],
					unit_tc: ["0043.png"],
					unit_en: ["0043.png"],
					negative_image: ["0042.png"],
					invalid_image: ["0044.png"],
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_current_city_text7 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 133,
					y: 329,
					w: 214,
					h: 24,
					color: 0xA1A1A1,
					text: '--',
					text_size: 24,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Roboto-Medium.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				if (screenType != hmSetting.screen_type.AOD) {
					normal_battery_progress9 = hmUI.createWidget(hmUI.widget.ARC, {
						enable: false,
					});
				}

				if (screenType != hmSetting.screen_type.AOD) {
					normal_heart_rate_progress11 = hmUI.createWidget(hmUI.widget.ARC, {
						enable: false,
					});
				}

				normal_img12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 111,
					y: 200,
					w: 79,
					h: 79,
					src: '0045.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_rotary14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 241,
					center_y: 240,
					pos_x: 227,
					pos_y: 114,
					src: '0046.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_rotary15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 241,
					center_y: 240,
					pos_x: 228,
					pos_y: 44,
					src: '0047.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 241,
					center_y: 239,
					pos_x: 237,
					pos_y: 29,
					src: '0048.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img19 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0049.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_month_imageset21 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 283,
					month_startY: 253,
					month_sc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png"],
					month_tc_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png"],
					month_en_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_imagecombo22 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 314,
					day_startY: 227,
					day_sc_array: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
					day_tc_array: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
					day_en_array: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_week_imageset23 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 260,
					y: 164,
					week_en: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
					week_tc: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
					week_sc: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_temperature_current_imagecombo25 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 210,
					y: 356,
					font_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0043.png"],
					unit_tc: ["0043.png"],
					unit_en: ["0043.png"],
					negative_image: ["0042.png"],
					invalid_image: ["0044.png"],
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_current_city_text26 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 133,
					y: 329,
					w: 214,
					h: 24,
					color: 0xA1A1A1,
					text: '--',
					text_size: 24,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Roboto-Medium.ttf',
					show_level: hmUI.show_level.ONAL_AOD,
				});

				if (screenType != hmSetting.screen_type.AOD) {
					idle_battery_progress28 = hmUI.createWidget(hmUI.widget.ARC, {
						enable: false,
					});
				}

				if (screenType != hmSetting.screen_type.AOD) {
					idle_heart_rate_progress30 = hmUI.createWidget(hmUI.widget.ARC, {
						enable: false,
					});
				}

				idle_img31 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 111,
					y: 200,
					w: 79,
					h: 79,
					src: '0045.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_rotary33 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 241,
					center_y: 240,
					pos_x: 227,
					pos_y: 114,
					src: '0046.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_rotary34 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 241,
					center_y: 240,
					pos_x: 228,
					pos_y: 44,
					src: '0047.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_second_rotary35 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 241,
					center_y: 239,
					pos_x: 237,
					pos_y: 29,
					src: '0048.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateTime() {
					if (normal_hour_rotary14) {
						normal_hour_rotary14.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (normal_minute_rotary15) {
						normal_minute_rotary15.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
					if (normal_second_rotary16) {
						normal_second_rotary16.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.second * (6 * 1))));
					}
					if (idle_hour_rotary33) {
						idle_hour_rotary33.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (idle_minute_rotary34) {
						idle_minute_rotary34.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
					if (idle_second_rotary35) {
						idle_second_rotary35.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.second * (6 * 1))));
					}
				}

				function updateBattery() {
					var current_normal_battery_progress9 = batterySensor.current;
					var target_normal_battery_progress9 = 100;
					var progress_normal_battery_progress9 = current_normal_battery_progress9 / target_normal_battery_progress9;

					if (progress_normal_battery_progress9 > 1) {
						progress_normal_battery_progress9 = 1;
					}

					var pcs_normal_battery_progress9 = progress_normal_battery_progress9;

					if (screenType != hmSetting.screen_type.AOD) {
						// initial parameters
						var sa_normal_battery_progress9 = -180;
						var ea_normal_battery_progress9 = 0;
						var cx_normal_battery_progress9 = 150;
						var cy_normal_battery_progress9 = 240;
						var r_normal_battery_progress9 = 38;
						var lw_normal_battery_progress9 = 12;
						var c_normal_battery_progress9 = 0xFF00E5FF;

						// calculated parameters
						var ax_normal_battery_progress9 = cx_normal_battery_progress9 - r_normal_battery_progress9;
						var ay_normal_battery_progress9 = cy_normal_battery_progress9 - r_normal_battery_progress9;
						var cw_normal_battery_progress9 = 2 * r_normal_battery_progress9;
						var ao_normal_battery_progress9 = ea_normal_battery_progress9 - sa_normal_battery_progress9;
						ao_normal_battery_progress9 = ao_normal_battery_progress9 * pcs_normal_battery_progress9;
						var ea_normal_battery_progress9_draw = sa_normal_battery_progress9 + ao_normal_battery_progress9;

						normal_battery_progress9.setProperty(hmUI.prop.MORE, {
							x: ax_normal_battery_progress9,
							y: ay_normal_battery_progress9,
							w: cw_normal_battery_progress9,
							h: cw_normal_battery_progress9,
							start_angle: sa_normal_battery_progress9,
							end_angle: ea_normal_battery_progress9_draw,
							color: c_normal_battery_progress9,
							line_width: lw_normal_battery_progress9,
						});
					};

					var current_idle_battery_progress28 = batterySensor.current;
					var target_idle_battery_progress28 = 100;
					var progress_idle_battery_progress28 = current_idle_battery_progress28 / target_idle_battery_progress28;

					if (progress_idle_battery_progress28 > 1) {
						progress_idle_battery_progress28 = 1;
					}

					var pcs_idle_battery_progress28 = progress_idle_battery_progress28;

					if (screenType == hmSetting.screen_type.AOD) {
						// initial parameters
						var sa_idle_battery_progress28 = -180;
						var ea_idle_battery_progress28 = 0;
						var cx_idle_battery_progress28 = 150;
						var cy_idle_battery_progress28 = 240;
						var r_idle_battery_progress28 = 38;
						var lw_idle_battery_progress28 = 12;
						var c_idle_battery_progress28 = 0xFF00E5FF;

						// calculated parameters
						var ax_idle_battery_progress28 = cx_idle_battery_progress28 - r_idle_battery_progress28;
						var ay_idle_battery_progress28 = cy_idle_battery_progress28 - r_idle_battery_progress28;
						var cw_idle_battery_progress28 = 2 * r_idle_battery_progress28;
						var ao_idle_battery_progress28 = ea_idle_battery_progress28 - sa_idle_battery_progress28;
						ao_idle_battery_progress28 = ao_idle_battery_progress28 * pcs_idle_battery_progress28;
						var ea_idle_battery_progress28_draw = sa_idle_battery_progress28 + ao_idle_battery_progress28;

						idle_battery_progress28.setProperty(hmUI.prop.MORE, {
							x: ax_idle_battery_progress28,
							y: ay_idle_battery_progress28,
							w: cw_idle_battery_progress28,
							h: cw_idle_battery_progress28,
							start_angle: sa_idle_battery_progress28,
							end_angle: ea_idle_battery_progress28_draw,
							color: c_idle_battery_progress28,
							line_width: lw_idle_battery_progress28,
						});
					};

				}

				function updateHeart() {
					var current_normal_heart_rate_progress11 = heartSensor.last - 71;
					var target_normal_heart_rate_progress11 = 108;
					var progress_normal_heart_rate_progress11 = current_normal_heart_rate_progress11 / target_normal_heart_rate_progress11;

					if (progress_normal_heart_rate_progress11 > 1) {
						progress_normal_heart_rate_progress11 = 1;
					}

					var pcs_normal_heart_rate_progress11 = progress_normal_heart_rate_progress11;

					if (screenType != hmSetting.screen_type.AOD) {
						// initial parameters
						var sa_normal_heart_rate_progress11 = -180;
						var ea_normal_heart_rate_progress11 = -360;
						var cx_normal_heart_rate_progress11 = 150;
						var cy_normal_heart_rate_progress11 = 239;
						var r_normal_heart_rate_progress11 = 38;
						var lw_normal_heart_rate_progress11 = 12;
						var c_normal_heart_rate_progress11 = 0xFFFF0000;

						// calculated parameters
						var ax_normal_heart_rate_progress11 = cx_normal_heart_rate_progress11 - r_normal_heart_rate_progress11;
						var ay_normal_heart_rate_progress11 = cy_normal_heart_rate_progress11 - r_normal_heart_rate_progress11;
						var cw_normal_heart_rate_progress11 = 2 * r_normal_heart_rate_progress11;
						var ao_normal_heart_rate_progress11 = ea_normal_heart_rate_progress11 - sa_normal_heart_rate_progress11;
						ao_normal_heart_rate_progress11 = ao_normal_heart_rate_progress11 * pcs_normal_heart_rate_progress11;
						var ea_normal_heart_rate_progress11_draw = sa_normal_heart_rate_progress11 + ao_normal_heart_rate_progress11;

						normal_heart_rate_progress11.setProperty(hmUI.prop.MORE, {
							x: ax_normal_heart_rate_progress11,
							y: ay_normal_heart_rate_progress11,
							w: cw_normal_heart_rate_progress11,
							h: cw_normal_heart_rate_progress11,
							start_angle: sa_normal_heart_rate_progress11,
							end_angle: ea_normal_heart_rate_progress11_draw,
							color: c_normal_heart_rate_progress11,
							line_width: lw_normal_heart_rate_progress11,
						});
					};

					var current_idle_heart_rate_progress30 = heartSensor.last - 71;
					var target_idle_heart_rate_progress30 = 108;
					var progress_idle_heart_rate_progress30 = current_idle_heart_rate_progress30 / target_idle_heart_rate_progress30;

					if (progress_idle_heart_rate_progress30 > 1) {
						progress_idle_heart_rate_progress30 = 1;
					}

					var pcs_idle_heart_rate_progress30 = progress_idle_heart_rate_progress30;

					if (screenType == hmSetting.screen_type.AOD) {
						// initial parameters
						var sa_idle_heart_rate_progress30 = -180;
						var ea_idle_heart_rate_progress30 = -360;
						var cx_idle_heart_rate_progress30 = 150;
						var cy_idle_heart_rate_progress30 = 239;
						var r_idle_heart_rate_progress30 = 38;
						var lw_idle_heart_rate_progress30 = 12;
						var c_idle_heart_rate_progress30 = 0xFFFF0000;

						// calculated parameters
						var ax_idle_heart_rate_progress30 = cx_idle_heart_rate_progress30 - r_idle_heart_rate_progress30;
						var ay_idle_heart_rate_progress30 = cy_idle_heart_rate_progress30 - r_idle_heart_rate_progress30;
						var cw_idle_heart_rate_progress30 = 2 * r_idle_heart_rate_progress30;
						var ao_idle_heart_rate_progress30 = ea_idle_heart_rate_progress30 - sa_idle_heart_rate_progress30;
						ao_idle_heart_rate_progress30 = ao_idle_heart_rate_progress30 * pcs_idle_heart_rate_progress30;
						var ea_idle_heart_rate_progress30_draw = sa_idle_heart_rate_progress30 + ao_idle_heart_rate_progress30;

						idle_heart_rate_progress30.setProperty(hmUI.prop.MORE, {
							x: ax_idle_heart_rate_progress30,
							y: ay_idle_heart_rate_progress30,
							w: cw_idle_heart_rate_progress30,
							h: cw_idle_heart_rate_progress30,
							start_angle: sa_idle_heart_rate_progress30,
							end_angle: ea_idle_heart_rate_progress30_draw,
							color: c_idle_heart_rate_progress30,
							line_width: lw_idle_heart_rate_progress30,
						});
					};

				}

				function updateWeather() {
					normal_current_city_text7.setProperty(hmUI.prop.TEXT, weatherSensor.getForecastWeather().cityName);
					idle_current_city_text26.setProperty(hmUI.prop.TEXT, weatherSensor.getForecastWeather().cityName);
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				batterySensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateBattery();
				});

				heartSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateHeart();
				});

				weatherSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateWeather();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						updateBattery();
						updateHeart();
						updateWeather();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}