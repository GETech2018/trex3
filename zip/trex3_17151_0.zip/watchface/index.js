﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let Button_Switch_BG_Color = ''

        let bgColorIndex = 0;
        let bgColorList = [0xFFFF8000, 0xFFFF0000, 0xFF80FF80, 0xFF0080FF, 0xFF808000, 0xFF0000FF, 0xFF808080, 0xFF00FFFF, 0xFF8000FF, 0xFFFFFF00, 0xFFFFFFFF, 0xFF000000];
        let bgColorToastList = ['Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region SwitchBG_Color
            console.log('SwitchBG_Color');
            function switchBG_Color() {
              bgColorIndex++;
              if (bgColorIndex >= bgColorList.length) bgColorIndex = 0;
              hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
              let toastText = bgColorToastList[bgColorIndex].replace('%s', `${bgColorIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
              vibro(28);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFF8000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Quadrante_00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 384,
              font_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              padding: false,
              h_space: 6,
              invalid_image: 'Sistema_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 87,
              font_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              padding: false,
              h_space: 6,
              unit_sc: 'Sistema_10.png',
              unit_tc: 'Sistema_10.png',
              unit_en: 'Sistema_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 297,
              y: 338,
              font_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              padding: false,
              h_space: 6,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 120,
              y: 384,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_14n.png","w_1n.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 101,
              y: 354,
              font_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              padding: false,
              h_space: 6,
              unit_sc: 'Sistema_13.png',
              unit_tc: 'Sistema_13.png',
              unit_en: 'Sistema_13.png',
              imperial_unit_sc: 'Sistema_13.png',
              imperial_unit_tc: 'Sistema_13.png',
              imperial_unit_en: 'Sistema_13.png',
              negative_image: 'Sistema_11.png',
              invalid_image: 'Sistema_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 101,
                y: 354,
                font_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
                padding: false,
                h_space: 6,
                unit_sc: 'Sistema_13.png',
                unit_tc: 'Sistema_13.png',
                unit_en: 'Sistema_13.png',
                imperial_unit_sc: 'Sistema_13.png',
                imperial_unit_tc: 'Sistema_13.png',
                imperial_unit_en: 'Sistema_13.png',
                negative_image: 'Sistema_11.png',
                invalid_image: 'Sistema_12.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 145,
              month_startY: 91,
              month_sc_array: ["Mesi_00.png","Mesi_01.png","Mesi_02.png","Mesi_03.png","Mesi_04.png","Mesi_05.png","Mesi_06.png","Mesi_07.png","Mesi_08.png","Mesi_09.png","Mesi_10.png","Mesi_11.png"],
              month_tc_array: ["Mesi_00.png","Mesi_01.png","Mesi_02.png","Mesi_03.png","Mesi_04.png","Mesi_05.png","Mesi_06.png","Mesi_07.png","Mesi_08.png","Mesi_09.png","Mesi_10.png","Mesi_11.png"],
              month_en_array: ["Mesi_00.png","Mesi_01.png","Mesi_02.png","Mesi_03.png","Mesi_04.png","Mesi_05.png","Mesi_06.png","Mesi_07.png","Mesi_08.png","Mesi_09.png","Mesi_10.png","Mesi_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 75,
              day_startY: 91,
              day_sc_array: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png","Giorno_08.png","Giorno_09.png"],
              day_tc_array: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png","Giorno_08.png","Giorno_09.png"],
              day_en_array: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png","Giorno_08.png","Giorno_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 163,
              y: 33,
              week_en: ["Giorni_00.png","Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png"],
              week_tc: ["Giorni_00.png","Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png"],
              week_sc: ["Giorni_00.png","Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 197,
              y: 427,
              src: 'Off_00.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 242,
              y: 427,
              src: 'Sveglia_00.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 162,
              hour_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_unit_sc: 'Ore_10.png',
              hour_unit_tc: 'Ore_10.png',
              hour_unit_en: 'Ore_10.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 252,
              minute_startY: 145,
              minute_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFFFF8000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Quadrante_00.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 384,
              font_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              padding: false,
              h_space: 6,
              invalid_image: 'Sistema_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 292,
              y: 87,
              font_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              padding: false,
              h_space: 6,
              unit_sc: 'Sistema_10.png',
              unit_tc: 'Sistema_10.png',
              unit_en: 'Sistema_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 297,
              y: 338,
              font_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              padding: false,
              h_space: 6,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 120,
              y: 384,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_14n.png","w_1n.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 101,
              y: 354,
              font_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
              padding: false,
              h_space: 6,
              unit_sc: 'Sistema_13.png',
              unit_tc: 'Sistema_13.png',
              unit_en: 'Sistema_13.png',
              imperial_unit_sc: 'Sistema_13.png',
              imperial_unit_tc: 'Sistema_13.png',
              imperial_unit_en: 'Sistema_13.png',
              negative_image: 'Sistema_11.png',
              invalid_image: 'Sistema_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 101,
                y: 354,
                font_array: ["Sistema_00.png","Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png"],
                padding: false,
                h_space: 6,
                unit_sc: 'Sistema_13.png',
                unit_tc: 'Sistema_13.png',
                unit_en: 'Sistema_13.png',
                imperial_unit_sc: 'Sistema_13.png',
                imperial_unit_tc: 'Sistema_13.png',
                imperial_unit_en: 'Sistema_13.png',
                negative_image: 'Sistema_11.png',
                invalid_image: 'Sistema_12.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 145,
              month_startY: 91,
              month_sc_array: ["Mesi_00.png","Mesi_01.png","Mesi_02.png","Mesi_03.png","Mesi_04.png","Mesi_05.png","Mesi_06.png","Mesi_07.png","Mesi_08.png","Mesi_09.png","Mesi_10.png","Mesi_11.png"],
              month_tc_array: ["Mesi_00.png","Mesi_01.png","Mesi_02.png","Mesi_03.png","Mesi_04.png","Mesi_05.png","Mesi_06.png","Mesi_07.png","Mesi_08.png","Mesi_09.png","Mesi_10.png","Mesi_11.png"],
              month_en_array: ["Mesi_00.png","Mesi_01.png","Mesi_02.png","Mesi_03.png","Mesi_04.png","Mesi_05.png","Mesi_06.png","Mesi_07.png","Mesi_08.png","Mesi_09.png","Mesi_10.png","Mesi_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 75,
              day_startY: 91,
              day_sc_array: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png","Giorno_08.png","Giorno_09.png"],
              day_tc_array: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png","Giorno_08.png","Giorno_09.png"],
              day_en_array: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png","Giorno_08.png","Giorno_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 163,
              y: 33,
              week_en: ["Giorni_00.png","Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png"],
              week_tc: ["Giorni_00.png","Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png"],
              week_sc: ["Giorni_00.png","Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 197,
              y: 427,
              src: 'Off_00.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 242,
              y: 427,
              src: 'Sveglia_00.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 40,
              hour_startY: 162,
              hour_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_angle: 0,
              hour_unit_sc: 'Ore_10.png',
              hour_unit_tc: 'Ore_10.png',
              hour_unit_en: 'Ore_10.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 252,
              minute_startY: 145,
              minute_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.SwitchBG_Color');
            // Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.SwitchBG_Color, {
              // x: 193,
              // y: 203,
              // w: 100,
              // h: 100,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: 'Tasto_00.png',
              // normal_src: 'Tasto_00.png',
              // color_list: 0xFFFF8000|0xFFFF0000|0xFF80FF80|0xFF0080FF|0xFF808000|0xFF0000FF|0xFF808080|0xFF00FFFF|0xFF8000FF|0xFFFFFF00|0xFFFFFFFF|0xFF000000,
              // toast_list: Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s,
              // use_crown: False,
              // use_in_AOD: True,
              // vibro: True,
            // });

            Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 193,
              y: 203,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Tasto_00.png',
              normal_src: 'Tasto_00.png',
              click_func: (button_widget) => {
                switchBG_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                //SwitchBgColor
                if (hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`) === undefined) {
                  bgColorIndex = 0;
                  hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
                } else {
                  bgColorIndex = hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg) normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
                if (screenType == hmSetting.screen_type.AOD && idle_background_bg) idle_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}