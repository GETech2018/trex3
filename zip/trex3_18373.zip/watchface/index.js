﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_year_text_font = ''
        let normal_day_month_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_humidity_image_progress_img_level = ''
        let normal_widget_text_1 = ''
        let normal_widget_text_2 = ''
        let normal_widget_text_4 = ''
        let normal_widget_text_5 = ''
        let normal_widget_text_7 = ''
        let normal_widget_text_8 = ''
        let normal_widget_text_9 = ''
        let normal_widget_text_10 = ''
        let normal_widget_text_11 = ''
        let normal_widget_text_13 = ''
        let normal_widget_text_14 = ''
        let normal_widget_text_15 = ''
        let normal_widget_text_17 = ''
        let normal_bio_charge_image_progress_img_level = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_time_hour_text_font = ''
        let normal_time_minute_text_font = ''
        let normal_time_second_text_font = ''
        let normal_wind_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_widget_text_6 = ''
        let idle_widget_text_8 = ''
        let idle_widget_text_15 = ''
        let idle_bio_charge_image_progress_img_level = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_time_hour_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_time_minute_text_font = ''
        let idle_time_second_text_font = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: UAFSans-OnBoardStencil.ttf; FontSize: 37
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 486,
              h: 52,
              text_size: 37,
              char_space: 0,
              line_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: UAFSans-OnBoardStencil.ttf; FontSize: 20; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 24,
              h: 24,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: UAFSans-OnBoardStencil.ttf; FontSize: 33
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 433,
              h: 46,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: UAFSans-OnBoardStencil.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 392,
              h: 43,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: UAFSans-OnBoardStencil.ttf; FontSize: 16
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 210,
              h: 22,
              text_size: 16,
              char_space: 0,
              line_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: UAFSans-OnBoardStencil.ttf; FontSize: 17
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 225,
              h: 25,
              text_size: 17,
              char_space: 0,
              line_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: UAFSans-OnBoardStencil.ttf; FontSize: 21
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 279,
              h: 30,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: UAFSans-OnBoardStencil.ttf; FontSize: 145
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1756,
              h: 208,
              text_size: 145,
              char_space: -5,
              line_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: UAFSans-OnBoardStencil.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 526,
              h: 57,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: UAFSans-OnBoardStencil.ttf; FontSize: 150
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 1820,
              h: 216,
              text_size: 150,
              char_space: -5,
              line_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'BG_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'Asset 77.png',
              // center_x: 129,
              // center_y: 298,
              // x: 7,
              // y: 23,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //#region Compass_Pointer
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 129 - 7,
              pos_y: 298 - 23,
              center_x: 129,
              center_y: 298,
              src: 'Asset 77.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //#endregion

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_year_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 82,
              y: 195,
              w: 150,
              h: 40,
              text_size: 37,
              char_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 251,
              y: 195,
              w: 150,
              h: 49,
              text_size: 37,
              char_space: -1,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              // padding: true,
              // unit_string: .,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 169,
              y: 84,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              // unit_type: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 326,
              y: 249,
              image_array: ["W052.png","W053.png","W054.png","W055.png","W056.png","W057.png","W058.png","W059.png","W060.png","W061.png","W062.png","W063.png","W064.png","W065.png","W066.png","W067.png","W068.png","W069.png","W070.png","W071.png","W072.png","W073.png","W074.png","W075.png","W076.png","W077.png","W078.png","W079.png","W080.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 233,
              y: 302,
              w: 150,
              h: 40,
              text_size: 33,
              char_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Asset 60.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 6,
              second_posY: 235,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 46,
              y: 45,
              image_array: ["Asset 49.png","Asset 50.png","Asset 51.png","Asset 52.png","Asset 53.png","Asset 54.png","Asset 55.png","Asset 56.png","Asset 57.png","Asset 58.png"],
              image_length: 10,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 24,
              y: 24,
              w: 432,
              h: 432,
              text_size: 30,
              char_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              // use_text_circle: true,
              start_angle: 283,
              end_angle: 355,
              mode: 0,
              // radius: 216,
              align_h: hmUI.align.LEFT,
              text: '0',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 124,
              y: 246,
              w: 180,
              h: 180,
              text_size: 16,
              char_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.LEFT,
              text: 'N',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 24,
              y: 24,
              w: 432,
              h: 432,
              text_size: 30,
              char_space: -3,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              // use_text_circle: true,
              start_angle: 194,
              end_angle: 355,
              mode: 0,
              // radius: 216,
              align_h: hmUI.align.LEFT,
              text: '0',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_5 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 24,
              y: 24,
              w: 432,
              h: 432,
              text_size: 30,
              char_space: -3,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              // use_text_circle: true,
              start_angle: 284,
              end_angle: 357,
              mode: 0,
              // radius: 216,
              align_h: hmUI.align.RIGHT,
              text: '100',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_7 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 22,
              y: 22,
              w: 436,
              h: 436,
              text_size: 30,
              char_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              // use_text_circle: true,
              start_angle: 254,
              end_angle: 277,
              mode: 1,
              // radius: 218,
              align_h: hmUI.align.RIGHT,
              text: '10+',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_8 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 24,
              y: 24,
              w: 432,
              h: 432,
              text_size: 30,
              char_space: -3,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              // use_text_circle: true,
              start_angle: 284,
              end_angle: 378,
              mode: 0,
              // radius: 216,
              align_h: hmUI.align.RIGHT,
              text: '100',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_9 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 24,
              y: 24,
              w: 432,
              h: 432,
              text_size: 30,
              char_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              // use_text_circle: true,
              start_angle: 88,
              end_angle: 388,
              mode: 1,
              // radius: 216,
              align_h: hmUI.align.RIGHT,
              text: '100%',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_10 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 24,
              y: 24,
              w: 432,
              h: 432,
              text_size: 30,
              char_space: -3,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              // use_text_circle: true,
              start_angle: 284,
              end_angle: 439,
              mode: 0,
              // radius: 216,
              align_h: hmUI.align.RIGHT,
              text: '0',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_11 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 24,
              y: 27,
              w: 432,
              h: 432,
              text_size: 30,
              char_space: -3,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              // use_text_circle: true,
              start_angle: 287,
              end_angle: 529,
              mode: 0,
              // radius: 216,
              align_h: hmUI.align.RIGHT,
              text: '0',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_13 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 54,
              y: 54,
              w: 372,
              h: 372,
              text_size: 17,
              char_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              // use_text_circle: true,
              start_angle: 305,
              end_angle: 322,
              mode: 0,
              // radius: 186,
              align_h: hmUI.align.CENTER_H,
              text: 'БІО',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_14 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 45,
              y: 45,
              w: 390,
              h: 390,
              text_size: 21,
              char_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              // use_text_circle: true,
              start_angle: 220,
              end_angle: 325,
              mode: 1,
              // radius: 195,
              align_h: hmUI.align.RIGHT,
              text: 'ВІТЕР',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_15 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 45,
              y: 45,
              w: 390,
              h: 390,
              text_size: 21,
              char_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              // use_text_circle: true,
              start_angle: 124,
              end_angle: 325,
              mode: 1,
              // radius: 195,
              align_h: hmUI.align.RIGHT,
              text: 'ВОЛ.',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_17 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 55,
              y: 55,
              w: 370,
              h: 370,
              text_size: 17,
              char_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              // use_text_circle: true,
              start_angle: 391,
              end_angle: 421,
              mode: 0,
              // radius: 185,
              align_h: hmUI.align.CENTER_H,
              text: 'БАТАРЕЯ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 52,
              y: 51,
              image_array: ["Asset 12.png","Asset 13.png","Asset 14.png","Asset 15.png","Asset 16.png","Asset 17.png","Asset 18.png","Asset 19.png","Asset 20.png","Asset 21.png"],
              image_length: 10,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 43,
              y: 51,
              image_array: ["Asset 22.png","Asset 23.png","Asset 24.png","Asset 25.png","Asset 26.png","Asset 27.png","Asset 28.png","Asset 29.png","Asset 30.png","Asset 31.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 56,
              y: 59,
              week_en: ["Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png"],
              week_tc: ["Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png"],
              week_sc: ["Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 142,
              y: 92,
              w: 201,
              h: 200,
              text_size: 145,
              char_space: -5,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 142,
              y: 221,
              w: 201,
              h: 200,
              text_size: 145,
              char_space: -5,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 358,
              w: 150,
              h: 40,
              text_size: 40,
              char_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              color: 0xFFFF8148,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 45,
              y: 43,
              image_array: ["Asset 32.png","Asset 33.png","Asset 34.png","Asset 35.png","Asset 36.png","Asset 37.png","Asset 38.png","Asset 39.png","Asset 40.png","Asset 41.png"],
              image_length: 10,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 128,
              y: 146,
              src: 'BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 324,
              y: 144,
              src: 'Asset 81.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'BG_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Asset 60.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 6,
              second_posY: 235,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_6 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 24,
              y: 24,
              w: 432,
              h: 432,
              text_size: 30,
              char_space: -3,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              alpha: 125,
              color: 0xFFFF8148,
              // use_text_circle: true,
              start_angle: 284,
              end_angle: 378,
              mode: 0,
              // radius: 216,
              align_h: hmUI.align.RIGHT,
              text: '100',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_8 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 24,
              y: 24,
              w: 432,
              h: 432,
              text_size: 30,
              char_space: -3,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              alpha: 125,
              color: 0xFFFF8148,
              // use_text_circle: true,
              start_angle: 284,
              end_angle: 439,
              mode: 0,
              // radius: 216,
              align_h: hmUI.align.RIGHT,
              text: '0',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_15 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 55,
              y: 55,
              w: 370,
              h: 370,
              text_size: 17,
              char_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              alpha: 125,
              color: 0xFFFF8148,
              // use_text_circle: true,
              start_angle: 391,
              end_angle: 421,
              mode: 0,
              // radius: 185,
              align_h: hmUI.align.CENTER_H,
              text: 'БАТАРЕЯ',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 52,
              y: 51,
              image_array: ["Asset 12.png","Asset 13.png","Asset 14.png","Asset 15.png","Asset 16.png","Asset 17.png","Asset 18.png","Asset 19.png","Asset 20.png","Asset 21.png"],
              image_length: 10,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 43,
              y: 51,
              image_array: ["Asset 22.png","Asset 23.png","Asset 24.png","Asset 25.png","Asset 26.png","Asset 27.png","Asset 28.png","Asset 29.png","Asset 30.png","Asset 31.png"],
              image_length: 10,
              // alpha: 125,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level.setAlpha(125);

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 56,
              y: 59,
              week_en: ["Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png"],
              week_tc: ["Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png"],
              week_sc: ["Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png"],
              // alpha: 125,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img.setAlpha(125);

            idle_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 142,
              y: 91,
              w: 201,
              h: 200,
              text_size: 150,
              char_space: -5,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              alpha: 125,
              color: 0xFFFF8148,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 142,
              y: 221,
              w: 201,
              h: 200,
              text_size: 150,
              char_space: -5,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              alpha: 125,
              color: 0xFFFF8148,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 358,
              w: 150,
              h: 40,
              text_size: 40,
              char_space: 0,
              font: 'fonts/UAFSans-OnBoardStencil.ttf',
              alpha: 125,
              color: 0xFFFF8148,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Bluetooth disconnected,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth connected,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth disconnected"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth connected"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 314,
              y: 198,
              w: 92,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 319,
              y: 140,
              w: 47,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 78,
              y: 198,
              w: 92,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 214,
              y: 366,
              w: 51,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 198,
              y: 253,
              w: 99,
              h: 105,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 198,
              y: 123,
              w: 99,
              h: 105,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('year font');
              if (updateHour) {
                let normal_yearStr = timeSensor.year.toString();
                normal_year_text_font.setProperty(hmUI.prop.TEXT, normal_yearStr );
              };

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '.' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '.' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
              console.log('hour font');
              if (updateHour) {
                let idle_hourStr = format_hour.toString();
                idle_hourStr = idle_hourStr.padStart(2, '0');
                idle_time_hour_text_font.setProperty(hmUI.prop.TEXT, idle_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let idle_minuteStr = minute.toString();
                idle_minuteStr = idle_minuteStr.padStart(2, '0');
                idle_time_minute_text_font.setProperty(hmUI.prop.TEXT, idle_minuteStr );
              };

              console.log('second font');
                let idle_secondStr = second.toString();
                idle_secondStr = idle_secondStr.padStart(2, '0');
                idle_time_second_text_font.setProperty(hmUI.prop.TEXT, idle_secondStr );
            };

            //#endregion
            //#region compass_update
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

                }

              }); // Listener end

            };
            //#endregion

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_cityNameStr = normal_cityNameStr.toUpperCase();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}