﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 5

        let lastProcessedMinute = -1;
        // Sleep / zodiac / day caches
        let sleep = null;
        let cachedSleepText = "00:00";
        let lastSleepDate = null;
        let lastShownSleepText = "--";
        let sleep_time_txt = null;
        let lastTotalMinutes = 0;
        let lastSleepUpdateMs = 0;
        const SLEEP_THROTTLE_MS = 15 * 60 * 1000;                 
        //   
        // Pressure file unified path
        const PRESSURE_FILE_PATH = "../../../baro_altim/pressure.dat";
        let lastPressureFileTime = 0;
        let lastPressureText = "--";
        let lastPressureUpdateMs = 0;
        const PRESSURE_THROTTLE_MS = 5 * 60 * 1000;
        let text_pressure = null;
        let lastPressureValue = 0;                
        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_image_progress_img_level = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_icon_img = ''
        
        let normal_battery_current_text_font = ''        
        let normal_step_current_text_font = ''
        let normal_sun_icon_img = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_calorie_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_readiness_current_text_font = ''
        let normal_distance_current_text_font = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_wind_current_text_font = ''
        let normal_humidity_current_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_battery_image_progress_img_level = ''
        let idle_step_image_progress_img_level = ''
        let idle_image_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        
        let idle_battery_current_text_font = ''
        
        let idle_step_current_text_font = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_readiness_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = '';

            // --------------------
            // Pressure read/update v2.0
            // --------------------
            function read_last_pressure() {
                try {
                    const [fs_stat, err] = hmFS.stat(PRESSURE_FILE_PATH);
                    if (err !== 0 || fs_stat.size < 4) return null;
                    
                    const fh = hmFS.open(PRESSURE_FILE_PATH, hmFS.O_RDONLY);
                    hmFS.seek(fh, -4, hmFS.SEEK_END);
                    
                    const buffer = new ArrayBuffer(4);
                    const readBytes = hmFS.read(fh, buffer, 0, 4);
                    hmFS.close(fh);
                    
                    if (readBytes !== 4) return (lastPressureValue || null);
                    
                    const view = new DataView(buffer);
                    const rawValue = view.getFloat32(0, true); 
                    
                    if (rawValue <= 0) return (lastPressureValue || null); 
                    
                    const hPa = Math.round(rawValue / 100);
                    lastPressureValue = hPa; 
                    
                    return hPa;
                } catch (e) {
                    console.log("Pressure read error:", e);
                    return (lastPressureValue || null);
                }
            }

            function updatePressure(force = false) {
                const now = Date.now();
                if (!force && (now - lastPressureUpdateMs) < PRESSURE_THROTTLE_MS) return;
                
                try {
                    const [stat, err] = hmFS.stat(PRESSURE_FILE_PATH);
                    if (err !== 0 || !stat) {
                        setPressureText("--");
                        lastPressureUpdateMs = now;
                        return;
                    }
                    
                    if (stat.mtime === lastPressureFileTime && !force) {
                        lastPressureUpdateMs = now;
                        return;
                    }
                    
                    const hPa = read_last_pressure(); 
                    
                    let mmHg;
                    if (!hPa || hPa < 300) {
                        mmHg = "--";
                    } else {
                        mmHg = Math.round(hPa * 0.750064) + " ";
                        lastPressureValue = hPa; 
                    }
                    
                    setPressureText(mmHg);
                    
                    lastPressureFileTime = stat.mtime;
                    lastPressureUpdateMs = now;
                } catch (e) {
                    setPressureText("--");
                }
            }

            function setPressureText(val) {
                if (val !== lastPressureText) {
                    text_pressure.setProperty(hmUI.prop.TEXT, val);
                    lastPressureText = val;
                }
            }
            // -------------
            // Sleep helpers 1.1
            // -------------
            try {
                sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
                sleep.onSleepStateChange = () => {
                    if (sleep.state === hmSensor.sleep_state.END) {
                        calculateAndCacheRealSleep(true);
                    }
                };

            } catch (e) {
                console.log("Sleep sensor init failed:", e);
                sleep = null;
            }
            function formatMinutes(mins) {
                if (!mins || mins <= 0) return "00:00";

                const h = Math.floor(mins / 60);
                const m = mins % 60;
                return String(h).padStart(2, "0") + ":" + String(m).padStart(2, "0");
            }
            function calculateAndCacheRealSleep(force = false) {
                if (!sleep) {
                    cachedSleepText = "00:00";
                    updateSleepText();
                    return;
                }
                
                try {
                    const now = Date.now();
                    const today = new Date().toDateString();
                    
                    if (!force && (now - lastSleepUpdateMs < SLEEP_THROTTLE_MS) && lastSleepDate === today) {
                        updateSleepText();
                        return;
                    }

                    let currentTotal = sleep.getTotalTime();
                    
                    if (!force && lastSleepDate === today && currentTotal === lastTotalMinutes) {
                        lastSleepUpdateMs = now;
                        updateSleepText();
                        return;
                    }

                    sleep.updateInfo();
                    currentTotal = sleep.getTotalTime();

                    const info = sleep.getBasicInfo();
                    if (!info || info.startTime === 0 || currentTotal <= 0) {
                        cachedSleepText = "00:00";
                        lastTotalMinutes = 0;
                        updateSleepText();
                        return;
                    }

                    let totalMinutes = currentTotal;

                    if (totalMinutes > 1080) totalMinutes = 0;

                    if (totalMinutes > 90) {
                        try {
                            const stages = sleep.getSleepStageData();
                            const model = sleep.getSleepStageModel();
                            let wakeMinutes = 0;
                            for (let i = 0, len = stages.length; i < len; i++) {
                                const st = stages[i];
                                if (st.model === model.WAKE_STAGE) {
                                    wakeMinutes += (st.stop + 1 - st.start);
                                }
                            }
                            totalMinutes -= wakeMinutes;
                        } catch (e) {}
                    }

                    cachedSleepText = formatMinutes(totalMinutes);
                    lastSleepDate = today;
                    lastTotalMinutes = currentTotal;
                    lastSleepUpdateMs = now;
                    updateSleepText();
                } catch (e) {
                    console.log("calculateAndCacheRealSleep error:", e);
                    cachedSleepText = "00:00";
                    updateSleepText();
                }
            }
            function updateSleepText() {
                if (!sleep_time_txt) return;
                if (hmSetting.getScreenType() === hmSetting.screen_type.AOD) return;
                if (lastShownSleepText !== cachedSleepText) {
                    try {
                        sleep_time_txt.setProperty(hmUI.prop.TEXT, cachedSleepText);
                    } catch (e) { }
                    lastShownSleepText = cachedSleepText;
                }
            }    
            
            


            function click_Bezel() {
              if(bezel_num>=bezel_all) {bezel_num=1;}
              else { bezel_num=bezel_num+1;}
              hmUI.showToast({text: "Цвет " + parseInt(bezel_num) });
                normal_background_bg_img.setProperty(hmUI.prop.SRC, "osn_" + parseInt(bezel_num) + ".png");
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "sekk_" + parseInt(bezel_num) + ".png"); 
            }             

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Roboto-Medium.ttf; FontSize: 29
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 399,
              h: 44,
              text_size: 29,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Roboto-Medium.ttf; FontSize: 20
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 260,
              h: 28,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Roboto-Medium.ttf; FontSize: 25
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 330,
              h: 36,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Roboto-Medium.ttf; FontSize: 20; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 24,
              h: 24,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'am_pm.png',
              am_en_path: 'am_pm.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 177,
              hour_startY: 359,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 246,
              minute_startY: 359,
              minute_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["bt_1.png","bt_2.png","bt_3.png","bt_4.png","bt_5.png","bt_6.png","bt_7.png","bt_8.png","bt_9.png","bt_10.png","bt_11.png","bt_12.png","bt_13.png","bt_14.png","bt_15.png","bt_16.png","bt_17.png","bt_18.png","bt_19.png","bt_20.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });     
            
            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["sh_1.png","sh_2.png","sh_3.png","sh_4.png","sh_5.png","sh_6.png","sh_7.png","sh_8.png","sh_9.png","sh_10.png","sh_11.png","sh_12.png","sh_13.png","sh_14.png","sh_15.png","sh_16.png","sh_17.png","sh_18.png","sh_19.png","sh_20.png"],
              image_length: 20,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 305,
              y: 321,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'text.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 116,
              y: 222,
              w: 150,
              h: 35,
              text_size: 29,
              char_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 219,
              y: 222,
              w: 150,
              h: 35,
              text_size: 29,
              char_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 155,
              y: 322,
              src: 'sleep.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            sleep_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 84,
              y: 320,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              text: "00:00",
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); 
            calculateAndCacheRealSleep(true);              

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 248,
              y: 320,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 289,
              y: 288,
              w: 80,
              h: 30,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 41,
              y: 288,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 116,
              y: 258,
              w: 80,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 219,
              y: 258,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 246,
              month_startY: 79,
              month_sc_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              month_tc_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              month_en_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              month_zero: 1,
              month_space: -1,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 177,
              day_startY: 79,
              day_sc_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              day_tc_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              day_en_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 162,
              y: 52,
              week_en: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_tc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_sc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 255,
              y: 164,
              w: 80,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 231,
              y: 164,
              w: 80,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            text_pressure = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 236,
              y: 133,
              w: 150,
              h: 50,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: "--",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            updatePressure(true);              

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 219,
              y: 138,
              image_array: ["A_0055.png","A_0056.png","A_0057.png","A_0058.png","A_0059.png","A_0060.png","A_0061.png","A_0062.png","A_0063.png","A_0064.png","A_0065.png","A_0066.png","A_0067.png","A_0068.png","A_0069.png","A_0070.png","A_0071.png","A_0072.png","A_0073.png","A_0074.png","A_0075.png","A_0076.png","A_0077.png","A_0078.png","A_0079.png","A_0080.png","A_0081.png","A_0082.png","A_0083.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 180,
              y: 164,
              w: 80,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 87,
              y: 164,
              w: 80,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 135,
              y: 133,
              w: 80,
              h: 50,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 23,
              hour_posY: 218,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minn.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 23,
              minute_posY: 218,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sekk_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 23,
              // y: 218,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 23,
              pos_y: 240 - 218,
              center_x: 240,
              center_y: 240,
              src: 'sekk_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();

            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 246,
              am_y: 403,
              am_sc_path: 'am_pm.png',
              am_en_path: 'am_pm.png',
              pm_x: 204,
              pm_y: 403,
              pm_sc_path: 'am_pm.png',
              pm_en_path: 'am_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 177,
              hour_startY: 359,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 246,
              minute_startY: 359,
              minute_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["bt_1.png","bt_2.png","bt_3.png","bt_4.png","bt_5.png","bt_6.png","bt_7.png","bt_8.png","bt_9.png","bt_10.png","bt_11.png","bt_12.png","bt_13.png","bt_14.png","bt_15.png","bt_16.png","bt_17.png","bt_18.png","bt_19.png","bt_20.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });   
            
            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["sh_1.png","sh_2.png","sh_3.png","sh_4.png","sh_5.png","sh_6.png","sh_7.png","sh_8.png","sh_9.png","sh_10.png","sh_11.png","sh_12.png","sh_13.png","sh_14.png","sh_15.png","sh_16.png","sh_17.png","sh_18.png","sh_19.png","sh_20.png"],
              image_length: 20,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });            

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 232,
              y: 325,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });


            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 116,
              y: 222,
              w: 150,
              h: 35,
              text_size: 29,
              char_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });


            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 219,
              y: 222,
              w: 150,
              h: 35,
              text_size: 29,
              char_space: 0,
              font: 'fonts/Roboto-Medium.ttf',
              color: 0xFF9D9D9D,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 246,
              month_startY: 79,
              month_sc_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              month_tc_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              month_en_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              month_zero: 1,
              month_space: -1,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 177,
              day_startY: 79,
              day_sc_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              day_tc_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              day_en_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              day_zero: 1,
              day_space: -1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 162,
              y: 52,
              week_en: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_tc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_sc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 23,
              hour_posY: 218,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minn.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 23,
              minute_posY: 218,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 299,
              y: 217,
              w: 70,
              h: 45,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 160,
              y: 280,
              w: 45,
              h: 40,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 202,
              w: 60,
              h: 50,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 146,
              y: 135,
              w: 50,
              h: 50,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 285,
              y: 133,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 183,
              y: 360,
              w: 50,
              h: 50,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 248,
              y: 360,
              w: 50,
              h: 50,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 243,
              y: 321,
              w: 60,
              h: 35,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 177,
              y: 321,
              w: 60,
              h: 35,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 105,
              y: 256,
              w: 46,
              h: 40,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 221,
              y: 140,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 82,
              w: 80,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 214,
              y: 214,
              text: '',
              w: 60,
              h: 60,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
              click_Bezel();
              
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);             

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              // Second Pointer
              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              if (normal_analog_clock_pro_second_pointer_img) {                    
                    if (hmSetting.getScreenType() !== hmSetting.screen_type.AOD) {
                        const ms = Date.now() % 1000;
                        const angle = (second * 6) + (ms * 0.006);
                        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, angle);
                    }
              }              

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType === hmSetting.screen_type.WATCHFACE) {
                    if (normal_timerUpdateSec) {
                        timer.stopTimer(normal_timerUpdateSec);
                        normal_timerUpdateSec = undefined;
                    }
                    const delay = 250 - (Date.now() % 250);                         
                    normal_timerUpdateSec = timer.createTimer(
                        delay,
                        250,
                        () => {
                            time_update(false, false); 
                        }
                    );
                } 
                calculateAndCacheRealSleep();
                updatePressure(false); 

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                    if (normal_timerUpdateSec) {
                        timer.stopTimer(normal_timerUpdateSec);
                        normal_timerUpdateSec = undefined;
                    }               
                    if (sleep) {
                        sleep = null;
                    }
                    try {                        
                        lastPressureFileTime = 0;
                        lastPressureText = null;
                        cachedSleepText = "--";
                        lastSleepDate = null;
                        lastShownSleepText = null;
                    } catch (e) {}                                  
                    logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}