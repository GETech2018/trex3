/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_week_imageset2 = '';
		let normal_date_imagecombo3 = '';
		let normal_month_imageset4 = '';
		let normal_heart_current_imagecombo6 = '';
		let normal_distance_imagecombo8 = '';
		let timeInterval;
		let normal_ampm24_imageset10 = '';
		let normal_ampm24_imageset10_array = ['0054.png','0055.png','0056.png'];
		let normal_hour_imagecombo11 = '';
		let normal_minute_imagecombo12 = '';
		let normal_second_imagecombo13 = '';
		let normal_battery_imageset15 = '';
		let normal_steps_imagecombo17 = '';
		let normal_animation19 = '';
		let idle_hour_imagecombo22 = '';
		let idle_minute_imagecombo23 = '';
		let idle_img25 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset2 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 158,
					y: 35,
					week_en: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png"],
					week_tc: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png"],
					week_sc: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo3 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 199,
					day_startY: 206,
					day_sc_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
					day_tc_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
					day_en_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.RIGHT,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset4 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 244,
					month_startY: 206,
					month_sc_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
					month_tc_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
					month_en_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo6 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 92,
					y: 137,
					font_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
					padding: false,
					h_space: 0,
					invalid_image: '0042.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo8 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 325,
					y: 137,
					font_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
					padding: false,
					h_space: 0,
					dot_image: '0053.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_ampm24_imageset10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 125,
					y: 248,
					w: 125,
					h: 248,
					src: '0056.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_imagecombo11 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 75,
					hour_startY: 277,
					hour_array: ["0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.RIGHT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo12 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 195,
					minute_startY: 278,
					minute_array: ["0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo13 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 315,
					second_startY: 277,
					second_array: ["0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imageset15 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 184,
					y: 240,
					image_array: ["0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png"],
					image_length: 11,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo17 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 173,
					y: 379,
					font_array: ["0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_animation19 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
					x: 133,
					y: 367,
					anim_path: '',
					anim_prefix: '1737068454841',
					anim_ext: 'png',
					anim_fps: 20,
					anim_size: 18,
					anim_repeat: true,
					repeat_count: 0,
					anim_status: hmUI.anim_status.START,
					display_on_restart: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});
				idle_hour_imagecombo22 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 104,
					hour_startY: 181,
					hour_array: ["0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.RIGHT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo23 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 258,
					minute_startY: 181,
					minute_array: ["0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 229,
					y: 170,
					w: 21,
					h: 125,
					src: '0126.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateTime() {
					normal_ampm24_imageset10.setProperty(hmUI.prop.MORE, {
						src: normal_ampm24_imageset10_array[(hmSetting.getTimeFormat() == 0 ? (timeSensor.hour >= 0 && timeSensor.hour < 12 ? 0 : 1) : 2)]
					})
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						normal_animation19.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
						updateTime();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						normal_animation19.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
						normal_animation19.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
		},
	});	})()
} catch (e) {
	console.log(e)
}