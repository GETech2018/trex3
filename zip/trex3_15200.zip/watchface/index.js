/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_second_rotary2 = '';
		let timeInterval;
		let normal_img3 = '';
		let normal_heart_rotary5 = '';
		let normal_heart_current_imagecombo6 = '';
		let normal_week_imageset8 = '';
		let normal_date_imagecombo9 = '';
		let normal_calories_imagecombo11 = '';
		let normal_battery_rotary13 = '';
		let normal_steps_imagecombo15 = '';
		let normal_sunrise_text17 = '';
		let normal_img18 = '';
		let normal_sunset_text20 = '';
		let normal_img21 = '';
		let normal_hour_rotary24 = '';
		let normal_minute_rotary25 = '';
		let normal_second_rotary26 = '';
		let idle_img29 = '';
		let idle_hour_rotary31 = '';
		let idle_minute_rotary32 = '';
		let idle_img33 = '';
		let container_1709147062594 = '';
		let container_1709147062594_customs = [
			{
				label: 'Sunrise',
				widgets: [
					'normal_sunrise_text17',
					'normal_img18',
				]
			},
			{
				label: 'Sunset',
				widgets: [
					'normal_sunset_text20',
					'normal_img21',
				]
			},
		];
		let container_1709147062594_selected = 0;
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
				const vibrateSensor = hmSensor.createSensor(hmSensor.id.VIBRATE);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 33,
					pos_y: 33,
					src: '0003.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_rotary5 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0005.png',
					center_x: 143,
					center_y: 185,
					x: 12,
					y: 72,
					start_angle: -136,
					end_angle: 136,
					type: hmUI.data_type.HEART,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo6 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 111,
					y: 164,
					font_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
					padding: false,
					h_space: 0,
					invalid_image: '0016.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset8 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 263,
					y: 112,
					week_en: ["0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
					week_tc: ["0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
					week_sc: ["0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo9 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 312,
					day_startY: 164,
					day_sc_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
					day_tc_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
					day_en_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.CENTER_H,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo11 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 357,
					y: 317,
					font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_rotary13 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0044.png',
					center_x: 240,
					center_y: 354,
					x: 9,
					y: 62,
					start_angle: -149,
					end_angle: 149,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo15 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 194,
					y: 59,
					font_array: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png"],
					padding: true,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sunrise_text17 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 365,
					y: 254,
					w: 103,
					h: 30,
					color: 0x0D0D0D,
					text_size: 30,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Oswald-Medium.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img18 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 353,
					y: 285,
					w: 19,
					h: 19,
					src: '0055.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sunset_text20 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 365,
					y: 254,
					w: 103,
					h: 30,
					color: 0x0F0F0F,
					text_size: 30,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Oswald-Medium.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sunset_text20.setProperty(hmUI.prop.VISIBLE, false);

				normal_img21 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 353,
					y: 285,
					w: 19,
					h: 19,
					src: '0056.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img21.setProperty(hmUI.prop.VISIBLE, false);

				normal_hour_rotary24 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 220,
					pos_y: 105,
					src: '0058.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_rotary25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 220,
					pos_y: 39,
					src: '0059.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary26 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 225,
					pos_y: 6,
					src: '0060.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img29 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0061.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_rotary31 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 220,
					pos_y: 105,
					src: '0058.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_rotary32 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 220,
					pos_y: 39,
					src: '0059.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img33 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 227,
					y: 227,
					w: 27,
					h: 30,
					src: '0062.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				container_1709147062594 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 331,
					y: 239,
					w: 121,
					h: 56,
					src: '0057.png',
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				container_1709147062594.addEventListener(hmUI.event.CLICK_DOWN, (info) => {
					container_1709147062594_selected = (container_1709147062594_selected+1 > container_1709147062594_customs.length-1) ? 0 : container_1709147062594_selected+1;
					for (let w = 0; w < container_1709147062594_customs.length; w++) {
						for (let z of container_1709147062594_customs[w].widgets) {
							eval(z).setProperty(hmUI.prop.VISIBLE, ((w == container_1709147062594_selected) ? true : false));
						}
					}
					hmUI.showToast({
						text: container_1709147062594_customs[container_1709147062594_selected].label.toString() + ' On'
					});
					vibrateSensor.stop();
					vibrateSensor.scene = 25;
					vibrateSensor.start();
				});

				function updateTime() {
					if (normal_second_rotary2) {
						normal_second_rotary2.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.second * (6 * 1))));
					}
					if (normal_hour_rotary24) {
						normal_hour_rotary24.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (normal_minute_rotary25) {
						normal_minute_rotary25.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
					if (normal_second_rotary26) {
						normal_second_rotary26.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.second * (6 * 1))));
					}
					if (idle_hour_rotary31) {
						idle_hour_rotary31.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (idle_minute_rotary32) {
						idle_minute_rotary32.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
				}

				function updateWeather() {
					let tideData = weatherSensor.getForecastWeather().tideData;
					normal_sunrise_text17.setProperty(hmUI.prop.TEXT, tideData.data[0].sunrise.hour.toString().padStart(2, '0') + ':' + tideData.data[0].sunrise.minute.toString().padStart(2, '0'));
					normal_sunset_text20.setProperty(hmUI.prop.TEXT, tideData.data[0].sunset.hour.toString().padStart(2, '0') + ':' + tideData.data[0].sunset.minute.toString().padStart(2, '0'));
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				weatherSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateWeather();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						updateWeather();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}