﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let cc = 0

		let alt_var = 1
        let alt_all = 2
		let alt_text = ' '
		let pressure_array = read_pressure();
        let value = getPressureValue(pressure_array);
		
		let night_var = 1
        let night_all = 2
		let name_text = ' '
		let night_dig = 1
		
		let menu = 1
        let total_menu = 2
		
		let color_r = 1
        let colors_r = 8
		let namecolor_r = ' '
		
		let color_digt = 1
        let all_digt = 6
		let color_text = '0xFFFFFFFF'
		let namecolor_digt = ' '
		
		let color_bg = 7
        let totalcolors_bg = 8
		let namecolor_main = ' '
		
		let visabl_main = 1
		let totalvisabl_main = 5
		
		let xxx_clock_h = 94       
		let yyy_clock_h = 193
		let xxx_clock_m = 223
		let yyy_clock_m = 193
		let xxx_clock_s = 323
		let yyy_clock_s = 228
		let xxx_clock = 191
		let yyy_clock = 190
		let xxx_day = 206
		let yyy_day = 134
		let xxx_month = 278
		let yyy_month = 134
		let xxx_day_w = 218
		let yyy_day_w = 80
		let xxx_batt = 206
		let yyy_batt = 439

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	
//# барометр в мм рт. ст.


function read_pressure() {
 console.log("read_pressure()");
 const file_name_alt = "../../../baro_altim/pressure.dat";
 const [fs_stat, err] = hmFS.stat(file_name_alt);
 if (err == 0) {
  let file_size = fs_stat.size;
  const len = file_size / 4;
  console.log(`size_alt: ${file_size}, lenght: ${len}`)
  const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)

  let array_buffer = new Float32Array(len);
  hmFS.read(fh, array_buffer.buffer, 0, file_size);
  hmFS.close(fh);
  console.log(`value ${array_buffer[array_buffer.length -1]}`);
  return array_buffer;
 } else {
  console.log('err:', err)
 }
 return null;
}

function getPressureValue(pressure_array) {
 console.log("getPressureValue()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
 }
 return 0;
}



function hPa_To_mmHg(hPa_value = 0) {
 let mmHg = Math.round(hPa_value * 0.750064);
 return mmHg;
}
//# конец барометр в мм рт. ст.

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// переключение едениц измерения давления

		

function click_ALT() {
            if(alt_var>=alt_all) {
            alt_var=1;
                }
            else {
                alt_var=alt_var+1;
            }
			if ( alt_var == 1) { 
			alt_text = "mmHg"  
			value = hPa_To_mmHg(value);              // перевод в мм.рт.ст.
			normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));
		    }			
			if ( alt_var == 2) { 
			alt_text = "hPa" 
			value = getPressureValue(pressure_array);              // перевод в гПа
			normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));
			}
			
			hmUI.showToast({text: alt_text });
			vibro(28);
									
		}

// конец переключение едениц измерения давления

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function clicker() {
	
		normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: parseInt(xxx_clock_h),
              hour_startY: parseInt(yyy_clock_h),
              hour_array: [night_dig + "_001.png",night_dig + "_002.png",night_dig + "_003.png",night_dig + "_004.png",night_dig + "_005.png",night_dig + "_006.png",night_dig + "_007.png",night_dig + "_008.png",night_dig + "_009.png",night_dig + "_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: parseInt(xxx_clock_m),
              minute_startY: parseInt(yyy_clock_m),
              minute_array: [night_dig + "_001.png",night_dig + "_002.png",night_dig + "_003.png",night_dig + "_004.png",night_dig + "_005.png",night_dig + "_006.png",night_dig + "_007.png",night_dig + "_008.png",night_dig + "_009.png",night_dig + "_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: parseInt(xxx_clock_s),
              second_startY: parseInt(yyy_clock_s),
              second_array: [night_dig + "_013.png",night_dig + "_014.png",night_dig + "_015.png",night_dig + "_016.png",night_dig + "_017.png",night_dig + "_018.png",night_dig + "_019.png",night_dig + "_020.png",night_dig + "_021.png",night_dig + "_022.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
		normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.MORE, {
              x: xxx_clock,
              y: yyy_clock,
              src: night_dig + '_011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
		normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: night_dig + '_am.png',
              am_en_path: night_dig + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: night_dig + '_pm.png',
              pm_en_path: night_dig + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	


		normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: xxx_day_w,
              y: yyy_day_w,
              week_en: [night_dig + "_023.png",night_dig + "_024.png",night_dig + "_025.png",night_dig + "_026.png",night_dig + "_027.png",night_dig + "_028.png",night_dig + "_029.png"],
              week_tc: [night_dig + "_023.png",night_dig + "_024.png",night_dig + "_025.png",night_dig + "_026.png",night_dig + "_027.png",night_dig + "_028.png",night_dig + "_029.png"],
              week_sc: [night_dig + "_023.png",night_dig + "_024.png",night_dig + "_025.png",night_dig + "_026.png",night_dig + "_027.png",night_dig + "_028.png",night_dig + "_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
		normal_date_img_date_month.setProperty(hmUI.prop.MORE, {
              month_startX: xxx_month,
              month_startY: yyy_month,
              month_sc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              month_tc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              month_en_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: xxx_day,
              day_startY: yyy_day,
              day_sc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              day_tc_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              day_en_array: [night_dig + "_030.png",night_dig + "_031.png",night_dig + "_032.png",night_dig + "_033.png",night_dig + "_034.png",night_dig + "_035.png",night_dig + "_036.png",night_dig + "_037.png",night_dig + "_038.png",night_dig + "_039.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


		normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: xxx_batt,
              y: yyy_batt,
              font_array: [night_dig + "_040.png",night_dig + "_041.png",night_dig + "_042.png",night_dig + "_043.png",night_dig + "_044.png",night_dig + "_045.png",night_dig + "_046.png",night_dig + "_047.png",night_dig + "_048.png",night_dig + "_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: night_dig + '_int.png',
              unit_tc: night_dig + '_int.png',
              unit_en: night_dig + '_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
	
}




//	возврат в дневной режим 

		function click_Day() {

		name_text = "DAYTIME MODE"
		night_dig = 1		
		
		 xxx_clock_h = 94
		 yyy_clock_h = 193
		 xxx_clock_m = 223
		 yyy_clock_m = 193
		 xxx_clock_s = 323
		 yyy_clock_s = 228
		 xxx_clock = 191
		 yyy_clock = 190
		 xxx_day = 206
		 yyy_day = 134
		 xxx_month = 278
		 yyy_month = 134
		 xxx_day_w = 218
		 yyy_day_w = 80
		 xxx_batt = 206
		 yyy_batt = 439

	
        clicker()
		
		normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: color_digt + '_am.png',
              am_en_path: color_digt + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: color_digt + '_pm.png',
              pm_en_path: color_digt + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
		
		normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);	
		normal_battery_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
		
		normal_background_bg_img.setProperty(hmUI.prop.SRC, "BG_" + color_digt + ".png");
		
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_heart_rate_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
		normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_step_linear_scale.setProperty(hmUI.prop.VISIBLE, true);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_alarm_clock_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_image_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
		normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
		normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, true);
		
		Button_1.setProperty(hmUI.prop.VISIBLE, true);      //   кнопка календарь
		Button_2.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка давление   
		Button_3.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка погодная программа
		Button_4.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка переход в ночной режим
		Button_5.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка изменения цвета
		Button_6.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка возврат в дневной режим
		
		normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык P A I
		normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык статистика активностей (калории)
		normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);          //   ярлык шаги 
		normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык пульса 
		normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);      //   ярлык температуры
		normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык будильник
		normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);       //   ярлык секундомер
		normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);           //   ярлык батарея		
		
		hmUI.showToast({text: name_text });
			
		vibro(28);		
				
			}
			
//	конец возврата в дневной режим 			

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			
//	переход в ночной режим 			
			
		function click_Night() {		
				
		name_text = "NIGHT MODE"
		night_dig = 'AOD'
		
		 xxx_clock_h = 37
		 yyy_clock_h = 194
		 xxx_clock_m = 223
		 yyy_clock_m = 194
		 xxx_clock_s = 364
		 yyy_clock_s = 237
		 xxx_clock = 170
		 yyy_clock = 211
		 xxx_day = 229
		 yyy_day = 89
		 xxx_month = 329
		 yyy_month = 89
		 xxx_day_w = 69
		 yyy_day_w = 90
		 xxx_batt = 184
		 yyy_batt = 411


		clicker()
		
		normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);	
		normal_battery_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
			
		
 
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_heart_rate_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
		normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_step_linear_scale.setProperty(hmUI.prop.VISIBLE, false);
		normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_humidity_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		normal_uvi_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_alarm_clock_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_image_img.setProperty(hmUI.prop.VISIBLE, false);
		normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		normal_frame_animation_1.setProperty(hmUI.prop.VISIBLE, false);
		
		
		
		Button_1.setProperty(hmUI.prop.VISIBLE, false);      //   кнопка календарь
		Button_2.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка давление   
		Button_3.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка погодная программа
		Button_4.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка переход в ночной режим
		Button_5.setProperty(hmUI.prop.VISIBLE, false);		//   кнопка изменения цвета
		Button_6.setProperty(hmUI.prop.VISIBLE, true);		//   кнопка возврат в дневной режим
		
		normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык P A I
		normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык статистика активностей (калории)
		normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);          //   ярлык шаги 
		normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык пульса 
		normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);      //   ярлык температуры
		normal_alarm_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык будильник
		normal_stopwatch_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);       //   ярлык секундомер
		normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);           //   ярлык батарея
		
		
		normal_background_bg_img.setProperty(hmUI.prop.SRC, night_dig + ".png");
		
		
		hmUI.showToast({text: name_text });
		vibro(28);
	
		}
		
//	конец перехода в ночной режим 		

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  изменение цвета фона

function click_BG() {
            if(color_digt>=all_digt) {
            color_digt=1;
                }
            else { 
			color_digt=color_digt+1;   
			}
			
			if ( color_digt == 1) namecolor_main = "BLUE"
			if ( color_digt == 2) namecolor_main = "GREEN"
			if ( color_digt == 3) namecolor_main = "YELLOW"
			if ( color_digt == 4) namecolor_main = "RED"
			if ( color_digt == 5) namecolor_main = "LILAC"
			if ( color_digt == 6) namecolor_main = "GREY"




		normal_background_bg_img.setProperty(hmUI.prop.SRC, "BG_" + parseInt(color_digt) + ".png");	
		normal_image_img.setProperty(hmUI.prop.SRC, "BG_TOP_" + parseInt(color_digt) + ".png");	
		
			
		normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: parseInt(color_digt) + '_am.png',
              am_en_path: parseInt(color_digt) + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: parseInt(color_digt) + '_pm.png',
              pm_en_path: parseInt(color_digt) + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		
		
		normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              src: parseInt(color_digt) + '_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });			
		

        normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 351,
              y: 149,
              image_array: [parseInt(color_digt) + "_WD_1_N.png",parseInt(color_digt) + "_WD_2_NE.png",parseInt(color_digt) + "_WD_3_E.png",parseInt(color_digt) + "_WD_4_SE.png",parseInt(color_digt) + "_WD_5_S.png",parseInt(color_digt) + "_WD_6_SW.png",parseInt(color_digt) + "_WD_7_W.png",parseInt(color_digt) + "_WD_8_NW.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


			hmUI.showToast({text: namecolor_main });	
				
			vibro(28);
					
			}
 //  конец  изменения цвета фона	







		
	
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_alarm_clock_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_calorie_current_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_uvi_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_frame_animation_1 = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_image_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'BG_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 393,
              y: 214,
              font_array: ["1_050.png","1_051.png","1_052.png","1_053.png","1_054.png","1_055.png","1_056.png","1_057.png","1_058.png","1_059.png"],
              padding: true,
              h_space: 2,
              invalid_image: '1_eror_a.png',
              dot_image: '1_012.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: '1_BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: '1_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 321,
              y: 365,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 362,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 362,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 345,
              y: 74,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 351,
              y: 149,
              image_array: ["1_WD_1_N.png","1_WD_2_NE.png","1_WD_3_E.png","1_WD_4_SE.png","1_WD_5_S.png","1_WD_6_SW.png","1_WD_7_W.png","1_WD_8_NW.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 397,
              y: 147,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 53,
              y: 147,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              invalid_image: '1_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 147,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_int.png',
              unit_tc: '1_int.png',
              unit_en: '1_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 115,
              y: 83,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 57,
              y: 340,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "puls",
              anim_fps: 12,
              anim_size: 27,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_battery_linear_scale.setAlpha(150);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 175,
              // start_y: 418,
              // color: 0xFF000000,
              // lenght: 129,
              // line_width: 15,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 439,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_int.png',
              unit_tc: '1_int.png',
              unit_en: '1_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 169,
              y: 371,
              image_array: ["AOD_batt_01.png","AOD_batt_02.png","AOD_batt_03.png","AOD_batt_04.png","AOD_batt_05.png","AOD_batt_06.png","AOD_batt_07.png","AOD_batt_08.png","AOD_batt_09.png","AOD_batt_10.png","AOD_batt_11.png","AOD_batt_12.png"],
              image_length: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_heart_rate_linear_scale.setAlpha(210);
            };

            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 49,
              // start_y: 302,
              // color: 0xFF000000,
              // lenght: 71,
              // line_width: 19,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 210,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 133,
              y: 298,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_step_linear_scale.setAlpha(210);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 215,
              // start_y: 310,
              // color: 0xFF000000,
              // lenght: 110,
              // line_width: 31,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 210,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 334,
              y: 307,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 278,
              month_startY: 134,
              month_sc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              month_tc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              month_en_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 206,
              day_startY: 134,
              day_sc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              day_tc_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              day_en_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 218,
              y: 80,
              week_en: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_tc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_sc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 176,
              y: 6,
              image_array: ["1_wth00.png","1_wth01.png","1_wth02.png","1_wth03.png","1_wth04.png","1_wth05.png","1_wth06.png","1_wth07.png","1_wth08.png","1_wth09.png","1_wth10.png","1_wth11.png","1_wth12.png","1_wth13.png","1_wth14.png","1_wth15.png","1_wth16.png","1_wth17.png","1_wth18.png","1_wth19.png","1_wth20.png","1_wth21.png","1_wth22.png","1_wth23.png","1_wth24.png","1_wth25.png","1_wth26.png","1_wth27.png","1_wth28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 22,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_dig.png',
              unit_tc: '1_dig.png',
              unit_en: '1_dig.png',
              imperial_unit_sc: '1_dig.png',
              imperial_unit_tc: '1_dig.png',
              imperial_unit_en: '1_dig.png',
              negative_image: '1_minus.png',
              invalid_image: '1_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 244,
                y: 22,
                font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
                padding: false,
                h_space: 0,
                unit_sc: '1_dig.png',
                unit_tc: '1_dig.png',
                unit_en: '1_dig.png',
                imperial_unit_sc: '1_dig.png',
                imperial_unit_tc: '1_dig.png',
                imperial_unit_en: '1_dig.png',
                negative_image: '1_minus.png',
                invalid_image: '1_eror.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: '1_am.png',
              am_en_path: '1_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: '1_pm.png',
              pm_en_path: '1_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 94,
              hour_startY: 193,
              hour_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 223,
              minute_startY: 193,
              minute_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 323,
              second_startY: 228,
              second_array: ["1_013.png","1_014.png","1_015.png","1_016.png","1_017.png","1_018.png","1_019.png","1_020.png","1_021.png","1_022.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 191,
              y: 190,
              src: '1_011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'BG_TOP_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 69,
              y: 90,
              week_en: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              week_tc: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              week_sc: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 329,
              month_startY: 89,
              month_sc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              month_tc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              month_en_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 229,
              day_startY: 89,
              day_sc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              day_tc_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              day_en_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 411,
              font_array: ["AOD_040.png","AOD_041.png","AOD_042.png","AOD_043.png","AOD_044.png","AOD_045.png","AOD_046.png","AOD_047.png","AOD_048.png","AOD_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD_int.png',
              unit_tc: 'AOD_int.png',
              unit_en: 'AOD_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 169,
              y: 371,
              image_array: ["AOD_batt_01.png","AOD_batt_02.png","AOD_batt_03.png","AOD_batt_04.png","AOD_batt_05.png","AOD_batt_06.png","AOD_batt_07.png","AOD_batt_08.png","AOD_batt_09.png","AOD_batt_10.png","AOD_batt_11.png","AOD_batt_12.png"],
              image_length: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'AOD_am.png',
              am_en_path: 'AOD_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'AOD_pm.png',
              pm_en_path: 'AOD_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 37,
              hour_startY: 194,
              hour_array: ["AOD_001.png","AOD_002.png","AOD_003.png","AOD_004.png","AOD_005.png","AOD_006.png","AOD_007.png","AOD_008.png","AOD_009.png","AOD_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 223,
              minute_startY: 194,
              minute_array: ["AOD_001.png","AOD_002.png","AOD_003.png","AOD_004.png","AOD_005.png","AOD_006.png","AOD_007.png","AOD_008.png","AOD_009.png","AOD_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 364,
              second_startY: 237,
              second_array: ["AOD_013.png","AOD_014.png","AOD_015.png","AOD_016.png","AOD_017.png","AOD_018.png","AOD_019.png","AOD_020.png","AOD_021.png","AOD_022.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 211,
              src: 'AOD_011.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // repeatAlert = hmUI.createWidget(hmUI.widget.RepeatAlert, {
              // everyHour_vibrate_type: 0,
            // });


            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              repeat_alerts();
            });
            // repeat alerts
            function repeat_alerts() {
              let hourEnd = false;
              if(timeSensor.minute == 0) {
                hourEnd = true;
                vibro(0);
              }
            };

            // end repeat alerts
            //#region vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 203,
              y: 296,
              w: 218,
              h: 59,
              src: '00_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 312,
              y: 361,
              w: 100,
              h: 60,
              src: '00_empty.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 32,
              y: 299,
              w: 163,
              h: 100,
              src: '00_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 201,
              y: 357,
              w: 100,
              h: 47,
              src: '00_empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 174,
              y: 409,
              w: 133,
              h: 69,
              src: '00_empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 337,
              y: 63,
              w: 93,
              h: 63,
              src: '00_empty.png',
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 239,
              y: 0,
              w: 90,
              h: 74,
              src: '00_empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 119,
              y: 74,
              w: 71,
              h: 50,
              src: '00_empty.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 326,
              y: 229,
              w: 57,
              h: 60,
              src: '00_empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 389,
              y: 189,
              w: 71,
              h: 50,
              src: '00_empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 80,
              w: 128,
              h: 101,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 65,
              y: 73,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_ALT()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 163,
              y: 2,
              w: 71,
              h: 69,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index' });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 91,
              y: 190,
              w: 98,
              h: 102,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Night()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 222,
              y: 190,
              w: 98,
              h: 102,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_BG()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 36,
              y: 190,
              w: 400,
              h: 141,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Day()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

let pressure_array = read_pressure();
let value = getPressureValue(pressure_array);
value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.
 
normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));

normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);	
Button_6.setProperty(hmUI.prop.VISIBLE, false);	





            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 304;
                  let start_y_normal_battery = 418;
                  let lenght_ls_normal_battery = -129;
                  let line_width_ls_normal_battery = 15;
                  let color_ls_normal_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 184;
                let progressHeartRate = (valueHeartRate - 30)/(targetHeartRate - 30);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = 1 - progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 120;
                  let start_y_normal_heart_rate = 302;
                  let lenght_ls_normal_heart_rate = -71;
                  let line_width_ls_normal_heart_rate = 19;
                  let color_ls_normal_heart_rate = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    lenght_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_x_normal_heart_rate_draw = start_x_normal_heart_rate - lenght_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    color: color_ls_normal_heart_rate,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 325;
                  let start_y_normal_step = 310;
                  let lenght_ls_normal_step = -110;
                  let line_width_ls_normal_step = 31;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}