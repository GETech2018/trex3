/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_hour_rotary2 = '';
		let timeInterval;
		let normal_hour_rotary3 = '';
		let normal_minute_rotary4 = '';
		let normal_minute_rotary5 = '';
		let normal_second_rotary6 = '';
		let normal_second_rotary7 = '';
		let idle_img10 = '';
		let idle_hour_rotary12 = '';
		let idle_minute_rotary13 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_rotary2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 237,
					pos_x: 224,
					pos_y: 103,
					src: '0003.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_rotary3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 224,
					pos_y: 106,
					src: '0004.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_rotary4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 235,
					center_y: 237,
					pos_x: 221,
					pos_y: 21,
					src: '0005.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_rotary5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 226,
					pos_y: 24,
					src: '0006.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 243,
					center_y: 236,
					pos_x: 233,
					pos_y: 15,
					src: '0007.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 238,
					center_y: 240,
					pos_x: 228,
					pos_y: 19,
					src: '0008.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 15,
					y: 15,
					w: 450,
					h: 450,
					src: '0009.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_rotary12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 224,
					pos_y: 106,
					src: '0010.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_rotary13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 226,
					pos_y: 24,
					src: '0011.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateTime() {
					if (normal_hour_rotary2) {
						normal_hour_rotary2.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (normal_hour_rotary3) {
						normal_hour_rotary3.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (normal_minute_rotary4) {
						normal_minute_rotary4.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
					if (normal_minute_rotary5) {
						normal_minute_rotary5.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
					if (normal_second_rotary6) {
						normal_second_rotary6.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.second * (6 * 1))));
					}
					if (normal_second_rotary7) {
						normal_second_rotary7.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.second * (6 * 1))));
					}
					if (idle_hour_rotary12) {
						idle_hour_rotary12.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (idle_minute_rotary13) {
						idle_minute_rotary13.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}