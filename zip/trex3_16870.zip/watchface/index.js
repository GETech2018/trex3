﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// user_script_end START
		let cc = 0
		// user_script_end END
		
		// Hands START
		let elementnumber_1 = 1
        let total_elemente = 6

        function click_me() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }
				if(elementnumber_1==3) {
                  UpdateElementeThree();
                }
				if(elementnumber_1==4) {
                  UpdateElementeFour();
                }
				if(elementnumber_1==5) {
                  UpdateElementeFive();
                }
				if(elementnumber_1==5) {
                  UpdateElementeFive();
                }
				if(elementnumber_1==6) {
                  UpdateElementeSix();
                }
			}
            if(elementnumber_1==1) hmUI.showToast({text: 'TIME'});
			if(elementnumber_1==2) hmUI.showToast({text: 'STEP'});
			if(elementnumber_1==3) hmUI.showToast({text: 'HEART RATE'});
            if(elementnumber_1==4) hmUI.showToast({text: 'ALTIMETER'});
			if(elementnumber_1==5) hmUI.showToast({text: 'BAROMETER'});
			if(elementnumber_1==6) hmUI.showToast({text: 'COMPASS'});
        }

        // TIME
        function UpdateElementeOne(){
        normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_time_gmt_text.setProperty(hmUI.prop.VISIBLE, false);
        }
        // STEP
        function UpdateElementeTwo(){
        normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_time_gmt_text.setProperty(hmUI.prop.VISIBLE, true);
        }
		// HEART
        function UpdateElementeThree(){
        normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_time_gmt_text.setProperty(hmUI.prop.VISIBLE, true);
        }    
		// ALTIMETER
        function UpdateElementeFour(){
        normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_time_gmt_text.setProperty(hmUI.prop.VISIBLE, true);
        }   
		// BAROMETER
        function UpdateElementeFive(){
        normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_time_gmt_text.setProperty(hmUI.prop.VISIBLE, true);
        }
		// COMPASS
        function UpdateElementeSix(){
        normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_time_gmt_text.setProperty(hmUI.prop.VISIBLE, true);
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_compass_direction_img_level = ''
        let normal_compass_direction_arr = ["91.png", "92.png", "93.png", "94.png", "95.png", "96.png", "97.png", "98.png"];
        let normal_compass_direction_pointer_img = ''
        let normal_compass_text_img = ''
        let normal_compass_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altitude_target_separator_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_icon_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_time_gmt_text = ''
        let worldClockIndex = 0
        let GMT_Button_NextSity = ''
        let GMT_Button_PreviewSity = ''
        let Button_1 = ''
        let timeSensor = '';
        let worldClock = '';
        worldClockIndex = hmFS.SysProGetInt('worldClockIndex') ?? 0;;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Digital Dismay.ttf; FontSize: 63; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 75,
              h: 75,
              text_size: 63,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Digital Dismay.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_direction_img_level = hmUI.createWidget(hmUI.widget.IMG, {
              x: 235,
              y: 105,
              src: '91.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
              // img_error: 'error unit.png',
              // type: hmUI.data_type.COMPASS,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'COMPASS IDICATOR.png',
              // center_x: 240,
              // center_y: 240,
              // x: 189,
              // y: 189,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //#region Compass_Pointer
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 189,
              pos_y: 240 - 189,
              center_x: 240,
              center_y: 240,
              src: 'COMPASS IDICATOR.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //#endregion

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 194,
              font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'compass unit.png',
              unit_tc: 'compass unit.png',
              unit_en: 'compass unit.png',
              negative_image: 'compass error.png',
              align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 232,
              y: 152,
              src: 'COMPASS ICON.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 194,
              font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'hr unit.png',
              unit_tc: 'hr unit.png',
              unit_en: 'hr unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 152,
              y: 152,
              src: 'HR ICON.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 194,
              font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'alti unit.png',
              unit_tc: 'alti unit.png',
              unit_en: 'alti unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 182,
              y: 152,
              src: 'ALTI ICON.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 194,
              font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'baro unit.png',
              unit_tc: 'baro unit.png',
              unit_en: 'baro unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 206,
              y: 152,
              src: 'BARO ICON.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 204,
              y: 97,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 109,
              font_array: ["70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'celcius.png',
              unit_tc: 'celcius.png',
              unit_en: 'celcius.png',
              invalid_image: 'error unit.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 276,
              y: 159,
              src: '0105.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 329,
              y: 159,
              src: '0106.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 348,
              y: 150,
              src: 'BLUETOOTH.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 302,
              y: 159,
              src: '0093.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 96,
              y: 177,
              src: 'H24.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 138,
              y: 88,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 119,
              y: 349,
              image_array: ["c0.png","c1.png","c2.png","c3.png","c4.png","c5.png","c6.png","c7.png"],
              image_length: 8,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 195,
              font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 123,
              y: 152,
              src: 'STEP ICON.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 429,
              y: 127,
              image_array: ["b0.png","b1.png","b2.png","b3.png","b4.png","b5.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 253,
              month_startY: 315,
              month_sc_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              month_tc_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              month_en_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              month_zero: 1,
              month_space: 5,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 173,
              day_startY: 315,
              day_sc_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              day_tc_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              day_en_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              day_zero: 1,
              day_space: 5,
              day_unit_sc: 'date unit.png',
              day_unit_tc: 'date unit.png',
              day_unit_en: 'date unit.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 214,
              y: 104,
              week_en: ["F1.png","F2.png","F3.png","F4.png","F5.png","F6.png","F7.png"],
              week_tc: ["F1.png","F2.png","F3.png","F4.png","F5.png","F6.png","F7.png"],
              week_sc: ["F1.png","F2.png","F3.png","F4.png","F5.png","F6.png","F7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 91,
              am_y: 175,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 91,
              pm_y: 175,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 194,
              hour_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'time unit.png',
              hour_unit_tc: 'time unit.png',
              hour_unit_en: 'time unit.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 345,
              second_startY: 234,
              second_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 94,
              y: 152,
              src: 'TIME ICON.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            
            if (!worldClock) {
              worldClock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);
              worldClock.init();
            };

            normal_time_gmt_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 166,
              y: 306,
              w: 150,
              h: 63,
              text_size: 63,
              char_space: 0,
              font: 'fonts/Digital Dismay.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_end: 2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region updateTimeGMT
            function updateTimeGMT() {
              console.log('updateTimeGMT()');
              let normal_timeStr = '--:--';
              let count = worldClock.getWorldClockCount();
              if (count > 0) {
                if (worldClockIndex >= count) worldClockIndex = count-1;
                let worldData = worldClock.getWorldClockInfo(worldClockIndex);
                let hour = worldData.hour;
                let minute = worldData.minute;
                if (!timeSensor.is24Hour) hour = hour % 12 || 12;
                let normal_hourStr = hour.toString().padStart(2, '0');
                let normal_minuteStr = minute.toString().padStart(2, '0');
                normal_timeStr = normal_hourStr + ':' + normal_minuteStr;
              } // count
              if (normal_time_gmt_text) normal_time_gmt_text.setProperty(hmUI.prop.TEXT, normal_timeStr);
            };
            //#endregion

            console.log('Watch_Face.ScreenAOD');

            GMT_Button_NextSity = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              radius: 12,
              press_color: 0xFFA0A0A0,
              normal_color: 0xFF696969,
              click_func: (button_widget) => {
                toggleWorldClock(1);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            GMT_Button_PreviewSity = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              radius: 12,
              press_color: 0xFFA0A0A0,
              normal_color: 0xFF696969,
              click_func: (button_widget) => {
                toggleWorldClock(-1);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region toggleWorldClock
            function toggleWorldClock(step = 1) {
              const count = worldClock.getWorldClockCount();
              if (count) {
                worldClockIndex += step;
                worldClockIndex = worldClockIndex < 0 ? count + worldClockIndex : worldClockIndex % count;
                updateWorldTime(true);
                hmFS.SysProSetInt('worldClockIndex', worldClockIndex);
              }
            };
            //#endregion

            //#region updateWorldTime
            function updateWorldTime(updateSity = false) {
              updateTimeGMT();
            };
            //#endregion

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 210,
              y: 99,
              w: 103,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                click_me()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if (cc ==0 ){
        normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_direction_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_time_gmt_text.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}
            // end user_script_end.js

            let screenType = hmSetting.getScreenType();
            //#region compass_update
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Images
                let compass_direction_angle = parseInt(compass.direction_angle);
                let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                let compass_direction_index = parseInt(compass_direction_angle_img/45);
                if (compass_direction_index > 7) compass_direction_index = 0;
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);
                // Compass Pointer
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                // Compass Number
                let normal_compass_direction_angle_text = compass_direction_angle.toString();
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

              } else { // error data
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, 'error unit.png');
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Images
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                  let compass_direction_index = parseInt(compass_direction_angle_img/45);
                  if (compass_direction_index > 7) compass_direction_index = 0;
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);
                  // Compass Pointer
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                  // Compass Number
                  let normal_compass_direction_angle_text = compass_direction_angle.toString();
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);

                } else { // error data
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, 'error unit.png');
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');

                }

              }); // Listener end

            };
            //#endregion

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();
                updateWorldTime();
                setTimeout(() => {
                  if (worldClock) {
                    worldClock.uninit();
                    worldClock.init();
                  };
                }, 500);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                worldClock.uninit();
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}