﻿/*
** Watch_Face_Editor tool
** watchface js version v2.1.1
** Copyright © SashaCX75. All Rights Reserved
*/

try {
  (() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const { px } = __$$app$$__.__globals__;
    const logger = Logger.getLogger('watchface_SashaCX75');
    //end of ignored block

    //dynamic modify start


    const curTime = hmSensor.createSensor(hmSensor.id.TIME);
    const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
    const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
    const isAOD = hmSetting.getScreenType() == hmSetting.screen_type.AOD;
    let bg_color, bottom_img, top_img, mask_img
    let normal_heart_rate_icon_img, normal_heart_rate_text_font, normal_calorie_target_text_font, normal_calorie_current_text_font, step_img
    let normal_calorie_icon_img
    let second_cover_pointer_img, second_cover_pointer_sh
    let normal_ampm24_text_font
    let normal_miles_distance_current_text_font, normal_distance_current_text_font, normal_step_text_font
    let normal_time_hour_text_font, normal_time_minute_text_font, normal_time_second_text_font
    let normal_battery_pointer_progress_img_pointer
    let normal_dow_text_font, normal_month_name_font, normal_date_text_font
    let normal_temperature_current_text_font, normal_temperature_high_text_font, normal_temperature_low_text_font, normal_weather_icon_text
    const array_ic_weather_day = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a", "b", "c"];
    const array_ic_weather_night = ["a", "b", "k", "c", "E", "l", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "a", "b", "c"];
    let normal_sun_high_text_font, normal_sun_low_text_font

    let normal_DOW_Array = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
    let normal_Month_Array = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    let groupCalorie = ''
    let groupStep = ''
    let isHealtVisible = true;

    let currentMask = 1
    let currentHand = 1
    let currentColor = 1

    let isDayIcons = true;
    let sunsetMins = 20 * 60;
    let sunriseMins = 8 * 60;


    function loadSettings() {
      if (hmFS.SysProGetInt('sol360_mask') === undefined) {
        currentMask = 1;
        hmFS.SysProSetInt('sol360_mask', currentMask);
      } else {
        currentMask = hmFS.SysProGetInt('sol360_mask');
      }

      if (hmFS.SysProGetInt('sol360_color') === undefined) {
        currentColor = 1;
        hmFS.SysProSetInt('sol360_color', currentColor);
      } else {
        currentColor = hmFS.SysProGetInt('sol360_color');
      }

      if (hmFS.SysProGetInt('sol360_hand') === undefined) {
        currentHand = 1;
        hmFS.SysProSetInt('sol360_hand', currentHand);
      } else {
        currentHand = hmFS.SysProGetInt('sol360_hand');
      }
    }

    const SCREEN_CENTER_X = 240;
    const SCREEN_CENTER_Y = 240;
    const SHADOW_OFFSET_X = 2;
    const SHADOW_OFFSET_Y = 8;
    const POINTER_CONFIG = {
      hour: {
        posX: 19,
        posY: 158
      },
      minute: {
        posX: 21,
        posY: 215
      },
      second: {
        posX: 15,
        posY: 218
      }
    };

    let pointersVisible = true;
    let pointers = [];
    let scaleTimer = null;

    const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
    let clickTimer = null;
    let clickCount = 0;

    const vibro = (scene = 25) => {
      const stopDelay = scene >= 23 && scene <= 25 ? 50 : 1220;
      vibrate.stop();
      vibrate.scene = scene;
      vibrate.start();

      setTimeout(vibrate.stop, stopDelay);
    };

    const stopTimer = (timerInstance) => {
      if (timerInstance) {
        clearTimeout(timerInstance);
        return null;
      }
      return null;
    };

    const handleClicks = (actions) => {
      clickCount++;
      clickTimer = stopTimer(clickTimer);

      clickTimer = setTimeout(() => {
        if (clickCount <= actions.length) {
          actions[clickCount - 1]();
        }
        clickCount = 0;
        clickTimer = null;
      }, 370);

      vibro();
    };

    const togglePointerAnimation = (start = true) => {
      scaleTimer = stopTimer(scaleTimer);
      if (start) {
        scaleTimer = timer.createTimer(0, 150, () => { });
      }
    };

    const togglePointers = () => {
      pointersVisible = !pointersVisible;
      pointers.forEach(pointer => {
        pointer.setProperty(hmUI.prop.VISIBLE, pointersVisible);
      });
      togglePointerAnimation(pointersVisible);
    };

    const changeHandStyle = () => {
      currentHand = (currentHand % 4) + 1;

      const updatePointer = (index, config) => {
        pointers[index].setProperty(hmUI.prop.MORE, config);
      };

      updatePointer(0, {
        hour_path: `hour_sh_${currentHand}.png`,
        hour_centerX: SCREEN_CENTER_X + SHADOW_OFFSET_X,
        hour_centerY: SCREEN_CENTER_Y + SHADOW_OFFSET_Y,
        hour_posX: POINTER_CONFIG.hour.posX,
        hour_posY: POINTER_CONFIG.hour.posY,
        show_level: hmUI.show_level.ONLY_NORMAL
      });

      updatePointer(1, {
        hour_path: `hour_${currentHand}.png`,
        hour_centerX: SCREEN_CENTER_X,
        hour_centerY: SCREEN_CENTER_Y,
        hour_posX: POINTER_CONFIG.hour.posX,
        hour_posY: POINTER_CONFIG.hour.posY
      });

      updatePointer(2, {
        minute_path: `minute_sh_${currentHand}.png`,
        minute_centerX: SCREEN_CENTER_X + SHADOW_OFFSET_X,
        minute_centerY: SCREEN_CENTER_Y + SHADOW_OFFSET_Y,
        minute_posX: POINTER_CONFIG.minute.posX,
        minute_posY: POINTER_CONFIG.minute.posY,
        show_level: hmUI.show_level.ONLY_NORMAL
      });

      updatePointer(3, {
        minute_path: `minute_${currentHand}.png`,
        minute_centerX: SCREEN_CENTER_X,
        minute_centerY: SCREEN_CENTER_Y,
        minute_posX: POINTER_CONFIG.minute.posX,
        minute_posY: POINTER_CONFIG.minute.posY
      });

      updatePointer(4, {
        second_path: `second_sh_${currentHand}.png`,
        second_centerX: SCREEN_CENTER_X + SHADOW_OFFSET_X,
        second_centerY: SCREEN_CENTER_Y + SHADOW_OFFSET_Y,
        second_posX: POINTER_CONFIG.second.posX,
        second_posY: POINTER_CONFIG.second.posY,
        fresh_frequency: 25,
        show_level: hmUI.show_level.ONLY_NORMAL
      });

      updatePointer(5, {
        second_path: `second_${currentHand}.png`,
        second_centerX: SCREEN_CENTER_X,
        second_centerY: SCREEN_CENTER_Y,
        second_posX: POINTER_CONFIG.second.posX,
        second_posY: POINTER_CONFIG.second.posY,
        fresh_frequency: 25,
        show_level: hmUI.show_level.ONLY_NORMAL
      });

      hmFS.SysProSetInt('sol360_hand', currentHand);
    };

    function clickChangeMask() {
      currentMask = (currentMask % 9) + 1;
      mask_img.setProperty(hmUI.prop.SRC, `mask_${currentMask}.png`);
      second_cover_pointer_img.setProperty(hmUI.prop.SRC, `cover_${currentMask}.png`);
      hmFS.SysProSetInt('sol360_mask', currentMask);
    }

    function clickChangeBgColor() {
      currentColor = (currentColor % 9) + 1;
      bg_color.setProperty(hmUI.prop.SRC, `color_${currentColor}.png`);
      hmFS.SysProSetInt('sol360_color', currentColor);
    }



    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        //dynamic modify start

        // FontName: Gotham_Bold.ttf; FontSize: 103
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 478,
          y: 478,
          w: 1596,
          h: 148,
          text_size: 103,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Gotham_Bold.ttf',
          color: 0xFFFF8C00,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "0123456789 _-.,:",
        });

        // FontName: Gotham_Bold.ttf; FontSize: 24
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 478,
          y: 478,
          w: 378,
          h: 34,
          text_size: 24,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Gotham_Bold.ttf',
          color: 0xFFFF8C00,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "0123456789 _-.,:AMPHmyKC°",
        });

        // FontName: Gotham_Medium.ttf; FontSize: 24
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 478,
          y: 478,
          w: 378,
          h: 34,
          text_size: 24,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Gotham_Medium.ttf',
          color: 0xFFFF8C00,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "0123456789 _-.,:",
        });

        // FontName: Gotham_Medium.ttf; FontSize: 24
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 478,
          y: 478,
          w: 378,
          h: 37,
          text_size: 34,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Gotham_Medium.ttf',
          color: 0xFFFF8C00,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "0123456789 _-.,:",
        });

        // FontName: Gotham_Light 23
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 478,
          y: 478,
          w: 378,
          h: 30,
          text_size: 23,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Gotham_Light.ttf',
          color: 0xFEB792,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "ADFIJKLMNOPRSTWАБВГДЖЗИЙКЛМНОПРСТЧІabcdefghiklmnoprstuvy'`,. абвгдеєжзилнопрстуь"
        });

        // FontName: Gotham_Light 60
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 478,
          y: 478,
          w: 378,
          h: 52,
          text_size: 60,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Gotham_Light.ttf',
          color: 0xFEB792,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "0123456789 _-.,:",
        });

        // FontName: Gotham_Bold.ttf; FontSize: 32
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 478,
          y: 478,
          w: 378,
          h: 34,
          text_size: 32,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Gotham_Bold.ttf',
          color: 0xFFFF8C00,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "0123456789 _-.,:C°",
        });

        // FontName: weather.ttf; FontSize: 61
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 478,
          y: 478,
          w: 378,
          h: 56,
          text_size: 61,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Weather.ttf',
          color: 0xFEB792,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "ABCDEFGHIJKLMNOPQRSTUVWXYZabckl"
          //show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Gotham_Bold.ttf; FontSize: 21
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 478,
          y: 478,
          w: 378,
          h: 25,
          text_size: 21,
          char_space: 0,
          line_space: 0,
          font: 'fonts/gotham_Bold.ttf',
          color: 0xFEB792,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "0123456789 _-.,:amp",
          //show_level: hmUI.show_level.ONLY_NORMAL,
        });

        //================================================================

        function setLang() {
          const lang = DeviceRuntimeCore.HmUtils.getLanguage();
          if (lang == 'en-US') {
            normal_DOW_Array = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
            normal_Month_Array = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
          }
          if (lang == 'uk-UA') {
            normal_DOW_Array = ["Понеділок", "Вівторок", "Середа", "Четвер", "П’ятниця", "Субота", "Неділя"];
            normal_Month_Array = ["Січень", "Лютий", "Березень", "Квітень", "Травень", "Червень", "Липень", "Серпень", "Вересень", "Жовтень", "Листопад", "Грудень"];
          }
          if (lang == 'ru-RU') {
            normal_DOW_Array = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"];
            normal_Month_Array = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"];
          }
        }

        bg_color = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: `color_${currentColor}.png`,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        bottom_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: isAOD ? 'down_aod.png' : 'down.png',
          //show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 310,
          y: 134,
          w: 150,
          h: 100,
          text_size: 103,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Gotham_Bold.ttf',
          color: 0xFEB792,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          //type: hmUI.data_type.HOUR,
          //padding: true,
          //show_level: hmUI.show_level.ONLY_NORMAL
        });


        normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 310,
          y: 216,
          w: 150,
          h: 100,
          text_size: 103,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Gotham_Bold.ttf',
          color: 0xFEB792,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          type: hmUI.data_type.MINUTE,
          padding: true,
          //show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 274,
          y: 283,
          w: 36,
          h: 24,
          text_size: 24,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Gotham_Bold.ttf',
          color: 0xFEB792,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          type: hmUI.data_type.SECOND,
          padding: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_ampm24_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 371,
          y: 107,
          w: 50,
          h: 30,
          text_size: 24,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Gotham_Bold.ttf',
          color: 0xFEB792,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,//TOP,
          text_style: hmUI.text_style.ELLIPSIS,
        });

        groupCalorie = hmUI.createWidget(hmUI.widget.GROUP, {
          x: 120,
          y: 304,
          w: 150,
          h: 81,
        });

        normal_calorie_current_text_font = groupCalorie.createWidget(hmUI.widget.TEXT_FONT, {
          x: 193 - 120,
          y: 321 - 304,
          w: 74,
          h: 30,
          text_size: 24,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Gotham_Medium.ttf',
          color: 0xFEB792,
          align_h: hmUI.align.RIGHT,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          type: hmUI.data_type.CAL,
        });

        normal_calorie_target_text_font = groupCalorie.createWidget(hmUI.widget.TEXT_FONT, {
          x: 193 - 120,
          y: 300 - 304,
          w: 74,
          h: 30,
          text_size: 24,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Gotham_Medium.ttf',
          color: 0xFEB792,
          align_h: hmUI.align.RIGHT,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          type: hmUI.data_type.CAL_TARGET,
        });

        normal_heart_rate_text_font = groupCalorie.createWidget(hmUI.widget.TEXT_FONT, {
          x: 197 - 120,
          y: 348 - 304,
          w: 70,
          h: 37,
          text_size: 34,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Gotham_Medium.ttf',
          color: 0xFEB792,
          align_h: hmUI.align.RIGHT,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          type: hmUI.data_type.HEART,
        });

        normal_heart_rate_icon_img = groupCalorie.createWidget(hmUI.widget.IMG, {
          x: 165 - 120,
          y: 350 - 304,
          src: 'heart.png',
        });

        normal_calorie_icon_img = groupCalorie.createWidget(hmUI.widget.IMG, {
          x: 167 - 120,
          y: 305 - 304,
          src: 'calorie.png',
        });

        groupStep = hmUI.createWidget(hmUI.widget.GROUP, {
          x: 120,
          y: 304,
          w: 150,
          h: 81,
        });

        normal_step_text_font = groupStep.createWidget(hmUI.widget.TEXT_FONT, {
          x: 138 - 120,
          y: 348 - 304,
          w: 130,
          h: 37,
          text_size: 34,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Gotham_Medium.ttf',
          color: 0xFEB792,
          align_h: hmUI.align.RIGHT,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
          type: hmUI.data_type.STEP,
        });

        step_img = groupStep.createWidget(hmUI.widget.IMG, {
          x: 141 - 120,
          y: 311 - 304,
          src: 'step.png',
          alpha: isAOD ? 100 : 255
        }),

          normal_miles_distance_current_text_font = groupStep.createWidget(hmUI.widget.TEXT, {
            x: 185 - 120,
            y: 300 - 304,
            w: 83,
            h: 30,
            text_size: 24,
            char_space: -1,
            line_space: 0,
            font: 'fonts/Gotham_Medium.ttf',
            color: 0xFEB792,
            align_h: hmUI.align.RIGHT,
            align_v: hmUI.align.CENTER_V,
            text_style: hmUI.text_style.ELLIPSIS,
          });

        normal_distance_current_text_font = groupStep.createWidget(hmUI.widget.TEXT, {
          x: 185 - 120,
          y: 324 - 304,
          w: 83,
          h: 30,
          text_size: 24,
          char_space: -1,
          line_space: 0,
          font: 'fonts/Gotham_Medium.ttf',
          color: 0xFEB792,
          align_h: hmUI.align.RIGHT,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
        });

        normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: 'arrow_bat.png',
          center_x: 226,
          center_y: 227,
          x: 22,
          y: 127,
          start_angle: -124,
          end_angle: 21,
          invalid_visible: false,
          type: hmUI.data_type.BATTERY,
        });

        normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 99,
          y: 381,
          w: 303,
          h: 30,
          text_size: 23,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Gotham_Light.ttf',
          color: 0xFEB792,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
        });

        normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 99,
          y: 386,
          w: 303,
          h: 30,
          text_size: 23,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Gotham_Light.ttf',
          color: 0xFEB792,
          align_h: hmUI.align.LEFT,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
        });

        normal_date_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 200,
          y: 410,
          w: 80,
          h: 52,
          text_size: 60,
          char_space: 0,
          line_space: 0,
          font: 'fonts/gotham_Light.ttf',
          color: 0xFEB792,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
        });

        normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 272,
          y: 310,
          w: 98,
          h: 30,
          text_size: 32,
          char_space: 0,
          line_space: 0,
          font: 'fonts/gotham_Bold.ttf',
          color: 0xFEB792,
          align_h: hmUI.align.RIGHT,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
        });

        normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 274,
          y: 339,
          w: 82,
          h: 26,
          text_size: 24,
          char_space: 0,
          line_space: 0,
          font: 'fonts/gotham_Bold.ttf',
          color: isAOD ? 0x916751 : 0xFEB792,
          align_h: hmUI.align.RIGHT,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
        });

        normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 274,
          y: 360,
          w: 82,
          h: 26,
          text_size: 24,
          char_space: 0,
          line_space: 0,
          font: 'fonts/gotham_Bold.ttf',
          color: isAOD ? 0x916751 : 0xFEB792,
          align_h: hmUI.align.RIGHT,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
        });

        normal_weather_icon_text = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 361,
          y: 310,
          w: 77,
          h: 69,
          text_size: 61,
          char_space: 0,
          line_space: 0,
          font: 'fonts/Weather.ttf',
          color: isAOD ? 0x916751 : 0xFEB792,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
        });

        normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 110,
          y: 407,
          w: 100,
          h: 25,
          text_size: 21,
          char_space: 0,
          line_space: 0,
          font: 'fonts/gotham_Bold.ttf',
          color: isAOD ? 0x916751 : 0xFEB792,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
        });

        normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 275,
          y: 407,
          w: 100,
          h: 25,
          text_size: 21,
          char_space: 0,
          line_space: 0,
          font: 'fonts/gotham_Bold.ttf',
          color: isAOD ? 0x916751 : 0xFEB792,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.ELLIPSIS,
        });

        alarm_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 279,
          y: 259,
          src: 'alarm.png',
          type: hmUI.system_status.CLOCK,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        bluetooth_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 114,
          y: 350,
          src: 'bl.png',
          type: hmUI.system_status.DISCONNECT,
        });


        mask_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: isAOD ? 'mask_aod.png' : `mask_${currentMask}.png`,
        });

        top_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          src: 'up.png',
        });

        pointers[0] = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: `hour_sh_${currentHand}.png`,
          hour_centerX: SCREEN_CENTER_X + SHADOW_OFFSET_X,
          hour_centerY: SCREEN_CENTER_Y + SHADOW_OFFSET_Y,
          hour_posX: POINTER_CONFIG.hour.posX,
          hour_posY: POINTER_CONFIG.hour.posY,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        pointers[1] = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: `hour_${currentHand}.png`,
          hour_centerX: SCREEN_CENTER_X,
          hour_centerY: SCREEN_CENTER_Y,
          hour_posX: POINTER_CONFIG.hour.posX,
          hour_posY: POINTER_CONFIG.hour.posY,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
        });

        pointers[2] = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: `minute_sh_${currentHand}.png`,
          minute_centerX: SCREEN_CENTER_X + SHADOW_OFFSET_X,
          minute_centerY: SCREEN_CENTER_Y + SHADOW_OFFSET_Y,
          minute_posX: POINTER_CONFIG.minute.posX,
          minute_posY: POINTER_CONFIG.minute.posY,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        pointers[3] = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: `minute_${currentHand}.png`,
          minute_centerX: SCREEN_CENTER_X,
          minute_centerY: SCREEN_CENTER_Y,
          minute_posX: POINTER_CONFIG.minute.posX,
          minute_posY: POINTER_CONFIG.minute.posY,
          show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD
        });

        pointers[4] = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          second_path: `second_sh_${currentHand}.png`,
          second_centerX: SCREEN_CENTER_X + SHADOW_OFFSET_X,
          second_centerY: SCREEN_CENTER_Y + SHADOW_OFFSET_Y,
          second_posX: POINTER_CONFIG.second.posX,
          second_posY: POINTER_CONFIG.second.posY,
          fresh_frequency: 25,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        pointers[5] = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          second_path: `second_${currentHand}.png`,
          second_centerX: SCREEN_CENTER_X,
          second_centerY: SCREEN_CENTER_Y,
          second_posX: POINTER_CONFIG.second.posX,
          second_posY: POINTER_CONFIG.second.posY,
          fresh_frequency: 25,
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        second_cover_pointer_sh = hmUI.createWidget(hmUI.widget.IMG, {
          x: 194,
          y: 198,
          src: 'cover_sh.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });


        second_cover_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 216,
          y: 216,
          src: isAOD ? "cover_aod.png" : `cover_${currentMask}.png`,
        });

        function updateWeather() {
          try {
            // Проверяет, существуют ли виджеты.
            if (!normal_weather_icon_text) {
              return;
            }

            const curAirIconIndex = weatherSensor.curAirIconIndex;
            const weatherData = weatherSensor.getForecastWeather();

            // Оптимизация солнечного времени
            if (weatherData?.tideData?.count > 0) {
              const today = weatherData.tideData.data[0];
              sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
              sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
            }

            // Оптимизированная проверка в режиме день/ночь
            const curTime = hmSensor.createSensor(hmSensor.id.TIME);
            const curMins = curTime.hour * 60 + curTime.minute;
            isDayIcons = (curMins >= sunriseMins && curMins < sunsetMins);

            const iconArray = isDayIcons ? array_ic_weather_day : array_ic_weather_night;

            const icon = iconArray[curAirIconIndex] || "Z";

            // Пакетное обновление для повышения производительности
            normal_weather_icon_text.setProperty(hmUI.prop.TEXT, icon);

          } catch (error) {
            console.log("Weather update error:", error);
          }
        }

        function updateSunTimes() {
          let tideData = weatherSensor.getForecastWeather().tideData;

          function formatTime(hour, minute) {
            let timeFormat = hmSetting.getTimeFormat();
            if (timeFormat == 0) {
              let period = hour >= 12 ? 'pm' : 'am';
              hour = hour % 12;
              hour = hour ? hour : 12;
              return `${hour}:${minute.toString().padStart(2, '0')}${period}`;
            } else {
              return `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
            }
          }

          if (tideData && tideData.count > 0) {
            let sunriseData = tideData.data[0].sunrise;
            let sunsetData = tideData.data[0].sunset;

            if (sunriseData) {
              let sunriseTime = formatTime(sunriseData.hour, sunriseData.minute);
              normal_sun_high_text_font.setProperty(hmUI.prop.TEXT, sunriseTime);
            }

            if (sunsetData) {
              let sunsetTime = formatTime(sunsetData.hour, sunsetData.minute);
              normal_sun_low_text_font.setProperty(hmUI.prop.TEXT, sunsetTime);
            }
          } else {
            normal_sun_high_text_font.setProperty(hmUI.prop.TEXT, "--:--");
            normal_sun_low_text_font.setProperty(hmUI.prop.TEXT, "--:--");
          }
        }

        function updateDistance() {
          const curDistMeters = distance.current;
          let kmValue = '';
          let milesValue = '';

          const METERS_IN_KM = 1000;
          const METERS_IN_MILE = 1609.34;
          const METERS_IN_YARD = 0.9144;

          if (curDistMeters < METERS_IN_KM) {
            kmValue = curDistMeters.toString() + 'm';
          } else {
            kmValue = (curDistMeters / METERS_IN_KM).toFixed(2) + 'K';
          }
          normal_distance_current_text_font.setProperty(hmUI.prop.TEXT, kmValue);

          const curDistMiles = curDistMeters / METERS_IN_MILE;
          if (curDistMiles < 1) {
            const curDistYards = (curDistMeters / METERS_IN_YARD).toFixed(0);
            milesValue = curDistYards.toString() + 'y';
          } else {
            milesValue = curDistMiles.toFixed(2) + 'M';
          }
          normal_miles_distance_current_text_font.setProperty(hmUI.prop.TEXT, milesValue);
        }

        function updateTemperature() {
          let c_text = weatherSensor.current.toString() + "°C";
          let h_text = weatherSensor.high.toString() + "°C";
          let l_text = weatherSensor.low.toString() + "°C";
          normal_temperature_current_text_font.setProperty(hmUI.prop.TEXT, c_text);
          normal_temperature_high_text_font.setProperty(hmUI.prop.TEXT, h_text);
          normal_temperature_low_text_font.setProperty(hmUI.prop.TEXT, l_text);
        }

        function getCurrentDate() {
          return curTime.day.toString();
        }

        function getCurrentDayName() {
          let currentDay = curTime.week;
          return normal_DOW_Array[currentDay - 1];
        }

        function getCurrentMonthName() {
          let currentMonth = curTime.month;
          return normal_Month_Array[currentMonth - 1];
        }

        function updateDate() {
          setLang();
          let currentDate = getCurrentDate();
          let currentDay = getCurrentDayName();
          let currentMonth = getCurrentMonthName();
          let combinedText = `${currentDay}, ${currentMonth}`;
          normal_dow_text_font.setProperty(hmUI.prop.TEXT, combinedText);
          normal_date_text_font.setProperty(hmUI.prop.TEXT, currentDate);
        }

        function updateTime() {
          const hour = curTime.hour;
          const is24Hour = curTime.is24Hour;
          const format_hour = curTime.format_hour;
          let hourStr, ampmText

          if (is24Hour) {
            hourStr = format_hour.toString().padStart(2, '0');
            ampmText = '24H';
          } else {
            hourStr = format_hour > 12 ? (format_hour - 12).toString() : format_hour.toString();
            ampmText = (hour >= 0 && hour < 12) ? 'AM' : 'PM';
          }

          normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, hourStr);
          normal_ampm24_text_font.setProperty(hmUI.prop.TEXT, ampmText);
        }


        function toggleHealt() {
          if (isHealtVisible) {
            groupCalorie.setProperty(hmUI.prop.VISIBLE, false);
            groupStep.setProperty(hmUI.prop.VISIBLE, true);
          } else {
            groupCalorie.setProperty(hmUI.prop.VISIBLE, true);
            groupStep.setProperty(hmUI.prop.VISIBLE, false);
          }
          isHealtVisible = !isHealtVisible;
        }

        groupStep.setProperty(hmUI.prop.VISIBLE, true);
        groupCalorie.setProperty(hmUI.prop.VISIBLE, false);


        // запуск приложения с заданным appId (если оно установлено) или системного приложения
        function launchAppOrAppId(url, appId, page = 'page/index') {
          let appInstalled = false;

          try {
            const id16 = appId.toString(16).padStart(8, "0");// переводим appId в 16-ричный формат

            const [fs_stat, err] = hmFS.stat_asset(`../../../js_apps/${id16}/app.json`);// проверяем наличие файла 'app.json' в папке приложения

            if (err == 0) {	//  если файл есть,  то приложение установлено
              appInstalled = true;
            } else {
              console.log("err:", err);
            }
          } catch (error) {
            console.log("error:", error);
            console.log("FAIL: No access to hmFS.");
          }

          if (appInstalled) hmApp.startApp({ appid: appId, url: page })
          else hmApp.startApp({ url: url, native: true });
        }


        btn_healt = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 168,
          y: 308,
          w: 90,
          h: 80,
          text: '',
          normal_src: 'blank.png',
          press_src: 'blank.png',
          click_func: () => {
            handleClicks([
              toggleHealt,
              () => {
                if (isHealtVisible) {
                  hmApp.startApp({ url: 'heart_app_Screen', native: true });
                } else {
                  hmApp.startApp({ url: 'activityAppScreen', native: true });
                }
              }
            ]);
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_weather = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 336,
          y: 308,
          w: 80,
          h: 80,
          text: '',
          normal_src: 'blank.png',
          press_src: 'blank.png',
          click_func: () => {
            launchAppOrAppId('WeatherScreen', 1051195);
            vibro();
          },
          longpress_func: () => {
            hmApp.startApp({ appid: 1065824, url: 'page/index' })
            vibro();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_calendar = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 204,
          y: 408,
          w: 80,
          h: 80,
          text: '',
          normal_src: 'blank.png',
          press_src: 'blank.png',
          click_func: () => {
            launchAppOrAppId('ScheduleCalScreen', 1057409);
            vibro();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_mask = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 188,
          y: 30,
          w: 80,
          h: 80,
          text: '',
          normal_src: 'blank.png',
          press_src: 'blank.png',
          click_func: () => {
            clickChangeBgColor()
            vibro();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_bgColor = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 8,
          y: 203,
          w: 80,
          h: 80,
          text: '',
          normal_src: 'blank.png',
          press_src: 'blank.png',
          click_func: () => {
            clickChangeMask()
            vibro();
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 201,
          y: 200,
          w: 80,
          h: 80,
          text: '',
          normal_src: 'blank.png',
          press_src: 'blank.png',
          click_func: () => {
            handleClicks([togglePointers, changeHandStyle]);
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        curTime.addEventListener(curTime.event.MINUTEEND, function () {
          updateTime();
        });
        distance.addEventListener(hmSensor.event.CHANGE, function () {
          updateDistance();
        });
        weatherSensor.addEventListener(hmSensor.event.CHANGE, function () {
          updateSunTimes();
        });

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            console.log('resume_call()');
            updateTime();
            updateDistance();
            updateDate();
            updateTemperature();
            updateWeather();
            updateSunTimes();
            setLang();

            if (hmSetting.getScreenType() === hmSetting.screen_type.WATCHFACE) {
              togglePointerAnimation(true);
            }
          }),

          pause_call: (function () {
            console.log('pause_call()');
            togglePointerAnimation(false);
          }),
        });
      },

      onInit() {
        logger.log('index page.js on init invoke');
        loadSettings();
      },
      build() {
        this.init_view();
        logger.log('index page.js on ready invoke');
      },
      onDestroy() {
        logger.log('index page.js on destroy invoke');
        vibrate && vibrate.stop();
      }
    });
    ;
  })();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
  ;
}