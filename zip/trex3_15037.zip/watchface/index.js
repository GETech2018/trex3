    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let idle_background_bg = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''

        const curTime = hmSensor.createSensor(hmSensor.id.TIME);

        let btn_color = ''
        let colornumber = 0
        let totalcolors = 8
        
        //let minute_arraym =  ["dtn_y_1.png","dtn_y_2.png","dtn_y_3.png","dtn_y_4.png","dtn_y_5.png","dtn_y_6.png","dtn_y_7.png","dtn_y_8.png","dtn_y_9.png","dtn_y_10.png"]
			
		 function call_change_Hands() {

        colornumber = (colornumber + 1) % (totalcolors);

        switch (colornumber) {
          case 0:
            normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {

              minute_startX: 310,
              minute_startY: 170,
              minute_array: ["dtn_1.png","dtn_2.png","dtn_3.png","dtn_4.png","dtn_5.png","dtn_6.png","dtn_7.png","dtn_8.png","dtn_9.png","dtn_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            bot_circle_state_txt = 'B L U E';
            break;
          case 1:
            normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {

              minute_startX: 310,
              minute_startY: 170,
              minute_array: ["dtn_y_1.png","dtn_y_2.png","dtn_y_3.png","dtn_y_4.png","dtn_y_5.png","dtn_y_6.png","dtn_y_7.png","dtn_y_8.png","dtn_y_9.png","dtn_y_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            bot_circle_state_txt = 'L I M E';
            break;
            case 2:
              normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
  
                minute_startX: 310,
                minute_startY: 170,
                minute_array: ["dtn_b_1.png","dtn_b_2.png","dtn_b_3.png","dtn_b_4.png","dtn_b_5.png","dtn_b_6.png","dtn_b_7.png","dtn_b_8.png","dtn_b_9.png","dtn_b_10.png"],
                minute_zero: 1,
                minute_space: 5,
                minute_follow: 0,
                minute_align: hmUI.align.CENTER_H,
  
 
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
     
               bot_circle_state_txt = 'W H I T E';
              break;

              case 3:
                normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {

                  minute_startX: 310,
                  minute_startY: 170,
                  minute_array: ["dtn_o_1.png","dtn_o_2.png","dtn_o_3.png","dtn_o_4.png","dtn_o_5.png","dtn_o_6.png","dtn_o_7.png","dtn_o_8.png","dtn_o_9.png","dtn_o_10.png"],
                  minute_zero: 1,
                  minute_space: 5,
                  minute_follow: 0,
                  minute_align: hmUI.align.CENTER_H,
    
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                  bot_circle_state_txt = 'O R A N G E';
                  break;
							
              case 4:
                normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {

                  minute_startX: 310,
                  minute_startY: 170,
                  minute_array: ["dtn_c_1.png","dtn_c_2.png","dtn_c_3.png","dtn_c_4.png","dtn_c_5.png","dtn_c_6.png","dtn_c_7.png","dtn_c_8.png","dtn_c_9.png","dtn_c_10.png"],
                  minute_zero: 1,
                  minute_space: 5,
                  minute_follow: 0,
                  minute_align: hmUI.align.CENTER_H,
    
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                  bot_circle_state_txt = 'C Y A N';
                  break;
							
              case 5:
                normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {

                  minute_startX: 310,
                  minute_startY: 170,
                  minute_array: ["dtn_r_1.png","dtn_r_2.png","dtn_r_3.png","dtn_r_4.png","dtn_r_5.png","dtn_r_6.png","dtn_r_7.png","dtn_r_8.png","dtn_r_9.png","dtn_r_10.png"],
                  minute_zero: 1,
                  minute_space: 5,
                  minute_follow: 0,
                  minute_align: hmUI.align.CENTER_H,
    
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                  bot_circle_state_txt = 'R E D';
				break;
							
              case 6:
                normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {

                  minute_startX: 310,
                  minute_startY: 170,
                  minute_array: ["dtn_p_1.png","dtn_p_2.png","dtn_p_3.png","dtn_p_4.png","dtn_p_5.png","dtn_p_6.png","dtn_p_7.png","dtn_p_8.png","dtn_p_9.png","dtn_p_10.png"],
                  minute_zero: 1,
                  minute_space: 5,
                  minute_follow: 0,
                  minute_align: hmUI.align.CENTER_H,
    
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                  bot_circle_state_txt = 'P U R P L E';
				break;
							
              case 7:
                normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {

                  minute_startX: 310,
                  minute_startY: 170,
                  minute_array: ["dtn_g_1.png","dtn_g_2.png","dtn_g_3.png","dtn_g_4.png","dtn_g_5.png","dtn_g_6.png","dtn_g_7.png","dtn_g_8.png","dtn_g_9.png","dtn_g_10.png"],
                  minute_zero: 1,
                  minute_space: 5,
                  minute_follow: 0,
                  minute_align: hmUI.align.CENTER_H,
    
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                  bot_circle_state_txt = 'G R A Y';
				
                    break;
				
              default:
            break;
          }
          
          hmUI.showToast({ text: bot_circle_state_txt });
        }	

   function call_change_Hours() {

          colornumber = (colornumber + 1) % (totalcolors);
  
          switch (colornumber) {
            case 0:
              normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                hour_startX: 21,
                hour_startY: 170,
                hour_array: ["dtn_1.png","dtn_2.png","dtn_3.png","dtn_4.png","dtn_5.png","dtn_6.png","dtn_7.png","dtn_8.png","dtn_9.png","dtn_10.png"],
                hour_zero: 1,
                hour_space: 5,
                hour_align: hmUI.align.CENTER_H,
  
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
           
              bot_circle_state_txt = 'B L U E';
              break;
              case 1:
                normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                  hour_startX: 21,
                  hour_startY: 170,
                  hour_array: ["dtn_y_1.png","dtn_y_2.png","dtn_y_3.png","dtn_y_4.png","dtn_y_5.png","dtn_y_6.png","dtn_y_7.png","dtn_y_8.png","dtn_y_9.png","dtn_y_10.png"],
                  hour_zero: 1,
                  hour_space: 5,
                  hour_align: hmUI.align.CENTER_H,

                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
       
                bot_circle_state_txt = 'L I M E';
                break;
              case 2:
                normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                  hour_startX: 21,
                  hour_startY: 170,
                  hour_array: ["dtn_b_1.png","dtn_b_2.png","dtn_b_3.png","dtn_b_4.png","dtn_b_5.png","dtn_b_6.png","dtn_b_7.png","dtn_b_8.png","dtn_b_9.png","dtn_b_10.png"],
                  hour_zero: 1,
                  hour_space: 5,
                  hour_align: hmUI.align.CENTER_H,
    
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                bot_circle_state_txt = 'W H I T E';
                break;
              case 3:
                  normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                    hour_startX: 21,
                    hour_startY: 170,
                    hour_array: ["dtn_o_1.png","dtn_o_2.png","dtn_o_3.png","dtn_o_4.png","dtn_o_5.png","dtn_o_6.png","dtn_o_7.png","dtn_o_8.png","dtn_o_9.png","dtn_o_10.png"],
                    hour_zero: 1,
                    hour_space: 5,
                    hour_align: hmUI.align.CENTER_H,
      
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                bot_circle_state_txt = 'O R A N G E';
				break;
              case 4:
                  normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                    hour_startX: 21,
                    hour_startY: 170,
                    hour_array: ["dtn_c_1.png","dtn_c_2.png","dtn_c_3.png","dtn_c_4.png","dtn_c_5.png","dtn_c_6.png","dtn_c_7.png","dtn_c_8.png","dtn_c_9.png","dtn_c_10.png"],
                    hour_zero: 1,
                    hour_space: 5,
                    hour_align: hmUI.align.CENTER_H,
      
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
      
                  bot_circle_state_txt = 'C Y A N';
				break;				  				
              case 5:
                  normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                    hour_startX: 21,
                    hour_startY: 170,
                    hour_array: ["dtn_r_1.png","dtn_r_2.png","dtn_r_3.png","dtn_r_4.png","dtn_r_5.png","dtn_r_6.png","dtn_r_7.png","dtn_r_8.png","dtn_r_9.png","dtn_r_10.png"],
                    hour_zero: 1,
                    hour_space: 5,
                    hour_follow: 0,
                    hour_align: hmUI.align.CENTER_H,
    
                   show_level: hmUI.show_level.ONLY_NORMAL,
                 }); 
				  
                  bot_circle_state_txt = 'R E D';
				break;							
              case 6:
                 normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                   hour_startX: 21,
                   hour_startY: 170,
                   hour_array: ["dtn_p_1.png","dtn_p_2.png","dtn_p_3.png","dtn_p_4.png","dtn_p_5.png","dtn_p_p6.png","dtn_p_7.png","dtn_p_8.png","dtn_p_9.png","dtn_p_10.png"],
                   hour_zero: 1,
                   hour_space: 5,
                   hour_follow: 0,
                   hour_align: hmUI.align.CENTER_H,
    
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                  bot_circle_state_txt = 'P U R P L E';
				break;
							
              case 7:
                 normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
                   hour_startX: 21,
                   hour_startY: 170,
                   hour_array: ["dtn_g_1.png","dtn_g_2.png","dtn_g_3.png","dtn_g_4.png","dtn_g_5.png","dtn_g_6.png","dtn_g_7.png","dtn_g_8.png","dtn_g_9.png","dtn_g_10.png"],
                   hour_zero: 1,
                   hour_space: 5,
                   hour_follow: 0,
                   hour_align: hmUI.align.CENTER_H,
    
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                  bot_circle_state_txt = 'G R A Y';
				  
                    break;
  
                default:
              break;
            }
            
            hmUI.showToast({ text: bot_circle_state_txt });
          }

          let delay_Timer = null;
          let clicks = 0;
          let clicksDelay = 400;       // задержка между кликами в мс 
  
        //--------------------- обработка множественных кликов (тапов) 1, 2, 3, ...  ---------------------	
   
        function checkClicks() {
  
          switch(clicks) {
            case 1:
              call_change_Hands();
           break;
            case 2:
              call_change_Hours(); // функции на двойной клик
           break;
          //  case 3:
          //    click_bot_ssmoth_Switcher() ;// функции на тройной клик
          // break;
           // case 4:
             // функции на 4-ной клик
           //break;
            default:
           break;
         }
          
         timer.stopTimer(delay_Timer);
         clicks = 0;
  
        }
		
		    function getClick() {		
    
          clicks++;
          if(delay_Timer) timer.stopTimer(delay_Timer);
          delay_Timer = timer.createTimer(clicksDelay, 0, checkClicks, {});
    
       }




        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 193,
              y: 17,
              src: '0041.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 355,
              y: 315,
              src: '0028.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 345,
              font_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
              padding: false,
              h_space: -1,
              unit_sc: '0027.png',
              unit_tc: '0027.png',
              unit_en: '0027.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 89,
              font_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              padding: false,
              h_space: 0,
              dot_image: '0040.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 89,
              font_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              padding: false,
              h_space: 0,
              dot_image: '0040.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 375,
              y: 133,
              font_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0051.png',
              unit_tc: '0051.png',
              unit_en: '0051.png',
              negative_image: '0012.png',
              invalid_image: '0052.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 328,
              y: 131,
              src: '0024.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 133,
              font_array: ["0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0051.png',
              unit_tc: '0051.png',
              unit_en: '0051.png',
              negative_image: '0012.png',
              invalid_image: '0052.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 49,
              y: 131,
              src: '0023.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 128,
              font_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0051.png',
              unit_tc: '0051.png',
              unit_en: '0051.png',
              negative_image: '0042.png',
              invalid_image: '0052.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 207,
              y: 53,
              image_array: ["0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 202,
              y: 184,
              week_en: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              week_tc: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              week_sc: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 201,
              month_startY: 277,
              month_sc_array: ["0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              month_tc_array: ["0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              month_en_array: ["0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 202,
              day_startY: 224,
              day_sc_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_tc_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_en_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 365,
              font_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 21,
              hour_startY: 170,
              hour_array: ["dtn_b_1.png","dtn_b_2.png","dtn_b_3.png","dtn_b_4.png","dtn_b_5.png","dtn_b_6.png","dtn_b_7.png","dtn_b_8.png","dtn_b_9.png","dtn_b_10.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 310,
              minute_startY: 170,
              minute_array: ["dtn_y_1.png","dtn_y_2.png","dtn_y_3.png","dtn_y_4.png","dtn_y_5.png","dtn_y_6.png","dtn_y_7.png","dtn_y_8.png","dtn_y_9.png","dtn_y_10.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 348,
              second_startY: 345,
              second_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 369,
              am_y: 383,
              am_sc_path: '0025.png',
              am_en_path: '0025.png',
              pm_x: 369,
              pm_y: 383,
              pm_sc_path: '0026.png',
              pm_en_path: '0026.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 3,
              y: 158,
              src: '0050.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 171,
              y: 436,
              font_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 193,
              y: 39,
              src: '0041.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 365,
              y: 296,
              src: '0028.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

             btn_color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 187, //x кнопки
              y: 0, //y кнопки
              text: '',
              w: 106, //ширина кнопки
              h: 70, //высота кнопки
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
                getClick();    //имя вызываемой функции
                vibro(2);
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_color.setProperty(hmUI.prop.VISIBLE, true);
				
            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 197,
              hour_startY: 196,
              hour_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_unit_sc: '2.png',
              hour_unit_tc: '2.png',
              hour_unit_en: '2.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 299,
              minute_startY: 170,
              minute_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 233,
              am_y: 297,
              am_sc_path: '0025.png',
              am_en_path: '0025.png',
              pm_x: 233,
              pm_y: 297,
              pm_sc_path: '0026.png',
              pm_en_path: '0026.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: Disconnected,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Connected,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Disconnected"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "Connected"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            console.log('Watch_Face.Shortcuts');

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 49,
              y: 340,
              w: 106,
              h: 106,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 170,
              w: 163,
              h: 160,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 321,
              y: 170,
              w: 151,
              h: 160,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 33,
              y: 42,
              w: 123,
              h: 123,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 325,
              y: 41,
              w: 123,
              h: 123,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 168,
              y: 74,
              w: 147,
              h: 85,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 327,
              w: 141,
              h: 63,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 167,
              y: 399,
              w: 145,
              h: 99,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 187,
              y: 169,
              w: 106,
              h: 69,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 336,
              y: 340,
              w: 103,
              h: 103,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 187,
              y: 248,
              w: 106,
              h: 69,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}