"""Génère les assets, les constantes de layout JS et un aperçu PNG du cadran."""
import json, os, shutil, math
from PIL import Image, ImageDraw, ImageFont

OUT = "/home/claude/trex3-face"
ASSETS = f"{OUT}/assets/default.r"
FONTS = "/home/claude/fonts"
DSEG = f"{FONTS}/fonts-DSEG_v046/DSEG7-Classic/DSEG7Classic-BoldItalic.ttf"
F_MED = f"{FONTS}/Barlow-Medium-sub.ttf"
F_SEMI = f"{FONTS}/Barlow-SemiBold-sub.ttf"

S = 480
CX = CY = 240
import os as _o
TEXT = (0xDC, 0xDE, 0xF7)
ACC = tuple(int("AEB2FF"[i:i+2],16) for i in (0,2,4))
TIMECOL = tuple(int("DCDEF7"[i:i+2],16) for i in (0,2,4))        # blanc lavande comme sur la photo
TEXT_HEX = 0xDCDEF7
AOD_HEX = 0x9A9CB0
BLUE_HEX = 0x7C82FF
TRACK_HEX = 0x1E2058
BLUE = (0x7C, 0x82, 0xFF)
TRACK = (0x1E, 0x20, 0x58)

RING = dict(radius=229, line_width=12)

# ---- textes : (clé, texte d'exemple, centre x, haut y, taille, police, largeur boîte)
LABEL, VALUE = 22, 34
texts = [
    ("temp", "4°", 252, 406, 28, "med", 70),
    ("date_day", "JEUDI", 240, 58, 34, "semi", 300),
    ("date", "26.NOV.2026", 240, 94, 40, "med", 300),
    ("cal_label", "CAL", 148, 318, LABEL, "semi", 110),
    ("cal_value", "433", 148, 346, VALUE, "med", 110),
    ("battery_label", "BATTERIE", 240, 318, LABEL, "semi", 110),
    ("battery_value", "83%", 240, 346, VALUE, "med", 110),
    ("steps_label", "PAS", 332, 318, LABEL, "semi", 110),
    ("steps_value", "2841", 332, 346, VALUE, "med", 110),
]

texts = [(k, t, cx, top + 4, sz, kd, w) for (k, t, cx, top, sz, kd, w) in texts]

# ---- heure en segments
BIG_H = 146       # hauteur des chiffres
SMALL_H = 50
TIME_Y = 154
SQ = 0.70


def font(kind, size):
    return ImageFont.truetype(F_SEMI if kind == "semi" else F_MED, size)


def render_glyphs(path_font, size, chars, color, pad=2, squeeze=1):
    """Rend chaque caractère sur une case de taille fixe (chasse fixe)."""
    f = ImageFont.truetype(path_font, size)
    asc, desc = f.getmetrics()
    boxes = {c: f.getbbox(c) for c in chars}
    left = min(b[0] for b in boxes.values())
    top = min(b[1] for b in boxes.values())
    right = max(b[2] for b in boxes.values())
    bottom = max(b[3] for b in boxes.values())
    w, h = right - left + pad * 2, bottom - top + pad * 2
    imgs = {}
    for c in chars:
        im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        ImageDraw.Draw(im).text((pad - left, pad - top), c, font=f, fill=color + (255,))
        if squeeze != 1:
            im = im.resize((round(w * squeeze), h), Image.LANCZOS)
        imgs[c] = im
    return imgs, ((round(w * squeeze) if squeeze != 1 else w), h)


def fit_size(path_font, target_h):
    size = target_h
    for _ in range(40):
        f = ImageFont.truetype(path_font, size)
        b = f.getbbox("8")
        if b[3] - b[1] >= target_h:
            break
        size += 2
    return size


def main():
    if os.path.exists(ASSETS):
        shutil.rmtree(ASSETS)
    for d in ["time", "time_s", "time_aod", "battery", "fonts", "icons"]:
        os.makedirs(f"{ASSETS}/{d}", exist_ok=True)
    os.makedirs(f"{OUT}/watchface", exist_ok=True)

    shutil.copy(F_MED, f"{ASSETS}/fonts/Barlow-Medium.ttf")
    shutil.copy(F_SEMI, f"{ASSETS}/fonts/Barlow-SemiBold.ttf")

    # --- chiffres de l'heure
    big_size = fit_size(DSEG, BIG_H)
    small_size = fit_size(DSEG, SMALL_H)
    big, (bw, bh) = render_glyphs(DSEG, big_size, "0123456789", TIMECOL, squeeze=SQ)
    big_aod, _ = render_glyphs(DSEG, big_size, "0123456789", tuple((AOD_HEX >> s) & 255 for s in (16, 8, 0)), squeeze=SQ)
    small, (sw, sh) = render_glyphs(DSEG, small_size, "0123456789", BLUE, squeeze=SQ)
    colon_imgs, (cw, ch) = render_glyphs(DSEG, big_size, ":", TIMECOL, squeeze=SQ)
    # resserrer le deux-points
    colon = colon_imgs[":"]
    cb = colon.getbbox()
    colon = colon.crop((max(cb[0] - 6, 0), 0, min(cb[2] + 6, colon.width), colon.height))
    colon_aod = colon.copy()
    px_ = colon_aod.load()
    for y in range(colon_aod.height):
        for x in range(colon_aod.width):
            r, g, b, a = px_[x, y]
            if a:
                px_[x, y] = ((AOD_HEX >> 16) & 255, (AOD_HEX >> 8) & 255, AOD_HEX & 255, a)

    for c in "0123456789":
        big[c].save(f"{ASSETS}/time/{c}.png")
        big_aod[c].save(f"{ASSETS}/time_aod/{c}.png")
        small[c].save(f"{ASSETS}/time_s/{c}.png")
    colon.save(f"{ASSETS}/time/colon.png")
    colon_aod.save(f"{ASSETS}/time_aod/colon.png")

    gap = -6  # chevauchement léger, typique des afficheurs segmentés italiques
    time_w = bw * 4 + colon.width + gap * 4
    sec_gap = 6
    total_w = time_w + sec_gap + sw * 2 + gap
    x0 = CX - total_w // 2 - 4
    hour_x = x0
    min_x = x0 + bw * 2 + gap * 2 + colon.width  # IMG_TIME place le deux-points après l'heure
    sec_x = x0 + time_w + sec_gap
    sec_y = TIME_Y + bh - sh

    # --- barre de batterie (21 niveaux : 0 à 20 segments)
    SEG_N, SEG_W, SEG_STEP, SEG_H = 20, 5, 10, 26
    bar_w = SEG_N * SEG_STEP
    for lvl in range(SEG_N + 1):
        im = Image.new("RGBA", (bar_w, SEG_H), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        for i in range(SEG_N):
            col = TEXT + (255,) if i < lvl else (0x3A, 0x3B, 0x48, 255)
            d.rounded_rectangle((i * SEG_STEP, 0, i * SEG_STEP + SEG_W, SEG_H - 1), radius=2, fill=col)
        im.save(f"{ASSETS}/battery/{lvl}.png")
    bar_x, bar_y = 150, 290

    # icône pile
    bi = Image.new("RGBA", (16, 26), (0, 0, 0, 0))
    d = ImageDraw.Draw(bi)
    d.rectangle((5, 0, 10, 3), fill=TEXT + (255,))
    d.rounded_rectangle((1, 3, 14, 25), radius=2, fill=TEXT + (255,))
    bi.save(f"{ASSETS}/icons/battery.png")
    bicon_x, bicon_y = 122, 290

    th = Image.new("RGBA", (16, 30), (0, 0, 0, 0))
    td = ImageDraw.Draw(th)
    td.rounded_rectangle((5, 1, 11, 20), radius=3, outline=ACC + (255,), width=2)
    td.ellipse((2, 16, 14, 28), fill=ACC + (255,))
    td.rectangle((7, 9, 9, 20), fill=ACC + (255,))
    th.save(f"{ASSETS}/icons/thermo.png")
    THERMO_X, THERMO_Y = 212, 416

    # --- constantes JS
    L = {
        "COLOR_TEXT": TEXT_HEX, "COLOR_AOD": AOD_HEX, "COLOR_BLUE": BLUE_HEX, "COLOR_TRACK": TRACK_HEX,
        "RING": dict(center_x=CX, center_y=CY, **RING),
        "TIME": dict(hour_x=hour_x, min_x=min_x, colon_x=hour_x + 2 * (bw + gap), y=TIME_Y, sec_x=sec_x, sec_y=sec_y, space=gap),
        "BATTERY_BAR": dict(x=bar_x, y=bar_y, n=SEG_N + 1),
        "BATTERY_ICON": dict(x=bicon_x, y=bicon_y),
        "THERMO": dict(x=THERMO_X, y=THERMO_Y),
        "COLOR_ACCENT": (ACC[0] << 16) | (ACC[1] << 8) | ACC[2],
        "TEXTS": {},
    }
    for key, sample, cx, top, size, kind, w in texts:
        h = round(size * 1.25)
        L["TEXTS"][key] = dict(x=cx - w // 2, y=top, w=w, h=h, size=size,
                               font=f"fonts/Barlow-{'SemiBold' if kind == 'semi' else 'Medium'}.ttf")
    with open(f"{OUT}/watchface/layout.const.js", "w") as fjs:
        fjs.write("// Fichier généré par gen.py — coordonnées pour un écran 480 x 480\n")
        fjs.write("export const L = " + json.dumps(L, indent=2) + ";\n")

    # --- aperçu
    def preview(sample_steps=2841, goal=8000, size=S):
        im = Image.new("RGBA", (S, S), (0, 0, 0, 255))
        d = ImageDraw.Draw(im)
        r, lw = RING["radius"], RING["line_width"]
        box = (CX - r - lw / 2, CY - r - lw / 2, CX + r + lw / 2, CY + r + lw / 2)
        d.arc(box, 0, 360, fill=TRACK, width=lw)
        pct = min(sample_steps / goal, 1)
        d.arc(box, -90, -90 + 360 * pct, fill=BLUE, width=lw)
        for key, sample, cx, top, sz, kind, w in texts:
            f = font(kind, sz)
            h = round(sz * 1.25)
            d.text((cx, top + h / 2), sample, font=f, fill=(ACC if key.endswith("label") or key=="date_day" else TEXT), anchor="mm")
        for i, c in enumerate("17"):
            im.alpha_composite(big[c], (hour_x + i * (bw + gap), TIME_Y))
        im.alpha_composite(colon, (hour_x + 2 * (bw + gap), TIME_Y))
        for i, c in enumerate("09"):
            im.alpha_composite(big[c], (min_x + i * (bw + gap), TIME_Y))
        for i, c in enumerate("09"):
            im.alpha_composite(small[c], (sec_x + i * (sw + gap), sec_y))
        im.alpha_composite(th, (THERMO_X, THERMO_Y))
        mask = Image.new("L", (S, S), 0)
        ImageDraw.Draw(mask).ellipse((0, 0, S - 1, S - 1), fill=255)
        out = Image.new("RGBA", (S, S), (0, 0, 0, 0))
        out.paste(im, (0, 0), mask)
        return out

    pv = preview()
    pv.save("/home/claude/apercu-final.png")
    pv.convert("RGB").resize((324, 324), Image.LANCZOS).save(f"{ASSETS}/cover.png")
    pv.resize((248, 248), Image.LANCZOS).save(f"{ASSETS}/icon.png")
    print("ok", dict(bw=bw, bh=bh, sw=sw, sh=sh, colon=colon.width, total_w=total_w, x0=x0))


if __name__ == "__main__":
    main()
