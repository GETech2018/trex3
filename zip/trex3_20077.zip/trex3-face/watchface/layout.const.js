// Fichier généré par gen.py — coordonnées pour un écran 480 x 480
export const L = {
  "COLOR_TEXT": 14474999,
  "COLOR_AOD": 10132656,
  "COLOR_BLUE": 8159999,
  "COLOR_TRACK": 1974360,
  "RING": {
    "center_x": 240,
    "center_y": 240,
    "radius": 229,
    "line_width": 12
  },
  "TIME": {
    "hour_x": 34,
    "min_x": 217,
    "colon_x": 194,
    "y": 154,
    "sec_x": 383,
    "sec_y": 250,
    "space": -6
  },
  "BATTERY_BAR": {
    "x": 150,
    "y": 290,
    "n": 21
  },
  "BATTERY_ICON": {
    "x": 122,
    "y": 290
  },
  "THERMO": {
    "x": 212,
    "y": 416
  },
  "COLOR_ACCENT": 11449087,
  "TEXTS": {
    "temp": {
      "x": 217,
      "y": 410,
      "w": 70,
      "h": 35,
      "size": 28,
      "font": "fonts/Barlow-Medium.ttf"
    },
    "date_day": {
      "x": 90,
      "y": 62,
      "w": 300,
      "h": 42,
      "size": 34,
      "font": "fonts/Barlow-SemiBold.ttf"
    },
    "date": {
      "x": 90,
      "y": 98,
      "w": 300,
      "h": 50,
      "size": 40,
      "font": "fonts/Barlow-Medium.ttf"
    },
    "cal_label": {
      "x": 93,
      "y": 322,
      "w": 110,
      "h": 28,
      "size": 22,
      "font": "fonts/Barlow-SemiBold.ttf"
    },
    "cal_value": {
      "x": 93,
      "y": 350,
      "w": 110,
      "h": 42,
      "size": 34,
      "font": "fonts/Barlow-Medium.ttf"
    },
    "battery_label": {
      "x": 185,
      "y": 322,
      "w": 110,
      "h": 28,
      "size": 22,
      "font": "fonts/Barlow-SemiBold.ttf"
    },
    "battery_value": {
      "x": 185,
      "y": 350,
      "w": 110,
      "h": 42,
      "size": 34,
      "font": "fonts/Barlow-Medium.ttf"
    },
    "steps_label": {
      "x": 277,
      "y": 322,
      "w": 110,
      "h": 28,
      "size": 22,
      "font": "fonts/Barlow-SemiBold.ttf"
    },
    "steps_value": {
      "x": 277,
      "y": 350,
      "w": 110,
      "h": 42,
      "size": 34,
      "font": "fonts/Barlow-Medium.ttf"
    }
  }
};
