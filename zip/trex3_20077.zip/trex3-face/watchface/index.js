import { L } from './layout.const';

const WEEK = ['LUNDI', 'MARDI', 'MERCREDI', 'JEUDI', 'VENDREDI', 'SAMEDI', 'DIMANCHE'];
const MONTHS = ['JAN', 'FÉV', 'MAR', 'AVR', 'MAI', 'JUN', 'JUL', 'AOÛ', 'SEP', 'OCT', 'NOV', 'DÉC'];

const NORMAL = hmUI.show_level.ONLY_NORMAL;
const AOD = hmUI.show_level.ONAL_AOD;

const digits = (dir) => new Array(10).fill(0).map((_, i) => `${dir}/${i}.png`);
const pad2 = (n) => (n < 10 ? '0' : '') + n;

function textProps(key, extra = {}) {
  const t = L.TEXTS[key];
  return {
    x: px(t.x),
    y: px(t.y),
    w: px(t.w),
    h: px(t.h),
    text_size: px(t.size),
    font: t.font,
    color: L.COLOR_TEXT,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.CENTER_V,
    text: '',
    show_level: NORMAL,
    ...extra,
  };
}

WatchFace({
  build() {
    this.timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
    this.batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
    this.stepSensor = hmSensor.createSensor(hmSensor.id.STEP);

    this.buildRing();
    this.buildDate();
    this.buildTime();
    this.buildTemperature();
    this.buildBottom();
    this.bindUpdates();
  },

  // Anneau bleu de progression des pas (part de midi, sens horaire)
  buildRing() {
    const base = {
      center_x: px(L.RING.center_x),
      center_y: px(L.RING.center_y),
      radius: px(L.RING.radius),
      start_angle: -90,
      end_angle: 270,
      line_width: px(L.RING.line_width),
      show_level: NORMAL,
    };
    hmUI.createWidget(hmUI.widget.ARC_PROGRESS, { ...base, color: L.COLOR_TRACK, level: 100 });
    this.ring = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, { ...base, color: L.COLOR_BLUE, level: 0 });
  },

  buildDate() {
    this.dayText = hmUI.createWidget(hmUI.widget.TEXT, textProps('date_day', { color: L.COLOR_ACCENT }));
    this.dateText = hmUI.createWidget(hmUI.widget.TEXT, textProps('date'));
    this.dayTextAod = hmUI.createWidget(
      hmUI.widget.TEXT,
      textProps('date_day', { color: L.COLOR_AOD, show_level: AOD }),
    );
    this.dateTextAod = hmUI.createWidget(
      hmUI.widget.TEXT,
      textProps('date', { color: L.COLOR_AOD, show_level: AOD }),
    );
  },

  buildTime() {
    const T = L.TIME;
    const make = (dir, level) =>
      hmUI.createWidget(hmUI.widget.IMG_TIME, {
        hour_zero: 1,
        hour_startX: px(T.hour_x),
        hour_startY: px(T.y),
        hour_array: digits(dir),
        hour_space: px(T.space),
        hour_align: hmUI.align.LEFT,
        minute_zero: 1,
        minute_startX: px(T.min_x),
        minute_startY: px(T.y),
        minute_array: digits(dir),
        minute_space: px(T.space),
        minute_align: hmUI.align.LEFT,
        show_level: level,
      });
    make('time', NORMAL);
    make('time_aod', AOD);
    hmUI.createWidget(hmUI.widget.IMG, { x: px(T.colon_x), y: px(T.y), src: 'time/colon.png', show_level: NORMAL });
    hmUI.createWidget(hmUI.widget.IMG, { x: px(T.colon_x), y: px(T.y), src: 'time_aod/colon.png', show_level: AOD });

    hmUI.createWidget(hmUI.widget.IMG_TIME, {
      second_zero: 1,
      second_startX: px(T.sec_x),
      second_startY: px(T.sec_y),
      second_array: digits('time_s'),
      second_space: px(T.space),
      second_align: hmUI.align.LEFT,
      show_level: NORMAL,
    });
  },

  buildTemperature() {
    hmUI.createWidget(hmUI.widget.IMG, {
      x: px(L.THERMO.x),
      y: px(L.THERMO.y),
      src: 'icons/thermo.png',
      show_level: NORMAL,
    });
    hmUI.createWidget(hmUI.widget.TEXT_FONT, {
      ...textProps('temp'),
      type: hmUI.data_type.WEATHER_CURRENT,
      unit_type: 1,
    });
  },

  buildBottom() {
    hmUI.createWidget(hmUI.widget.TEXT, textProps('cal_label', { text: 'CAL', color: L.COLOR_ACCENT }));
    hmUI.createWidget(hmUI.widget.TEXT, textProps('battery_label', { text: 'BATTERIE', color: L.COLOR_ACCENT }));
    hmUI.createWidget(hmUI.widget.TEXT, textProps('steps_label', { text: 'PAS', color: L.COLOR_ACCENT }));
    hmUI.createWidget(hmUI.widget.TEXT_FONT, { ...textProps('cal_value'), type: hmUI.data_type.CAL });
    this.batteryText = hmUI.createWidget(hmUI.widget.TEXT, textProps('battery_value'));
    this.stepsText = hmUI.createWidget(hmUI.widget.TEXT, textProps('steps_value'));
  },

  // ---- mises à jour
  updateDate() {
    const { week, day, month, year } = this.timeSensor;
    const dayName = WEEK[week - 1];
    const text = `${pad2(day)}.${MONTHS[month - 1]}.${year}`;
    this.dayText.setProperty(hmUI.prop.TEXT, dayName);
    this.dayTextAod.setProperty(hmUI.prop.TEXT, dayName);
    this.dateText.setProperty(hmUI.prop.TEXT, text);
    this.dateTextAod.setProperty(hmUI.prop.TEXT, text);
  },

  updateBattery() {
    const { current = 0 } = this.batterySensor;
    this.batteryText.setProperty(hmUI.prop.TEXT, `${current}%`);
  },

  updateSteps() {
    const { current = 0, target = 8000 } = this.stepSensor;
    const goal = target > 0 ? target : 8000;
    const level = Math.max(0, Math.min(100, Math.round((100 * current) / goal)));
    this.ring.setProperty(hmUI.prop.LEVEL, level);
    this.stepsText.setProperty(hmUI.prop.TEXT, `${current}`);
  },

  bindUpdates() {
    const onMinute = () => this.updateDate();
    const onSteps = () => this.updateSteps();
    const onBattery = () => this.updateBattery();
    const ts = this.timeSensor;

    hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
      resume_call: () => {
        const screen = hmSetting.getScreenType();
        ts.addEventListener?.(ts.event.MINUTEEND, onMinute);
        this.updateDate();
        if (screen == hmSetting.screen_type.WATCHFACE) {
          this.stepSensor.addEventListener?.(hmSensor.event.CHANGE, onSteps);
          this.batterySensor.addEventListener?.(hmSensor.event.CHANGE, onBattery);
          this.updateSteps();
          this.updateBattery();
        }
      },
      pause_call: () => {
        ts.removeEventListener?.(ts.event.MINUTEEND, onMinute);
        this.stepSensor.removeEventListener?.(hmSensor.event.CHANGE, onSteps);
        this.batterySensor.removeEventListener?.(hmSensor.event.CHANGE, onBattery);
      },
    });

    // premier affichage
    this.updateDate();
    this.updateSteps();
    this.updateBattery();
  },
});
