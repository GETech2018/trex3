# T-Rex Steps Ring — cadran Zepp OS pour Amazfit T-Rex 3 (480 x 480)

Cadran digital en français (date sur 2 lignes, grande heure bleue, CAL · BATTERIE · PAS, température),
avec un anneau bleu tout autour qui se remplit selon l'objectif de pas.

## Installer sur la montre
1. Installer Node.js puis l'outil Zepp :  `npm i -g @zeppos/zeus-cli`
2. Dans ce dossier :  `zeus login`  (compte développeur Zepp gratuit)
3. Dans l'appli Zepp sur le téléphone : Profil > Paramètres > À propos,
   tapoter 7 fois le logo Zepp pour activer le mode développeur.
4. `zeus preview` → choisir « Amazfit T-Rex 3 » → scanner le QR code
   dans Zepp (Profil > Mode développeur > Scan).
Pour un paquet installable : `zeus build` (fichier .zab dans dist/).

## Modifier
- watchface/index.js : logique et widgets
- tools/gen.py : régénère les images (chiffres, barre batterie) et
  watchface/layout.const.js (positions). Nécessite Pillow + polices Barlow / DSEG7.
