﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let cc = 0
       // SWITHC Weather / Calories+HeartRate

        let elementnumber_1 = 1
        let total_elemente = 2

        function click_elemente() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }

            }
            if(elementnumber_1==1) hmUI.showToast({text: 'Weather'});
            if(elementnumber_1==2) hmUI.showToast({text: 'Calories & Pulse'});
        }

        //Weather
        function UpdateElementeOne(){

        normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);

       normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);


        }

        //Calories & Pulse
        function UpdateElementeTwo(){

        normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

       normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

        normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        }

////////////////////////////////////////////


        // Change color style
        let colornumber_main = 1
        let totalcolors_main = 6
        let namecolor_main = ''

        function click_ColorStyle() {
            if(colornumber_main>=totalcolors_main) {
            colornumber_main=1;
                }
            else {
                colornumber_main=colornumber_main+1;
            }

if ( colornumber_main == 1) { namecolor_main = "RED"}
if ( colornumber_main == 2) { namecolor_main = "ORANGE"}
if ( colornumber_main == 3) { namecolor_main = "GREEN"}
if ( colornumber_main == 4) { namecolor_main = "CYAN"}
if ( colornumber_main == 5) { namecolor_main = "BLUE"}
if ( colornumber_main == 6) { namecolor_main = "GRAY"}
hmUI.showToast({text: namecolor_main });

        normal_image_img.setProperty(hmUI.prop.SRC, "Top_main" + parseInt(colornumber_main) + ".png");
        normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "Hand_H" + parseInt(colornumber_main) + ".png");
        normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "Hand_M" + parseInt(colornumber_main) + ".png");
                           
        }


        // Change color Hour
        let colornumber_mainH = 1
        let totalcolors_mainH = 6
        let namecolor_mainH = ''

        function click_ColorH() {
            if(colornumber_mainH>=totalcolors_mainH) {
            colornumber_mainH=1;
                }
            else {
                colornumber_mainH=colornumber_mainH+1;
            }

if ( colornumber_mainH == 1) { namecolor_mainH = "RED"}
if ( colornumber_mainH == 2) { namecolor_mainH = "ORANGE"}
if ( colornumber_mainH == 3) { namecolor_mainH = "GREEN"}
if ( colornumber_mainH == 4) { namecolor_mainH = "CYAN"}
if ( colornumber_mainH == 5) { namecolor_mainH = "BLUE"}
if ( colornumber_mainH == 6) { namecolor_mainH = "GRAY"}
hmUI.showToast({text: namecolor_mainH });

  //      normal_image_img.setProperty(hmUI.prop.SRC, "Top_main" + parseInt(colornumber_main) + ".png");
 normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "Hand_H" + parseInt(colornumber_mainH) + ".png");
   //     normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "Hand_M" + parseInt(colornumber_main) + ".png");
                           
        }

        // Change color Minute
        let colornumber_mainM = 1
        let totalcolors_mainM = 6
        let namecolor_mainM = ''

        function click_ColorM() {
            if(colornumber_mainM>=totalcolors_mainM) {
            colornumber_mainM=1;
                }
            else {
                colornumber_mainM=colornumber_mainM+1;
            }

if ( colornumber_mainM == 1) { namecolor_mainM = "RED"}
if ( colornumber_mainM == 2) { namecolor_mainM = "ORANGE"}
if ( colornumber_mainM == 3) { namecolor_mainM = "GREEN"}
if ( colornumber_mainM == 4) { namecolor_mainM = "CYAN"}
if ( colornumber_mainM == 5) { namecolor_mainM = "BLUE"}
if ( colornumber_mainM == 6) { namecolor_mainM = "GRAY"}
hmUI.showToast({text: namecolor_mainM });

  //normal_image_img.setProperty(hmUI.prop.SRC, "Top_main" + parseInt(colornumber_main) + ".png");
 //normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "Hand_H" + parseInt(colornumber_mainH) + ".png");
 normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "Hand_M" + parseInt(colornumber_mainM) + ".png");
                           
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_battery_circle_scale = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_image_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_distance_TextRotate = new Array(5);
        let normal_distance_TextRotate_ASCIIARRAY = new Array(10);
        let normal_distance_TextRotate_img_width = 1;
        let normal_distance_TextRotate_unit = null;
        let normal_distance_TextRotate_unit_width = 25;
        let normal_distance_TextRotate_dot_width = 1;
        let normal_distance_TextRotate_error_img_width = 1;
        let normal_distance_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let image_top_img = ''
        let normal_battery_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 211,
              // end_angle: 380,
              // radius: 140,
              // line_width: 33,
              // line_cap: Flat,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 211,
              end_angle: 380,
              radius: 124,
              line_width: 33,
              corner_flag: 3,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_H1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 188,
              // y: 192,
              // start_angle: 229,
              // end_angle: 391,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 188,
              pos_y: 240 - 192,
              center_x: 240,
              center_y: 240,
              src: 'Hand_H1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_M1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 232,
              // y: 237,
              // start_angle: 213,
              // end_angle: 385,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 232,
              pos_y: 240 - 237,
              center_x: 240,
              center_y: 240,
              src: 'Hand_M1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0_Empty.png',
              // center_x: 0,
              // center_y: 0,
              // x: 0,
              // y: 0,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 0 - 0,
              pos_y: 0 - 0,
              center_x: 0,
              center_y: 0,
              src: '0_Empty.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + (360*(animDuration*6/1000))/360,
                repeat_count: 1,
                anim_fps: 15,
                anim_key: 'angle',
                anim_status: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 1,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 16,
              y: 18,
              src: 'Top_main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 138,
              y: 342,
              src: 'Windows_Heart_Cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 378,
              font_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 423,
              font_array: ["Heart_0.png","Heart_1.png","Heart_2.png","Heart_3.png","Heart_4.png","Heart_5.png","Heart_6.png","Heart_7.png","Heart_8.png","Heart_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 300,
              y: 426,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 138,
              y: 342,
              src: 'Windows_weather.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 181,
              y: 356,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 239,
              y: 431,
              font_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Temp_HL_C.png',
              unit_tc: 'Temp_HL_C.png',
              unit_en: 'Temp_HL_C.png',
              imperial_unit_sc: 'Temp_HL_F.png',
              imperial_unit_tc: 'Temp_HL_F.png',
              imperial_unit_en: 'Temp_HL_F.png',
              negative_image: 'Temp_HL_error.png',
              invalid_image: 'Temp_HL_error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_high_text_img.setProperty(hmUI.prop.MORE, {
                x: 239,
                y: 431,
                font_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
                padding: false,
                h_space: 2,
                unit_sc: 'Temp_HL_F.png',
                unit_tc: 'Temp_HL_F.png',
                unit_en: 'Temp_HL_F.png',
                imperial_unit_sc: 'Temp_HL_C.png',
                imperial_unit_tc: 'Temp_HL_C.png',
                imperial_unit_en: 'Temp_HL_C.png',
                negative_image: 'Temp_HL_error.png',
                invalid_image: 'Temp_HL_error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_HIGH,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 431,
              font_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Temp_HL_C.png',
              unit_tc: 'Temp_HL_C.png',
              unit_en: 'Temp_HL_C.png',
              imperial_unit_sc: 'Temp_HL_F.png',
              imperial_unit_tc: 'Temp_HL_F.png',
              imperial_unit_en: 'Temp_HL_F.png',
              negative_image: 'Temp_HL_error.png',
              invalid_image: 'Temp_HL_error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_low_text_img.setProperty(hmUI.prop.MORE, {
                x: 184,
                y: 431,
                font_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
                padding: false,
                h_space: 2,
                unit_sc: 'Temp_HL_F.png',
                unit_tc: 'Temp_HL_F.png',
                unit_en: 'Temp_HL_F.png',
                imperial_unit_sc: 'Temp_HL_C.png',
                imperial_unit_tc: 'Temp_HL_C.png',
                imperial_unit_en: 'Temp_HL_C.png',
                negative_image: 'Temp_HL_error.png',
                invalid_image: 'Temp_HL_error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_LOW,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 234,
              y: 377,
              font_array: ["Heart_0.png","Heart_1.png","Heart_2.png","Heart_3.png","Heart_4.png","Heart_5.png","Heart_6.png","Heart_7.png","Heart_8.png","Heart_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'TempC.png',
              unit_tc: 'TempC.png',
              unit_en: 'TempC.png',
              imperial_unit_sc: 'TempF.png',
              imperial_unit_tc: 'TempF.png',
              imperial_unit_en: 'TempF.png',
              negative_image: 'Temp_Err.png',
              invalid_image: 'Temp_Err.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 234,
                y: 377,
                font_array: ["Heart_0.png","Heart_1.png","Heart_2.png","Heart_3.png","Heart_4.png","Heart_5.png","Heart_6.png","Heart_7.png","Heart_8.png","Heart_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'TempF.png',
                unit_tc: 'TempF.png',
                unit_en: 'TempF.png',
                imperial_unit_sc: 'TempC.png',
                imperial_unit_tc: 'TempC.png',
                imperial_unit_en: 'TempC.png',
                negative_image: 'Temp_Err.png',
                invalid_image: 'Temp_Err.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 301,
              y: 404,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 354,
              // y: 364,
              // font_array: ["E0.png","E1.png","E2.png","E3.png","E4.png","E5.png","E6.png","E7.png","E8.png","E9.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 0,
              // unit_en: 'Dis_KM.png',
              // imperial_unit_en: 'Dis_Mi.png',
              // invalid_image: 'E1.png',
              // dot_image: 'E0.png',
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextRotate_ASCIIARRAY[0] = 'E0.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = 'E1.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = 'E2.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = 'E3.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = 'E4.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = 'E5.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = 'E6.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = 'E7.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = 'E8.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = 'E9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 354,
                center_y: 364,
                pos_x: 354,
                pos_y: 364,
                angle: 0,
                src: 'E0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 354,
              center_y: 364,
              pos_x: 354,
              pos_y: 364,
              angle: 0,
              src: 'Dis_KM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Dis_Mi.png');
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 336,
              y: 339,
              font_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 330,
              y: 172,
              src: 'Clock_24H.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'step_Pointer.png',
              center_x: 374,
              center_y: 324,
              x: 7,
              y: 57,
              start_angle: 259,
              end_angle: 460,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 331,
              y: 311,
              font_array: ["Time_S_0.png","Time_S_1.png","Time_S_2.png","Time_S_3.png","Time_S_4.png","Time_S_5.png","Time_S_6.png","Time_S_7.png","Time_S_8.png","Time_S_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 330,
              am_y: 170,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 330,
              pm_y: 170,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 406,
              second_startY: 224,
              second_array: ["Heart_0.png","Heart_1.png","Heart_2.png","Heart_3.png","Heart_4.png","Heart_5.png","Heart_6.png","Heart_7.png","Heart_8.png","Heart_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 366,
              minute_startY: 169,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 345,
              y: 228,
              src: 'System_BT_On.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 343,
              hour_startY: 111,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 379,
              y: 229,
              src: 'System_Alarm_OFF.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 212,
              month_startY: 254,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 212,
              day_startY: 212,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 345,
              y: 228,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 380,
              y: 228,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 159,
              y: 161,
              week_en: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_tc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_sc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 377,
              minute_startY: 248,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 377,
              hour_startY: 187,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 401,
              am_y: 163,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 401,
              pm_y: 163,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 339,
              y: 221,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 309,
              y: 232,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'pst.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 258,
              y: 95,
              w: 67,
              h: 67,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 327,
              y: 278,
              w: 93,
              h: 57,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 206,
              y: 416,
              w: 91,
              h: 36,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 295,
              y: 400,
              w: 38,
              h: 57,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 185,
              y: 390,
              w: 101,
              h: 73,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 148,
              y: 410,
              w: 46,
              h: 46,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 350,
              y: 104,
              w: 67,
              h: 57,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 373,
              y: 167,
              w: 67,
              h: 52,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 364,
              y: 221,
              w: 52,
              h: 52,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 194,
              y: 197,
              w: 90,
              h: 91,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 185,
              y: 322,
              w: 106,
              h: 52,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // swithc weather , ( Cal-heart)
                click_elemente()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 338,
              y: 380,
              w: 71,
              h: 72,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // change style color
                click_ColorStyle()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 40,
              y: 208,
              w: 67,
              h: 67,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //change color Hour
                click_ColorH()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 206,
              y: 0,
              w: 67,
              h: 67,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                //Change color minute
                click_ColorM()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if ( cc == 0 )
{
UpdateElementeOne()
cc =1
}
            // end user_script_end.js

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 162;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 229 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 172;
                let normal_angle_minute = 213 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
            };

            //end of ignored block
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_rotate_string.length > 0 && normal_distance_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 354 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, normal_distance_TextRotate_ASCIIARRAY[charCode]);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_img_width;
                      index++;
                    }  // end if digit
                    else { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 354 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'E0.png');
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_dot_width;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 354 + img_offset);
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 354);
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.SRC, 'E1.png');
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 211,
                      end_angle: 380,
                      radius: 124,
                      line_width: 33,
                      corner_flag: 3,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                let secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 0 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}