﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 20;
        let normal_sun_icon_img = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_altitude_target_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_current_text_font = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_image_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''
        let Button_13 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Roboto-Light.ttf; FontSize: 33
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 385,
              h: 46,
              text_size: 33,
              char_space: -1,
              line_space: 0,
              font: 'fonts/Roboto-Light.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Roboto-Regular.ttf; FontSize: 26
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 346,
              h: 38,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto-Regular.ttf',
              color: 0xFFCEE733,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: RobotoCondensed-Regular.ttf; FontSize: 31
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 333,
              h: 44,
              text_size: 31,
              char_space: -1,
              line_space: 0,
              font: 'fonts/RobotoCondensed-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Roboto-Light.ttf; FontSize: 34
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 436,
              h: 49,
              text_size: 34,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto-Light.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'WF---Garmin-Instinct-3-BGV-3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 24,
              // y: 268,
              // font_array: ["WF---Garmin-Instinct-3-STEP-00.png","WF---Garmin-Instinct-3-STEP-01.png","WF---Garmin-Instinct-3-STEP-02.png","WF---Garmin-Instinct-3-STEP-03.png","WF---Garmin-Instinct-3-STEP-04.png","WF---Garmin-Instinct-3-STEP-05.png","WF---Garmin-Instinct-3-STEP-06.png","WF---Garmin-Instinct-3-STEP-07.png","WF---Garmin-Instinct-3-STEP-08.png","WF---Garmin-Instinct-3-STEP-09.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: -90,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'WF---Garmin-Instinct-3-STEP-00.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'WF---Garmin-Instinct-3-STEP-01.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'WF---Garmin-Instinct-3-STEP-02.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'WF---Garmin-Instinct-3-STEP-03.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'WF---Garmin-Instinct-3-STEP-04.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'WF---Garmin-Instinct-3-STEP-05.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'WF---Garmin-Instinct-3-STEP-06.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'WF---Garmin-Instinct-3-STEP-07.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'WF---Garmin-Instinct-3-STEP-08.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'WF---Garmin-Instinct-3-STEP-09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 24,
                center_y: 268,
                pos_x: 24,
                pos_y: 268,
                angle: -90,
                src: 'WF---Garmin-Instinct-3-STEP-00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 211,
              y: 413,
              src: 'WF---Garmin-Instinct-3-SUNRISE-00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 60,
              y: 412,
              w: 150,
              h: 31,
              text_size: 33,
              char_space: -1,
              line_space: 0,
              font: 'fonts/Roboto-Light.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 273,
              y: 412,
              w: 150,
              h: 31,
              text_size: 33,
              char_space: -1,
              line_space: 0,
              font: 'fonts/Roboto-Light.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 363,
              y: 115,
              image_array: ["0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 265,
              y: 176,
              w: 150,
              h: 25,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto-Regular.ttf',
              color: 0xFFCEE733,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 265,
              y: 142,
              w: 150,
              h: 25,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 367,
              y: 165,
              w: 150,
              h: 37,
              text_size: 31,
              char_space: -1,
              line_space: 0,
              font: 'fonts/RobotoCondensed-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 316,
              y: 237,
              w: 150,
              h: 32,
              text_size: 34,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto-Light.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 316,
              y: 287,
              w: 150,
              h: 32,
              text_size: 34,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto-Light.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 98,
              y: 51,
              week_en: ["WF---Garmin-Instinct-3-WEEK-01.png","WF---Garmin-Instinct-3-WEEK-02.png","WF---Garmin-Instinct-3-WEEK-03.png","WF---Garmin-Instinct-3-WEEK-04.png","WF---Garmin-Instinct-3-WEEK-05.png","WF---Garmin-Instinct-3-WEEK-06.png","WF---Garmin-Instinct-3-WEEK-07.png"],
              week_tc: ["WF---Garmin-Instinct-3-WEEK-01.png","WF---Garmin-Instinct-3-WEEK-02.png","WF---Garmin-Instinct-3-WEEK-03.png","WF---Garmin-Instinct-3-WEEK-04.png","WF---Garmin-Instinct-3-WEEK-05.png","WF---Garmin-Instinct-3-WEEK-06.png","WF---Garmin-Instinct-3-WEEK-07.png"],
              week_sc: ["WF---Garmin-Instinct-3-WEEK-01.png","WF---Garmin-Instinct-3-WEEK-02.png","WF---Garmin-Instinct-3-WEEK-03.png","WF---Garmin-Instinct-3-WEEK-04.png","WF---Garmin-Instinct-3-WEEK-05.png","WF---Garmin-Instinct-3-WEEK-06.png","WF---Garmin-Instinct-3-WEEK-07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 195,
              month_startY: 22,
              month_sc_array: ["WF---Garmin-Instinct-3-MES-01.png","WF---Garmin-Instinct-3-MES-02.png","WF---Garmin-Instinct-3-MES-03.png","WF---Garmin-Instinct-3-MES-04.png","WF---Garmin-Instinct-3-MES-05.png","WF---Garmin-Instinct-3-MES-06.png","WF---Garmin-Instinct-3-MES-07.png","WF---Garmin-Instinct-3-MES-08.png","WF---Garmin-Instinct-3-MES-09.png","WF---Garmin-Instinct-3-MES-10.png","WF---Garmin-Instinct-3-MES-11.png","WF---Garmin-Instinct-3-MES-12.png"],
              month_tc_array: ["WF---Garmin-Instinct-3-MES-01.png","WF---Garmin-Instinct-3-MES-02.png","WF---Garmin-Instinct-3-MES-03.png","WF---Garmin-Instinct-3-MES-04.png","WF---Garmin-Instinct-3-MES-05.png","WF---Garmin-Instinct-3-MES-06.png","WF---Garmin-Instinct-3-MES-07.png","WF---Garmin-Instinct-3-MES-08.png","WF---Garmin-Instinct-3-MES-09.png","WF---Garmin-Instinct-3-MES-10.png","WF---Garmin-Instinct-3-MES-11.png","WF---Garmin-Instinct-3-MES-12.png"],
              month_en_array: ["WF---Garmin-Instinct-3-MES-01.png","WF---Garmin-Instinct-3-MES-02.png","WF---Garmin-Instinct-3-MES-03.png","WF---Garmin-Instinct-3-MES-04.png","WF---Garmin-Instinct-3-MES-05.png","WF---Garmin-Instinct-3-MES-06.png","WF---Garmin-Instinct-3-MES-07.png","WF---Garmin-Instinct-3-MES-08.png","WF---Garmin-Instinct-3-MES-09.png","WF---Garmin-Instinct-3-MES-10.png","WF---Garmin-Instinct-3-MES-11.png","WF---Garmin-Instinct-3-MES-12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 256,
              day_startY: 22,
              day_sc_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              day_tc_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              day_en_array: ["WF---Garmin-Instinct-3-DAY-00.png","WF---Garmin-Instinct-3-DAY-01.png","WF---Garmin-Instinct-3-DAY-02.png","WF---Garmin-Instinct-3-DAY-03.png","WF---Garmin-Instinct-3-DAY-04.png","WF---Garmin-Instinct-3-DAY-05.png","WF---Garmin-Instinct-3-DAY-06.png","WF---Garmin-Instinct-3-DAY-07.png","WF---Garmin-Instinct-3-DAY-08.png","WF---Garmin-Instinct-3-DAY-09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 316,
              y: 336,
              w: 150,
              h: 32,
              text_size: 34,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto-Light.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 262,
              y: 344,
              image_array: ["WF---Garmin-Instinct-3-BAT-00.png","WF---Garmin-Instinct-3-BAT-10.png","WF---Garmin-Instinct-3-BAT-20.png","WF---Garmin-Instinct-3-BAT-30.png","WF---Garmin-Instinct-3-BAT-40.png","WF---Garmin-Instinct-3-BAT-50.png","WF---Garmin-Instinct-3-BAT-60.png","WF---Garmin-Instinct-3-BAT-70.png","WF---Garmin-Instinct-3-BAT-80.png","WF---Garmin-Instinct-3-BAT-90.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 78,
              hour_startY: 140,
              hour_array: ["WF---Garmin-Instinct-3-HORA-00.png","WF---Garmin-Instinct-3-HORA-01.png","WF---Garmin-Instinct-3-HORA-02.png","WF---Garmin-Instinct-3-HORA-03.png","WF---Garmin-Instinct-3-HORA-04.png","WF---Garmin-Instinct-3-HORA-05.png","WF---Garmin-Instinct-3-HORA-06.png","WF---Garmin-Instinct-3-HORA-07.png","WF---Garmin-Instinct-3-HORA-08.png","WF---Garmin-Instinct-3-HORA-09.png"],
              hour_zero: 1,
              hour_space: 12,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 78,
              minute_startY: 244,
              minute_array: ["WF---Garmin-Instinct-3-HORA-00.png","WF---Garmin-Instinct-3-HORA-01.png","WF---Garmin-Instinct-3-HORA-02.png","WF---Garmin-Instinct-3-HORA-03.png","WF---Garmin-Instinct-3-HORA-04.png","WF---Garmin-Instinct-3-HORA-05.png","WF---Garmin-Instinct-3-HORA-06.png","WF---Garmin-Instinct-3-HORA-07.png","WF---Garmin-Instinct-3-HORA-08.png","WF---Garmin-Instinct-3-HORA-09.png"],
              minute_zero: 1,
              minute_space: 12,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 148,
              second_startY: 348,
              second_array: ["WF---Garmin-Instinct-3-SEG-00.png","WF---Garmin-Instinct-3-SEG-01.png","WF---Garmin-Instinct-3-SEG-02.png","WF---Garmin-Instinct-3-SEG-03.png","WF---Garmin-Instinct-3-SEG-04.png","WF---Garmin-Instinct-3-SEG-05.png","WF---Garmin-Instinct-3-SEG-06.png","WF---Garmin-Instinct-3-SEG-07.png","WF---Garmin-Instinct-3-SEG-08.png","WF---Garmin-Instinct-3-SEG-09.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 195,
              month_startY: 22,
              month_sc_array: ["062.png","063.png","064.png","065.png","066.png","067.png","068.png","069.png","070.png","071.png","072.png","073.png"],
              month_tc_array: ["062.png","063.png","064.png","065.png","066.png","067.png","068.png","069.png","070.png","071.png","072.png","073.png"],
              month_en_array: ["062.png","063.png","064.png","065.png","066.png","067.png","068.png","069.png","070.png","071.png","072.png","073.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 256,
              day_startY: 22,
              day_sc_array: ["042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png"],
              day_tc_array: ["042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png"],
              day_en_array: ["042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png","050.png","051.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 171,
              hour_startY: 144,
              hour_array: ["WF---Garmin-Instinct-3-HORAB-00.png","WF---Garmin-Instinct-3-HORAB-01.png","WF---Garmin-Instinct-3-HORAB-02.png","WF---Garmin-Instinct-3-HORAB-03.png","WF---Garmin-Instinct-3-HORAB-04.png","WF---Garmin-Instinct-3-HORAB-05.png","WF---Garmin-Instinct-3-HORAB-06.png","WF---Garmin-Instinct-3-HORAB-07.png","WF---Garmin-Instinct-3-HORAB-08.png","WF---Garmin-Instinct-3-HORAB-09.png"],
              hour_zero: 1,
              hour_space: 12,
              hour_angle: 0,
              // alpha: 150,
              hour_align: hmUI.align.LEFT,

              minute_startX: 171,
              minute_startY: 248,
              minute_array: ["WF---Garmin-Instinct-3-HORAB-00.png","WF---Garmin-Instinct-3-HORAB-01.png","WF---Garmin-Instinct-3-HORAB-02.png","WF---Garmin-Instinct-3-HORAB-03.png","WF---Garmin-Instinct-3-HORAB-04.png","WF---Garmin-Instinct-3-HORAB-05.png","WF---Garmin-Instinct-3-HORAB-06.png","WF---Garmin-Instinct-3-HORAB-07.png","WF---Garmin-Instinct-3-HORAB-08.png","WF---Garmin-Instinct-3-HORAB-09.png"],
              minute_zero: 1,
              minute_space: 12,
              minute_angle: 0,
              minute_follow: 0,
              // alpha: 100,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time.setAlpha(150);

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'Black480B.png',
              // alpha: 150,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img.setAlpha(150);
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: KD seu CEL?,
              // conneсnt_vibrate_type: 25,
              // conneсnt_toast_text: TD OK!,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "KD seu CEL?"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "TD OK!"});
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 384,
              y: 52,
              w: 107,
              h: 116,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AppListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 384,
              y: 317,
              w: 107,
              h: 116,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: -14,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 243,
              y: 139,
              w: 131,
              h: 73,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 243,
              y: 233,
              w: 131,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 243,
              y: 283,
              w: 131,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 243,
              y: 333,
              w: 131,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 146,
              y: 409,
              w: 186,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'TideScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 10,
              y: 160,
              w: 50,
              h: 154,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: -9,
              y: 58,
              w: 100,
              h: 106,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'HmReStartScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: -9,
              y: 322,
              w: 100,
              h: 106,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 98,
              y: 138,
              w: 100,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_13 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 98,
              y: 242,
              w: 100,
              h: 90,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              normal_src: 'WF_-_Garmin_Instinct-BUTTONS.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'StopWatchScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 24 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}