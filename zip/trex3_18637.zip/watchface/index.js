﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block
        let curTime = null;
        try {
            curTime = hmSensor.createSensor(hmSensor.id.TIME);
        } catch (e) {
            curTime = null;
            console.log('TIME sensor not available or failed to create:', e);
        }        
        let weatherImg, tempText, cityNameText, tempMinText, tempMaxText, tempFeelsText, descriptionText;
        let weatherProvider = null;
        
        //dynamic modify start

        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 8         
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''        
        let normal_alarm_clock_current_text_font = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_sleep_icon_img = ''
        let normal_sleep_time_font = ''
        let normal_year_icon_img = ''
        let normal_year_text_font = ''
        let normal_step_image_progress_img_level = ''
        let normal_step_current_text_font = ''
        let normal_sun_icon_img = ''
        let normal_sun_icon2_img = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_temperature_icon_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_text_font = ''
        let normal_battery_icon_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_current_text_font = ''
        let hour_tens = ''
        let hour_units = ''
        let minute_tens = ''
        let minute_units = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_second_separator_img = ''
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_alarm_clock_current_text_font = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_sleep_icon_img = ''
        let idle_sleep_time_font = ''
        let idle_step_image_progress_img_level = ''
        let idle_step_current_text_font = ''
        let idle_sun_icon_img = ''
        let idle_sun_icon2_img = ''
        let idle_sun_high_text_font = ''
        let idle_sun_low_text_font = ''
        let idle_city_name_text = ''
        let idle_temperature_icon_img = ''
        let idle_weather_image_progress_img_level = ''        
        let idle_temperature_current_text_font = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_heart_rate_text_font = ''
        let idle_battery_icon_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_current_text_font = ''
        let idle_hour_tens = ''
        let idle_hour_units = ''
        let idle_minute_tens = ''
        let idle_minute_units = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''        
        let sleepSensor = '';

            // --------------------
            // WeatherProvider v5.1 —  T-Rex Ultra 2
            // --------------------
            class WeatherProvider {
                constructor(props = {}) {
                    this.iconMapService = {
                        1: 3, 2: 0, 3: 4, 4: 4, 5: 1, 6: 5, 7: 10, 8: 15,
                        9: 6, 10: 8, 11: 9, 12: 12, 13: 13, 14: 17
                    };

                    this.description = [
                        ['Облачно','Временами дождь','Временами снег','Ясно','Пасмурно','Слабый дождь','Слабый снег','Умеренный дождь','Умеренный снег','Сильный снегопад','Сильный дождь','Песчаная буря','Мокрый снег','Туман','Дымка','Дождь с грозой','Метель','Пыльно','Ливень','Дождь с градом','Сильный дождь с градом','Сильный дождь','Пыльная буря','Сильная песчаная буря','Сильный дождь','Обновите погоду','Облачно ночью','Дождливо ночью','Ясно ночью'],
                        ['Cloudy','Showers','Snow Showers','Sunny','Overcast','Light Rain','Light Snow','Moderate Rain','Moderate Snow','Heavy Snow','Heavy Rain','Sandstorm','Rain and Snow','Fog','Hazy','T-Storms','Snowstorm','Floating dust','Very Heavy Rainstorm','Rain and Hail','T-Storms and Hail','Heavy Rainstorm','Dust','Heavy sand storm','Rainstorm','Unknown','Cloudy Nighttime','Showers Nighttime','Sunny Nighttime']
                    ];

                    this.props = {
                        night_icons: [0, 1, 2, 3, 14],
                        index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,
                        show_toast: true,
                        temp_widget: null,
                        temp_max_widget: null,
                        temp_min_widget: null,
                        temp_feels_widget: null,
                        description_widget: null,
                        cityName_widget: null,
                        icon_widget: null,
                        time_sensor: null,
                        weather_sensor: null,
                        lang: (hmSetting.getLanguage() === 4 ? 0 : 1),
                        ...props
                    };

                    this.providers = [
                        { name: ['Zepp','Zepp'], appId: null },
                        { name: ['Погодный сервис','Weather service'], appId: 1065824 }
                    ];

                    this.last = {
                        weatherIcon: 25,
                        displayedIcon: '25',
                        weatherDescription: 'Нет данных',
                        temperature: '--',
                        temperatureFeels: '--',
                        temperatureMax: '--',
                        temperatureMin: '--',
                        cityName: '--',
                        modTime: null,
                        sunriseMins: 360,
                        sunsetMins: 1200
                    };

                    this._THROTTLE_MS = 6 * 60 * 1000;
                    this._lastUpdateMs = hmFS.SysProGetInt64("weatherLastUpdateMs") || 0;
                    this._isUpdating = false;

                    if (!this.props.time_sensor) this.props.time_sensor = curTime;

                    if (!this.props.weather_sensor) {
                        try {
                            this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
                        } catch (e) {
                            console.log('WEATHER sensor creation failed:', e);
                            this.props.weather_sensor = null;
                        }
                    }

                    if (isFinite(this.props.index)) {
                        hmFS.SysProSetInt('WeatherProviderIndex', this.props.index);
                    }
                }

                update(force = false) {
                    if (this._isUpdating) return;

                    const nowMs = Date.now();
                    const isTimeout = (nowMs - this._lastUpdateMs >= this._THROTTLE_MS);

                    if (!force && !isTimeout) return;

                    this._isUpdating = true;

                    const prov = this.providers[this.props.index];
                    const isZepp = prov.appId === null;

                    let shouldApply = force;

                    if (isZepp) {
                        shouldApply = isTimeout || force;
                    } else {                        
                        const modTime = this.getFileModTime(prov.appId);
                        if (force || !modTime || modTime !== this.last.modTime) {
                            this.last.modTime = modTime;
                            shouldApply = true;
                        } else if (isTimeout) {
                            shouldApply = true;
                        }
                    }

                    if (shouldApply) {
                        const newData = this.getWeatherData(prov.appId);
                        this._applyWeatherData(newData);
                    }

                    this._lastUpdateMs = nowMs;
                    hmFS.SysProSetInt64("weatherLastUpdateMs", nowMs);

                    this._isUpdating = false;
                }

                _applyWeatherData(newData) {
                    
                    const tVal = this.tempWithSign(newData.temperature);
                    if (tVal !== this.last.temperature) {
                        this.last.temperature = tVal;
                        this.props.temp_widget?.setProperty(hmUI.prop.TEXT, tVal);
                    }

                    const tMax = this.tempWithSign(newData.temperatureMax);
                    if (tMax !== this.last.temperatureMax) {
                        this.last.temperatureMax = tMax;
                        this.props.temp_max_widget?.setProperty(hmUI.prop.TEXT, tMax);
                    }

                    const tMin = this.tempWithSign(newData.temperatureMin);
                    if (tMin !== this.last.temperatureMin) {
                        this.last.temperatureMin = tMin;
                        this.props.temp_min_widget?.setProperty(hmUI.prop.TEXT, tMin);
                    }

                    const tFeels = this.tempWithSign(newData.temperatureFeels);
                    if (tFeels !== this.last.temperatureFeels) {
                        this.last.temperatureFeels = tFeels;
                        this.props.temp_feels_widget?.setProperty(hmUI.prop.TEXT, tFeels);
                    }

                    if (newData.cityName !== this.last.cityName) {
                        this.last.cityName = newData.cityName;
                        this.props.cityName_widget?.setProperty(hmUI.prop.TEXT, newData.cityName);
                    }

                    if (newData.weatherDescription !== this.last.weatherDescription) {
                        this.last.weatherDescription = newData.weatherDescription;
                        this.props.description_widget?.setProperty(hmUI.prop.TEXT, newData.weatherDescription);
                    }
                    
                    let curIcon = parseInt(newData.weatherIcon);
                    let iconSuffix = (this.props.night_icons.includes(curIcon) && !this.isDayNow()) ? 'n' : '';
                    const finalIconStr = `${curIcon}${iconSuffix}`;

                    if (finalIconStr !== this.last.displayedIcon) {
                        this.last.displayedIcon = finalIconStr;
                        this.last.weatherIcon = curIcon;
                        this.props.icon_widget?.setProperty(hmUI.prop.SRC, `w_${finalIconStr}.png`);
                    }
                }

                tempWithSign(val) {
                    let fVal = parseFloat(val);
                    if (isNaN(fVal) || !isFinite(fVal)) return '--';
                    return (fVal > 0 ? '+' : '') + Math.round(fVal) + '°';
                }

                isDayNow() {
                    const ts = this.props.time_sensor;
                    let curMins;

                    if (ts && typeof ts.hour === 'number' && typeof ts.minute === 'number') {
                        curMins = ts.hour * 60 + ts.minute;
                    } else {
                        const now = new Date();
                        curMins = now.getHours() * 60 + now.getMinutes();
                    }

                    if (isNaN(this.last.sunriseMins) || isNaN(this.last.sunsetMins)) {
                        return true;
                    }

                    return curMins >= this.last.sunriseMins && curMins < this.last.sunsetMins;
                }

                getWeatherData(app_id = null) {
                    return !app_id ? this.getZeppWeatherData() : this.getAppWeatherData(app_id);
                }

                getZeppWeatherData() {
                    try {
                        const ws = this.props.weather_sensor;
                        if (!ws) throw new Error("No Sensor");

                        const fw = ws.getForecastWeather ? ws.getForecastWeather() : null;
                        const cityName = fw ? fw.cityName : '--';
                        const iconIndex = ws.curAirIconIndex ?? 25;

                        if (fw && fw.forecastData && fw.forecastData.count > 0) {
                            const today = fw.forecastData.data[0];
                            if (today.sunrise && today.sunset) {
                                const riseHour = parseInt(today.sunrise.hour);
                                const riseMin = parseInt(today.sunrise.minute);
                                const setHour = parseInt(today.sunset.hour);
                                const setMin = parseInt(today.sunset.minute);

                                if (!isNaN(riseHour) && !isNaN(riseMin) && !isNaN(setHour) && !isNaN(setMin)) {
                                    this.last.sunriseMins = riseHour * 60 + riseMin;
                                    this.last.sunsetMins = setHour * 60 + setMin;
                                    this.last.sunData = this.props.time_sensor ? this.props.time_sensor.day : new Date().getDate();
                                }
                            }
                        }

                        return {
                            weatherIcon: iconIndex,
                            weatherDescription: this.description[this.props.lang][iconIndex] || 'Нет данных',
                            temperature: ws.current ?? '--',
                            temperatureFeels: ws.feelsLike ?? '--',
                            temperatureMax: ws.high ?? '--',
                            temperatureMin: ws.low ?? '--',
                            cityName: cityName
                        };
                    } catch (e) {
                        console.log('getZeppWeatherData error:', e);
                        return { weatherIcon:25, weatherDescription:'Нет данных', temperature:'--', temperatureFeels:'--', temperatureMax:'--', temperatureMin:'--', cityName:'--' };
                    }
                }

                getAppWeatherData(app_id) {
                    const data = { weatherIcon: 25, weatherDescription: 'Нет данных', temperature: '--', temperatureFeels: '--', temperatureMax: '--', temperatureMin: '--', cityName: '--' };
                    const weather_str = this.readFile(app_id);
                    if (!weather_str) return data;

                    try {
                        const weatherJson = JSON.parse(weather_str);
                        if (weatherJson) {
                            data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon || 25), app_id);

                            if (weatherJson.weatherDescriptionExtended) {
                                const desc = weatherJson.weatherDescriptionExtended;
                                data.weatherDescription = desc.charAt(0).toUpperCase() + desc.slice(1);
                            } else {
                                data.weatherDescription = this.description[this.props.lang][data.weatherIcon] || 'Нет данных';
                            }

                            data.temperature = weatherJson.temperature ?? '--';
                            data.temperatureFeels = weatherJson.temperatureFeels ?? '--';
                            data.temperatureMax = weatherJson.temperatureMax ?? '--';
                            data.temperatureMin = weatherJson.temperatureMin ?? '--';
                            data.cityName = weatherJson.city || '--';
                        }
                    } catch (e) {
                        console.log('JSON Parse error in getAppWeatherData:', e);
                    }
                    return data;
                }

                getZeppIconIndex(index, app_id = null) {
                    if (!app_id) return index;
                    if (app_id === 1065824) return this.iconMapService[index] ?? 25;
                    if (app_id === 1066654) return index - 1;
                    return index;
                }

                readFile(app_id) {
                    if (!app_id) return null;
                    try {
                        const [fs_stat, err] = hmFS.stat('weather.json', { appid: app_id });
                        if (err === 0 && fs_stat.size > 0) {
                            const fh = hmFS.open('weather.json', hmFS.O_RDONLY, { appid: app_id });
                            const array_buffer = new ArrayBuffer(fs_stat.size);
                            hmFS.read(fh, array_buffer, 0, fs_stat.size);
                            hmFS.close(fh);
                            return this.arrayBufferToCyrillic(array_buffer);
                        }
                    } catch (e) {
                        console.log('readFile error:', e);
                    }
                    return null;
                }

                getFileModTime(app_id) {
                    if (!app_id) return null;
                    try {
                        const [fs_stat, err] = hmFS.stat('weather.json', { appid: app_id });
                        if (err === 0) return fs_stat.mtime;
                    } catch (e) {}
                    return null;
                }

                arrayBufferToCyrillic(buffer) {
                    let result = '';
                    const bytes = new Uint8Array(buffer);
                    for (let i = 0; i < bytes.length;) {
                        let byte1 = bytes[i++];
                        if (byte1 < 0x80) {
                            result += String.fromCharCode(byte1);
                        } else if (byte1 >= 0xC0 && byte1 < 0xE0) {
                            let byte2 = bytes[i++];
                            result += String.fromCharCode(((byte1 & 0x1F) << 6) | (byte2 & 0x3F));
                        } else if (byte1 >= 0xE0 && byte1 < 0xF0) {
                            let byte2 = bytes[i++];
                            let byte3 = bytes[i++];
                            result += String.fromCharCode(((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F));
                        }
                    }
                    return result;
                }

                next(show_toast = this.props.show_toast) {
                    this.props.index = (this.props.index + 1) % this.providers.length;
                    hmFS.SysProSetInt('WeatherProviderIndex', this.props.index);
                    this.last.modTime = 0;                    
                    if (show_toast) hmUI.showToast({ text: this.providers[this.props.index].name[this.props.lang] });
                    this.update(true);
                }

                prev(show_toast = this.props.show_toast) {
                    this.props.index = (this.props.index - 1 + this.providers.length) % this.providers.length;
                    hmFS.SysProSetInt('WeatherProviderIndex', this.props.index);
                    this.last.modTime = 0;                    
                    if (show_toast) hmUI.showToast({ text: this.providers[this.props.index].name[this.props.lang] });
                    this.update(true);
                }

                get cityName() { return this.last.cityName ?? '--'; }
                get temperature() { return this.last.temperature ?? '--'; }
                get temperatureFeels() { return this.last.temperatureFeels ?? '--'; }
                get temperatureMax() { return this.last.temperatureMax ?? '--'; }
                get temperatureMin() { return this.last.temperatureMin ?? '--'; }
                get weatherDescription() { return this.last.weatherDescription ?? 'Нет данных'; }
                get weatherIcon() { return this.last.weatherIcon ?? 25; }

                delete() {
                    this._isUpdating = false;
                    this.props = null;
                    this.last = null;
                    this.description = null;
                    this.iconMapService = null;
                    this.providers = null;
                }
            }

            function click_Bezel() {
              if(bezel_num>=bezel_all) {bezel_num=1;}
              else { bezel_num=bezel_num+1;}
              hmUI.showToast({text: "Цвет " + parseInt(bezel_num) });
                normal_background_bg_img.setProperty(hmUI.prop.SRC, "osn_" + parseInt(bezel_num) + ".png");

            }  
        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
            // FontName: GoogleSans-Regular.ttf; FontSize: 25
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 333,
              h: 37,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: GoogleSans-Regular.ttf; FontSize: 28
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 373,
              h: 42,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
                        
            if (curTime) {
                try {
                    
                    curTime.addEventListener(curTime.event.MINUTEEND, function() {
                        let updateHour = curTime.minute === 0;
                        time_update(updateHour, true);
                    });        
                    
                    
                    curTime.addEventListener(curTime.event.HOUR12, function() {
                        time_update(true, true);    
                    });

                    
                    curTime.addEventListener(curTime.event.DAYCHANGE, function() {
                        time_update(true);
                    });
                } catch (e) {
                    console.log('Failed to add event listeners to curTime:', e);
                }
            } else {
                console.log('curTime is null, listeners not attached');
            }
            

            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'sekk_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 18,
              hour_posY: 195,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minn_1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 18,
              minute_posY: 195,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            let screenType = hmSetting.getScreenType();
            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 120,
              w: 150,
              h: 50,
              text_size: 25,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 229,
              y: 98,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 268,
              month_startY: 303,
              month_sc_array: ["Month_0.png","Month_1.png","Month_2.png","Month_3.png","Month_4.png","Month_5.png","Month_6.png","Month_7.png","Month_8.png","Month_9.png","Month_10.png","Month_11.png"],
              month_tc_array: ["Month_0.png","Month_1.png","Month_2.png","Month_3.png","Month_4.png","Month_5.png","Month_6.png","Month_7.png","Month_8.png","Month_9.png","Month_10.png","Month_11.png"],
              month_en_array: ["Month_0.png","Month_1.png","Month_2.png","Month_3.png","Month_4.png","Month_5.png","Month_6.png","Month_7.png","Month_8.png","Month_9.png","Month_10.png","Month_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 217,
              day_startY: 299,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 0,
              day_space: -11,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 142,
              y: 303,
              week_en: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png"],
              week_tc: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png"],
              week_sc: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 355,
              src: 'sleep.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_time_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 328,
              w: 150,
              h: 50,
              text_size: 25,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);             

            normal_year_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 209,
              y: 326,
              src: 'calendar_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_year_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 344,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["shg_0.png","shg_1.png","shg_2.png","shg_3.png","shg_4.png","shg_5.png","shg_6.png","shg_7.png","shg_8.png","shg_9.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -3,
              y: -3,
              w: 486,
              h: 486,
              text_size: 25,
              char_space: 3,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 159,
              end_angle: 179,
              mode: 1,
              // radius: 243,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 146,
              src: 'sunset.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon2_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 146,
              src: 'sunrise.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 110,
              y: 143,
              w: 150,
              h: 50,
              text_size: 28,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 110,
              y: 143,
              w: 150,
              h: 50,
              text_size: 28,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 255,
              y: 170,
              src: 'zapl_pogoda.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            const weatherInfo = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
            });
              
            weatherImg = weatherInfo.createWidget(hmUI.widget.IMG, {
                x: 265,
                y: 181,
                w: 80,
                h: 80,
                src: 'w_25.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            }); 
              
            tempText = weatherInfo.createWidget(hmUI.widget.TEXT, {
                x: 240,
                y: 143,
                w: 100,
                h: 50,
                text_size: 28,
                char_space: 0,
                font: 'fonts/GoogleSans-Regular.ttf',
                text: '--',
                color: 0xFFFFFFFF,
                line_space: 0,
                align_v: hmUI.align.TOP,
                text_style: hmUI.text_style.ELLIPSIS,
                align_h: hmUI.align.CENTER_H,
                unit_type: 1,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });   
              
            descriptionText = hmUI.createWidget(hmUI.widget.TEXT, {
                x: -3,
                y: -3,
                w: 486,
                h: 486,
                text_size: 25,
                char_space: 0,
                font: 'fonts/GoogleSans-Regular.ttf',
                color: 0xFFFFFFFF,
                // use_text_circle: true,
                start_angle: 181,
                end_angle: 270,
                mode: 1,
                // radius: 243,
                align_h: hmUI.align.CENTER_H,
                show_level: hmUI.show_level.ONLY_NORMAL,                
            });                        

            weatherProvider = new WeatherProvider({
                time_sensor: curTime,
                temp_widget: tempText,
                cityName_widget: cityNameText,
                icon_widget: weatherImg,
                description_widget: descriptionText,
                night_icons: [0, 1, 2, 3, 14],
                show_toast: true
            });
            weatherProvider.update(true); 


            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["pls_0.png","pls_1.png","pls_2.png","pls_3.png","pls_4.png","pls_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -3,
              y: -3,
              w: 486,
              h: 486,
              text_size: 25,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 70,
              end_angle: 200,
              mode: 0,
              // radius: 243,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 255,
              y: 240,
              src: 'dv.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["zr_1.png","zr_2.png","zr_3.png","zr_4.png","zr_5.png","zr_6.png","zr_7.png","zr_8.png","zr_9.png","zr_10.png","zr_11.png","zr_12.png"],
              image_length: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -3,
              y: -3,
              w: 486,
              h: 486,
              text_size: 25,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -200,
              end_angle: -68,
              mode: 0,
              // radius: 243,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // === ЧАСЫ ===
            hour_tens = hmUI.createWidget(hmUI.widget.IMG, {     
              x: 114,
              y: 171,
              src: 'HM_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hour_units = hmUI.createWidget(hmUI.widget.IMG, {     
              x: 183,           
              y: 170,          
              src: 'HB_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
           

            // === МИНУТЫ ===
            minute_tens = hmUI.createWidget(hmUI.widget.IMG, {    
              x: 267,
              y: 214,
              src: 'MM_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            minute_units = hmUI.createWidget(hmUI.widget.IMG, {   
              x: 310,          
              y: 212,          
              src: 'MB_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
           

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 315,
              second_startY: 174,
              second_array: ["SEK_0.png","SEK_1.png","SEK_2.png","SEK_3.png","SEK_4.png","SEK_5.png","SEK_6.png","SEK_7.png","SEK_8.png","SEK_9.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 313,
              y: 171,
              src: 'SEK_zapl.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 18,
              hour_posY: 195,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minn_1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 18,
              minute_posY: 195,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 120,
              w: 150,
              h: 50,
              text_size: 25,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 229,
              y: 98,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 268,
              month_startY: 303,
              month_sc_array: ["Month_0.png","Month_1.png","Month_2.png","Month_3.png","Month_4.png","Month_5.png","Month_6.png","Month_7.png","Month_8.png","Month_9.png","Month_10.png","Month_11.png"],
              month_tc_array: ["Month_0.png","Month_1.png","Month_2.png","Month_3.png","Month_4.png","Month_5.png","Month_6.png","Month_7.png","Month_8.png","Month_9.png","Month_10.png","Month_11.png"],
              month_en_array: ["Month_0.png","Month_1.png","Month_2.png","Month_3.png","Month_4.png","Month_5.png","Month_6.png","Month_7.png","Month_8.png","Month_9.png","Month_10.png","Month_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 217,
              day_startY: 299,
              day_sc_array: ["dataAOD_0.png","dataAOD_1.png","dataAOD_2.png","dataAOD_3.png","dataAOD_4.png","dataAOD_5.png","dataAOD_6.png","dataAOD_7.png","dataAOD_8.png","dataAOD_9.png"],
              day_tc_array: ["dataAOD_0.png","dataAOD_1.png","dataAOD_2.png","dataAOD_3.png","dataAOD_4.png","dataAOD_5.png","dataAOD_6.png","dataAOD_7.png","dataAOD_8.png","dataAOD_9.png"],
              day_en_array: ["dataAOD_0.png","dataAOD_1.png","dataAOD_2.png","dataAOD_3.png","dataAOD_4.png","dataAOD_5.png","dataAOD_6.png","dataAOD_7.png","dataAOD_8.png","dataAOD_9.png"],
              day_zero: 0,
              day_space: -11,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 142,
              y: 303,
              week_en: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png"],
              week_tc: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png"],
              week_sc: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sleep_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 355,
              src: 'sleep.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sleep_time_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 328,
              w: 150,
              h: 50,
              text_size: 25,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["shg_0.png","shg_1.png","shg_2.png","shg_3.png","shg_4.png","shg_5.png","shg_6.png","shg_7.png","shg_8.png","shg_9.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -3,
              y: -3,
              w: 486,
              h: 486,
              text_size: 25,
              char_space: 3,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 159,
              end_angle: 179,
              mode: 1,
              // radius: 243,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 146,
              src: 'sunset.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_icon2_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 226,
              y: 146,
              src: 'sunrise.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });             

            idle_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 110,
              y: 143,
              w: 150,
              h: 50,
              text_size: 28,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 110,
              y: 143,
              w: 150,
              h: 50,
              text_size: 28,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -3,
              y: -3,
              w: 486,
              h: 486,
              text_size: 25,
              char_space: 0,
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 181,
              end_angle: 270,
              mode: 1,
              // radius: 243,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 255,
              y: 170,
              src: 'zapl_pogoda.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });            

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 265,
              y: 181,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 240,
              y: 143,
              w: 100,
              h: 50,
              text_size: 28,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["pls_0.png","pls_1.png","pls_2.png","pls_3.png","pls_4.png","pls_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -3,
              y: -3,
              w: 486,
              h: 486,
              text_size: 25,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 70,
              end_angle: 200,
              mode: 0,
              // radius: 243,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 255,
              y: 240,
              src: 'dvAOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["zr_1.png","zr_2.png","zr_3.png","zr_4.png","zr_5.png","zr_6.png","zr_7.png","zr_8.png","zr_9.png","zr_10.png","zr_11.png","zr_12.png"],
              image_length: 12,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -3,
              y: -3,
              w: 486,
              h: 486,
              text_size: 25,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -200,
              end_angle: -68,
              mode: 0,
              // radius: 243,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            
            // === ЧАСЫ ===
            idle_hour_tens = hmUI.createWidget(hmUI.widget.IMG, {     
              x: 114,
              y: 171,
              src: 'HMAOD_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_hour_units = hmUI.createWidget(hmUI.widget.IMG, {     
              x: 183,           
              y: 170,          
              src: 'HB_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
           
            // === МИНУТЫ ===
            idle_minute_tens = hmUI.createWidget(hmUI.widget.IMG, {    
              x: 267,
              y: 214,
              src: 'MMAOD_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_minute_units = hmUI.createWidget(hmUI.widget.IMG, {   
              x: 310,          
              y: 212,          
              src: 'MB_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
              

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 251,
              y: 422,
              w: 70,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 423,
              y: 148,
              w: 60,
              h: 60,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 3,
              y: 147,
              w: 60,
              h: 60,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 144,
              w: 65,
              h: 38,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 281,
              y: 238,
              w: 60,
              h: 60,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 317,
              y: 178,
              w: 40,
              h: 40,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 209,
              y: 96,
              w: 60,
              h: 45,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 205,
              y: 336,
              w: 70,
              h: 50,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 301,
              w: 100,
              h: 32,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 280,
              y: 132,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button   
            
            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 261,
              y: 175,
              w: 40,
              h: 40,
              text: '',
              text_size: 25,
              color: 0xFFFF8C00,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: () => {                
                weatherProvider.prev(true);                
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });   

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 153,
              y: 209,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button   

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 32,
              y: 324,
              text: '',
              w: 50,
              h: 50,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
               click_Bezel();
               
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);              

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
                if (!curTime) return;

                let hour = curTime.hour;
                let minute = curTime.minute;
                let second = curTime.second;
                let format_hour = curTime.format_hour;
                let month = curTime.month;
                let day = curTime.day;
                              
                if (normal_analog_clock_pro_second_pointer_img) {
                    normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, second * 6);
                }

                if (updateHour) {
                    let normal_yearStr = (curTime.year % 100).toString();
                    normal_year_text_font.setProperty(hmUI.prop.TEXT, normal_yearStr);
                }

                let is12Hour = false;                
                if (typeof curTime.format_hour !== "undefined" && curTime.format_hour === 1) {
                    is12Hour = true;
                }                
                else if (typeof curTime.is24Hour !== "undefined" && curTime.is24Hour === false) {
                    is12Hour = true;
                }                

                let displayHour = hour;
                if (is12Hour) {
                    displayHour = hour % 12;
                    if (displayHour === 0) displayHour = 12;   
                }
                
                if (updateMinute) {
                    let h_tens = Math.floor(displayHour / 10);
                    let h_units = displayHour % 10;
                    let m_tens = Math.floor(minute / 10);
                    let m_units = minute % 10;
                    
                    hour_tens.setProperty(hmUI.prop.SRC, `HM_${h_tens}.png`);
                    hour_units.setProperty(hmUI.prop.SRC, `HB_${h_units}.png`);
                    minute_tens.setProperty(hmUI.prop.SRC, `MM_${m_tens}.png`);
                    minute_units.setProperty(hmUI.prop.SRC, `MB_${m_units}.png`);
                    
                    idle_hour_tens.setProperty(hmUI.prop.SRC, `HMAOD_${h_tens}.png`);
                    idle_hour_units.setProperty(hmUI.prop.SRC, `HB_${h_units}.png`);
                    idle_minute_tens.setProperty(hmUI.prop.SRC, `MMAOD_${m_tens}.png`);
                    idle_minute_units.setProperty(hmUI.prop.SRC, `MB_${m_units}.png`);
                }  

                if (updateHour) {
                    const curtMinutes = hour * 60 + minute;
                    const isMorningSleepTime = curtMinutes >= 6*60 && curtMinutes < 10*60;

                    if (isMorningSleepTime) {                  
                      normal_sleep_time_font.setProperty(hmUI.prop.VISIBLE, true);
                      normal_sleep_icon_img.setProperty(hmUI.prop.VISIBLE, true);                  
                      normal_year_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                      normal_year_text_font.setProperty(hmUI.prop.VISIBLE, false);
                    } else {                  
                      normal_sleep_time_font.setProperty(hmUI.prop.VISIBLE, false);
                      normal_sleep_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                      normal_year_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                      normal_year_text_font.setProperty(hmUI.prop.VISIBLE, true);
                    } 

                    let calendarSrc = 'calendar_0.png'; 
                    if ((month === 12 && day >= 31) || (month === 1 && day <= 1)) {
                        calendarSrc = 'calendar_1.png';
                    } else if (month === 2 && day === 14) {
                        calendarSrc = 'calendar_2.png';
                    } else if (month === 3 && day === 8) {
                        calendarSrc = 'calendar_3.png';
                    } else if (month === 4 && day === 1) {
                        calendarSrc = 'calendar_4.png';
                    } else if (month === 9 && day === 1) {
                        calendarSrc = 'calendar_5.png';
                    }
                    normal_year_icon_img.setProperty(hmUI.prop.SRC, calendarSrc);
                }                                         
                
                const weatherData = weatherSensor.getForecastWeather();
                const tide = weatherData.tideData.data[0];
                let sunriseMinutes = tide.sunrise.hour * 60 + tide.sunrise.minute;
                let sunsetMinutes  = tide.sunset.hour  * 60 + tide.sunset.minute;
                let currentMinutes = curTime.hour * 60 + curTime.minute;
                let isDay = currentMinutes >= sunriseMinutes && currentMinutes < sunsetMinutes;

                if (isDay) {                  
                  normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                  idle_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_sun_icon2_img.setProperty(hmUI.prop.VISIBLE, true);
                  idle_sun_icon2_img.setProperty(hmUI.prop.VISIBLE, true);
                  normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, false);
                  idle_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, false);
                  normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, true);
                  idle_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, true);
                } else {                  
                  normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                  idle_sun_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                  normal_sun_icon2_img.setProperty(hmUI.prop.VISIBLE, false);
                  idle_sun_icon2_img.setProperty(hmUI.prop.VISIBLE, false);
                  normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, true);
                  idle_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, true);
                  normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, false);
                  idle_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, false);
                } 
            }

            //#endregion
            if (!sleepSensor) sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
            //#region sleep_update
            function sleep_update() {
              let sleepTime = sleepSensor.getTotalTime();
              const modelData = sleepSensor.getSleepStageModel();
              let sleepStageArray = sleepSensor.getSleepStageData();
              let wakeupTime = 0;
              let wakeupCount = 0;

              for (let i = 0; i < sleepStageArray.length; i++) {
                let data = sleepStageArray[i];
                if (data.model == modelData.WAKE_STAGE) {
                  wakeupTime += data.stop + 1 - data.start;
                  wakeupCount++;
                };
              };
              sleepTime -= wakeupTime;
              let sleepTimeHour = Math.floor(sleepTime / 60);
              let sleepTimeMin = sleepTime % 60;

              let normal_sleepTimeHourStr = sleepTimeHour.toString();
              normal_sleepTimeHourStr = normal_sleepTimeHourStr.padStart(2, '0');
              let normal_sleepTimeMinStr = sleepTimeMin.toString().padStart(2, '0');
              let normal_sleepTimeStr = normal_sleepTimeHourStr + ':' + normal_sleepTimeMinStr;
              if (normal_sleep_time_font) normal_sleep_time_font.setProperty(hmUI.prop.TEXT, normal_sleepTimeStr);

              let idle_sleepTimeHourStr = sleepTimeHour.toString();
              idle_sleepTimeHourStr = idle_sleepTimeHourStr.padStart(2, '0');
              let idle_sleepTimeMinStr = sleepTimeMin.toString().padStart(2, '0');
              let idle_sleepTimeStr = idle_sleepTimeHourStr + ':' + idle_sleepTimeMinStr;
              if (idle_sleep_time_font) idle_sleep_time_font.setProperty(hmUI.prop.TEXT, idle_sleepTimeStr);

            };

            function update_smooth_second() {
                if (!curTime || !normal_analog_clock_pro_second_pointer_img) return;
                const second = curTime.second;
                const now = Date.now();
                const ms = now % 1000;                
                const angle = (second * 6) + (ms * 0.006);   
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, angle);
            }            

            //#endregion
            function scale_call() {
              let weatherData = weatherSensor.getForecastWeather();
              let idle_cityNameStr = weatherData.cityName;
              idle_city_name_text.setProperty(hmUI.prop.TEXT, idle_cityNameStr);
            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                time_update(true, true); 
                sleep_update();
                
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = 0;   
                    let animRepeat = 40;                     
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      update_smooth_second(); 
                    }));  // end timer 
                  }  // end timer check
                }  // end screenType
                
                if (weatherProvider) {
                    weatherProvider.update(false);
                }                  
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {                
                
                if (weatherProvider) {
                    weatherProvider.delete();
                    weatherProvider = null;
                }
                
                logger.log('watchface destroyed — all cleaned OK');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}