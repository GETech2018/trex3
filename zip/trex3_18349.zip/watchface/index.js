﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block
        let curTime = null;
        try {
            curTime = hmSensor.createSensor(hmSensor.id.TIME);
        } catch (e) {
            curTime = null;
            console.log('TIME sensor not available or failed to create:', e);
        }
        //dynamic modify start
        // Pressure file unified path
        let barometer = null;            
        // Handler references 
        let curTimeMinuteHandler = null;
        // Widgets & globals
        let weatherImg, tempText, cityNameText, tempMinText, tempMaxText, tempFeelsText, descriptionText;
        let weatherProvider = null; 
        // Sleep 
        let sleep = null;
        let cachedSleepText = "00:00";
        let lastSleepDate = null;
        let lastShownSleepText = "--";
        let sleep_time_txt = null;
        let lastTotalMinutes = 0;
        let lastSleepUpdateMs = 0;
        const SLEEP_THROTTLE_MS = 30 * 60 * 1000;             

        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_distance_current_text_font = ''
        let normal_step_current_text_font = ''
        let normal_step_image_progress_img_level = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_readiness_current_text_font = ''        
        let normal_moon_pointer_progress_img_pointer = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_sun_pointer_progress_img_pointer = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_current_text_font = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_step_current_text_font = ''
        let idle_alarm_clock_current_text_font = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_battery_current_text_font = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_readiness_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
            // --------------------
            // WeatherProvider v5.1 —  T-Rex Ultra 2
            // --------------------
            class WeatherProvider {
                constructor(props = {}) {
                    this.iconMapService = {
                        1: 3, 2: 0, 3: 4, 4: 4, 5: 1, 6: 5, 7: 10, 8: 15,
                        9: 6, 10: 8, 11: 9, 12: 12, 13: 13, 14: 17
                    };

                    this.description = [
                        ['Облачно','Временами дождь','Временами снег','Ясно','Пасмурно','Слабый дождь','Слабый снег','Умеренный дождь','Умеренный снег','Сильный снегопад','Сильный дождь','Песчаная буря','Мокрый снег','Туман','Дымка','Дождь с грозой','Метель','Пыльно','Ливень','Дождь с градом','Сильный дождь с градом','Сильный дождь','Пыльная буря','Сильная песчаная буря','Сильный дождь','Обновите погоду','Облачно ночью','Дождливо ночью','Ясно ночью'],
                        ['Cloudy','Showers','Snow Showers','Sunny','Overcast','Light Rain','Light Snow','Moderate Rain','Moderate Snow','Heavy Snow','Heavy Rain','Sandstorm','Rain and Snow','Fog','Hazy','T-Storms','Snowstorm','Floating dust','Very Heavy Rainstorm','Rain and Hail','T-Storms and Hail','Heavy Rainstorm','Dust','Heavy sand storm','Rainstorm','Unknown','Cloudy Nighttime','Showers Nighttime','Sunny Nighttime']
                    ];

                    this.props = {
                        night_icons: [0, 1, 2, 3, 14],
                        index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,
                        show_toast: true,
                        temp_widget: null,
                        temp_max_widget: null,
                        temp_min_widget: null,
                        temp_feels_widget: null,
                        description_widget: null,
                        cityName_widget: null,
                        icon_widget: null,
                        time_sensor: null,
                        weather_sensor: null,
                        lang: (hmSetting.getLanguage() === 4 ? 0 : 1),
                        ...props
                    };

                    this.providers = [
                        { name: ['Zepp','Zepp'], appId: null },
                        { name: ['Погодный сервис','Weather service'], appId: 1065824 }
                    ];

                    this.last = {
                        weatherIcon: 25,
                        displayedIcon: '25',
                        weatherDescription: 'Нет данных',
                        temperature: '--',
                        temperatureFeels: '--',
                        temperatureMax: '--',
                        temperatureMin: '--',
                        cityName: '--',
                        modTime: null,
                        sunriseMins: 360,
                        sunsetMins: 1200
                    };

                    this._THROTTLE_MS = 6 * 60 * 1000;
                    this._lastUpdateMs = hmFS.SysProGetInt64("weatherLastUpdateMs") || 0;
                    this._isUpdating = false;

                    if (!this.props.time_sensor) this.props.time_sensor = curTime;

                    if (!this.props.weather_sensor) {
                        try {
                            this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
                        } catch (e) {
                            console.log('WEATHER sensor creation failed:', e);
                            this.props.weather_sensor = null;
                        }
                    }

                    if (isFinite(this.props.index)) {
                        hmFS.SysProSetInt('WeatherProviderIndex', this.props.index);
                    }
                }

                update(force = false) {
                    if (this._isUpdating) return;

                    const nowMs = Date.now();
                    const isTimeout = (nowMs - this._lastUpdateMs >= this._THROTTLE_MS);

                    if (!force && !isTimeout) return;

                    this._isUpdating = true;

                    const prov = this.providers[this.props.index];
                    const isZepp = prov.appId === null;

                    let shouldApply = force;

                    if (isZepp) {
                        shouldApply = isTimeout || force;
                    } else {                        
                        const modTime = this.getFileModTime(prov.appId);
                        if (force || !modTime || modTime !== this.last.modTime) {
                            this.last.modTime = modTime;
                            shouldApply = true;
                        } else if (isTimeout) {
                            shouldApply = true;
                        }
                    }

                    if (shouldApply) {
                        const newData = this.getWeatherData(prov.appId);
                        this._applyWeatherData(newData);
                    }

                    this._lastUpdateMs = nowMs;
                    hmFS.SysProSetInt64("weatherLastUpdateMs", nowMs);

                    this._isUpdating = false;
                }

                _applyWeatherData(newData) {
                    
                    const tVal = this.tempWithSign(newData.temperature);
                    if (tVal !== this.last.temperature) {
                        this.last.temperature = tVal;
                        this.props.temp_widget?.setProperty(hmUI.prop.TEXT, tVal);
                    }

                    const tMax = this.tempWithSign(newData.temperatureMax);
                    if (tMax !== this.last.temperatureMax) {
                        this.last.temperatureMax = tMax;
                        this.props.temp_max_widget?.setProperty(hmUI.prop.TEXT, tMax);
                    }

                    const tMin = this.tempWithSign(newData.temperatureMin);
                    if (tMin !== this.last.temperatureMin) {
                        this.last.temperatureMin = tMin;
                        this.props.temp_min_widget?.setProperty(hmUI.prop.TEXT, tMin);
                    }

                    const tFeels = this.tempWithSign(newData.temperatureFeels);
                    if (tFeels !== this.last.temperatureFeels) {
                        this.last.temperatureFeels = tFeels;
                        this.props.temp_feels_widget?.setProperty(hmUI.prop.TEXT, tFeels);
                    }

                    if (newData.cityName !== this.last.cityName) {
                        this.last.cityName = newData.cityName;
                        this.props.cityName_widget?.setProperty(hmUI.prop.TEXT, newData.cityName);
                    }

                    if (newData.weatherDescription !== this.last.weatherDescription) {
                        this.last.weatherDescription = newData.weatherDescription;
                        this.props.description_widget?.setProperty(hmUI.prop.TEXT, newData.weatherDescription);
                    }
                    
                    let curIcon = parseInt(newData.weatherIcon);
                    let iconSuffix = (this.props.night_icons.includes(curIcon) && !this.isDayNow()) ? 'n' : '';
                    const finalIconStr = `${curIcon}${iconSuffix}`;

                    if (finalIconStr !== this.last.displayedIcon) {
                        this.last.displayedIcon = finalIconStr;
                        this.last.weatherIcon = curIcon;
                        this.props.icon_widget?.setProperty(hmUI.prop.SRC, `w_${finalIconStr}.png`);
                    }
                }

                tempWithSign(val) {
                    let fVal = parseFloat(val);
                    if (isNaN(fVal) || !isFinite(fVal)) return '--';
                    return (fVal > 0 ? '+' : '') + Math.round(fVal) + '°';
                }

                isDayNow() {
                    const ts = this.props.time_sensor;
                    let curMins;

                    if (ts && typeof ts.hour === 'number' && typeof ts.minute === 'number') {
                        curMins = ts.hour * 60 + ts.minute;
                    } else {
                        const now = new Date();
                        curMins = now.getHours() * 60 + now.getMinutes();
                    }

                    if (isNaN(this.last.sunriseMins) || isNaN(this.last.sunsetMins)) {
                        return true;
                    }

                    return curMins >= this.last.sunriseMins && curMins < this.last.sunsetMins;
                }

                getWeatherData(app_id = null) {
                    return !app_id ? this.getZeppWeatherData() : this.getAppWeatherData(app_id);
                }

                getZeppWeatherData() {
                    try {
                        const ws = this.props.weather_sensor;
                        if (!ws) throw new Error("No Sensor");

                        const fw = ws.getForecastWeather ? ws.getForecastWeather() : null;
                        const cityName = fw ? fw.cityName : '--';
                        const iconIndex = ws.curAirIconIndex ?? 25;

                        if (fw && fw.forecastData && fw.forecastData.count > 0) {
                            const today = fw.forecastData.data[0];
                            if (today.sunrise && today.sunset) {
                                const riseHour = parseInt(today.sunrise.hour);
                                const riseMin = parseInt(today.sunrise.minute);
                                const setHour = parseInt(today.sunset.hour);
                                const setMin = parseInt(today.sunset.minute);

                                if (!isNaN(riseHour) && !isNaN(riseMin) && !isNaN(setHour) && !isNaN(setMin)) {
                                    this.last.sunriseMins = riseHour * 60 + riseMin;
                                    this.last.sunsetMins = setHour * 60 + setMin;
                                    this.last.sunData = this.props.time_sensor ? this.props.time_sensor.day : new Date().getDate();
                                }
                            }
                        }

                        return {
                            weatherIcon: iconIndex,
                            weatherDescription: this.description[this.props.lang][iconIndex] || 'Нет данных',
                            temperature: ws.current ?? '--',
                            temperatureFeels: ws.feelsLike ?? '--',
                            temperatureMax: ws.high ?? '--',
                            temperatureMin: ws.low ?? '--',
                            cityName: cityName
                        };
                    } catch (e) {
                        console.log('getZeppWeatherData error:', e);
                        return { weatherIcon:25, weatherDescription:'Нет данных', temperature:'--', temperatureFeels:'--', temperatureMax:'--', temperatureMin:'--', cityName:'--' };
                    }
                }

                getAppWeatherData(app_id) {
                    const data = { weatherIcon: 25, weatherDescription: 'Нет данных', temperature: '--', temperatureFeels: '--', temperatureMax: '--', temperatureMin: '--', cityName: '--' };
                    const weather_str = this.readFile(app_id);
                    if (!weather_str) return data;

                    try {
                        const weatherJson = JSON.parse(weather_str);
                        if (weatherJson) {
                            data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon || 25), app_id);

                            if (weatherJson.weatherDescriptionExtended) {
                                const desc = weatherJson.weatherDescriptionExtended;
                                data.weatherDescription = desc.charAt(0).toUpperCase() + desc.slice(1);
                            } else {
                                data.weatherDescription = this.description[this.props.lang][data.weatherIcon] || 'Нет данных';
                            }

                            data.temperature = weatherJson.temperature ?? '--';
                            data.temperatureFeels = weatherJson.temperatureFeels ?? '--';
                            data.temperatureMax = weatherJson.temperatureMax ?? '--';
                            data.temperatureMin = weatherJson.temperatureMin ?? '--';
                            data.cityName = weatherJson.city || '--';
                        }
                    } catch (e) {
                        console.log('JSON Parse error in getAppWeatherData:', e);
                    }
                    return data;
                }

                getZeppIconIndex(index, app_id = null) {
                    if (!app_id) return index;
                    if (app_id === 1065824) return this.iconMapService[index] ?? 25;
                    if (app_id === 1066654) return index - 1;
                    return index;
                }

                readFile(app_id) {
                    if (!app_id) return null;
                    try {
                        const [fs_stat, err] = hmFS.stat('weather.json', { appid: app_id });
                        if (err === 0 && fs_stat.size > 0) {
                            const fh = hmFS.open('weather.json', hmFS.O_RDONLY, { appid: app_id });
                            const array_buffer = new ArrayBuffer(fs_stat.size);
                            hmFS.read(fh, array_buffer, 0, fs_stat.size);
                            hmFS.close(fh);
                            return this.arrayBufferToCyrillic(array_buffer);
                        }
                    } catch (e) {
                        console.log('readFile error:', e);
                    }
                    return null;
                }

                getFileModTime(app_id) {
                    if (!app_id) return null;
                    try {
                        const [fs_stat, err] = hmFS.stat('weather.json', { appid: app_id });
                        if (err === 0) return fs_stat.mtime;
                    } catch (e) {}
                    return null;
                }

                arrayBufferToCyrillic(buffer) {
                    let result = '';
                    const bytes = new Uint8Array(buffer);
                    for (let i = 0; i < bytes.length;) {
                        let byte1 = bytes[i++];
                        if (byte1 < 0x80) {
                            result += String.fromCharCode(byte1);
                        } else if (byte1 >= 0xC0 && byte1 < 0xE0) {
                            let byte2 = bytes[i++];
                            result += String.fromCharCode(((byte1 & 0x1F) << 6) | (byte2 & 0x3F));
                        } else if (byte1 >= 0xE0 && byte1 < 0xF0) {
                            let byte2 = bytes[i++];
                            let byte3 = bytes[i++];
                            result += String.fromCharCode(((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F));
                        }
                    }
                    return result;
                }

                next(show_toast = this.props.show_toast) {
                    this.props.index = (this.props.index + 1) % this.providers.length;
                    hmFS.SysProSetInt('WeatherProviderIndex', this.props.index);
                    this.last.modTime = 0;                    
                    if (show_toast) hmUI.showToast({ text: this.providers[this.props.index].name[this.props.lang] });
                    this.update(true);
                }

                prev(show_toast = this.props.show_toast) {
                    this.props.index = (this.props.index - 1 + this.providers.length) % this.providers.length;
                    hmFS.SysProSetInt('WeatherProviderIndex', this.props.index);
                    this.last.modTime = 0;                    
                    if (show_toast) hmUI.showToast({ text: this.providers[this.props.index].name[this.props.lang] });
                    this.update(true);
                }

                get cityName() { return this.last.cityName ?? '--'; }
                get temperature() { return this.last.temperature ?? '--'; }
                get temperatureFeels() { return this.last.temperatureFeels ?? '--'; }
                get temperatureMax() { return this.last.temperatureMax ?? '--'; }
                get temperatureMin() { return this.last.temperatureMin ?? '--'; }
                get weatherDescription() { return this.last.weatherDescription ?? 'Нет данных'; }
                get weatherIcon() { return this.last.weatherIcon ?? 25; }

                delete() {
                    this._isUpdating = false;
                    this.props = null;
                    this.last = null;
                    this.description = null;
                    this.iconMapService = null;
                    this.providers = null;
                }
            }
            // ================================================
            // AdvancedBarometer v3.3 — Стабильная + энергоэффективная версия
            // ================================================
            class AdvancedBarometer {
                constructor(props = {}) {
                    this.props = {
                        unit_index: hmFS.SysProGetInt('BaroUnitIndex') ?? 0,
                        widget: null,
                        trend_widget: null,
                        lang: hmSetting.getLanguage() === 4 ? 0 : 1,
                        d_time: 30,                    
                        change_threshold: 0.15,        
                        ...props
                    };

                    this.unitStr = [
                        ['мм рт.ст.', 'mmHg'],
                        ['гПа', 'hPa']
                    ];

                    this.last = { value: null, trend: '' };

                    this.prev = {
                        value: hmFS.SysProGetDouble('BaroPrevValue') || null,
                        time: hmFS.SysProGetInt64('BaroPrevTime') || 0
                    };

                    this._changeHandler = null;
                    this.baroSensor = null;

                    try {
                        this.baroSensor = hmSensor.createSensor(hmSensor.id.BARO);

                        this._changeHandler = () => this._onPressureChange();
                        this.baroSensor.addEventListener(hmSensor.event.CHANGE, this._changeHandler);

                        setTimeout(() => this._onPressureChange(), 400);

                    } catch (e) {
                        console.log('BARO sensor creation failed:', e);
                        this.baroSensor = null;
                    }

                    hmFS.SysProSetInt('BaroUnitIndex', this.props.unit_index);
                }

                _onPressureChange() {
                    if (!this.baroSensor || !this.props) return;

                    const rawValue = this.baroSensor.pressure;
                    if (!rawValue || rawValue <= 300 || rawValue > 1200) return;

                    // === 1. Фильтр дребезга (по сырому значению) ===
                    if (this.last.value !== null) {
                        const diff = Math.abs(rawValue - this.last.value);
                        if (diff < this.props.change_threshold) {
                            return;
                        }
                    }

                    let trend = '';
                    if (this.prev.value !== null) {
                        const diff = rawValue - this.prev.value;
                        if (diff > 0.5)      trend = '\u2191';
                        else if (diff < -0.5) trend = '\u2193';
                    }

                    // === 3. Проверка реального изменения отображаемого значения ===
                    const newDisplay = this.props.unit_index === 0 
                        ? Math.round(rawValue * 0.750064).toString()
                        : Math.round(rawValue).toString();

                    const currentDisplay = this.pressure;

                    const displayChanged = (newDisplay !== currentDisplay);
                    const trendChanged = (trend !== this.last.trend);

                    if (displayChanged || trendChanged) {
                        this.last.value = rawValue;   
                        this.last.trend = trend;
                        this._updateWidgets();
                    }

                    const now = Date.now();
                    if (now - this.prev.time > this.props.d_time * 60 * 1000) {
                        this.prev.value = rawValue;
                        this.prev.time = now;

                        hmFS.SysProSetDouble('BaroPrevValue', rawValue);
                        hmFS.SysProSetInt64('BaroPrevTime', now);
                    }
                }

                _updateWidgets() {
                    if (!this.props) return;

                    if (this.props.widget) {
                        this.props.widget.setProperty(hmUI.prop.TEXT, this.pressure);
                    }

                    if (this.props.trend_widget) {
                        this.props.trend_widget.setProperty(hmUI.prop.TEXT, this.last.trend || ' ');
                    }
                }

                get mmHg() {
                    const v = this.last.value;
                    return (v == null || !isFinite(v)) ? '--' : Math.round(v * 0.750064).toString();
                }

                get hPa() {
                    const v = this.last.value;
                    return (v == null || !isFinite(v)) ? '--' : Math.round(v).toString();
                }

                get pressure() {
                    return this.props.unit_index === 0 ? this.mmHg : this.hPa;
                }

                get unit() {
                    return this.unitStr[this.props.unit_index][this.props.lang];
                }

                toggleUnits(show_toast = true) {
                    if (!this.props) return;
                    this.props.unit_index = (this.props.unit_index + 1) % 2;
                    hmFS.SysProSetInt('BaroUnitIndex', this.props.unit_index);
                    this._updateWidgets();
                    if (show_toast) hmUI.showToast({ text: this.unit });
                }

                delete() {
                    if (this.baroSensor && this._changeHandler) {
                        try {
                            this.baroSensor.removeEventListener(hmSensor.event.CHANGE, this._changeHandler);
                        } catch (e) {}
                    }

                    this.baroSensor = null;
                    this._changeHandler = null;
                    this.last = null;
                    this.prev = null;
                    this.props = null;
                }
            }

            // -------------
            // Sleep helpers 1.2
            // -------------
            try {
                sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
                sleep.onSleepStateChange = () => {
                    if (sleep.state === hmSensor.sleep_state.END) {
                        calculateAndCacheRealSleep(true);
                    }
                };
            } catch (e) {
                console.log("Sleep sensor init failed:", e);
                sleep = null;
            }

            function formatMinutes(mins) {
                if (!mins || mins <= 0) return "00:00";
                const h = Math.floor(mins / 60);
                const m = mins % 60;
                return String(h).padStart(2, "0") + ":" + String(m).padStart(2, "0");
            }

            function calculateAndCacheRealSleep(force = false) {
                if (!sleep) {
                    cachedSleepText = "00:00";
                    updateSleepText();
                    return;
                }

                try {
                    const now = Date.now();
                    const today = new Date().toDateString();
                    
                    if (!force && (now - lastSleepUpdateMs < SLEEP_THROTTLE_MS) && lastSleepDate === today) {
                        updateSleepText();
                        return;
                    }
                    
                    sleep.updateInfo();                    
                    let currentTotal = sleep.getTotalTime();
                    
                    if (currentTotal <= 0) {
                        try {
                            const info = sleep.getBasicInfo();
                            if (info && info.totalTime > 0) {
                                currentTotal = info.totalTime;
                            }
                        } catch (e) {}
                    }
                    
                    if (currentTotal <= 0 || !isFinite(currentTotal)) {
                        cachedSleepText = "00:00";
                        lastTotalMinutes = 0;
                        lastSleepDate = today;
                        lastSleepUpdateMs = now;
                        updateSleepText();
                        return;
                    }

                    let totalMinutes = currentTotal;
                    
                    if (totalMinutes > 90) {
                        try {
                            const stages = sleep.getSleepStageData();
                            if (stages && stages.length > 0) {
                                const model = sleep.getSleepStageModel();
                                let wakeMinutes = 0;
                                for (let i = 0, len = stages.length; i < len; i++) {
                                    const st = stages[i];
                                    if (st.model === model.WAKE_STAGE) {
                                        wakeMinutes += (st.stop + 1 - st.start);
                                    }
                                }
                                totalMinutes = Math.max(0, totalMinutes - wakeMinutes);
                            }
                        } catch (e) {
                            
                            console.log("Sleep stages error:", e);
                        }
                    }

                    
                    if (totalMinutes > 960) totalMinutes = 0;

                    cachedSleepText = formatMinutes(totalMinutes);
                    lastSleepDate = today;
                    lastTotalMinutes = currentTotal;
                    lastSleepUpdateMs = now;

                    updateSleepText();

                    console.log(`[SLEEP] Success: ${cachedSleepText} (${totalMinutes} min, total=${currentTotal})`);

                } catch (e) {
                    console.log("calculateAndCacheRealSleep error:", e);
                    cachedSleepText = "00:00";
                    updateSleepText();
                }
            }

            function updateSleepText() {
                if (!sleep_time_txt) return;
                if (hmSetting.getScreenType() === hmSetting.screen_type.AOD) return;

                if (lastShownSleepText !== cachedSleepText) {
                    try {
                        sleep_time_txt.setProperty(hmUI.prop.TEXT, cachedSleepText);
                    } catch (e) { }
                    lastShownSleepText = cachedSleepText;
                }
            }            
        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: impact.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 402,
              h: 46,
              text_size: 30,
              char_space: 1,
              line_space: 0,
              font: 'fonts/impact.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: impact.ttf; FontSize: 42
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 535,
              h: 62,
              text_size: 42,
              char_space: 1,
              line_space: 0,
              font: 'fonts/impact.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: impact.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 332,
              h: 38,
              text_size: 24,
              char_space: 1,
              line_space: 0,
              font: 'fonts/impact.ttf',
              color: 0xFFD3D3B8,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: impact.ttf; FontSize: 24; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 28,
              h: 28,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/impact.ttf',
              color: 0xFFD3D3B8,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: impact.ttf; FontSize: 35
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 422,
              h: 51,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/impact.ttf',
              color: 0xFFD3D3B8,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: impact.ttf; FontSize: 22
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 304,
              h: 33,
              text_size: 22,
              char_space: 1,
              line_space: 0,
              font: 'fonts/impact.ttf',
              color: 0xFFD3D3B8,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            

            const weatherInfo = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
            });

            weatherImg = weatherInfo.createWidget(hmUI.widget.IMG, {
                x: 219,
                y: 69,
                w: 80,
                h: 80,
                src: 'w_25.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            tempText = weatherInfo.createWidget(hmUI.widget.TEXT, {
                x: -6,
                y: -6,
                w: 492,
                h: 492,
                text_size: 35,
                char_space: 0,
                font: 'fonts/impact.ttf',
                color: 0xFFD3D3B8,
                // use_text_circle: true,
                start_angle: -103,
                end_angle: 0,
                mode: 0,
                // radius: 246,
                align_h: hmUI.align.CENTER_H,
                unit_type: 1,
                text: '--',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });
          

            descriptionText = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 110,
                y: 114,
                w: 264,
                h: 35,
                text_size: 24,
                char_space: 0,
                font: 'fonts/impact.ttf',
                text: '--',
                color: 0xFFD3D3B8,
                line_space: 0,
                align_v: hmUI.align.TOP,
                text_style: hmUI.text_style.ELLIPSIS,
                align_h: hmUI.align.CENTER_H,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            weatherProvider = new WeatherProvider({
                time_sensor: curTime,
                temp_widget: tempText,
                cityName_widget: cityNameText,
                icon_widget: weatherImg,
                description_widget: descriptionText,
                night_icons: [0, 1, 2, 3, 14],
                show_toast: true
            });
            weatherProvider.update(true); 

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 314,
              day_startY: 324,
              day_sc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_tc_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_en_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 249,
              y: 291,
              week_en: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_tc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_sc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 75,
              y: 330,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 1,
              font: 'fonts/impact.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 171,
              y: 327,
              w: 150,
              h: 60,
              text_size: 42,
              char_space: 1,
              font: 'fonts/impact.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 94,
              y: 352,
              image_array: ["shag_0.png","shag_1.png","shag_2.png","shag_3.png","shag_4.png","shag_5.png","shag_6.png","shag_7.png","shag_8.png","shag_9.png","shag_10.png","shag_11.png","shag_12.png"],
              image_length: 13,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 234,
              y: 394,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 1,
              font: 'fonts/impact.ttf',
              color: 0xFFD3D3B8,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            text_pressure = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -6,
              y: -6,
              w: 492,
              h: 492,
              text_size: 35,
              char_space: 0,
              font: 'fonts/impact.ttf',
              color: 0xFFD3D3B8,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 106,
              mode: 0,
              // radius: 246,
              align_h: hmUI.align.CENTER_H,
              text: "--",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            text_trend_icon = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -6,
              y: -6,
              w: 492,
              h: 492,
              text_size: 25,
              char_space: 0,
              color: 0xFFD3D3B8,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 127,
              mode: 0,
              // radius: 246,
              align_h: hmUI.align.CENTER_H,
              text: "--",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });     
            
            barometer = new AdvancedBarometer({
                widget: text_pressure,
                trend_widget: text_trend_icon,
                time_sensor: curTime,   
            });   

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -5,
              y: -5,
              w: 490,
              h: 490,
              text_size: 35,
              char_space: 2,
              font: 'fonts/impact.ttf',
              color: 0xFFD3D3B8,
              // use_text_circle: true,
              start_angle: 180,
              end_angle: 285,
              mode: 1,
              // radius: 245,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -5,
              y: -5,
              w: 490,
              h: 490,
              text_size: 35,
              char_space: 2,
              font: 'fonts/impact.ttf',
              color: 0xFFD3D3B8,
              // use_text_circle: true,
              start_angle: 73,
              end_angle: 180,
              mode: 1,
              // radius: 245,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            sleep_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 99,
              y: 394,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 1,
              font: 'fonts/impact.ttf',
              color: 0xFFD3D3B8,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: "00:00",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            calculateAndCacheRealSleep(true);    

            normal_moon_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'zakat.png',
              center_x: 240,
              center_y: 240,
              x: 32,
              y: 245,
              start_angle: 146,
              end_angle: 214,
              invalid_visible: false,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 88,
              y: 74,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 1,
              font: 'fonts/impact.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 243,
              y: 74,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 1,
              font: 'fonts/impact.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'voshod.png',
              center_x: 240,
              center_y: 240,
              x: 32,
              y: 247,
              start_angle: -34,
              end_angle: 34,
              invalid_visible: false,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'zariad.png',
              center_x: 240,
              center_y: 240,
              x: 31,
              y: 236,
              start_angle: 69,
              end_angle: 111,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 2,
              y: 2,
              w: 476,
              h: 476,
              text_size: 22,
              char_space: 1,
              font: 'fonts/impact.ttf',
              color: 0xFFD3D3B8,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 182,
              mode: 0,
              // radius: 238,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: -1,
              y: 32,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 241,
              y: 387,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: 171,
              hour_array: ["HY_0.png","HY_1.png","HY_2.png","HY_3.png","HY_4.png","HY_5.png","HY_6.png","HY_7.png","HY_8.png","HY_9.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 259,
              minute_startY: 168,
              minute_array: ["M_0.png","M_1.png","M_2.png","M_3.png","M_4.png","M_5.png","M_6.png","M_7.png","M_8.png","M_9.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sekk.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 6,
              second_posY: 241,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 314,
              day_startY: 324,
              day_sc_array: ["dataA_0.png","dataA_1.png","dataA_2.png","dataA_3.png","dataA_4.png","dataA_5.png","dataA_6.png","dataA_7.png","dataA_8.png","dataA_9.png"],
              day_tc_array: ["dataA_0.png","dataA_1.png","dataA_2.png","dataA_3.png","dataA_4.png","dataA_5.png","dataA_6.png","dataA_7.png","dataA_8.png","dataA_9.png"],
              day_en_array: ["dataA_0.png","dataA_1.png","dataA_2.png","dataA_3.png","dataA_4.png","dataA_5.png","dataA_6.png","dataA_7.png","dataA_8.png","dataA_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 249,
              y: 291,
              week_en: ["DA_0.png","DA_1.png","DA_2.png","DA_3.png","DA_4.png","DA_5.png","DA_6.png"],
              week_tc: ["DA_0.png","DA_1.png","DA_2.png","DA_3.png","DA_4.png","DA_5.png","DA_6.png"],
              week_sc: ["DA_0.png","DA_1.png","DA_2.png","DA_3.png","DA_4.png","DA_5.png","DA_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 171,
              y: 327,
              w: 150,
              h: 60,
              text_size: 42,
              char_space: 1,
              font: 'fonts/impact.ttf',
              color: 0xFFD3D3B8,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 394,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 1,
              font: 'fonts/impact.ttf',
              color: 0xFFD3D3B8,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 219,
              y: 69,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 172,
              y: 118,
              w: 150,
              h: 40,
              text_size: 35,
              char_space: 0,
              font: 'fonts/impact.ttf',
              color: 0xFFD3D3B8,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 58,
              y: 327,
              w: 150,
              h: 70,
              text_size: 42,
              char_space: 1,
              font: 'fonts/impact.ttf',
              color: 0xFFD3D3B8,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 413,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: 171,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 259,
              minute_startY: 168,
              minute_array: ["Maod_0.png","Maod_1.png","Maod_2.png","Maod_3.png","Maod_4.png","Maod_5.png","Maod_6.png","Maod_7.png","Maod_8.png","Maod_9.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });            

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 196,
              y: 328,
              w: 98,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 28,
              y: 337,
              w: 71,
              h: 83,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 435,
              y: 210,
              w: 45,
              h: 64,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 192,
              y: 119,
              w: 100,
              h: 31,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 382,
              y: 60,
              w: 73,
              h: 82,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 103,
              y: 200,
              w: 70,
              h: 70,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 294,
              y: 190,
              w: 65,
              h: 65,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 248,
              y: 388,
              w: 91,
              h: 45,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 136,
              y: 388,
              w: 91,
              h: 45,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 380,
              y: 334,
              w: 77,
              h: 86,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: -2,
              y: 209,
              w: 55,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 313,
              y: 305,
              w: 55,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 27,
              y: 56,
              w: 85,
              h: 85,
              text: '',
              text_size: 25,
              color: 0xFFFF8C00,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: () => {
                weatherProvider.prev(true);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 216,
              y: 60,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button    
                    

            // Widget delegate (resume_call)
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {                                                              
                calculateAndCacheRealSleep();                                      
                                               
                if (barometer && barometer._onPressureChange) {
                    barometer._onPressureChange();
                }   
                if (weatherProvider) {
                    weatherProvider.update(false);
                }                         
              }),
            });

            //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                
                if (barometer) {
                    barometer.delete();
                    barometer = null;
                }
                
                if (weatherProvider) {
                    weatherProvider.delete();
                    weatherProvider = null;
                }
                
                if (curTime) {
                    if (curTimeMinuteHandler) {
                        try {
                            curTime.removeEventListener(hmSensor.event.MINUTEEND, curTimeMinuteHandler);
                        } catch (e) {
                            console.log('Error removing TIME listener:', e);
                        }
                        curTimeMinuteHandler = null;
                    }
                    curTime = null;
                }
                
                
                if (sleep) {
                    sleep.onSleepStateChange = null;
                    sleep = null;
                }
                
                lastSleepDate = null;
                lastShownSleepText = "--";

                logger.log('watchface destroyed — all cleaned OK');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}