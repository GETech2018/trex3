/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_battery_imageset2 = '';
		let normal_battery_imagecombo3 = '';
		let normal_steps_imageset5 = '';
		let normal_steps_imagecombo6 = '';
		let normal_weather_imageset8 = '';
		let normal_temperature_current_imagecombo9 = '';
		let normal_current_city_text10 = '';
		let normal_temperature_high_imagecombo11 = '';
		let normal_temperature_low_imagecombo12 = '';
		let normal_hour_imagecombo14 = '';
		let normal_minute_imagecombo15 = '';
		let normal_second_imagecombo16 = '';
		let timeInterval;
		let normal_ampm24_imageset17 = '';
		let normal_ampm24_imageset17_array = ['0117.png','0118.png','0119.png'];
		let normal_img19 = '';
		let normal_week_imageset20 = '';
		let normal_date_imagecombo21 = '';
		let normal_month_imageset22 = '';
		let idle_img25 = '';
		let idle_hour_imagecombo27 = '';
		let idle_minute_imagecombo28 = '';
		let idle_img29 = '';
		let idle_temperature_current_imagecombo31 = '';
		let idle_weather_imageset32 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imageset2 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 277,
					y: 46,
					image_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
					image_length: 11,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo3 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 225,
					y: 9,
					font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
					padding: false,
					h_space: 0,
					unit_sc: '0024.png',
					unit_tc: '0024.png',
					unit_en: '0024.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imageset5 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 268,
					y: 320,
					image_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
					image_length: 11,
					type: hmUI.data_type.STEP,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo6 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 209,
					y: 441,
					font_array: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
					padding: true,
					h_space: 0,
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset8 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 380,
					y: 185,
					image_array: ["0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0048.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0052.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo9 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 385,
					y: 249,
					font_array: ["0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0084.png"],
					unit_tc: ["0084.png"],
					unit_en: ["0084.png"],
					negative_image: ["0083.png"],
					invalid_image: ["0083.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_current_city_text10 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 65,
					y: 340,
					w: 215,
					h: 33,
					color: 0x7D7D7D,
					text: '--',
					text_size: 33,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Roboto-Medium.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_high_imagecombo11 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 438,
					y: 233,
					font_array: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0096.png"],
					unit_tc: ["0096.png"],
					unit_en: ["0096.png"],
					negative_image: ["0095.png"],
					invalid_image: ["0095.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_HIGH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_low_imagecombo12 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 340,
					y: 233,
					font_array: ["0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0096.png"],
					unit_tc: ["0096.png"],
					unit_en: ["0096.png"],
					negative_image: ["0095.png"],
					invalid_image: ["0095.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_LOW,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo14 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 89,
					hour_startY: 201,
					hour_array: ["0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.RIGHT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo15 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 185,
					minute_startY: 201,
					minute_array: ["0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo16 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 274,
					second_startY: 206,
					second_array: ["0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_ampm24_imageset17 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 273,
					y: 252,
					w: 273,
					h: 252,
					src: '0119.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_img19 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 166,
					y: 190,
					w: 18,
					h: 97,
					src: '0120.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset20 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 81,
					y: 111,
					week_en: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
					week_tc: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
					week_sc: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo21 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 137,
					day_startY: 111,
					day_sc_array: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png"],
					day_tc_array: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png"],
					day_en_array: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.LEFT,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset22 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 173,
					month_startY: 111,
					month_sc_array: ["0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png"],
					month_tc_array: ["0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png"],
					month_en_array: ["0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0150.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_imagecombo27 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 106,
					hour_startY: 193,
					hour_array: ["0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.RIGHT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo28 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 216,
					minute_startY: 193,
					minute_array: ["0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png","0160.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img29 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 197,
					y: 180,
					w: 22,
					h: 119,
					src: '0161.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_temperature_current_imagecombo31 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 378,
					y: 241,
					font_array: ["0162.png","0163.png","0164.png","0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0173.png"],
					unit_tc: ["0173.png"],
					unit_en: ["0173.png"],
					negative_image: ["0172.png"],
					invalid_image: ["0172.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_weather_imageset32 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 379,
					y: 181,
					image_array: ["0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0048.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0052.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateTime() {
					normal_ampm24_imageset17.setProperty(hmUI.prop.MORE, {
						src: normal_ampm24_imageset17_array[(hmSetting.getTimeFormat() == 0 ? (timeSensor.hour >= 0 && timeSensor.hour < 12 ? 0 : 1) : 2)]
					})
				}

				function updateWeather() {
					normal_current_city_text10.setProperty(hmUI.prop.TEXT, weatherSensor.getForecastWeather().cityName);
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				weatherSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateWeather();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						updateWeather();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}