    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        const lang = DeviceRuntimeCore.HmUtils.getLanguage()
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_icon_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_circle_scale_2 = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
let  normal_second_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 301,
              y: -309,
              src: 'SecondS_Bar.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

          let  normal_step_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 390,
              y: -468,
              src: 'StepS_Bar.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            // end user_script.js

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'BG1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 175,
              // center_y: 387,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 51,
              // line_width: 9,
              // line_cap: Flat,
              // color: 0xFFCFBA8E,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 175,
              center_y: 387,
              start_angle: 0,
              end_angle: 360,
              radius: 47,
              line_width: 9,
              corner_flag: 3,
              color: 0xFFCFBA8E,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 143,
              y: 387,
              font_array: ["DataB_0.png","DataB_1.png","DataB_2.png","DataB_3.png","DataB_4.png","DataB_5.png","DataB_6.png","DataB_7.png","DataB_8.png","DataB_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 122,
              y: 333,
              src: 'Top_power.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
			let sted=["i_en.png"]
				if(lang=='pt-BR'){
				   sted=["i_pt.png"]
			}	

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 278,
              y: 79,
              src: sted,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
				
			let dwed=["en_Week_1.png","en_Week_2.png","en_Week_3.png","en_Week_4.png","en_Week_5.png","en_Week_6.png","en_Week_7.png"]
				if(lang=='pt-BR'){
				   dwed=["pt_Week_1.png","pt_Week_2.png","pt_Week_3.png","pt_Week_4.png","pt_Week_5.png","pt_Week_6.png","pt_Week_7.png"]
			}	

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 320,
              y: 338,
              week_en: dwed,
              week_tc: ["en_Week_1.png","en_Week_2.png","en_Week_3.png","en_Week_4.png","en_Week_5.png","en_Week_6.png","en_Week_7.png"],
              week_sc: ["en_Week_1.png","en_Week_2.png","en_Week_3.png","en_Week_4.png","en_Week_5.png","en_Week_6.png","en_Week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 255,
              day_startY: 334,
              day_sc_array: ["DataB_0.png","DataB_1.png","DataB_2.png","DataB_3.png","DataB_4.png","DataB_5.png","DataB_6.png","DataB_7.png","DataB_8.png","DataB_9.png"],
              day_tc_array: ["DataB_0.png","DataB_1.png","DataB_2.png","DataB_3.png","DataB_4.png","DataB_5.png","DataB_6.png","DataB_7.png","DataB_8.png","DataB_9.png"],
              day_en_array: ["DataB_0.png","DataB_1.png","DataB_2.png","DataB_3.png","DataB_4.png","DataB_5.png","DataB_6.png","DataB_7.png","DataB_8.png","DataB_9.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 175,
              center_y: 95,
              start_angle: 0,
              end_angle: 360,
              radius: 47,
              line_width: 9,
              corner_flag: 3,
              type: hmUI.data_type.HEART,
              color: 0xFFCFBA8E,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 139,
              y: 95,
              font_array: ["DataB_0.png","DataB_1.png","DataB_2.png","DataB_3.png","DataB_4.png","DataB_5.png","DataB_6.png","DataB_7.png","DataB_8.png","DataB_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'DataB_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 122,
              y: 42,
              src: 'Top_Heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 258,
              y: 124,
              font_array: ["DataB_0.png","DataB_1.png","DataB_2.png","DataB_3.png","DataB_4.png","DataB_5.png","DataB_6.png","DataB_7.png","DataB_8.png","DataB_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 381,
              y: 129,
              src: 'Top_steps_progress.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 144,
              minute_startY: 208,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 7,
              hour_startY: 208,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 114,
              y: 207,
              src: 'Time_Dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AOD_BG.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 144,
              minute_startY: 208,
              minute_array: ["AOD_Time_0.png","AOD_Time_1.png","AOD_Time_2.png","AOD_Time_3.png","AOD_Time_4.png","AOD_Time_5.png","AOD_Time_6.png","AOD_Time_7.png","AOD_Time_8.png","AOD_Time_9.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 7,
              hour_startY: 208,
              hour_array: ["AOD_Time_0.png","AOD_Time_1.png","AOD_Time_2.png","AOD_Time_3.png","AOD_Time_4.png","AOD_Time_5.png","AOD_Time_6.png","AOD_Time_7.png","AOD_Time_8.png","AOD_Time_9.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 114,
              y: 207,
              src: 'AOD_Time_Dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 140,
              y: 342,
              w: 70,
              h: 89,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 302,
              y: 170,
              w: 70,
              h: 144,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 138,
              y: 53,
              w: 74,
              h: 84,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 247,
              y: 323,
              w: 137,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 249,
              y: 114,
              w: 135,
              h: 47,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

const time = hmSensor.createSensor(hmSensor.id.TIME);

 function second_image_call() {
const start = -308;
const end = 158;  // note : (7.9pix x 59)+(-308)
const step = (end - start) / 59;

            normal_second_img.setProperty(hmUI.prop.MORE, {
              x: 301,
              // y: -308+(time.second*7.9), // normal
             // y: Math.round(-308 + (time.second * 7.9)), // good
                y: Math.round(start + time.second * step),  // best
              src: 'SecondS_Bar.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

}


const stepSensor = hmSensor.createSensor(hmSensor.id.STEP);

// กำหนดตำแหน่งเริ่ม และ สิ้นสุดของ bar
const START_Y = -468;
const END_Y   = 0;

function step_image_call() {

  const currentStep = stepSensor.current;
  const targetStep  = stepSensor.target || 10000;

  let yPos;

  // ถ้าถึงหรือเกินเป้าหมาย → หยุดที่ END_Y
  if (currentStep >= targetStep) {

    yPos = END_Y;

  } else {

    let progress = currentStep / targetStep;

    yPos = Math.round(
      START_Y + (END_Y - START_Y) * progress
    );

  }

  normal_step_img.setProperty(hmUI.prop.MORE, {
    x: 390,
    y: yPos,
  });

}


timer.createTimer(0, 1000, second_image_call);  
timer.createTimer(0, 1000, step_image_call);
            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 175,
                      center_y: 387,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 47,
                      line_width: 9,
                      corner_flag: 3,
                      color: 0xFFCFBA8E,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}