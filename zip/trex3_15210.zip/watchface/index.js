/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_week_imageset2 = '';
		let normal_date_imagecombo3 = '';
		let normal_month_imageset4 = '';
		let normal_heart_rate_imageset6 = '';
		let normal_img7 = '';
		let normal_heart_current_imagecombo8 = '';
		let normal_heartrate_linegraph9 = '';
		let normal_img11 = '';
		let normal_steps_imagecombo12 = '';
		let normal_img13 = '';
		let normal_img15 = '';
		let normal_calories_imagecombo16 = '';
		let normal_img18 = '';
		let normal_stress_imagecombo19 = '';
		let normal_distance_imagecombo21 = '';
		let normal_img22 = '';
		let normal_blood_oxygen_imagecombo24 = '';
		let normal_img25 = '';
		let normal_hour_imagecombo27 = '';
		let normal_minute_imagecombo28 = '';
		let normal_img29 = '';
		let normal_battery_imageset31 = '';
		let idle_img34 = '';
		let idle_week_imageset36 = '';
		let idle_date_imagecombo37 = '';
		let idle_month_imageset38 = '';
		let idle_heart_rate_imageset40 = '';
		let idle_img41 = '';
		let idle_heart_current_imagecombo42 = '';
		let idle_heartrate_linegraph43 = '';
		let idle_img45 = '';
		let idle_steps_imagecombo46 = '';
		let idle_img47 = '';
		let idle_img49 = '';
		let idle_calories_imagecombo50 = '';
		let idle_img52 = '';
		let idle_stress_imagecombo53 = '';
		let idle_distance_imagecombo55 = '';
		let idle_img56 = '';
		let idle_blood_oxygen_imagecombo58 = '';
		let idle_img59 = '';
		let idle_hour_imagecombo61 = '';
		let idle_minute_imagecombo62 = '';
		let idle_img63 = '';
		let idle_battery_imageset65 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset2 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 54,
					y: 92,
					week_en: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png"],
					week_tc: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png"],
					week_sc: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo3 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 160,
					day_startY: 33,
					day_sc_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
					day_tc_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
					day_en_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.LEFT,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset4 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 261,
					month_startY: 41,
					month_sc_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
					month_tc_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
					month_en_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_rate_imageset6 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 157,
					y: 217,
					image_array: ["0032.png","0033.png","0033.png","0033.png","0034.png","0034.png"],
					image_length: 6,
					type: hmUI.data_type.HEART,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 247,
					y: 223,
					w: 28,
					h: 26,
					src: '0035.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo8 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 259,
					y: 253,
					font_array: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
					padding: true,
					h_space: 0,
					invalid_image: '0046.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heartrate_linegraph9 = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, {
					x: 115,
					y: 277,
					w: 105,
					h: 28,
					line_color: 0xFF0000,
					line_width: 1,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 282,
					y: 224,
					w: 39,
					h: 17,
					src: '0047.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo12 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 150,
					y: 157,
					font_array: ["0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png"],
					padding: true,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 193,
					y: 138,
					w: 97,
					h: 23,
					src: '0058.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 25,
					y: 124,
					w: 28,
					h: 28,
					src: '0059.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo16 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 30,
					y: 160,
					font_array: ["0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img18 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 7,
					y: 199,
					w: 28,
					h: 35,
					src: '0070.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_imagecombo19 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 29,
					y: 234,
					font_array: ["0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo21 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 397,
					y: 160,
					font_array: ["0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png"],
					padding: false,
					h_space: 0,
					dot_image: '0081.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img22 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 427,
					y: 125,
					w: 23,
					h: 32,
					src: '0082.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_blood_oxygen_imagecombo24 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 417,
					y: 233,
					font_array: ["0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.SPO2,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 445,
					y: 200,
					w: 28,
					h: 29,
					src: '0083.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo27 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 110,
					hour_startY: 361,
					hour_array: ["0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.RIGHT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo28 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 254,
					minute_startY: 361,
					minute_array: ["0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img29 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 235,
					y: 356,
					w: 15,
					h: 70,
					src: '0094.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imageset31 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 144,
					y: 334,
					image_array: ["0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
					image_length: 11,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img34 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0106.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_week_imageset36 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 54,
					y: 92,
					week_en: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png"],
					week_tc: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png"],
					week_sc: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png"],
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_imagecombo37 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 160,
					day_startY: 33,
					day_sc_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
					day_tc_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
					day_en_array: ["0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.LEFT,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_month_imageset38 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 261,
					month_startY: 41,
					month_sc_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
					month_tc_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
					month_en_array: ["0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_heart_rate_imageset40 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 157,
					y: 217,
					image_array: ["0032.png","0033.png","0033.png","0033.png","0034.png","0034.png"],
					image_length: 6,
					type: hmUI.data_type.HEART,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img41 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 247,
					y: 223,
					w: 28,
					h: 26,
					src: '0035.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_heart_current_imagecombo42 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 259,
					y: 253,
					font_array: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png"],
					padding: true,
					h_space: 0,
					invalid_image: '0046.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_heartrate_linegraph43 = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, {
					x: 115,
					y: 277,
					w: 105,
					h: 28,
					line_color: 0xFF0000,
					line_width: 1,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img45 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 282,
					y: 224,
					w: 39,
					h: 17,
					src: '0047.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_steps_imagecombo46 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 150,
					y: 157,
					font_array: ["0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png"],
					padding: true,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img47 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 193,
					y: 138,
					w: 97,
					h: 23,
					src: '0058.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img49 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 25,
					y: 124,
					w: 28,
					h: 28,
					src: '0059.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_calories_imagecombo50 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 30,
					y: 160,
					font_array: ["0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img52 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 7,
					y: 199,
					w: 28,
					h: 35,
					src: '0070.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_stress_imagecombo53 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 29,
					y: 234,
					font_array: ["0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_distance_imagecombo55 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 397,
					y: 160,
					font_array: ["0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png"],
					padding: false,
					h_space: 0,
					dot_image: '0081.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img56 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 427,
					y: 125,
					w: 23,
					h: 32,
					src: '0082.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_blood_oxygen_imagecombo58 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 417,
					y: 233,
					font_array: ["0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.SPO2,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img59 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 445,
					y: 200,
					w: 28,
					h: 29,
					src: '0083.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_imagecombo61 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 110,
					hour_startY: 361,
					hour_array: ["0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.RIGHT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo62 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 254,
					minute_startY: 361,
					minute_array: ["0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img63 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 235,
					y: 356,
					w: 15,
					h: 70,
					src: '0094.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_battery_imageset65 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 144,
					y: 334,
					image_array: ["0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
					image_length: 11,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}