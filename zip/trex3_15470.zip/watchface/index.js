﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_uvi_text_text_img = ''
        let normal_uvi_text_separator_img = ''
        let normal_wind_text_text_img = ''
        let normal_wind_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_moon_high_text_font = ''
        let normal_moon_low_text_font = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_linear_scale = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_humidity_text_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 223,
              y: 331,
              src: 'Wid-B.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 223,
              y: 297,
              src: 'Wid-A.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 244,
              y: 83,
              font_array: ["00_ml00.png","00_ml01.png","00_ml02.png","00_ml03.png","00_ml04.png","00_ml05.png","00_ml06.png","00_ml07.png","00_ml08.png","00_ml09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 201,
              y: 86,
              src: '00__UVI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 47,
              font_array: ["00_ml00.png","00_ml01.png","00_ml02.png","00_ml03.png","00_ml04.png","00_ml05.png","00_ml06.png","00_ml07.png","00_ml08.png","00_ml09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 313,
              y: 51,
              src: '00__km_h.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 428,
              font_array: ["00_ml00.png","00_ml01.png","00_ml02.png","00_ml03.png","00_ml04.png","00_ml05.png","00_ml06.png","00_ml07.png","00_ml08.png","00_ml09.png"],
              padding: false,
              h_space: 0,
              dot_image: '0150.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 278,
              y: 430,
              src: '00__km.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 27,
              y: 163,
              week_en: ["tyg__01.png","tyg__02.png","tyg__03.png","tyg__04.png","tyg__05.png","tyg__06.png","tyg__07.png"],
              week_tc: ["tyg__01.png","tyg__02.png","tyg__03.png","tyg__04.png","tyg__05.png","tyg__06.png","tyg__07.png"],
              week_sc: ["tyg__01.png","tyg__02.png","tyg__03.png","tyg__04.png","tyg__05.png","tyg__06.png","tyg__07.png"],
              // alpha: 230,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img.setAlpha(230);

            normal_moon_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 312,
              y: 298,
              w: 70,
              h: 29,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.MOON_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 312,
              y: 331,
              w: 70,
              h: 29,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.MOON_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 392,
              y: 300,
              image_array: ["moon__01.png","moon__02.png","moon__03.png","moon__04.png","moon__05.png","moon__06.png","moon__07.png","moon__08.png","moon__09.png","moon__10.png","moon__11.png","moon__12.png","moon__13.png","moon__14.png","moon__15.png","moon__16.png","moon__17.png","moon__18.png","moon__19.png","moon__20.png","moon__21.png","moon__22.png","moon__23.png","moon__24.png","moon__25.png","moon__26.png","moon__27.png"],
              image_length: 27,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 40,
              // start_y: 287,
              // color: 0xFFA7A7A7,
              // lenght: 400,
              // line_width: 5,
              // line_cap: Rounded,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 324,
              y: 382,
              font_array: ["00_ml00.png","00_ml01.png","00_ml02.png","00_ml03.png","00_ml04.png","00_ml05.png","00_ml06.png","00_ml07.png","00_ml08.png","00_ml09.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0176.png',
              unit_tc: '0176.png',
              unit_en: '0176.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 272,
              y: 387,
              src: '00__SpO2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 382,
              font_array: ["00_ml00.png","00_ml01.png","00_ml02.png","00_ml03.png","00_ml04.png","00_ml05.png","00_ml06.png","00_ml07.png","00_ml08.png","00_ml09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 162,
              y: 387,
              src: '00__bpm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 111,
              y: 47,
              font_array: ["00_ml00.png","00_ml01.png","00_ml02.png","00_ml03.png","00_ml04.png","00_ml05.png","00_ml06.png","00_ml07.png","00_ml08.png","00_ml09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 179,
              y: 50,
              src: '00__hPa.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 16,
              font_array: ["00_ml00.png","00_ml01.png","00_ml02.png","00_ml03.png","00_ml04.png","00_ml05.png","00_ml06.png","00_ml07.png","00_ml08.png","00_ml09.png"],
              padding: false,
              h_space: 1,
              unit_sc: '0176.png',
              unit_tc: '0176.png',
              unit_en: '0176.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 370,
              year_startY: 167,
              year_sc_array: ["00_ml00.png","00_ml01.png","00_ml02.png","00_ml03.png","00_ml04.png","00_ml05.png","00_ml06.png","00_ml07.png","00_ml08.png","00_ml09.png"],
              year_tc_array: ["00_ml00.png","00_ml01.png","00_ml02.png","00_ml03.png","00_ml04.png","00_ml05.png","00_ml06.png","00_ml07.png","00_ml08.png","00_ml09.png"],
              year_en_array: ["00_ml00.png","00_ml01.png","00_ml02.png","00_ml03.png","00_ml04.png","00_ml05.png","00_ml06.png","00_ml07.png","00_ml08.png","00_ml09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              // alpha: 230,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year.setAlpha(230);

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 290,
              month_startY: 162,
              month_sc_array: ["mies__01.png","mies__02.png","mies__03.png","mies__04.png","mies__05.png","mies__06.png","mies__07.png","mies__08.png","mies__09.png","mies__10.png","mies__11.png","mies__12.png"],
              month_tc_array: ["mies__01.png","mies__02.png","mies__03.png","mies__04.png","mies__05.png","mies__06.png","mies__07.png","mies__08.png","mies__09.png","mies__10.png","mies__11.png","mies__12.png"],
              month_en_array: ["mies__01.png","mies__02.png","mies__03.png","mies__04.png","mies__05.png","mies__06.png","mies__07.png","mies__08.png","mies__09.png","mies__10.png","mies__11.png","mies__12.png"],
              // alpha: 230,
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img.setAlpha(230);

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 238,
              day_startY: 167,
              day_sc_array: ["00_ml00.png","00_ml01.png","00_ml02.png","00_ml03.png","00_ml04.png","00_ml05.png","00_ml06.png","00_ml07.png","00_ml08.png","00_ml09.png"],
              day_tc_array: ["00_ml00.png","00_ml01.png","00_ml02.png","00_ml03.png","00_ml04.png","00_ml05.png","00_ml06.png","00_ml07.png","00_ml08.png","00_ml09.png"],
              day_en_array: ["00_ml00.png","00_ml01.png","00_ml02.png","00_ml03.png","00_ml04.png","00_ml05.png","00_ml06.png","00_ml07.png","00_ml08.png","00_ml09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              // alpha: 230,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day.setAlpha(230);

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 99,
              y: 298,
              w: 70,
              h: 29,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 99,
              y: 331,
              w: 70,
              h: 29,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 27,
              y: 295,
              image_array: ["Meteo_01.png","Meteo_02.png","Meteo_03.png","Meteo_04.png","Meteo_05.png","Meteo_06.png","Meteo_07.png","Meteo_08.png","Meteo_09.png","Meteo_10.png","Meteo_11.png","Meteo_12.png","Meteo_13.png","Meteo_14.png","Meteo_15.png","Meteo_16.png","Meteo_17.png","Meteo_18.png","Meteo_19.png","Meteo_20.png","Meteo_21.png","Meteo_22.png","Meteo_23.png","Meteo_24.png","Meteo_25.png","Meteo_26.png","Meteo_27.png","Meteo_28.png","Meteo_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 355,
              y: 120,
              font_array: ["00_ml00.png","00_ml01.png","00_ml02.png","00_ml03.png","00_ml04.png","00_ml05.png","00_ml06.png","00_ml07.png","00_ml08.png","00_ml09.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0075.png',
              unit_tc: '0075.png',
              unit_en: '0075.png',
              negative_image: '0074.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 367,
              y: 98,
              src: '00__max.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 120,
              font_array: ["00_ml00.png","00_ml01.png","00_ml02.png","00_ml03.png","00_ml04.png","00_ml05.png","00_ml06.png","00_ml07.png","00_ml08.png","00_ml09.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0075.png',
              unit_tc: '0075.png',
              unit_en: '0075.png',
              negative_image: '0074.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 142,
              src: '00__min.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 120,
              font_array: ["00_ml00.png","00_ml01.png","00_ml02.png","00_ml03.png","00_ml04.png","00_ml05.png","00_ml06.png","00_ml07.png","00_ml08.png","00_ml09.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0075.png',
              unit_tc: '0075.png',
              unit_en: '0075.png',
              negative_image: '0074.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 57,
              y: 115,
              src: '0139.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 200,
              hour_array: ["00_dl00.png","00_dl01.png","00_dl02.png","00_dl03.png","00_dl04.png","00_dl05.png","00_dl06.png","00_dl07.png","00_dl08.png","00_dl09.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: '0012.png',
              hour_unit_tc: '0012.png',
              hour_unit_en: '0012.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 140,
              minute_startY: 173,
              minute_array: ["00_dl00.png","00_dl01.png","00_dl02.png","00_dl03.png","00_dl04.png","00_dl05.png","00_dl06.png","00_dl07.png","00_dl08.png","00_dl09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: '0012b.png',
              minute_unit_tc: '0012b.png',
              minute_unit_en: '0012b.png',
              minute_align: hmUI.align.RIGHT,

              second_startX: 0,
              second_startY: 0,
              second_array: ["00_dld00.png","00_dld01.png","00_dld02.png","00_dld03.png","00_dld04.png","00_dld05.png","00_dld06.png","00_dld07.png","00_dld08.png","00_dld09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 415,
              w: 91,
              h: 66,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 45,
              y: 375,
              w: 136,
              h: 97,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 5,
              y: 298,
              w: 165,
              h: 63,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 312,
              y: 298,
              w: 162,
              h: 63,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 45,
              y: 113,
              w: 391,
              h: 45,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 375,
              w: 136,
              h: 100,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 75,
              y: 15,
              w: 92,
              h: 61,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 173,
              y: 200,
              w: 122,
              h: 81,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 30,
              y: 200,
              w: 122,
              h: 81,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 201,
              y: 299,
              w: 80,
              h: 80,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 40;
                  let start_y_normal_battery = 287;
                  let lenght_ls_normal_battery = 400;
                  let line_width_ls_normal_battery = 5;
                  let color_ls_normal_battery = 0xFFA7A7A7;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    radius: 2,
                    color: color_ls_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}