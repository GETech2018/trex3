﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let editBg = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_linear_scale_pointer_img = ''
        let normal_heart_rate_text_font = ''
        let normal_step_linear_scale = ''
        let normal_step_linear_scale_pointer_img = ''
        let normal_step_current_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_max_min_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_battery_linear_scale = ''
        let normal_battery_linear_scale_pointer_img = ''
        let normal_battery_current_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];
        let normal_day_text_font = ''
        let normal_time_hour_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_minute_text_font = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg_img = ''
        let idle_heart_rate_linear_scale = ''
        let idle_heart_rate_linear_scale_pointer_img = ''
        let idle_heart_rate_text_font = ''
        let idle_step_linear_scale = ''
        let idle_step_linear_scale_pointer_img = ''
        let idle_step_current_text_font = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_max_min_text_font = ''
        let idle_temperature_current_text_font = ''
        let idle_battery_linear_scale = ''
        let idle_battery_linear_scale_pointer_img = ''
        let idle_battery_current_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'];
        let idle_day_text_font = ''
        let idle_time_hour_text_font = ''
        let idle_timerTimeUpdate = undefined;
        let idle_time_minute_text_font = ''
        let idle_system_disconnect_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Dock_51.ttf; FontSize: 138
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 464,
              y: 464,
              w: 1699,
              h: 172,
              text_size: 138,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Dock_51.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 466,
              // h: 466,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'Picsart_26-01-01_19-17-09-752-picsay.png', path: 'Picsart_26-01-01_19-17-09-752-picsay.png' },
                { id: 2, preview: 'Picsart_26-01-01_19-15-22-208-picsay.png', path: 'Picsart_26-01-01_19-15-22-208-picsay.png' },
                { id: 3, preview: 'Picsart_26-01-01_19-15-54-187-picsay.png', path: 'Picsart_26-01-01_19-15-54-187-picsay.png' },
                { id: 4, preview: 'Picsart_26-01-01_19-10-08-226-picsay.png', path: 'Picsart_26-01-01_19-10-08-226-picsay.png' },
                { id: 5, preview: 'Picsart_26-01-01_19-14-29-466-picsay.png', path: 'Picsart_26-01-01_19-14-29-466-picsay.png' },
                { id: 6, preview: 'Picsart_26-01-04_12-15-47-599.png', path: 'Picsart_26-01-04_12-15-47-599.png' },
                { id: 7, preview: 'Picsart_26-01-04_12-17-23-003.png', path: 'Picsart_26-01-04_12-17-23-003.png' },
              ],
              count: 7,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_heart_rate_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 261,
              // start_y: 72,
              // color: 0xFFFF0000,
              // pointer: '0104.png',
              // lenght: 141,
              // line_width: 17,
              // line_cap: Rounded,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 238,
              y: 233,
              w: 60,
              h: 26,
              text_size: 23,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_step_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 380,
              // start_y: 73,
              // color: 0xFF8000FF,
              // pointer: '0103.png',
              // lenght: 141,
              // line_width: 17,
              // line_cap: Rounded,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 344,
              y: 235,
              w: 84,
              h: 26,
              text_size: 23,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 201,
              y: 383,
              image_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 433,
              w: 146,
              h: 30,
              text_size: 23,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 270,
              y: 398,
              w: 49,
              h: 30,
              text_size: 23,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            normal_battery_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 320,
              // start_y: 94,
              // color: 0xFF00FF00,
              // pointer: '0068.png',
              // lenght: 162,
              // line_width: 17,
              // line_cap: Rounded,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 312,
              y: 254,
              w: 57,
              h: 39,
              text_size: 29,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 282,
              y: 30,
              w: 35,
              h: 37,
              text_size: 27,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: Mo, Tu, We, Th, Fr, Sa, Su,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 319,
              y: 28,
              w: 53,
              h: 38,
              text_size: 31,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 49,
              y: 57,
              w: 187,
              h: 139,
              text_size: 138,
              char_space: 0,
              font: 'fonts/Dock_51.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 49,
              y: 159,
              w: 187,
              h: 129,
              text_size: 138,
              char_space: 0,
              font: 'fonts/Dock_51.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 14,
              y: 206,
              src: 'Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 466,
              h: 466,
              src: 'Picsart_26-01-01_19-14-29-466-picsay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            idle_heart_rate_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // idle_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 261,
              // start_y: 72,
              // color: 0xFFE80074,
              // pointer: '0104.png',
              // lenght: 141,
              // line_width: 17,
              // line_cap: Rounded,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 238,
              y: 233,
              w: 60,
              h: 26,
              text_size: 23,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            idle_step_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // idle_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 380,
              // start_y: 73,
              // color: 0xFF80FFFF,
              // pointer: '0103.png',
              // lenght: 141,
              // line_width: 17,
              // line_cap: Rounded,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 344,
              y: 235,
              w: 84,
              h: 26,
              text_size: 23,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.BOTTOM,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 201,
              y: 383,
              image_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_max_min_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 433,
              w: 146,
              h: 30,
              text_size: 23,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 270,
              y: 398,
              w: 49,
              h: 30,
              text_size: 23,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            idle_battery_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 320,
              // start_y: 94,
              // color: 0xFF80FF00,
              // pointer: '0068.png',
              // lenght: 162,
              // line_width: 17,
              // line_cap: Rounded,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 312,
              y: 254,
              w: 57,
              h: 39,
              text_size: 29,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 282,
              y: 30,
              w: 35,
              h: 37,
              text_size: 27,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: Mo, Tu, We, Th, Fr, Sa, Su,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 319,
              y: 28,
              w: 53,
              h: 38,
              text_size: 31,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 49,
              y: 57,
              w: 187,
              h: 139,
              text_size: 138,
              char_space: 0,
              font: 'fonts/Dock_51.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 49,
              y: 159,
              w: 187,
              h: 129,
              text_size: 138,
              char_space: 0,
              font: 'fonts/Dock_51.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 14,
              y: 206,
              src: 'Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 374,
              y: 70,
              w: 29,
              h: 194,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 254,
              y: 70,
              w: 29,
              h: 194,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 315,
              y: 95,
              w: 29,
              h: 194,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 117,
              y: 392,
              w: 239,
              h: 97,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 88,
              y: 180,
              w: 97,
              h: 97,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 88,
              y: 59,
              w: 97,
              h: 97,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 103,
              y: 0,
              w: 257,
              h: 55,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              console.log('hour font');
              if (updateHour) {
                let idle_hourStr = format_hour.toString();
                idle_hourStr = idle_hourStr.padStart(2, '0');
                idle_time_hour_text_font.setProperty(hmUI.prop.TEXT, idle_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let idle_minuteStr = minute.toString();
                idle_minuteStr = idle_minuteStr.padStart(2, '0');
                idle_time_minute_text_font.setProperty(hmUI.prop.TEXT, idle_minuteStr );
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 184;
                let progressHeartRate = (valueHeartRate - 30)/(targetHeartRate - 30);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 261;
                  let start_y_normal_heart_rate = 72;
                  let lenght_ls_normal_heart_rate = 141;
                  let line_width_ls_normal_heart_rate = 17;
                  let color_ls_normal_heart_rate = 0xFFFF0000;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    line_width_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_y_normal_heart_rate_draw = start_y_normal_heart_rate_draw - line_width_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    radius: 8,
                    color: color_ls_normal_heart_rate,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_heart_rate = 18;
                  let pointer_offset_y_ls_normal_heart_rate = 16;
                  normal_heart_rate_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw + line_width_ls_normal_heart_rate / 2 - pointer_offset_x_ls_normal_heart_rate,
                    y: start_y_normal_heart_rate + lenght_ls_normal_heart_rate - pointer_offset_y_ls_normal_heart_rate,
                    src: '0104.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 380;
                  let start_y_normal_step = 73;
                  let lenght_ls_normal_step = 141;
                  let line_width_ls_normal_step = 17;
                  let color_ls_normal_step = 0xFF8000FF;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = line_width_ls_normal_step;
                  let line_width_ls_normal_step_draw = lenght_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    line_width_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_y_normal_step_draw = start_y_normal_step_draw - line_width_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    radius: 8,
                    color: color_ls_normal_step,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_step = 17;
                  let pointer_offset_y_ls_normal_step = 16;
                  normal_step_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw + line_width_ls_normal_step / 2 - pointer_offset_x_ls_normal_step,
                    y: start_y_normal_step + lenght_ls_normal_step - pointer_offset_y_ls_normal_step,
                    src: '0103.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 320;
                  let start_y_normal_battery = 94;
                  let lenght_ls_normal_battery = 162;
                  let line_width_ls_normal_battery = 17;
                  let color_ls_normal_battery = 0xFF00FF00;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = line_width_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = lenght_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    line_width_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_y_normal_battery_draw = start_y_normal_battery_draw - line_width_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    radius: 8,
                    color: color_ls_normal_battery,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_normal_battery = 20;
                  let pointer_offset_y_ls_normal_battery = 21;
                  normal_battery_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw + line_width_ls_normal_battery / 2 - pointer_offset_x_ls_normal_battery,
                    y: start_y_normal_battery + lenght_ls_normal_battery - pointer_offset_y_ls_normal_battery,
                    src: '0068.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

                console.log('update scales HEART');
                let progress_ls_idle_heart_rate = progressHeartRate;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_heart_rate_linear_scale
                  // initial parameters
                  let start_x_idle_heart_rate = 261;
                  let start_y_idle_heart_rate = 72;
                  let lenght_ls_idle_heart_rate = 141;
                  let line_width_ls_idle_heart_rate = 17;
                  let color_ls_idle_heart_rate = 0xFFE80074;
                  
                  // calculated parameters
                  let start_x_idle_heart_rate_draw = start_x_idle_heart_rate;
                  let start_y_idle_heart_rate_draw = start_y_idle_heart_rate;
                  lenght_ls_idle_heart_rate = lenght_ls_idle_heart_rate * progress_ls_idle_heart_rate;
                  let lenght_ls_idle_heart_rate_draw = line_width_ls_idle_heart_rate;
                  let line_width_ls_idle_heart_rate_draw = lenght_ls_idle_heart_rate;
                  if (lenght_ls_idle_heart_rate < 0){
                    line_width_ls_idle_heart_rate_draw = -lenght_ls_idle_heart_rate;
                    start_y_idle_heart_rate_draw = start_y_idle_heart_rate_draw - line_width_ls_idle_heart_rate_draw;
                  };
                  
                  idle_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_heart_rate_draw,
                    y: start_y_idle_heart_rate_draw,
                    w: lenght_ls_idle_heart_rate_draw,
                    h: line_width_ls_idle_heart_rate_draw,
                    radius: 8,
                    color: color_ls_idle_heart_rate,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_idle_heart_rate = 18;
                  let pointer_offset_y_ls_idle_heart_rate = 16;
                  idle_heart_rate_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_heart_rate_draw + line_width_ls_idle_heart_rate / 2 - pointer_offset_x_ls_idle_heart_rate,
                    y: start_y_idle_heart_rate + lenght_ls_idle_heart_rate - pointer_offset_y_ls_idle_heart_rate,
                    src: '0104.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                  });
                };

                console.log('update scales STEP');
                let progress_ls_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_linear_scale
                  // initial parameters
                  let start_x_idle_step = 380;
                  let start_y_idle_step = 73;
                  let lenght_ls_idle_step = 141;
                  let line_width_ls_idle_step = 17;
                  let color_ls_idle_step = 0xFF80FFFF;
                  
                  // calculated parameters
                  let start_x_idle_step_draw = start_x_idle_step;
                  let start_y_idle_step_draw = start_y_idle_step;
                  lenght_ls_idle_step = lenght_ls_idle_step * progress_ls_idle_step;
                  let lenght_ls_idle_step_draw = line_width_ls_idle_step;
                  let line_width_ls_idle_step_draw = lenght_ls_idle_step;
                  if (lenght_ls_idle_step < 0){
                    line_width_ls_idle_step_draw = -lenght_ls_idle_step;
                    start_y_idle_step_draw = start_y_idle_step_draw - line_width_ls_idle_step_draw;
                  };
                  
                  idle_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step_draw,
                    y: start_y_idle_step_draw,
                    w: lenght_ls_idle_step_draw,
                    h: line_width_ls_idle_step_draw,
                    radius: 8,
                    color: color_ls_idle_step,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_idle_step = 17;
                  let pointer_offset_y_ls_idle_step = 16;
                  idle_step_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_step_draw + line_width_ls_idle_step / 2 - pointer_offset_x_ls_idle_step,
                    y: start_y_idle_step + lenght_ls_idle_step - pointer_offset_y_ls_idle_step,
                    src: '0103.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 320;
                  let start_y_idle_battery = 94;
                  let lenght_ls_idle_battery = 162;
                  let line_width_ls_idle_battery = 17;
                  let color_ls_idle_battery = 0xFF80FF00;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = line_width_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = lenght_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    line_width_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_y_idle_battery_draw = start_y_idle_battery_draw - line_width_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    radius: 8,
                    color: color_ls_idle_battery,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_idle_battery = 20;
                  let pointer_offset_y_ls_idle_battery = 21;
                  idle_battery_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw + line_width_ls_idle_battery / 2 - pointer_offset_x_ls_idle_battery,
                    y: start_y_idle_battery + lenght_ls_idle_battery - pointer_offset_y_ls_idle_battery,
                    src: '0068.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTimeUpdate) {
                    idle_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (idle_timerTimeUpdate) {
                  timer.stopTimer(idle_timerTimeUpdate);
                  idle_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}