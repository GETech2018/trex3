﻿    /*
    ** Watch_Face_Editor tool v 17.2
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

       let barowind_num = 0
       let barowind_all = 2
		function click_barowind() {
		  barowind_num = (barowind_num + 1) % (barowind_all + 1);
          if (barowind_num == 0) {	
		  normal_altimeter_current_text_font.setProperty(hmUI.prop.VISIBLE, true);	 
          normal_widget_text_1.setProperty(hmUI.prop.VISIBLE, true);			  
	      normal_pressure_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_widget_text_2.setProperty(hmUI.prop.VISIBLE, false);
          normal_wind_speed_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);	  
    
          };
          if (barowind_num == 1) {			  
		  normal_altimeter_current_text_font.setProperty(hmUI.prop.VISIBLE, false);	  
		  normal_widget_text_1.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pressure_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_widget_text_2.setProperty(hmUI.prop.VISIBLE, true);
          normal_wind_speed_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);	  
          };
		  
          if (barowind_num == 2) {			  
		  normal_altimeter_current_text_font.setProperty(hmUI.prop.VISIBLE, false);	  
		  normal_widget_text_1.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pressure_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_widget_text_2.setProperty(hmUI.prop.VISIBLE, false);
          normal_wind_speed_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);	  
          };	  		  
		}

       let kardio_num = 0
       let kardio_all = 2
		function click_kardio() {
		  kardio_num = (kardio_num + 1) % (kardio_all + 1);
          if (kardio_num == 0) {	
		  normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, true);	 
          normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);			  
	      normal_bio_charge_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_bio_charge_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_hrv_current_text_font.setProperty(hmUI.prop.VISIBLE, false);	
          normal_hrv_icon_img.setProperty(hmUI.prop.VISIBLE, false);		  
          };
          if (kardio_num == 1) {			  
		  normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);	  
		  normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_bio_charge_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_bio_charge_icon_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_hrv_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_hrv_icon_img.setProperty(hmUI.prop.VISIBLE, false);		  
          };	 
          if (kardio_num == 2) {			  
		  normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, false);	  
		  normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_bio_charge_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_bio_charge_icon_img.setProperty(hmUI.prop.VISIBLE, false);	
          normal_hrv_current_text_font.setProperty(hmUI.prop.VISIBLE, true);	
          normal_hrv_icon_img.setProperty(hmUI.prop.VISIBLE, true);			  
          };		  
		}
       let stcalfat_num = 0
       let stcalfat_all = 2
		function click_stcalfat() {
		  stcalfat_num = (stcalfat_num + 1) % (stcalfat_all + 1);
          if (stcalfat_num == 0) {	
		  normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, true);	 
          normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);		  
          normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);	
          normal_fat_burning_current_text_font.setProperty(hmUI.prop.VISIBLE, false);		  
          normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  };
          if (stcalfat_num == 1) {			  
		  normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);	  
		  normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_fat_burning_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);
		  };	 
          if (stcalfat_num == 2) {			  
		  normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, false);	  
		  normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);	
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);	
		  normal_fat_burning_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		  };		  
		}				

      let batbtemp_num = 0
       let batbtemp_all = 1
		function click_batbtemp() {
		  batbtemp_num = (batbtemp_num + 1) % (batbtemp_all + 1);
          if (batbtemp_num == 0) {	
		  normal_battery_linear_scale.setProperty(hmUI.prop.VISIBLE, true);	 
          normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);			  
          normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
          normal_body_temp_icon_img.setProperty(hmUI.prop.VISIBLE, false);	
          normal_body_temp_current_text_font.setProperty(hmUI.prop.VISIBLE, false);		  
		  };
          if (batbtemp_num == 1) {			  
		  normal_battery_linear_scale.setProperty(hmUI.prop.VISIBLE, false);	  
		  normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_body_temp_icon_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_body_temp_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
		  };	 	  
		}				

    /* переменные цвета  */

let DataColor = "0xFFE68B2A"
let batteryColor = "0xFFE68B2A"
let bg_img = "bg_01.png"

let tap_dannye = 0;
/* функция смены цветов массива данных */
function click_dannye() {
    tap_dannye = (tap_dannye + 1) % 2;

switch (tap_dannye) {
	
case 0:
    /* кейс для красного цвета */
DataColor = "0xFFE68B2A"
bg_img = "bg_01.png";
m_array = ["Minut-1_0.png","Minut-1_1.png","Minut-1_2.png","Minut-1_3.png","Minut-1_4.png","Minut-1_5.png","Minut-1_6.png","Minut-1_7.png","Minut-1_8.png","Minut-1_9.png"];
break;
case 1:
    /* кейс для голубого цвета */
DataColor = "0xFFb4d4e1"
bg_img = "bg_02.png";
m_array = ["Minut-2_0.png","Minut-2_1.png","Minut-2_2.png","Minut-2_3.png","Minut-2_4.png","Minut-2_5.png","Minut-2_6.png","Minut-2_7.png","Minut-2_8.png","Minut-2_9.png"];
break;

default:
    /* кейс для цвета по умолчанию */	
DataColor = "0xFFE68B2A"
bg_img = "bg_01.png";
m_array = ["Minut-1_0.png","Minut-1_1.png","Minut-1_2.png","Minut-1_3.png","Minut-1_4.png","Minut-1_5.png","Minut-1_6.png","Minut-1_7.png","Minut-1_8.png","Minut-1_9.png"];
}

            normal_background_bg_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: bg_img,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: 225,
              hour_startY: 102,
              hour_array: ["Hour_0.png","Hour_1.png","Hour_2.png","Hour_3.png","Hour_4.png","Hour_5.png","Hour_6.png","Hour_7.png","Hour_8.png","Hour_9.png"],
              hour_zero: 1,
              hour_space: -16,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 208,
              minute_startY: 240,
              minute_array: m_array,
              minute_zero: 1,
              minute_space: -16,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 263,
              second_startY: 394,
              second_array: ["Sec_0.png","Sec_1.png","Sec_2.png","Sec_3.png","Sec_4.png","Sec_5.png","Sec_6.png","Sec_7.png","Sec_8.png","Sec_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 113,
              y: 88,
              w: 118,
              h: 44,
              text_size: 33,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			

            normal_fat_burning_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 113,
              y: 88,
              w: 118,
              h: 44,
              text_size: 33,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_calorie_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 113,
              y: 88,
              w: 118,
              h: 44,
              text_size: 33,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			
            normal_battery_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 87,
              y: 198,
              w: 118,
              h: 44,
              text_size: 34,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
            normal_body_temp_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 87,
              y: 198,
              w: 118,
              h: 44,
              text_size: 34,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });			

            normal_temperature_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 103,
              y: 144,
              w: 118,
              h: 44,
              text_size: 34,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

            normal_heart_rate_text_font.setProperty(hmUI.prop.MORE, {
              x: 31,
              y: 267,
              w: 152,
              h: 140,
              text_size: 53,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

            normal_wind_speed_text_font.setProperty(hmUI.prop.MORE, {
              x: 155,
              y: 14,
              w: 118,
              h: 44,
              text_size: 38,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND_SPEED,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pressure_text_font.setProperty(hmUI.prop.MORE, {
              x: 122,
              y: 14,
              w: 118,
              h: 44,
              text_size: 38,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            const baroSensor = hmSensor.createSensor(hmSensor.id.BARO);

            normal_altimeter_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 133,
              y: 14,
              w: 118,
              h: 44,
              text_size: 38,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

            normal_widget_text_1.setProperty(hmUI.prop.MORE, {
              x: 247,
              y: 14,
              w: 80,
              h: 44,
              text_size: 38,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'гПа',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2.setProperty(hmUI.prop.MORE, {
              x: 235,
              y: 14,
              w: 99,
              h: 44,
              text_size: 38,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'м.р.с.',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

            normal_hrv_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 31,
              y: 269,
              w: 152,
              h: 140,
              text_size: 48,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 31,
              y: 269,
              w: 152,
              h: 140,
              text_size: 48,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font.setProperty(hmUI.prop.MORE, {
              x: 31,
              y: 269,
              w: 152,
              h: 140,
              text_size: 48,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });				

}			


	   const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
		let weatherData = weatherSensor.getForecastWeather();
        let tideData = weatherData.tideData;
		
  // Получение времени заката
        let sunset_hour = -1;
        let sunset_minute = -1;
            if (tideData.count > 0) {
                sunset_hour = tideData.data[0].sunset.hour;
                sunset_minute = tideData.data[0].sunset.minute;
    }

        let normal_sunset = undefined;
            if (sunset_hour >= 0 && sunset_minute >= 0) {
                normal_sunset = String(sunset_hour).padStart(2, '0') + ':' + String(sunset_minute).padStart(2, '0');
    }



  // Получение времени восхода
        let sunrise_hour = -1;
        let sunrise_minute = -1;
            if (tideData.count > 0) {
                sunrise_hour = tideData.data[0].sunrise.hour;
                sunrise_minute = tideData.data[0].sunrise.minute;
    }

        let normal_sunrise = undefined;
            if (sunrise_hour >= 0 && sunrise_minute >= 0) {
                normal_sunrise = String(sunrise_hour).padStart(2, '0') + ':' + String(sunrise_minute).padStart(2, '0');
    } 

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_widget_text_1 = ''
        let normal_widget_text_2 = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_speed_text_font = ''
        let normal_pressure_text_font = ''
        let normal_altimeter_current_text_font = ''
        let normal_day_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПНД', 'ВТР', 'СРЕ', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let normal_hrv_icon_img = ''
        let normal_hrv_current_text_font = ''
        let normal_bio_charge_icon_img = ''
        let normal_bio_charge_current_text_font = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_body_temp_icon_img = ''
        let normal_body_temp_current_text_font = ''
        let normal_battery_linear_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_current_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_fat_burning_icon_img = ''
        let normal_fat_burning_current_text_font = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_font = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_widget_text_1 = ''
        let idle_altimeter_current_text_font = ''
        let idle_day_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['ПНД', 'ВТР', 'СРЕ', 'ЧТВ', 'ПТН', 'СБТ', 'ВСК'];
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_font = ''
        let idle_battery_linear_scale = ''
        let idle_battery_icon_img = ''
        let idle_battery_current_text_font = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_font = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Eurostile-MedIta.ttf; FontSize: 38
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 591,
              h: 57,
              text_size: 38,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFFF8C00,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Eurostile-MedIta.ttf; FontSize: 38; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 45,
              h: 45,
              text_size: 38,
              char_space: 2,
              line_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFC3C3C3,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Eurostile-MedIta.ttf; FontSize: 48
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 744,
              h: 73,
              text_size: 48,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFE68B2A,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Eurostile-MedIta.ttf; FontSize: 34
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 523,
              h: 51,
              text_size: 34,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFE68B2A,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Eurostile-MedIta.ttf; FontSize: 33
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 505,
              h: 50,
              text_size: 33,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFE68B2A,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT, screenShape: isRoundScreen } = hmSetting.getDeviceInfo();
	
	/********  класс всплывающее сообщение с таймаутом и расширенными настройками *********/
class Message {      
  #msg = null													// само сообщение
  
  constructor(props = {}) {
	this._propsDef = {											// параметры по умолчанию
		y: isRoundScreen ? 60 : 30,								// отступ рамки от верхней границы экрана для круглых и прямоугольных экранов
		offset: 10,												// отступ текста от рамки
		w: null,												// ширина рамки	(null - автовычисление размеров)
		h: null,												// высота рамки	(null - автовычисление размеров)
		text: '',
		text_size: 30,											// размер текста
		color: 0x666666,										// цвет рамки
		text_color: 0xffffff,									// цвет текста
		alpha: 250,												// прозрачность рамки
		radius: 25,												// радиус скругления рамки
		timeout: 1500,											// время показа сообщения, если равно 0 - не прятать
		...props
	};
	this._timer = null;
	this._visible = false;
  }

  delete() {
	this.visible = false;
	hmUI.deleteWidget(this.#msg);
	this.#msg = null;
	this._props = null;
	if (this._timer) {
		clearTimeout(this._timer);
		this._timer = null
	}
  }

  show(props = {}) {
	this._props = {...this._propsDef, ...props}
	if (!this._props.w) this._props.auto_w = true
	if (!this._props.h) this._props.auto_h = true
	if (this._visible) this.#update()
	else this.#create();
  }

  hide() {
	if (this._visible) this.#moveOut();
  }

  #create() {
	const {propsGroup, propsFrame, propsText} = this.#getWidgetProps();
	if (this._timer) clearTimeout(this._timer);
	this._timer = null;
	this._visible = true;
	const root = this;

	this.#msg = hmUI.createWidget(hmUI.widget.GROUP, propsGroup);

	this._frame = this.#msg.createWidget(hmUI.widget.FILL_RECT, propsFrame);
	this._frame.addEventListener(hmUI.event.CLICK_DOWN, function () {
		root.#moveOut();
	});

	this._text = this.#msg.createWidget(hmUI.widget.TEXT, propsText);
	this._text.setEnable(false);

	if (this._props.timeout) {
		this._timer = setTimeout(() => {
			this.#moveOut();
		}, this._props.timeout)
	}

	this.#moveIn();
  }

  #update() {
	const {propsGroup, propsFrame, propsText} = this.#getWidgetProps();
	if (this._timer) clearTimeout(this._timer);
	this._timer = null;
	propsGroup.y = this._props.y;
	this.#msg.setProperty(hmUI.prop.MORE, propsGroup);
	this._frame.setProperty(hmUI.prop.MORE, propsFrame);
	this._text.setProperty(hmUI.prop.MORE, propsText);

	if (this._props.timeout) {
		this._timer = setTimeout(() => {
			this.#moveOut();
		}, this._props.timeout)
	}
  }

  #getWidgetProps() {
	const { width, height } = this.#calcSize(this._props.text , this._props.text_size);
	if (this._props.auto_w) this._props.w = width;
	if (this._props.auto_h) this._props.h = height;
	if (height == DEVICE_HEIGHT - this._props.y) this._props.align_v = hmUI.align.TOP;

	const propsGroup =  {
		x: (DEVICE_WIDTH - this._props.w) / 2,
		y: - this._props.h,
		w: this._props.w,
		h: this._props.h,
	}

	const propsFrame = {
		x: 0,
		y: 0,
		w: this._props.w,
		h: this._props.h,
		color: this._props.color,
		radius: this._props.radius,
		alpha: this._props.alpha
	}

	const propsText = {
		x: this._props.offset,
		y: this._props.offset,
		w: this._props.w - 2 * this._props.offset,
		h: this._props.h - 2 * this._props.offset,
		text_size: this._props.text_size || 30,
		char_space: this._props.char_space || 0,
		line_space: this._props.line_space || 0,
		text: this._props.text,
		color: this._props.text_color,
		align_h: this._props.align_h || hmUI.align.CENTER_H,
		align_v: this._props.align_v || hmUI.align.CENTER_V,
		text_style: this._props.text_style || hmUI.text_style.WRAP,
	}
	
	if (this._props.font) propsText.font = this._props.font;
	return {propsGroup, propsFrame, propsText}
  }


  #calcSize(txt, size) {
	const maxW = DEVICE_WIDTH - (isRoundScreen ? 150 : 60);								// максимальная ширина
	let { width, height } = hmUI.getTextLayout(txt, {
		text_size: size,
		text_width: maxW - 2 * this._props.offset,
	});
	width += 2 * this._props.offset;
	height += 2 * this._props.offset;
	if (height > DEVICE_HEIGHT - this._props.y) height = DEVICE_HEIGHT - this._props.y;
	return {width, height}
  }

  #moveIn() {
	const moveAnim = {
		anim_steps: [{
		  anim_rate: 'easeout',
		  anim_duration: 350,
		  anim_from: -this._props.h,
		  anim_to: this._props.y,
		  anim_prop: hmUI.prop.Y,
		}],
		anim_fps: 25,
		anim_auto_start: 1,
		anim_repeat: 0,
		anim_auto_destroy: 1,
	}			  
	
	this._visible = true;			  
	this.#msg.setProperty(hmUI.prop.ANIM, moveAnim);
  }

  #moveOut() {
	const moveAnim = {
		anim_steps: [{
		  anim_rate: 'easein',
		  anim_duration: 550,
		  anim_from: this._props.y,
		  anim_to: -this._props.h,
		  anim_prop: hmUI.prop.Y,
		}],
		anim_fps: 25,
		anim_auto_start: 1,
		anim_repeat: 0,
		anim_auto_destroy: 1,
		anim_complete_func:() => {
			this.delete();
		}
	}			  
	if (this._timer) {
		clearTimeout(this._timer);
		this._timer = null;
	}
	this.#msg.setProperty(hmUI.prop.ANIM, moveAnim);
  }

  set visible(v) {
	this._visible = v;
	if(this.#msg) this.#msg.setProperty(hmUI.prop.VISIBLE, v);
  }
  
  get visible() {
	return this._visible
  }
  
  set y(v) {
	this._propsDef.y = v;
	if (this._visible) {
		this._props.y = v;
		this.#update();
	}
  }

  set text(txt) {
	if (this._text){
		this._text.setProperty(hmUI.prop.TEXT, txt);
		if (this._timer) {
			clearTimeout(this._timer);
			this._timer = setTimeout(() => {
				this.#moveOut();
			}, this._props.timeout)
		}
	}
  }

  set color(v) {
	this._propsDef.color = v;
	if (this._frame) {
		this._props.color = v;
		this._frame.setProperty(hmUI.prop.MORE, {
			x: 0,
			y: 0,
			w: this._props.w,
			h: this._props.h,
			color: this._props.color,
			radius: this._props.radius,
			alpha: this._props.alpha
		});
	}
  }

  set text_color(v) {
	this._propsDef.text_color = v;
	if (this._text) {
		this._props.text_color = v;
		this._text.setProperty(hmUI.prop.MORE, { color: v});
	}
  }
  
  set timeout(v) {
	this._propsDef.timeout = v;
	if (this._timer) {
		clearTimeout(this._timer);
		this._timer = setTimeout(() => {
			this.#moveOut();
		}, v);
	}
  }
}			
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 247,
              y: 14,
              w: 80,
              h: 44,
              text_size: 38,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'гПа',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 235,
              y: 14,
              w: 99,
              h: 44,
              text_size: 38,
              char_space: -2,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFFF8C00,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'м.р.с.',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 261,
              y: 11,
              image_array: ["wind_0.png","wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_speed_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 155,
              y: 14,
              w: 118,
              h: 44,
              text_size: 38,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFE68B2A,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND_SPEED,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pressure_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 122,
              y: 14,
              w: 118,
              h: 44,
              text_size: 38,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFE68B2A,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            const baroSensor = hmSensor.createSensor(hmSensor.id.BARO);

            normal_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 133,
              y: 14,
              w: 118,
              h: 44,
              text_size: 38,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFE68B2A,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 349,
              y: 70,
              w: 62,
              h: 44,
              text_size: 38,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFC3C3C3,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 262,
              y: 70,
              w: 100,
              h: 44,
              text_size: 38,
              char_space: 2,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFC3C3C3,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ПНД, ВТР, СРЕ, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 87,
              y: 269,
              src: 'icon_hrv.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_hrv_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 31,
              y: 269,
              w: 152,
              h: 140,
              text_size: 48,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFE68B2A,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HRV,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 87,
              y: 269,
              src: 'icon_bioch.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 31,
              y: 269,
              w: 152,
              h: 140,
              text_size: 48,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFE68B2A,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 87,
              y: 269,
              src: 'icon_hr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 31,
              y: 269,
              w: 152,
              h: 140,
              text_size: 48,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFE68B2A,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_body_temp_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 45,
              y: 194,
              src: 'icon_temper.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_body_temp_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 87,
              y: 198,
              w: 118,
              h: 44,
              text_size: 34,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFE68B2A,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 35,
              // start_y: 207,
              // color: 0xFFE68B2A,
              // lenght: 30,
              // line_width: 15,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 31,
              y: 203,
              src: 'icon_bat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 87,
              y: 198,
              w: 118,
              h: 44,
              text_size: 34,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFE68B2A,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 52,
              y: 132,
              image_array: ["w_00.png","w_01.png","w_02.png","w_03.png","w_04.png","w_05.png","w_06.png","w_07.png","w_08.png","w_09.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 103,
              y: 144,
              w: 118,
              h: 44,
              text_size: 34,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFE68B2A,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 71,
              y: 84,
              src: 'icon_fat.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 113,
              y: 88,
              w: 118,
              h: 44,
              text_size: 33,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFE68B2A,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 71,
              y: 84,
              src: 'icon_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 113,
              y: 88,
              w: 118,
              h: 44,
              text_size: 33,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFE68B2A,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 71,
              y: 84,
              src: 'icon_step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 113,
              y: 88,
              w: 118,
              h: 44,
              text_size: 33,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFE68B2A,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 225,
              hour_startY: 102,
              hour_array: ["Hour_0.png","Hour_1.png","Hour_2.png","Hour_3.png","Hour_4.png","Hour_5.png","Hour_6.png","Hour_7.png","Hour_8.png","Hour_9.png"],
              hour_zero: 1,
              hour_space: -16,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 208,
              minute_startY: 240,
              minute_array: ["Minut-1_0.png","Minut-1_1.png","Minut-1_2.png","Minut-1_3.png","Minut-1_4.png","Minut-1_5.png","Minut-1_6.png","Minut-1_7.png","Minut-1_8.png","Minut-1_9.png"],
              minute_zero: 1,
              minute_space: -16,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 263,
              second_startY: 394,
              second_array: ["Sec_0.png","Sec_1.png","Sec_2.png","Sec_3.png","Sec_4.png","Sec_5.png","Sec_6.png","Sec_7.png","Sec_8.png","Sec_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 247,
              y: 14,
              w: 80,
              h: 44,
              text_size: 38,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'гПа',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 133,
              y: 14,
              w: 118,
              h: 44,
              text_size: 38,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 349,
              y: 70,
              w: 62,
              h: 44,
              text_size: 38,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 262,
              y: 70,
              w: 100,
              h: 44,
              text_size: 38,
              char_space: 2,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // unit_string: ПНД, ВТР, СРЕ, ЧТВ, ПТН, СБТ, ВСК,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 87,
              y: 269,
              src: 'icon_hr.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 31,
              y: 269,
              w: 152,
              h: 140,
              text_size: 48,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 35,
              // start_y: 207,
              // color: 0xFFFFFFFF,
              // lenght: 30,
              // line_width: 15,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 31,
              y: 203,
              src: 'icon_bat.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 87,
              y: 192,
              w: 118,
              h: 44,
              text_size: 34,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 52,
              y: 132,
              image_array: ["w_00.png","w_01.png","w_02.png","w_03.png","w_04.png","w_05.png","w_06.png","w_07.png","w_08.png","w_09.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 103,
              y: 138,
              w: 118,
              h: 44,
              text_size: 34,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 71,
              y: 84,
              src: 'icon_step.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 113,
              y: 82,
              w: 118,
              h: 44,
              text_size: 33,
              char_space: 0,
              font: 'fonts/Eurostile-MedIta.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 225,
              hour_startY: 102,
              hour_array: ["M_AOD_0.png","M_AOD_1.png","M_AOD_2.png","M_AOD_3.png","M_AOD_4.png","M_AOD_5.png","M_AOD_6.png","M_AOD_7.png","M_AOD_8.png","M_AOD_9.png"],
              hour_zero: 1,
              hour_space: -16,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 208,
              minute_startY: 240,
              minute_array: ["M_AOD_0.png","M_AOD_1.png","M_AOD_2.png","M_AOD_3.png","M_AOD_4.png","M_AOD_5.png","M_AOD_6.png","M_AOD_7.png","M_AOD_8.png","M_AOD_9.png"],
              minute_zero: 1,
              minute_space: -16,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('user_script_beforeShortcuts.js');
            // start user_script_beforeShortcuts.js

const msg = new Message();
            // end user_script_beforeShortcuts.js

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 244,
              y: 393,
              w: 100,
              h: 56,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_dannye();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 30,
              y: 134,
              w: 178,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                msg.show({text: 'Температура' + '\nДень. :  ' + weatherSensor.high +'°' + '\nНочь. : ' + weatherSensor.low + '°' + '\nВосход : ' + normal_sunrise + '\n Закат   : ' + normal_sunset, text_size: 40, timeout: 8000});
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 179,
              y: 16,
              w: 129,
              h: 43,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_barowind();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 64,
              y: 280,
              w: 88,
              h: 88,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_kardio();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 61,
              y: 81,
              w: 154,
              h: 42,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_stcalfat();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 32,
              y: 191,
              w: 154,
              h: 42,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_batbtemp();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

        if (screenType != hmSetting.screen_type.AOD) {
          normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);	
          normal_fat_burning_current_text_font.setProperty(hmUI.prop.VISIBLE, false);		  
          normal_fat_burning_icon_img.setProperty(hmUI.prop.VISIBLE, false);		  		  
	      normal_bio_charge_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_bio_charge_icon_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_hrv_current_text_font.setProperty(hmUI.prop.VISIBLE, false);	
          normal_hrv_icon_img.setProperty(hmUI.prop.VISIBLE, false);			  
	      normal_pressure_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_widget_text_2.setProperty(hmUI.prop.VISIBLE, false);
          normal_wind_speed_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
          normal_body_temp_icon_img.setProperty(hmUI.prop.VISIBLE, false);	
          normal_body_temp_current_text_font.setProperty(hmUI.prop.VISIBLE, false);				  
    	};	
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

            };

            //#endregion
            //#region text_update
            function text_update() {
              console.log('text_update()');
              // Pressure Font
              let pressureValue = baroSensor.pressure;
              let normal_pressure_font = '-';
              if (pressureValue) normal_pressure_font = Math.round(pressureValue * 0.75006375541921).toString();
              normal_pressure_text_font.setProperty(hmUI.prop.TEXT, normal_pressure_font);

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 35;
                  let start_y_normal_battery = 207;
                  let lenght_ls_normal_battery = 30;
                  let line_width_ls_normal_battery = 15;
                  let color_ls_normal_battery = 0xFFE68B2A;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 35;
                  let start_y_idle_battery = 207;
                  let lenght_ls_idle_battery = 30;
                  let line_width_ls_idle_battery = 15;
                  let color_ls_idle_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}