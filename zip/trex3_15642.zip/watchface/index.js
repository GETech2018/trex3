﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

        // смена фона
        let mask_img = ''
        let btn_mask = ''
        let mask_num = 1
        let mask_all = 6
           
        function click_mask() {
           if(mask_num>=mask_all) {mask_num=1;}
            else { mask_num=mask_num+1;}
            hmUI.showToast({text: "<Фон> " + parseInt(mask_num) });
            normal_image_img.setProperty(hmUI.prop.SRC, "fons_" + parseInt(mask_num) + ".png");
        }
        
       
        // end user_functions.js

        let normal_background_bg = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let normal_image_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 13;
        let normal_battery_TextCircle_img_height = 33;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 20;
        let normal_battery_TextCircle_error_img_width = 13;
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 13;
        let normal_step_TextCircle_img_height = 33;
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 13;
        let normal_heart_rate_TextCircle_img_height = 33;
        let normal_heart_rate_TextCircle_error_img_width = 13;
        let normal_distance_TextCircle = new Array(5);
        let normal_distance_TextCircle_ASCIIARRAY = new Array(10);
        let normal_distance_TextCircle_img_width = 13;
        let normal_distance_TextCircle_img_height = 33;
        let normal_distance_TextCircle_dot_width = 13;
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 13;
        let normal_calorie_TextCircle_img_height = 33;
        let normal_calorie_TextCircle_error_img_width = 13;
        let normal_pai_icon_img = ''
        let normal_date_img_date_week_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_TextCircle = new Array(4);
        let normal_temperature_high_TextCircle_ASCIIARRAY = new Array(10);
        let normal_temperature_high_TextCircle_img_width = 13;
        let normal_temperature_high_TextCircle_img_height = 33;
        let normal_temperature_high_TextCircle_unit = null;
        let normal_temperature_high_TextCircle_unit_width = 13;
        let normal_temperature_high_TextCircle_dot_width = 13;
        let normal_temperature_high_TextCircle_error_img_width = 13;
        let normal_temperature_low_TextCircle = new Array(4);
        let normal_temperature_low_TextCircle_ASCIIARRAY = new Array(10);
        let normal_temperature_low_TextCircle_img_width = 13;
        let normal_temperature_low_TextCircle_img_height = 33;
        let normal_temperature_low_TextCircle_unit = null;
        let normal_temperature_low_TextCircle_unit_width = 13;
        let normal_temperature_low_TextCircle_dot_width = 13;
        let normal_temperature_low_TextCircle_error_img_width = 13;
        let normal_temperature_current_TextCircle = new Array(4);
        let normal_temperature_current_TextCircle_ASCIIARRAY = new Array(10);
        let normal_temperature_current_TextCircle_img_width = 13;
        let normal_temperature_current_TextCircle_img_height = 33;
        let normal_temperature_current_TextCircle_unit = null;
        let normal_temperature_current_TextCircle_unit_width = 13;
        let normal_temperature_current_TextCircle_dot_width = 13;
        let normal_temperature_current_TextCircle_error_img_width = 13;
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hour_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 180,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'hour_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'min_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'min_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sec_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'sec_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'fons_6.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 60,
              y: 245,
              src: '0075.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 64,
              y: 279,
              src: '0074.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 77,
              y: 302,
              src: '0076.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 221,
              month_startY: 115,
              month_sc_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_tc_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_en_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 195,
              day_startY: 108,
              day_sc_array: ["dnum_1.png","dnum_2.png","dnum_3.png","dnum_4.png","dnum_5.png","dnum_6.png","dnum_7.png","dnum_8.png","dnum_9.png","dnum_10.png"],
              day_tc_array: ["dnum_1.png","dnum_2.png","dnum_3.png","dnum_4.png","dnum_5.png","dnum_6.png","dnum_7.png","dnum_8.png","dnum_9.png","dnum_10.png"],
              day_en_array: ["dnum_1.png","dnum_2.png","dnum_3.png","dnum_4.png","dnum_5.png","dnum_6.png","dnum_7.png","dnum_8.png","dnum_9.png","dnum_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["dnum_1.png","dnum_2.png","dnum_3.png","dnum_4.png","dnum_5.png","dnum_6.png","dnum_7.png","dnum_8.png","dnum_9.png","dnum_10.png"],
              // radius: 180,
              // angle: -80,
              // char_space_angle: 0,
              // unit: 'dnum_15.png',
              // error_image: 'dnum_11.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'dnum_1.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'dnum_2.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'dnum_3.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'dnum_4.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'dnum_5.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'dnum_6.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'dnum_7.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'dnum_8.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'dnum_9.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'dnum_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_battery_TextCircle_img_width / 2,
                pos_y: 240 - 213,
                src: 'dnum_1.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 240 - 213,
              src: 'dnum_15.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["dnum_1.png","dnum_2.png","dnum_3.png","dnum_4.png","dnum_5.png","dnum_6.png","dnum_7.png","dnum_8.png","dnum_9.png","dnum_10.png"],
              // radius: 180,
              // angle: -64,
              // char_space_angle: -1,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 'dnum_1.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 'dnum_2.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 'dnum_3.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 'dnum_4.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 'dnum_5.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 'dnum_6.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 'dnum_7.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 'dnum_8.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 'dnum_9.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 'dnum_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_step_TextCircle_img_width / 2,
                pos_y: 240 - 213,
                src: 'dnum_1.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["dnum_1.png","dnum_2.png","dnum_3.png","dnum_4.png","dnum_5.png","dnum_6.png","dnum_7.png","dnum_8.png","dnum_9.png","dnum_10.png"],
              // radius: 180,
              // angle: -43,
              // char_space_angle: -1,
              // error_image: 'dnum_11.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'dnum_1.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'dnum_2.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'dnum_3.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'dnum_4.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'dnum_5.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'dnum_6.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'dnum_7.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'dnum_8.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'dnum_9.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'dnum_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 - 213,
                src: 'dnum_1.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_distance_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["dnum_1.png","dnum_2.png","dnum_3.png","dnum_4.png","dnum_5.png","dnum_6.png","dnum_7.png","dnum_8.png","dnum_9.png","dnum_10.png"],
              // radius: 180,
              // angle: -26,
              // char_space_angle: -1,
              // dot_image: 'dnum_12.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextCircle_ASCIIARRAY[0] = 'dnum_1.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[1] = 'dnum_2.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[2] = 'dnum_3.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[3] = 'dnum_4.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[4] = 'dnum_5.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[5] = 'dnum_6.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[6] = 'dnum_7.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[7] = 'dnum_8.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[8] = 'dnum_9.png';  // set of images with numbers
            normal_distance_TextCircle_ASCIIARRAY[9] = 'dnum_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_distance_TextCircle_img_width / 2,
                pos_y: 240 - 213,
                src: 'dnum_1.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["dnum_1.png","dnum_2.png","dnum_3.png","dnum_4.png","dnum_5.png","dnum_6.png","dnum_7.png","dnum_8.png","dnum_9.png","dnum_10.png"],
              // radius: 180,
              // angle: 0,
              // char_space_angle: 0,
              // error_image: 'dnum_11.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = 'dnum_1.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = 'dnum_2.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = 'dnum_3.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = 'dnum_4.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = 'dnum_5.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = 'dnum_6.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = 'dnum_7.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = 'dnum_8.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = 'dnum_9.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = 'dnum_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 240 - 213,
                src: 'dnum_1.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -19,
              y: -8,
              src: 'mask_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: -20,
              week_en: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_tc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_sc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 398,
              y: 256,
              image_array: ["65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_temperature_high_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["dnum_1.png","dnum_2.png","dnum_3.png","dnum_4.png","dnum_5.png","dnum_6.png","dnum_7.png","dnum_8.png","dnum_9.png","dnum_10.png"],
              // radius: 180,
              // angle: 79,
              // char_space_angle: 0,
              // unit: 'dnum_13.png',
              // dot_image: 'dnum_11.png',
              // error_image: 'dnum_11.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_high_TextCircle_ASCIIARRAY[0] = 'dnum_1.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[1] = 'dnum_2.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[2] = 'dnum_3.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[3] = 'dnum_4.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[4] = 'dnum_5.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[5] = 'dnum_6.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[6] = 'dnum_7.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[7] = 'dnum_8.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[8] = 'dnum_9.png';  // set of images with numbers
            normal_temperature_high_TextCircle_ASCIIARRAY[9] = 'dnum_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_temperature_high_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_temperature_high_TextCircle_img_width / 2,
                pos_y: 240 - 213,
                src: 'dnum_1.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_high_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_temperature_high_TextCircle_unit_width / 2,
              pos_y: 240 - 213,
              src: 'dnum_13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            // normal_temperature_low_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["dnum_1.png","dnum_2.png","dnum_3.png","dnum_4.png","dnum_5.png","dnum_6.png","dnum_7.png","dnum_8.png","dnum_9.png","dnum_10.png"],
              // radius: 180,
              // angle: 64,
              // char_space_angle: 0,
              // unit: 'dnum_13.png',
              // dot_image: 'dnum_11.png',
              // error_image: 'dnum_11.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_low_TextCircle_ASCIIARRAY[0] = 'dnum_1.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[1] = 'dnum_2.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[2] = 'dnum_3.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[3] = 'dnum_4.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[4] = 'dnum_5.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[5] = 'dnum_6.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[6] = 'dnum_7.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[7] = 'dnum_8.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[8] = 'dnum_9.png';  // set of images with numbers
            normal_temperature_low_TextCircle_ASCIIARRAY[9] = 'dnum_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_temperature_low_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_temperature_low_TextCircle_img_width / 2,
                pos_y: 240 - 213,
                src: 'dnum_1.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_low_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_temperature_low_TextCircle_unit_width / 2,
              pos_y: 240 - 213,
              src: 'dnum_13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // normal_temperature_current_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["dnum_1.png","dnum_2.png","dnum_3.png","dnum_4.png","dnum_5.png","dnum_6.png","dnum_7.png","dnum_8.png","dnum_9.png","dnum_10.png"],
              // radius: 180,
              // angle: 36,
              // char_space_angle: 0,
              // unit: 'dnum_13.png',
              // dot_image: 'dnum_11.png',
              // error_image: 'dnum_11.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.WEATHER_CURRENT,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_current_TextCircle_ASCIIARRAY[0] = 'dnum_1.png';  // set of images with numbers
            normal_temperature_current_TextCircle_ASCIIARRAY[1] = 'dnum_2.png';  // set of images with numbers
            normal_temperature_current_TextCircle_ASCIIARRAY[2] = 'dnum_3.png';  // set of images with numbers
            normal_temperature_current_TextCircle_ASCIIARRAY[3] = 'dnum_4.png';  // set of images with numbers
            normal_temperature_current_TextCircle_ASCIIARRAY[4] = 'dnum_5.png';  // set of images with numbers
            normal_temperature_current_TextCircle_ASCIIARRAY[5] = 'dnum_6.png';  // set of images with numbers
            normal_temperature_current_TextCircle_ASCIIARRAY[6] = 'dnum_7.png';  // set of images with numbers
            normal_temperature_current_TextCircle_ASCIIARRAY[7] = 'dnum_8.png';  // set of images with numbers
            normal_temperature_current_TextCircle_ASCIIARRAY[8] = 'dnum_9.png';  // set of images with numbers
            normal_temperature_current_TextCircle_ASCIIARRAY[9] = 'dnum_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_temperature_current_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_temperature_current_TextCircle_img_width / 2,
                pos_y: 240 - 213,
                src: 'dnum_1.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_current_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_current_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_temperature_current_TextCircle_unit_width / 2,
              pos_y: 240 - 213,
              src: 'dnum_13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_current_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 101,
              hour_startY: 189,
              hour_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 250,
              minute_startY: 189,
              minute_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 101,
              hour_startY: 189,
              hour_array: ["aod_num_1.png","aod_num_2.png","aod_num_3.png","aod_num_4.png","aod_num_5.png","aod_num_6.png","aod_num_7.png","aod_num_8.png","aod_num_9.png","aod_num_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 250,
              minute_startY: 189,
              minute_array: ["aod_num_1.png","aod_num_2.png","aod_num_3.png","aod_num_4.png","aod_num_5.png","aod_num_6.png","aod_num_7.png","aod_num_8.png","aod_num_9.png","aod_num_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 362,
              y: 242,
              w: 103,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1051195, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 303,
              y: 74,
              w: 64,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 44,
              y: 166,
              w: 64,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LowBatteryScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 58,
              y: 107,
              w: 64,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 95,
              y: 65,
              w: 64,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 137,
              y: 31,
              w: 64,
              h: 68,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 211,
              y: 27,
              w: 64,
              h: 68,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 185,
              y: 107,
              w: 100,
              h: 76,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                click_mask();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 180;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = -80;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 180));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 180));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + (normal_battery_TextCircle_img_angle + normal_battery_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle += normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_battery_TextCircle_error_img_width / 2);
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.SRC, 'dnum_11.png');
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -64;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 180));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_step_TextCircle_img_angle + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -43;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 180));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_heart_rate_TextCircle_img_angle + -1;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_heart_rate_TextCircle_error_img_width / 2);
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.SRC, 'dnum_11.png');
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_circle_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -26;
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_circle_string.length > 0 && normal_distance_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_distance_TextCircle_img_angle = 0;
                  let normal_distance_TextCircle_dot_img_angle = 0;
                  normal_distance_TextCircle_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_img_width/2, 180));
                  normal_distance_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_distance_TextCircle_dot_width/2, 180));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_distance_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_distance_TextCircle_img_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, normal_distance_TextCircle_ASCIIARRAY[charCode]);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_img_angle + -1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_distance_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_distance_TextCircle_dot_width / 2);
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.SRC, 'dnum_12.png');
                      normal_distance_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_distance_TextCircle_dot_img_angle + -1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 0;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 180));
                  // alignment = CENTER_H
                  let normal_calorie_TextCircle_angleOffset = normal_calorie_TextCircle_img_angle * (normal_calorie_circle_string.length - 1);
                  char_Angle -= normal_calorie_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_calorie_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_calorie_TextCircle_error_img_width / 2);
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.SRC, 'dnum_11.png');
                  normal_calorie_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let temperature_high_temp = -100;
              if (forecastData.count > 0) {
                temperature_high_temp = forecastData.data[0].high;
              }; // end forecastData;

              console.log('update text circle temperature_high_forecastData');
              let temperatureHigh = undefined;
              let normal_temperature_high_circle_string = undefined;
              if (temperature_high_temp > -100) {
                temperatureHigh = 0;
                normal_temperature_high_circle_string = String(temperature_high_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_high_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 79;
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && normal_temperature_high_circle_string.length > 0 && normal_temperature_high_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_temperature_high_TextCircle_img_angle = 0;
                  let normal_temperature_high_TextCircle_dot_img_angle = 0;
                  let normal_temperature_high_TextCircle_unit_angle = 0;
                  normal_temperature_high_TextCircle_img_angle = toDegree(Math.atan2(normal_temperature_high_TextCircle_img_width/2, 180));
                  normal_temperature_high_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_temperature_high_TextCircle_dot_width/2, 180));
                  normal_temperature_high_TextCircle_unit_angle = toDegree(Math.atan2(normal_temperature_high_TextCircle_unit_width/2, 180));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_temperature_high_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_temperature_high_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_temperature_high_TextCircle_img_width / 2);
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.SRC, normal_temperature_high_TextCircle_ASCIIARRAY[charCode]);
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_temperature_high_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_temperature_high_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_temperature_high_TextCircle_dot_width / 2);
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.SRC, 'dnum_11.png');
                      normal_temperature_high_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_temperature_high_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += normal_temperature_high_TextCircle_unit_angle;
                  normal_temperature_high_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_temperature_high_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_temperature_high_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_temperature_high_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_temperature_high_TextCircle_error_img_width / 2);
                  normal_temperature_high_TextCircle[0].setProperty(hmUI.prop.SRC, 'dnum_11.png');
                  normal_temperature_high_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let temperature_low_temp = -100;
              if (forecastData.count > 0) {
                temperature_low_temp = forecastData.data[0].low;
              }; // end forecastData;

              console.log('update text circle temperature_low_forecastData');
              let temperatureLow = undefined;
              let normal_temperature_low_circle_string = undefined;
              if (temperature_low_temp > -100) {
                temperatureLow = 0;
                normal_temperature_low_circle_string = String(temperature_low_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_low_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 64;
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && normal_temperature_low_circle_string.length > 0 && normal_temperature_low_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_temperature_low_TextCircle_img_angle = 0;
                  let normal_temperature_low_TextCircle_dot_img_angle = 0;
                  let normal_temperature_low_TextCircle_unit_angle = 0;
                  normal_temperature_low_TextCircle_img_angle = toDegree(Math.atan2(normal_temperature_low_TextCircle_img_width/2, 180));
                  normal_temperature_low_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_temperature_low_TextCircle_dot_width/2, 180));
                  normal_temperature_low_TextCircle_unit_angle = toDegree(Math.atan2(normal_temperature_low_TextCircle_unit_width/2, 180));
                  // alignment = RIGHT
                  let normal_temperature_low_TextCircle_angleOffset = normal_temperature_low_TextCircle_img_angle * (normal_temperature_low_circle_string.length - 1);
                  normal_temperature_low_TextCircle_angleOffset = normal_temperature_low_TextCircle_angleOffset + (normal_temperature_low_TextCircle_img_angle + normal_temperature_low_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= 2 * normal_temperature_low_TextCircle_angleOffset;
                  if (normal_temperature_low_circle_string.startsWith('-')) char_Angle = char_Angle - normal_temperature_low_TextCircle_dot_img_angle + normal_temperature_low_TextCircle_img_angle;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_temperature_low_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_temperature_low_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_temperature_low_TextCircle_img_width / 2);
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.SRC, normal_temperature_low_TextCircle_ASCIIARRAY[charCode]);
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_temperature_low_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_temperature_low_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_temperature_low_TextCircle_dot_width / 2);
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.SRC, 'dnum_11.png');
                      normal_temperature_low_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_temperature_low_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += normal_temperature_low_TextCircle_unit_angle;
                  normal_temperature_low_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_temperature_low_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_temperature_low_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_temperature_low_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_temperature_low_TextCircle_error_img_width / 2);
                  normal_temperature_low_TextCircle[0].setProperty(hmUI.prop.SRC, 'dnum_11.png');
                  normal_temperature_low_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let temperature_current_temp = -100;
              if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
                temperature_current_temp = weatherSensor.current;
              }; // end currentWeather;

              console.log('update text circle temperature_current_currentWeather');
              let temperatureCurrent = undefined;
              let normal_temperature_current_circle_string = undefined;
              if (temperature_current_temp > -100) {
                temperatureCurrent = 0;
                normal_temperature_current_circle_string = String(temperature_current_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_current_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_current_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 36;
                if (temperatureCurrent != null && temperatureCurrent != undefined && isFinite(temperatureCurrent) && normal_temperature_current_circle_string.length > 0 && normal_temperature_current_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_temperature_current_TextCircle_img_angle = 0;
                  let normal_temperature_current_TextCircle_dot_img_angle = 0;
                  let normal_temperature_current_TextCircle_unit_angle = 0;
                  normal_temperature_current_TextCircle_img_angle = toDegree(Math.atan2(normal_temperature_current_TextCircle_img_width/2, 180));
                  normal_temperature_current_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_temperature_current_TextCircle_dot_width/2, 180));
                  normal_temperature_current_TextCircle_unit_angle = toDegree(Math.atan2(normal_temperature_current_TextCircle_unit_width/2, 180));
                  // alignment = CENTER_H
                  let normal_temperature_current_TextCircle_angleOffset = normal_temperature_current_TextCircle_img_angle * (normal_temperature_current_circle_string.length - 1);
                  normal_temperature_current_TextCircle_angleOffset = normal_temperature_current_TextCircle_angleOffset + (normal_temperature_current_TextCircle_img_angle + normal_temperature_current_TextCircle_unit_angle + 0) / 2;
                  char_Angle -= normal_temperature_current_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_temperature_current_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_temperature_current_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_temperature_current_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_temperature_current_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_temperature_current_TextCircle_img_width / 2);
                      normal_temperature_current_TextCircle[index].setProperty(hmUI.prop.SRC, normal_temperature_current_TextCircle_ASCIIARRAY[charCode]);
                      normal_temperature_current_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_temperature_current_TextCircle_img_angle;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_temperature_current_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_temperature_current_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_temperature_current_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_temperature_current_TextCircle_dot_width / 2);
                      normal_temperature_current_TextCircle[index].setProperty(hmUI.prop.SRC, 'dnum_11.png');
                      normal_temperature_current_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_temperature_current_TextCircle_dot_img_angle;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += normal_temperature_current_TextCircle_unit_angle;
                  normal_temperature_current_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_temperature_current_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_temperature_current_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_temperature_current_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_temperature_current_TextCircle_error_img_width / 2);
                  normal_temperature_current_TextCircle[0].setProperty(hmUI.prop.SRC, 'dnum_11.png');
                  normal_temperature_current_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}