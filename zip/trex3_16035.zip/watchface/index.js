﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_vo2max_text_text_img = ''
        let normal_stress_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_max_min_text_img = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_week_img = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_vo2max_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_trainingLoad_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 142,
              hour_startY: 51,
              hour_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 248,
              minute_startY: 51,
              minute_array: ["5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 346,
              second_startY: 75,
              second_array: ["15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 89,
              am_y: 68,
              am_sc_path: '26.png',
              am_en_path: '26.png',
              pm_x: 89,
              pm_y: 68,
              pm_sc_path: '28.png',
              pm_en_path: '28.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 201,
              y: 14,
              image_array: ["29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 17,
              font_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              padding: false,
              h_space: 1,
              unit_sc: '49.png',
              unit_tc: '49.png',
              unit_en: '49.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 199,
              font_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 250,
              font_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 129,
              y: 300,
              font_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              padding: false,
              h_space: 1,
              dot_image: '51.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 350,
              font_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 344,
              y: 199,
              font_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              padding: false,
              h_space: 2,
              invalid_image: '52.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 344,
              y: 248,
              font_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              padding: false,
              h_space: 2,
              invalid_image: '53.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 344,
              y: 300,
              font_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 344,
              y: 349,
              font_array: ["39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              padding: false,
              h_space: 2,
              invalid_image: '54.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 47,
              y: 112,
              week_en: ["55.png","56.png","57.png","58.png","59.png","60.png","61.png"],
              week_tc: ["55.png","56.png","57.png","58.png","59.png","60.png","61.png"],
              week_sc: ["55.png","56.png","57.png","58.png","59.png","60.png","61.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 167,
              day_startY: 115,
              day_sc_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              day_tc_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              day_en_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '86.png',
              day_unit_tc: '86.png',
              day_unit_en: '86.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 201,
              month_startY: 115,
              month_sc_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              month_tc_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              month_en_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 262,
              y: 104,
              image_array: ["87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 302,
              y: 115,
              font_array: ["116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png"],
              padding: false,
              h_space: 1,
              unit_sc: '134.png',
              unit_tc: '134.png',
              unit_en: '134.png',
              negative_image: '133.png',
              invalid_image: '132.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 345,
              y: 115,
              font_array: ["116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png"],
              padding: false,
              h_space: 0,
              unit_sc: '131.png',
              unit_tc: '131.png',
              unit_en: '131.png',
              negative_image: '126.png',
              dot_image: '128.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '135.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 114,
              hour_startY: 196,
              hour_array: ["136.png","137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 252,
              minute_startY: 196,
              minute_array: ["136.png","137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 265,
              day_startY: 277,
              day_sc_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              day_tc_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              day_en_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '146.png',
              day_unit_tc: '146.png',
              day_unit_en: '146.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 298,
              month_startY: 277,
              month_sc_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              month_tc_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              month_en_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 140,
              y: 274,
              week_en: ["147.png","148.png","149.png","150.png","151.png","152.png","153.png"],
              week_tc: ["147.png","148.png","149.png","150.png","151.png","152.png","153.png"],
              week_sc: ["147.png","148.png","149.png","150.png","151.png","152.png","153.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 236,
              w: 192,
              h: 47,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 245,
              y: 185,
              w: 192,
              h: 47,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 330,
              w: 192,
              h: 56,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 245,
              y: 236,
              w: 192,
              h: 47,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 115,
              y: 394,
              w: 60,
              h: 60,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 243,
              y: 393,
              w: 60,
              h: 58,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 245,
              y: 335,
              w: 192,
              h: 47,
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 306,
              y: 392,
              w: 60,
              h: 60,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_trainingLoad_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 394,
              w: 60,
              h: 60,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}