﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// =========================================================
// 1. VARIABLES GLOBALES (ESTADO INICIAL)
// =========================================================
let colornumber_H = 1; // Contador para Horas
let colornumber_M = 1; // Contador para Minutos
let colornumber_2 = 1; // Contador para Fondo (Style)
let total_styles = 7;
let totalcolors = 8;

// =========================================================
// 2. AYUDANTE DE RUTAS (CARPETAS)
// =========================================================
function getFolder(number) {
    if (number === 1) return { name: "WHITE", path: "" };
    if (number === 2) return { name: "BLUE", path: "Blue/" };
    if (number === 3) return { name: "GREEN", path: "Green/" };
    if (number === 4) return { name: "LEMON", path: "Lemon/" };
    if (number === 5) return { name: "ORANGE", path: "Orange/" };
    if (number === 6) return { name: "YELLOW", path: "Yellow/" };
    if (number === 7) return { name: "RED", path: "Red/" };
    if (number === 8) return { name: "MAGENTA", path: "Magenta/" };
    return { name: "WHITE", path: "" };
}

// =========================================================
// 3. FUNCIÓN DE ACTUALIZACIÓN DEL RELOJ
// =========================================================
function update_watch_face() {
    let hourProps = getFolder(colornumber_H);
    let minuteProps = getFolder(colornumber_M);

    if (typeof normal_digital_clock_img_time !== 'undefined' && normal_digital_clock_img_time) {
        normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
            // Horas
            hour_startX: 53,
            hour_startY: 171,
            hour_array: [
                hourProps.path + "Time_0.png", hourProps.path + "Time_1.png", hourProps.path + "Time_2.png",
                hourProps.path + "Time_3.png", hourProps.path + "Time_4.png", hourProps.path + "Time_5.png",
                hourProps.path + "Time_6.png", hourProps.path + "Time_7.png", hourProps.path + "Time_8.png", hourProps.path + "Time_9.png"
            ],
            hour_zero: 1,
            hour_align: hmUI.align.CENTER_H,
            // Minutos
            minute_startX: 233,
            minute_startY: 171,
            minute_array: [
                minuteProps.path + "Time_0.png", minuteProps.path + "Time_1.png", minuteProps.path + "Time_2.png",
                minuteProps.path + "Time_3.png", minuteProps.path + "Time_4.png", minuteProps.path + "Time_5.png",
                minuteProps.path + "Time_6.png", minuteProps.path + "Time_7.png", minuteProps.path + "Time_8.png", minuteProps.path + "Time_9.png"
            ],
            minute_zero: 1,
            minute_follow: 0,
            minute_align: hmUI.align.CENTER_H,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
    }
}

// =========================================================
// 4. FUNCIONES PARA LOS BOTONES
// =========================================================

// Botón ESTILO (Fondo) - Ahora simplificado al principio
function color_style() {
    colornumber_2 = (colornumber_2 >= total_styles) ? 1 : colornumber_2 + 1;
    hmUI.showToast({ text: "Style " + colornumber_2 });
    
    if (typeof normal_background_bg_img !== 'undefined' && normal_background_bg_img) {
        normal_background_bg_img.setProperty(hmUI.prop.SRC, "Bg" + colornumber_2 + ".png");
    }
}

// Botón HORA
function color_hour() {
    colornumber_H = (colornumber_H >= totalcolors) ? 1 : colornumber_H + 1;
    let props = getFolder(colornumber_H);
    hmUI.showToast({ text: "Hour: " + props.name });
    update_watch_face();
}

// Botón MINUTO
function color_minute() {
    colornumber_M = (colornumber_M >= totalcolors) ? 1 : colornumber_M + 1;
    let props = getFolder(colornumber_M);
    hmUI.showToast({ text: "Minute: " + props.name });
    update_watch_face();
}

// Botón TIME (Sincroniza ambos al mismo color)
function color_time() {
    colornumber_H = (colornumber_H >= totalcolors) ? 1 : colornumber_H + 1;
    colornumber_M = colornumber_H; 
    let props = getFolder(colornumber_H);
    hmUI.showToast({ text: "All Color: " + props.name });
    update_watch_face();
}
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let normal_cal_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''
        let Button_10 = ''
        let Button_11 = ''
        let Button_12 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 53,
              hour_startY: 171,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 233,
              minute_startY: 171,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,


              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0105.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 405,
              y: 199,
              src: '0103.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 53,
              hour_startY: 171,
              hour_array: ["timeaod_0.png","timeaod_1.png","timeaod_2.png","timeaod_3.png","timeaod_4.png","timeaod_5.png","timeaod_6.png","timeaod_7.png","timeaod_8.png","timeaod_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 233,
              minute_startY: 171,
              minute_array: ["timeaod_0.png","timeaod_1.png","timeaod_2.png","timeaod_3.png","timeaod_4.png","timeaod_5.png","timeaod_6.png","timeaod_7.png","timeaod_8.png","timeaod_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,


              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 247,
              y: 82,
              w: 155,
              h: 85,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 72,
              y: 273,
              w: 100,
              h: 63,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 244,
              y: 340,
              w: 77,
              h: 64,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 324,
              y: 340,
              w: 100,
              h: 64,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 3,
              w: 100,
              h: 72,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0063.png',
              normal_src: '0063.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_batteryManagerScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 303,
              y: 273,
              w: 104,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0063.png',
              normal_src: '0063.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'BioChargeHomeScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'Sleep_HomeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 113,
              y: 339,
              w: 123,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0063.png',
              normal_src: '0063.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'SportScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 178,
              y: 408,
              w: 123,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0063.png',
              normal_src: '0063.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportRecordListScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'oneKeyAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 383,
              y: 176,
              w: 82,
              h: 94,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0063.png',
              normal_src: '0063.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 185,
              y: 273,
              w: 104,
              h: 64,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0063.png',
              normal_src: '0063.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'SportStatusScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 79,
              y: 129,
              w: 158,
              h: 56,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0063.png',
              normal_src: '0063.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 84,
              y: 77,
              w: 153,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0063.png',
              normal_src: '0063.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 64,
              y: 195,
              w: 122,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0063.png',
              normal_src: '0063.png',
              click_func: (button_widget) => {
                // change color Hour
                color_hour()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_10 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 276,
              y: 191,
              w: 105,
              h: 75,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0063.png',
              normal_src: '0063.png',
              click_func: (button_widget) => {
                // change color minute
                color_minute()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_11 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 189,
              y: 188,
              w: 76,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0063.png',
              normal_src: '0063.png',
              click_func: (button_widget) => {
                // change color Time
                color_time()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_12 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 6,
              y: 194,
              w: 52,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0063.png',
              normal_src: '0063.png',
              click_func: (button_widget) => {
                //switch Colors
                color_style()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}