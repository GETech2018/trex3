﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let cc = 0

		let alt_var = 1
        let alt_all = 2
		let alt_text = ' '
		let pressure_array = read_pressure();
        let value = getPressureValue(pressure_array);
		
		let night_var = 1
        let night_all = 2
		let name_text = ' '
		
		let menu = 1
        let total_menu = 2
		
		let color_r = 1
        let colors_r = 10
		let namecolor_r = ' '
		
		
		let hrs = 4
		let min = 4
		let sec = 4
		let week = 4
	
		
	
		
		
		let color_l = 4
		let color_a = 5
		let color_t = 3
		let color_k = 8
		let color_j = 8
		let color_o = 7
		let color_y = 6
		let color_c = 10
		let color_e = 1
		let color_s = 1
		let color_d = 4
		let color_vl = 5
		
		
		let color_digt = 1
        let all_digt = 15
		let color_text = '0xFFFFFFFF'
		let namecolor_digt = ' '
		
		let color_bg = 1
        let totalcolors_bg = 15
		let namecolor_main = ' '

	// vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
	
//# барометр в мм рт. ст.


function read_pressure() {
 console.log("read_pressure()");
 const file_name_alt = "../../../baro_altim/pressure.dat";
 const [fs_stat, err] = hmFS.stat(file_name_alt);
 if (err == 0) {
  let file_size = fs_stat.size;
  const len = file_size / 4;
  console.log(`size_alt: ${file_size}, lenght: ${len}`)
  const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)

  let array_buffer = new Float32Array(len);
  hmFS.read(fh, array_buffer.buffer, 0, file_size);
  hmFS.close(fh);
  console.log(`value ${array_buffer[array_buffer.length -1]}`);
  return array_buffer;
 } else {
  console.log('err:', err)
 }
 return null;
}

function getPressureValue(pressure_array) {
 console.log("getPressureValue()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
 }
 return 0;
}



function hPa_To_mmHg(hPa_value = 0) {
 let mmHg = Math.round(hPa_value * 0.750064);
 return mmHg;
}
//# конец барометр в мм рт. ст.

// переключение едениц измерения давления

		

function click_ALT() {
            if(alt_var>=alt_all) {
            alt_var=1;
                }
            else {
                alt_var=alt_var+1;
            }
			if ( alt_var == 1) { 
			alt_text = "мм рт. ст."  
			value = hPa_To_mmHg(value);              // перевод в мм.рт.ст.
			normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));
		    }			
			if ( alt_var == 2) { 
			alt_text = "гПа" 
			value = getPressureValue(pressure_array);              // перевод в гПа
			normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));
			}
			
			hmUI.showToast({text: alt_text });
			vibro(28);
									
		}

// конец переключение едениц измерения давления

//	переход в ночной режим (подставлением полупрозрачной картинки поверх циферблата)
		

			
		function click_Night() {
            if(night_var>=night_all) {
            night_var=1;
                }
            else {
                night_var=night_var+1;
            }
			if ( night_var == 1) name_text = "ДНЕВНОЙ РЕЖИМ"  // "DAYTIME MODE"
			if ( night_var == 2) name_text = "НОЧНОЙ РЕЖИМ"   // "NIGHT MODE"
			hmUI.showToast({text: name_text });
			image_top_img.setProperty(hmUI.prop.SRC, "night_" + parseInt(night_var) + ".png");
			vibro(28);
		}
		
//	конец перехода в ночной режим 


function click_BG() {
            if(color_bg>=totalcolors_bg) {
            color_bg=1;
                }
            else { 
			color_bg=color_bg+1;   
			}
			if ( color_bg == 1) namecolor_main = "ЯРКИЙ БЕЛЫЙ"
			if ( color_bg == 2) namecolor_main = "СЕРЫЙ"
			if ( color_bg == 3) namecolor_main = "ИЗУМРУД"
			if ( color_bg == 4) namecolor_main = "ЗЕЛЁНЫЙ"
			if ( color_bg == 5) namecolor_main = "АКВА"
			if ( color_bg == 6) namecolor_main = "ЖЁЛТЫЙ"
			if ( color_bg == 7) namecolor_main = "ОРАНЖ"
			if ( color_bg == 8) namecolor_main = "КРСНЫЙ"
			if ( color_bg == 9) namecolor_main = "ЗЕЛЁНЫЙ В БЕЛЫЙ"
			if ( color_bg == 10) namecolor_main = "АКВА В БЕЛЫЙ"
			if ( color_bg == 11) namecolor_main = "КРСНЫЙ В БЕЛЫЙ"
			if ( color_bg == 12) namecolor_main = "ОРАНЖ В БЕЛЫЙ"
			if ( color_bg == 13) namecolor_main = "ЖЁЛТЫЙ В БЕЛЫЙ"
			if ( color_bg == 14) namecolor_main = "ЦВЕТНОЙ 1"
			if ( color_bg == 15) namecolor_main = "ЦВЕТНОЙ 2"
			
			
			hmUI.showToast({text: namecolor_main });	
				
			vibro(28);
			
			if ( color_bg == 1) {color_text = '0xFFffffff'}    // белый
			if ( color_bg == 2) {color_text = '0xFFb8b8b8'}    //  серый
			if ( color_bg == 3) {color_text = '0xFF00fe9a'}	// изумруд
			if ( color_bg == 4) {color_text = '0xFF00ff25'}	// зелёный
			if ( color_bg == 5) {color_text = '0xFF00FFFF'}    // аква
			if ( color_bg == 6) {color_text = '0xFFFFFF00'}	//  жёлтый
			if ( color_bg == 7) {color_text = '0xFFfe8500'}	// оранжевый
			if ( color_bg == 8) {color_text = '0xFFFF0000'}	// КРАСНЫЙ
			if ( color_bg == 9) {color_text = '0xFF00ff25'}	// зелёный
			if ( color_bg == 10) {color_text = '0xFF00FFFF'}    // аква
			if ( color_bg == 11) {color_text = '0xFFFF0000'}    // КРАСНЫЙ
			if ( color_bg == 12) {color_text = '0xFFfe8500'}    // оранжевый
			if ( color_bg == 13) {color_text = '0xFFFFFF00'}    //  жёлтый
			if ( color_bg == 14) {color_text = '0xFFa0ff00'}    // салатовый
			if ( color_bg == 15) {color_text = '0xFFffffff'}    // белый

			
			

		normal_city_name_text.setProperty(hmUI.prop.MORE, {
              x: 192,
              y: 4,
              w: 100,
              h: 30,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/lcddisplaycapssskcyrillic.ttf',
              color: color_text,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });			
			
			
			
			normal_image_img.setProperty(hmUI.prop.SRC, "TOP_" + parseInt(color_bg) + ".png");
//			normal_background_bg_img.setProperty(hmUI.prop.SRC, "BG_" + parseInt(color_bg) + ".png");	
					
			}
 //  конец  изменения цвета фона	

 //  изменение цвета цифр
  
	function click_DIGT() {
            if(color_digt>=all_digt) {
            color_digt=1;
                }
            else { 
			color_digt=color_digt+1;   
			}
			            if(color_digt == 1)  { 
		    color_r=color_digt;
		    color_l=color_digt;
			color_a=color_digt;
			color_t=color_digt;
			color_k=color_digt;
			color_o=color_digt;
			color_y=color_digt;
			color_c=color_digt;
			color_e=color_digt;
			color_s=color_digt;
			color_d=color_digt;
			color_j=color_digt;
			hrs=color_digt;
			min=color_digt;
			sec=color_digt;
			week=color_digt;
			color_vl=color_digt;
			}
			            if(color_digt == 2)  { 
		    color_r=color_digt;
		    color_l=color_digt;
			color_a=color_digt;
			color_t=color_digt;
			color_k=color_digt;
			color_o=color_digt;
			color_y=color_digt;
			color_c=color_digt;
			color_e=color_digt;
			color_s=color_digt;
			color_d=color_digt;
			color_j=color_digt;
			hrs=color_digt;
			min=color_digt;
			sec=color_digt;
			week=color_digt;
			color_vl=color_digt;
			}
			            if(color_digt == 3)  { 
		    color_r=color_digt;
		    color_l=color_digt;
			color_a=color_digt;
			color_t=color_digt;
			color_k=color_digt;
			color_o=color_digt;
			color_y=color_digt;
			color_c=color_digt;
			color_e=color_digt;
			color_s=color_digt;
			color_d=color_digt;
			color_j=color_digt;
			hrs=color_digt;
			min=color_digt;
			sec=color_digt;
			week=color_digt;
			color_vl=color_digt;
			}
			            if(color_digt == 4)  { 
		    color_r=color_digt;
		    color_l=color_digt;
			color_a=color_digt;
			color_t=color_digt;
			color_k=color_digt;
			color_o=color_digt;
			color_y=color_digt;
			color_c=color_digt;
			color_e=color_digt;
			color_s=color_digt;
			color_d=color_digt;
			color_j=color_digt;
			hrs=color_digt;
			min=color_digt;
			sec=color_digt;
			week=color_digt;
			color_vl=color_digt;
			}
			            if(color_digt == 5)  { 
		    color_r=color_digt;
		    color_l=color_digt;
			color_a=color_digt;
			color_t=color_digt;
			color_k=color_digt;
			color_o=color_digt;
			color_y=color_digt;
			color_c=color_digt;
			color_e=color_digt;
			color_s=color_digt;
			color_d=color_digt;
			color_j=color_digt;
			hrs=color_digt;
			min=color_digt;
			sec=color_digt;
			week=color_digt;
			color_vl=color_digt;
			}
			            if(color_digt == 6)  { 
		    color_r=color_digt;
		    color_l=color_digt;
			color_a=color_digt;
			color_t=color_digt;
			color_k=color_digt;
			color_o=color_digt;
			color_y=color_digt;
			color_c=color_digt;
			color_e=color_digt;
			color_s=color_digt;
			color_d=color_digt;
			color_j=color_digt;
			hrs=color_digt;
			min=color_digt;
			sec=color_digt;
			week=color_digt;
			color_vl=color_digt;
			}
			            if(color_digt == 7)  { 
		    color_r=color_digt;
		    color_l=color_digt;
			color_a=color_digt;
			color_t=color_digt;
			color_k=color_digt;
			color_o=color_digt;
			color_y=color_digt;
			color_c=color_digt;
			color_e=color_digt;
			color_s=color_digt;
			color_d=color_digt;
			color_j=color_digt;
			hrs=color_digt;
			min=color_digt;
			sec=color_digt;
			week=color_digt;
			color_vl=color_digt;
			}
			            if(color_digt == 8)  { 
		    color_r=color_digt;
		    color_l=color_digt;
			color_a=color_digt;
			color_t=color_digt;
			color_k=color_digt;
			color_o=color_digt;
			color_y=color_digt;
			color_c=color_digt;
			color_e=color_digt;
			color_s=color_digt;
			color_d=color_digt;
			color_j=color_digt;
			hrs=color_digt;
			min=color_digt;
			sec=color_digt;
			week=color_digt;
			color_vl=color_digt;
			}
						if(color_digt == 9) {
		   color_r=1;
		   color_j=1;
		   color_l=4;
		   color_a=4;
		   color_c=4;
		   color_k=4;
		   color_o=1;
		   color_y=1;
		   color_e=4;
		   color_s=1;
		   color_d=4;
		   color_t=4;
		   hrs=color_digt;
			min=color_digt;
			sec=color_digt;
			week=4;
			color_vl=4;
		    }
						if(color_digt == 10) {
		   color_r=1;
		   color_j=1;
		   color_l=5;
		   color_a=5;
		   color_c=5;
		   color_k=5;
		   color_o=1;
		   color_y=1;
		   color_e=5;
		   color_s=1;
		   color_d=5;
		   color_t=5;
		   hrs=color_digt;
			min=color_digt;
			sec=color_digt;
			week=5;
			color_vl=5;
		    }
						if(color_digt == 11) {
		   color_r=1;
		   color_j=1;
		   color_l=8;
		   color_a=8;
		   color_c=8;
		   color_k=8;
		   color_o=1;
		   color_y=1;
		   color_e=8;
		   color_s=1;
		   color_d=8;
		   color_t=8;
		   hrs=color_digt;
			min=color_digt;
			sec=color_digt;
			week=8;
			color_vl=8;
		    }
						if(color_digt == 12) {
		   color_r=1;
		   color_j=1;
		   color_l=7;
		   color_a=7;
		   color_c=7;
		   color_k=7;
		   color_o=1;
		   color_y=1;
		   color_e=7;
		   color_s=1;
		   color_d=7;
		   color_t=7;
		   hrs=color_digt;
			min=color_digt;
			sec=color_digt;
			week=7;
			color_vl=7;
		    }			
						if(color_digt == 13) {
		   color_r=1;
		   color_j=1;
		   color_l=6;
		   color_a=6;
		   color_c=6;
		   color_k=6;
		   color_o=1;
		   color_y=1;
		   color_e=6;
		   color_s=1;
		   color_d=6;
		   color_t=6;
		   hrs=color_digt;
			min=color_digt;
			sec=color_digt;
			week=6;
			color_vl=6;
		    }			
			
					   if(color_digt == 14) {
		   color_r=3;
		   color_l=4;
		   color_a=3;
		   color_t=1;
		   color_k=8;
		   color_j=11;
		   color_o=7;
		   color_y=6;
		   color_e=6;
		   color_s=1;
		   color_d=1;
		   color_c=15;
		   hrs=10;
			min=9;
			sec=13;
			week=5;
			color_vl=5;
            }						
					   if(color_digt == 15) {
		   color_r=3;
		   color_l=4;
		   color_a=5;
		   color_t=1;
		   color_k=8;
		   color_j=11;
		   color_o=7;
		   color_y=6;
		   color_e=1;
		   color_s=1;
		   color_d=1;
		   color_c=color_digt;
		   hrs=1;
			min=1;
			sec=1;
			week=4;
			color_vl=5;
            }			

	
	normal_stress_icon_img.setProperty(hmUI.prop.SRC, parseInt(color_t) + "_alarm.png");	
	normal_pai_icon_img.setProperty(hmUI.prop.SRC, parseInt(color_k) + "_lock.png");
	

	normal_system_clock_img.setProperty(hmUI.prop.MORE, {
              x: 353,
              y: 193,
              src: parseInt(color_t) + '_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
	normal_system_lock_img.setProperty(hmUI.prop.MORE, {
              x: 246,
              y: 156,
              src: parseInt(color_k) + '_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		
			
	normal_battery_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 304,
              y: 313,
              font_array: [parseInt(color_y) + "_040.png",parseInt(color_y) + "_041.png",parseInt(color_y) + "_042.png",parseInt(color_y) + "_043.png",parseInt(color_y) + "_044.png",parseInt(color_y) + "_045.png",parseInt(color_y) + "_046.png",parseInt(color_y) + "_047.png",parseInt(color_y) + "_048.png",parseInt(color_y) + "_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_y) + '_int.png',
              unit_tc: parseInt(color_y) + '_int.png',
              unit_en: parseInt(color_y) + '_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

    normal_battery_text_separator_img.setProperty(hmUI.prop.SRC, parseInt(color_digt) + "_scale.png");			
	
/////////////////////////////////////////////////////
			
		normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: 120,
              hour_startY: 194,
              hour_array: [parseInt(hrs) + "_001.png",parseInt(hrs) + "_002.png",parseInt(hrs) + "_003.png",parseInt(hrs) + "_004.png",parseInt(hrs) + "_005.png",parseInt(hrs) + "_006.png",parseInt(hrs) + "_007.png",parseInt(hrs) + "_008.png",parseInt(hrs) + "_009.png",parseInt(hrs) + "_010.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 244,
              minute_startY: 194,
              minute_array: [parseInt(min) + "_001.png",parseInt(min) + "_002.png",parseInt(min) + "_003.png",parseInt(min) + "_004.png",parseInt(min) + "_005.png",parseInt(min) + "_006.png",parseInt(min) + "_007.png",parseInt(min) + "_008.png",parseInt(min) + "_009.png",parseInt(min) + "_010.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 341,
              second_startY: 233,
              second_array: [parseInt(sec) + "_013.png",parseInt(sec) + "_014.png",parseInt(sec) + "_015.png",parseInt(sec) + "_016.png",parseInt(sec) + "_017.png",parseInt(sec) + "_018.png",parseInt(sec) + "_019.png",parseInt(sec) + "_020.png",parseInt(sec) + "_021.png",parseInt(sec) + "_022.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });
		
	normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.SRC, parseInt(hrs) + "_24h.png");	
	
    normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.SRC, parseInt(hrs) + "_011.png");	

	normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 0,
              am_y: 0,
              am_sc_path: parseInt(hrs) + '_am.png',
              am_en_path: parseInt(hrs) + '_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: parseInt(hrs) + '_pm.png',
              pm_en_path: parseInt(hrs) + '_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			
			
			
	    normal_date_img_date_week_img.setProperty(hmUI.prop.MORE, {
              x: 178,
              y: 119,
              week_en: [parseInt(week) + "_023.png",parseInt(week) + "_024.png",parseInt(week) + "_025.png",parseInt(week) + "_026.png",parseInt(week) + "_027.png",parseInt(week) + "_028.png",parseInt(week) + "_029.png"],
              week_tc: [parseInt(week) + "_023.png",parseInt(week) + "_024.png",parseInt(week) + "_025.png",parseInt(week) + "_026.png",parseInt(week) + "_027.png",parseInt(week) + "_028.png",parseInt(week) + "_029.png"],
              week_sc: [parseInt(week) + "_023.png",parseInt(week) + "_024.png",parseInt(week) + "_025.png",parseInt(week) + "_026.png",parseInt(week) + "_027.png",parseInt(week) + "_028.png",parseInt(week) + "_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_date_img_date_month_img.setProperty(hmUI.prop.MORE, {
              month_startX: 304,
              month_startY: 138,
              month_sc_array: [parseInt(color_l) + "_051.png",parseInt(color_l) + "_052.png",parseInt(color_l) + "_053.png",parseInt(color_l) + "_054.png",parseInt(color_l) + "_055.png",parseInt(color_l) + "_056.png",parseInt(color_l) + "_057.png",parseInt(color_l) + "_058.png",parseInt(color_l) + "_059.png",parseInt(color_l) + "_060.png",parseInt(color_l) + "_061.png",parseInt(color_l) + "_062.png"],
              month_tc_array: [parseInt(color_l) + "_051.png",parseInt(color_l) + "_052.png",parseInt(color_l) + "_053.png",parseInt(color_l) + "_054.png",parseInt(color_l) + "_055.png",parseInt(color_l) + "_056.png",parseInt(color_l) + "_057.png",parseInt(color_l) + "_058.png",parseInt(color_l) + "_059.png",parseInt(color_l) + "_060.png",parseInt(color_l) + "_061.png",parseInt(color_l) + "_062.png"],
              month_en_array: [parseInt(color_l) + "_051.png",parseInt(color_l) + "_052.png",parseInt(color_l) + "_053.png",parseInt(color_l) + "_054.png",parseInt(color_l) + "_055.png",parseInt(color_l) + "_056.png",parseInt(color_l) + "_057.png",parseInt(color_l) + "_058.png",parseInt(color_l) + "_059.png",parseInt(color_l) + "_060.png",parseInt(color_l) + "_061.png",parseInt(color_l) + "_062.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
              day_startX: 259,
              day_startY: 115,
              day_sc_array: [parseInt(color_d) + "_040.png",parseInt(color_d) + "_041.png",parseInt(color_d) + "_042.png",parseInt(color_d) + "_043.png",parseInt(color_d) + "_044.png",parseInt(color_d) + "_045.png",parseInt(color_d) + "_046.png",parseInt(color_d) + "_047.png",parseInt(color_d) + "_048.png",parseInt(color_d) + "_049.png"],
              day_tc_array: [parseInt(color_d) + "_040.png",parseInt(color_d) + "_041.png",parseInt(color_d) + "_042.png",parseInt(color_d) + "_043.png",parseInt(color_d) + "_044.png",parseInt(color_d) + "_045.png",parseInt(color_d) + "_046.png",parseInt(color_d) + "_047.png",parseInt(color_d) + "_048.png",parseInt(color_d) + "_049.png"],
              day_en_array: [parseInt(color_d) + "_040.png",parseInt(color_d) + "_041.png",parseInt(color_d) + "_042.png",parseInt(color_d) + "_043.png",parseInt(color_d) + "_044.png",parseInt(color_d) + "_045.png",parseInt(color_d) + "_046.png",parseInt(color_d) + "_047.png",parseInt(color_d) + "_048.png",parseInt(color_d) + "_049.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		
	
///////////////////////////////////////////////////////	
	
	
		normal_fat_burning_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 113,
              y: 363,
              font_array: [parseInt(color_r) + "_040.png",parseInt(color_r) + "_041.png",parseInt(color_r) + "_042.png",parseInt(color_r) + "_043.png",parseInt(color_r) + "_044.png",parseInt(color_r) + "_045.png",parseInt(color_r) + "_046.png",parseInt(color_r) + "_047.png",parseInt(color_r) + "_048.png",parseInt(color_r) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
	
        normal_pai_weekly_text_img.setProperty(hmUI.prop.MORE, {
              x: 311,
              y: 363,
              font_array: [parseInt(color_r) + "_040.png",parseInt(color_r) + "_041.png",parseInt(color_r) + "_042.png",parseInt(color_r) + "_043.png",parseInt(color_r) + "_044.png",parseInt(color_r) + "_045.png",parseInt(color_r) + "_046.png",parseInt(color_r) + "_047.png",parseInt(color_r) + "_048.png",parseInt(color_r) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 210,
              y: 297,
              font_array: [parseInt(color_j) + "_030.png",parseInt(color_j) + "_031.png",parseInt(color_j) + "_032.png",parseInt(color_j) + "_033.png",parseInt(color_j) + "_034.png",parseInt(color_j) + "_035.png",parseInt(color_j) + "_036.png",parseInt(color_j) + "_037.png",parseInt(color_j) + "_038.png",parseInt(color_j) + "_039.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			
		normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 100,
              y: 313,
              font_array: [parseInt(color_o) + "_040.png",parseInt(color_o) + "_041.png",parseInt(color_o) + "_042.png",parseInt(color_o) + "_043.png",parseInt(color_o) + "_044.png",parseInt(color_o) + "_045.png",parseInt(color_o) + "_046.png",parseInt(color_o) + "_047.png",parseInt(color_o) + "_048.png",parseInt(color_o) + "_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
		normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 190,
              y: 371,
              font_array: [parseInt(color_s) + "_030.png",parseInt(color_s) + "_031.png",parseInt(color_s) + "_032.png",parseInt(color_s) + "_033.png",parseInt(color_s) + "_034.png",parseInt(color_s) + "_035.png",parseInt(color_s) + "_036.png",parseInt(color_s) + "_037.png",parseInt(color_s) + "_038.png",parseInt(color_s) + "_039.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	
			
			
/////////////////////////////////////////////////////////			
			
			
        normal_humidity_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 96,
              y: 137,
              font_array: [parseInt(color_vl) + "_040.png",parseInt(color_vl) + "_041.png",parseInt(color_vl) + "_042.png",parseInt(color_vl) + "_043.png",parseInt(color_vl) + "_044.png",parseInt(color_vl) + "_045.png",parseInt(color_vl) + "_046.png",parseInt(color_vl) + "_047.png",parseInt(color_vl) + "_048.png",parseInt(color_vl) + "_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_vl) + '_int.png',
              unit_tc: parseInt(color_vl) + '_int.png',
              unit_en: parseInt(color_vl) + '_int.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

 

        normal_altimeter_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 267,
              y: 71,
              font_array: [parseInt(color_a) + "_040.png",parseInt(color_a) + "_041.png",parseInt(color_a) + "_042.png",parseInt(color_a) + "_043.png",parseInt(color_a) + "_044.png",parseInt(color_a) + "_045.png",parseInt(color_a) + "_046.png",parseInt(color_a) + "_047.png",parseInt(color_a) + "_048.png",parseInt(color_a) + "_049.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });			
				
				
		normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 207,
              y: 41,
              image_array: [parseInt(color_c) + "_wth00.png",parseInt(color_c) + "_wth01.png",parseInt(color_c) + "_wth02.png",parseInt(color_c) + "_wth03.png",parseInt(color_c) + "_wth04.png",parseInt(color_c) + "_wth05.png",parseInt(color_c) + "_wth06.png",parseInt(color_c) + "_wth07.png",parseInt(color_c) + "_wth08.png",parseInt(color_c) + "_wth09.png",parseInt(color_c) + "_wth10.png",parseInt(color_c) + "_wth11.png",parseInt(color_c) + "_wth12.png",parseInt(color_c) + "_wth13.png",parseInt(color_c) + "_wth14.png",parseInt(color_c) + "_wth15.png",parseInt(color_c) + "_wth16.png",parseInt(color_c) + "_wth17.png",parseInt(color_c) + "_wth18.png",parseInt(color_c) + "_wth19.png",parseInt(color_c) + "_wth20.png",parseInt(color_c) + "_wth21.png",parseInt(color_c) + "_wth22.png",parseInt(color_c) + "_wth23.png",parseInt(color_c) + "_wth24.png",parseInt(color_c) + "_wth25.png",parseInt(color_c) + "_wth26.png",parseInt(color_c) + "_wth27.png",parseInt(color_c) + "_wth28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });		
				
				
        normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 134,
              y: 70,
              font_array: [parseInt(color_e) + "_040.png",parseInt(color_e) + "_041.png",parseInt(color_e) + "_042.png",parseInt(color_e) + "_043.png",parseInt(color_e) + "_044.png",parseInt(color_e) + "_045.png",parseInt(color_e) + "_046.png",parseInt(color_e) + "_047.png",parseInt(color_e) + "_048.png",parseInt(color_e) + "_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: parseInt(color_e) + '_dig.png',
              unit_tc: parseInt(color_e) + '_dig.png',
              unit_en: parseInt(color_e) + '_dig.png',
              imperial_unit_sc: parseInt(color_e) + '_dig.png',
              imperial_unit_tc: parseInt(color_e) + '_dig.png',
              imperial_unit_en: parseInt(color_e) + '_dig.png',
              negative_image: parseInt(color_e) + '_minus.png',
              invalid_image: parseInt(color_e) + '_eror.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

        
			
        

			} 
 
//  конец  изменения цвета цифр

 
 

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_stress_icon_img = ''
        let normal_fat_burning_icon_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_pai_icon_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_humidity_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_circle_scale = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_image_img = ''
        let idle_background_bg_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_minute_separator_img = ''
        let image_top_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: lcddisplaycapssskcyrillic.ttf; FontSize: 27; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 32,
              h: 32,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/lcddisplaycapssskcyrillic.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 353,
              y: 193,
              src: '1_alarm.png',
              // alpha: 125,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img.setAlpha(125);

            normal_fat_burning_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 208,
              y: 156,
              src: 'BT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 113,
              y: 363,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 246,
              y: 156,
              src: '1_lock.png',
              // alpha: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img.setAlpha(100);

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 311,
              y: 363,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 297,
              font_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 137,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_int.png',
              unit_tc: '1_int.png',
              unit_en: '1_int.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 313,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 71,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 190,
              y: 4,
              w: 100,
              h: 30,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/lcddisplaycapssskcyrillic.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 207,
              y: 41,
              image_array: ["1_wth00.png","1_wth01.png","1_wth02.png","1_wth03.png","1_wth04.png","1_wth05.png","1_wth06.png","1_wth07.png","1_wth08.png","1_wth09.png","1_wth10.png","1_wth11.png","1_wth12.png","1_wth13.png","1_wth14.png","1_wth15.png","1_wth16.png","1_wth17.png","1_wth18.png","1_wth19.png","1_wth20.png","1_wth21.png","1_wth22.png","1_wth23.png","1_wth24.png","1_wth25.png","1_wth26.png","1_wth27.png","1_wth28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 70,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_dig.png',
              unit_tc: '1_dig.png',
              unit_en: '1_dig.png',
              imperial_unit_sc: '1_dig.png',
              imperial_unit_tc: '1_dig.png',
              imperial_unit_en: '1_dig.png',
              negative_image: '1_minus.png',
              invalid_image: '1_eror.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 131,
                y: 70,
                font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
                padding: false,
                h_space: 0,
                unit_sc: '1_dig.png',
                unit_tc: '1_dig.png',
                unit_en: '1_dig.png',
                imperial_unit_sc: '1_dig.png',
                imperial_unit_tc: '1_dig.png',
                imperial_unit_en: '1_dig.png',
                negative_image: '1_minus.png',
                invalid_image: '1_eror.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 313,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_int.png',
              unit_tc: '1_int.png',
              unit_en: '1_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '1_scale.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 120,
              // end_angle: 60,
              // radius: 208,
              // line_width: 13,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 60,
              end_angle: 120,
              radius: 202,
              line_width: 13,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale.setAlpha(150);
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -120,
              // end_angle: -60,
              // radius: 208,
              // line_width: 13,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -60,
              end_angle: -120,
              radius: 202,
              line_width: 13,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_circle_scale.setAlpha(150);
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 371,
              font_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 178,
              y: 119,
              week_en: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_tc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_sc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 304,
              month_startY: 138,
              month_sc_array: ["1_051.png","1_052.png","1_053.png","1_054.png","1_055.png","1_056.png","1_057.png","1_058.png","1_059.png","1_060.png","1_061.png","1_062.png"],
              month_tc_array: ["1_051.png","1_052.png","1_053.png","1_054.png","1_055.png","1_056.png","1_057.png","1_058.png","1_059.png","1_060.png","1_061.png","1_062.png"],
              month_en_array: ["1_051.png","1_052.png","1_053.png","1_054.png","1_055.png","1_056.png","1_057.png","1_058.png","1_059.png","1_060.png","1_061.png","1_062.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 259,
              day_startY: 115,
              day_sc_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              day_tc_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              day_en_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 246,
              y: 156,
              src: '1_lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 208,
              y: 157,
              src: 'BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 353,
              y: 193,
              src: '1_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 120,
              hour_startY: 194,
              hour_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 244,
              minute_startY: 194,
              minute_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 341,
              second_startY: 233,
              second_array: ["1_013.png","1_014.png","1_015.png","1_016.png","1_017.png","1_018.png","1_019.png","1_020.png","1_021.png","1_022.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 194,
              src: '1_011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '1_24h.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: '1_am.png',
              am_en_path: '1_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: '1_pm.png',
              pm_en_path: '1_pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'TOP_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 120,
              // end_angle: 60,
              // radius: 208,
              // line_width: 13,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 60,
              end_angle: 120,
              radius: 202,
              line_width: 13,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_circle_scale.setAlpha(150);

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 304,
              y: 313,
              font_array: ["AOD_040.png","AOD_041.png","AOD_042.png","AOD_043.png","AOD_044.png","AOD_045.png","AOD_046.png","AOD_047.png","AOD_048.png","AOD_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD_int.png',
              unit_tc: 'AOD_int.png',
              unit_en: 'AOD_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 178,
              y: 119,
              week_en: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              week_tc: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              week_sc: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 304,
              month_startY: 138,
              month_sc_array: ["AOD_051.png","AOD_052.png","AOD_053.png","AOD_054.png","AOD_055.png","AOD_056.png","AOD_057.png","AOD_058.png","AOD_059.png","AOD_060.png","AOD_061.png","AOD_062.png"],
              month_tc_array: ["AOD_051.png","AOD_052.png","AOD_053.png","AOD_054.png","AOD_055.png","AOD_056.png","AOD_057.png","AOD_058.png","AOD_059.png","AOD_060.png","AOD_061.png","AOD_062.png"],
              month_en_array: ["AOD_051.png","AOD_052.png","AOD_053.png","AOD_054.png","AOD_055.png","AOD_056.png","AOD_057.png","AOD_058.png","AOD_059.png","AOD_060.png","AOD_061.png","AOD_062.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 259,
              day_startY: 115,
              day_sc_array: ["AOD_040.png","AOD_041.png","AOD_042.png","AOD_043.png","AOD_044.png","AOD_045.png","AOD_046.png","AOD_047.png","AOD_048.png","AOD_049.png"],
              day_tc_array: ["AOD_040.png","AOD_041.png","AOD_042.png","AOD_043.png","AOD_044.png","AOD_045.png","AOD_046.png","AOD_047.png","AOD_048.png","AOD_049.png"],
              day_en_array: ["AOD_040.png","AOD_041.png","AOD_042.png","AOD_043.png","AOD_044.png","AOD_045.png","AOD_046.png","AOD_047.png","AOD_048.png","AOD_049.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'AOD_am.png',
              am_en_path: 'AOD_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'AOD_pm.png',
              pm_en_path: 'AOD_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 120,
              hour_startY: 194,
              hour_array: ["AOD_001.png","AOD_002.png","AOD_003.png","AOD_004.png","AOD_005.png","AOD_006.png","AOD_007.png","AOD_008.png","AOD_009.png","AOD_010.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 244,
              minute_startY: 194,
              minute_array: ["AOD_001.png","AOD_002.png","AOD_003.png","AOD_004.png","AOD_005.png","AOD_006.png","AOD_007.png","AOD_008.png","AOD_009.png","AOD_010.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 341,
              second_startY: 232,
              second_array: ["AOD_013.png","AOD_014.png","AOD_015.png","AOD_016.png","AOD_017.png","AOD_018.png","AOD_019.png","AOD_020.png","AOD_021.png","AOD_022.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 194,
              src: 'AOD_011.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'AOD_24h.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: АХТУНГ\r\nсигнал потерян,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: связь востановлена,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "АХТУНГ\r\nсигнал потерян"});
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "связь востановлена"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            
            // repeatAlert = hmUI.createWidget(hmUI.widget.RepeatAlert, {
              // everyHour_vibrate_type: 0,
            // });


            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              repeat_alerts();
            });
            // repeat alerts
            function repeat_alerts() {
              let hourEnd = false;
              if(timeSensor.minute == 0) {
                hourEnd = true;
                vibro(0);
              }
            };

            // end repeat alerts

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'night_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 181,
              y: 362,
              w: 122,
              h: 100,
              src: '00_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 79,
              y: 296,
              w: 100,
              h: 63,
              src: '00_empty.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 191,
              y: 294,
              w: 98,
              h: 64,
              src: '00_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 310,
              y: 361,
              w: 114,
              h: 79,
              src: '00_empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 405,
              y: 141,
              w: 100,
              h: 202,
              src: '00_empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 98,
              y: 22,
              w: 100,
              h: 85,
              src: '00_empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 339,
              y: 234,
              w: 60,
              h: 60,
              src: '00_empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 348,
              y: 179,
              w: 50,
              h: 50,
              src: '00_empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 91,
              y: 364,
              w: 84,
              h: 93,
              src: '00_empty.png',
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 122,
              y: 195,
              w: 100,
              h: 92,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Night()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 236,
              y: 195,
              w: 100,
              h: 92,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_BG()
click_DIGT()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 281,
              y: 39,
              w: 150,
              h: 72,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_ALT()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 20,
              w: 70,
              h: 85,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 177,
              y: 113,
              w: 164,
              h: 72,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 302,
              y: 298,
              w: 94,
              h: 59,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 2,
              y: 131,
              w: 72,
              h: 227,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

let pressure_array = read_pressure();
let value = getPressureValue(pressure_array);
value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.
 
normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));


            // end user_script_end.js

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 60,
                      end_angle: 120,
                      radius: 202,
                      line_width: 13,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -60,
                      end_angle: -120,
                      radius: 202,
                      line_width: 13,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 60,
                      end_angle: 120,
                      radius: 202,
                      line_width: 13,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}