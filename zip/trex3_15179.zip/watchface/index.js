/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_animation1 = '';
		let normal_battery_progress3 = '';
		let normal_battery_imagecombo4 = '';
		let normal_weather_imageset7 = '';
		let normal_temperature_current_imagecombo8 = '';
		let normal_hour_imagecombo10 = '';
		let normal_minute_imagecombo11 = '';
		let normal_img12 = '';
		let normal_second_imagecombo13 = '';
		let timeInterval;
		let normal_ampm24_imageset14 = '';
		let normal_ampm24_imageset14_array = ['0126.png','0127.png','0128.png'];
		let normal_week_imageset16 = '';
		let normal_date_imagecombo17 = '';
		let normal_month_imagecombo18 = '';
		let normal_img19 = '';
		let normal_img21 = '';
		let normal_img22 = '';
		let normal_img23 = '';
		let normal_heart_current_imagecombo24 = '';
		let normal_heart_rotary25 = '';
		let normal_steps_imageset27 = '';
		let normal_steps_imagecombo28 = '';
		let normal_stand_imagecombo30 = '';
		let normal_calories_imagecombo32 = '';
		let idle_img35 = '';
		let idle_battery_progress37 = '';
		let idle_battery_imagecombo38 = '';
		let idle_weather_imageset41 = '';
		let idle_temperature_current_imagecombo42 = '';
		let idle_hour_imagecombo44 = '';
		let idle_minute_imagecombo45 = '';
		let idle_img46 = '';
		let idle_second_imagecombo47 = '';
		let idle_ampm24_imageset48 = '';
		let idle_ampm24_imageset48_array = ['0126.png','0127.png','0128.png'];
		let idle_week_imageset50 = '';
		let idle_date_imagecombo51 = '';
		let idle_month_imagecombo52 = '';
		let idle_img53 = '';
		let idle_img55 = '';
		let idle_img56 = '';
		let idle_img57 = '';
		let idle_heart_current_imagecombo58 = '';
		let idle_heart_rotary59 = '';
		let idle_steps_imageset61 = '';
		let idle_steps_imagecombo62 = '';
		let idle_stand_imagecombo64 = '';
		let idle_calories_imagecombo66 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				const batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_animation1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
					x: 220,
					y: 323,
					anim_path: '',
					anim_prefix: '1737384030378',
					anim_ext: 'png',
					anim_fps: 28,
					anim_size: 54,
					anim_repeat: true,
					repeat_count: 0,
					anim_status: hmUI.anim_status.START,
					display_on_restart: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});
				if (screenType != hmSetting.screen_type.AOD) {
					normal_battery_progress3 = hmUI.createWidget(hmUI.widget.ARC, {
						enable: false,
					});
				}

				normal_battery_imagecombo4 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 178,
					y: 79,
					font_array: ["0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png"],
					padding: false,
					h_space: 0,
					unit_sc: '0067.png',
					unit_tc: '0067.png',
					unit_en: '0067.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset7 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 273,
					y: 14,
					image_array: ["0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0070.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0068.png","0069.png","0071.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo8 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 273,
					y: 64,
					font_array: ["0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0104.png"],
					unit_tc: ["0104.png"],
					unit_en: ["0104.png"],
					negative_image: ["0103.png"],
					invalid_image: ["0103.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo10 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 46,
					hour_startY: 143,
					hour_array: ["0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.RIGHT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo11 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 196,
					minute_startY: 143,
					minute_array: ["0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 168,
					y: 132,
					w: 19,
					h: 117,
					src: '0115.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo13 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 335,
					second_startY: 213,
					second_array: ["0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_ampm24_imageset14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 339,
					y: 162,
					w: 339,
					h: 162,
					src: '0128.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_week_imageset16 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 394,
					y: 180,
					week_en: ["0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
					week_tc: ["0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
					week_sc: ["0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo17 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 392,
					day_startY: 221,
					day_sc_array: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
					day_tc_array: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
					day_en_array: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.RIGHT,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imagecombo18 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 436,
					month_startY: 221,
					month_sc_array: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
					month_tc_array: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
					month_en_array: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
					month_zero: true,
					month_space: 0,
					month_align: hmUI.align.LEFT,
					month_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img19 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 424,
					y: 221,
					w: 7,
					h: 20,
					src: '0146.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img21 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 397,
					y: 160,
					w: 40,
					h: 16,
					src: '0147.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img22 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 397,
					y: 203,
					w: 37,
					h: 16,
					src: '0148.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img23 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 50,
					y: 301,
					w: 41,
					h: 18,
					src: '0149.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo24 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 46,
					y: 325,
					font_array: ["0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png"],
					padding: true,
					h_space: 0,
					invalid_image: '0160.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_rotary25 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0161.png',
					center_x: 148,
					center_y: 376,
					x: 15,
					y: 39,
					start_angle: -40,
					end_angle: 224,
					type: hmUI.data_type.HEART,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imageset27 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 358,
					y: 294,
					image_array: ["0162.png","0163.png","0164.png","0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png"],
					image_length: 11,
					type: hmUI.data_type.STEP,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo28 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 343,
					y: 313,
					font_array: ["0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png","0180.png","0181.png","0182.png"],
					padding: true,
					h_space: 0,
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stand_imagecombo30 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 295,
					y: 379,
					font_array: ["0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png","0180.png","0181.png","0182.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.STAND,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo32 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 211,
					y: 437,
					font_array: ["0183.png","0184.png","0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png","0192.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img35 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0193.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				if (screenType != hmSetting.screen_type.AOD) {
					idle_battery_progress37 = hmUI.createWidget(hmUI.widget.ARC, {
						enable: false,
					});
				}

				idle_battery_imagecombo38 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 178,
					y: 79,
					font_array: ["0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png"],
					padding: false,
					h_space: 0,
					unit_sc: '0067.png',
					unit_tc: '0067.png',
					unit_en: '0067.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_weather_imageset41 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 273,
					y: 14,
					image_array: ["0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0070.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0068.png","0069.png","0071.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_temperature_current_imagecombo42 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 273,
					y: 64,
					font_array: ["0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0104.png"],
					unit_tc: ["0104.png"],
					unit_en: ["0104.png"],
					negative_image: ["0103.png"],
					invalid_image: ["0103.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_imagecombo44 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 46,
					hour_startY: 143,
					hour_array: ["0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.RIGHT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo45 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 196,
					minute_startY: 143,
					minute_array: ["0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img46 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 168,
					y: 132,
					w: 19,
					h: 117,
					src: '0115.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_second_imagecombo47 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 335,
					second_startY: 213,
					second_array: ["0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_ampm24_imageset48 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 339,
					y: 162,
					w: 339,
					h: 162,
					src: '0128.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_week_imageset50 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 394,
					y: 180,
					week_en: ["0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
					week_tc: ["0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
					week_sc: ["0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_imagecombo51 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 392,
					day_startY: 221,
					day_sc_array: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
					day_tc_array: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
					day_en_array: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.RIGHT,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_month_imagecombo52 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 436,
					month_startY: 221,
					month_sc_array: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
					month_tc_array: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
					month_en_array: ["0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
					month_zero: true,
					month_space: 0,
					month_align: hmUI.align.LEFT,
					month_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img53 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 424,
					y: 221,
					w: 7,
					h: 20,
					src: '0146.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img55 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 397,
					y: 160,
					w: 40,
					h: 16,
					src: '0147.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img56 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 397,
					y: 203,
					w: 37,
					h: 16,
					src: '0148.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img57 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 50,
					y: 301,
					w: 41,
					h: 18,
					src: '0149.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_heart_current_imagecombo58 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 46,
					y: 325,
					font_array: ["0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png"],
					padding: true,
					h_space: 0,
					invalid_image: '0160.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_heart_rotary59 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0161.png',
					center_x: 148,
					center_y: 376,
					x: 15,
					y: 39,
					start_angle: -40,
					end_angle: 224,
					type: hmUI.data_type.HEART,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_steps_imageset61 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 358,
					y: 294,
					image_array: ["0162.png","0163.png","0164.png","0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png"],
					image_length: 11,
					type: hmUI.data_type.STEP,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_steps_imagecombo62 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 343,
					y: 313,
					font_array: ["0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png","0180.png","0181.png","0182.png"],
					padding: true,
					h_space: 0,
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_stand_imagecombo64 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 295,
					y: 379,
					font_array: ["0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png","0180.png","0181.png","0182.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.STAND,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_calories_imagecombo66 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 211,
					y: 437,
					font_array: ["0183.png","0184.png","0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png","0192.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateTime() {
					normal_ampm24_imageset14.setProperty(hmUI.prop.MORE, {
						src: normal_ampm24_imageset14_array[(hmSetting.getTimeFormat() == 0 ? (timeSensor.hour >= 0 && timeSensor.hour < 12 ? 0 : 1) : 2)]
					})
					idle_ampm24_imageset48.setProperty(hmUI.prop.MORE, {
						src: idle_ampm24_imageset48_array[(hmSetting.getTimeFormat() == 0 ? (timeSensor.hour >= 0 && timeSensor.hour < 12 ? 0 : 1) : 2)]
					})
				}

				function updateBattery() {
					var current_normal_battery_progress3 = batterySensor.current;
					var target_normal_battery_progress3 = 100;
					var progress_normal_battery_progress3 = current_normal_battery_progress3 / target_normal_battery_progress3;

					if (progress_normal_battery_progress3 > 1) {
						progress_normal_battery_progress3 = 1;
					}

					var pcs_normal_battery_progress3 = progress_normal_battery_progress3;

					if (screenType != hmSetting.screen_type.AOD) {
						// initial parameters
						var sa_normal_battery_progress3 = -138;
						var ea_normal_battery_progress3 = -98;
						var cx_normal_battery_progress3 = 238;
						var cy_normal_battery_progress3 = 237;
						var r_normal_battery_progress3 = 221;
						var lw_normal_battery_progress3 = 8;
						var c_normal_battery_progress3 = 0xFF40FF00;

						// calculated parameters
						var ax_normal_battery_progress3 = cx_normal_battery_progress3 - r_normal_battery_progress3;
						var ay_normal_battery_progress3 = cy_normal_battery_progress3 - r_normal_battery_progress3;
						var cw_normal_battery_progress3 = 2 * r_normal_battery_progress3;
						var ao_normal_battery_progress3 = ea_normal_battery_progress3 - sa_normal_battery_progress3;
						ao_normal_battery_progress3 = ao_normal_battery_progress3 * pcs_normal_battery_progress3;
						var ea_normal_battery_progress3_draw = sa_normal_battery_progress3 + ao_normal_battery_progress3;

						normal_battery_progress3.setProperty(hmUI.prop.MORE, {
							x: ax_normal_battery_progress3,
							y: ay_normal_battery_progress3,
							w: cw_normal_battery_progress3,
							h: cw_normal_battery_progress3,
							start_angle: sa_normal_battery_progress3,
							end_angle: ea_normal_battery_progress3_draw,
							color: c_normal_battery_progress3,
							line_width: lw_normal_battery_progress3,
						});
					};

					var current_idle_battery_progress37 = batterySensor.current;
					var target_idle_battery_progress37 = 100;
					var progress_idle_battery_progress37 = current_idle_battery_progress37 / target_idle_battery_progress37;

					if (progress_idle_battery_progress37 > 1) {
						progress_idle_battery_progress37 = 1;
					}

					var pcs_idle_battery_progress37 = progress_idle_battery_progress37;

					if (screenType == hmSetting.screen_type.AOD) {
						// initial parameters
						var sa_idle_battery_progress37 = -138;
						var ea_idle_battery_progress37 = -98;
						var cx_idle_battery_progress37 = 238;
						var cy_idle_battery_progress37 = 237;
						var r_idle_battery_progress37 = 221;
						var lw_idle_battery_progress37 = 8;
						var c_idle_battery_progress37 = 0xFF40FF00;

						// calculated parameters
						var ax_idle_battery_progress37 = cx_idle_battery_progress37 - r_idle_battery_progress37;
						var ay_idle_battery_progress37 = cy_idle_battery_progress37 - r_idle_battery_progress37;
						var cw_idle_battery_progress37 = 2 * r_idle_battery_progress37;
						var ao_idle_battery_progress37 = ea_idle_battery_progress37 - sa_idle_battery_progress37;
						ao_idle_battery_progress37 = ao_idle_battery_progress37 * pcs_idle_battery_progress37;
						var ea_idle_battery_progress37_draw = sa_idle_battery_progress37 + ao_idle_battery_progress37;

						idle_battery_progress37.setProperty(hmUI.prop.MORE, {
							x: ax_idle_battery_progress37,
							y: ay_idle_battery_progress37,
							w: cw_idle_battery_progress37,
							h: cw_idle_battery_progress37,
							start_angle: sa_idle_battery_progress37,
							end_angle: ea_idle_battery_progress37_draw,
							color: c_idle_battery_progress37,
							line_width: lw_idle_battery_progress37,
						});
					};

				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				batterySensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateBattery();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						normal_animation1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
						updateTime();
						updateBattery();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						normal_animation1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
						normal_animation1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
		},
	});	})()
} catch (e) {
	console.log(e)
}