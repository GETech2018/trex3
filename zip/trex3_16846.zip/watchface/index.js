﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

// user_script_end START
		let cc = 0
		// user_script_end END
		
		// Hands START
		let elementnumber_1 = 1
        let total_elemente = 6

        function click_NEXT() {
            if(elementnumber_1==total_elemente) {
            elementnumber_1=1;
                UpdateElementeOne();
                }
            else {
                elementnumber_1=elementnumber_1+1;
                if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }
				if(elementnumber_1==3) {
                  UpdateElementeThree();
                }
				if(elementnumber_1==4) {
                  UpdateElementeFour();
                }
				if(elementnumber_1==5) {
                  UpdateElementeFive();
                }
				if(elementnumber_1==6) {
                  UpdateElementeSix();
                }			
            }
            if(elementnumber_1==1) hmUI.showToast({text: 'TIME'});
			if(elementnumber_1==2) hmUI.showToast({text: 'STEPS'});
            if(elementnumber_1==3) hmUI.showToast({text: 'HEART RATE'});
			if(elementnumber_1==4) hmUI.showToast({text: 'ALTIMETER'});
			if(elementnumber_1==5) hmUI.showToast({text: 'BAROMETER'});
			if(elementnumber_1==6) hmUI.showToast({text: 'COMPASS'});
        }
        function click_PREV() {
            elementnumber_1=elementnumber_1-1 ;
			if(elementnumber_1==0){
				elementnumber_1=total_elemente
			}
                if(elementnumber_1==1) {
                  UpdateElementeOne();
                }
				if(elementnumber_1==2) {
                  UpdateElementeTwo();
                }
				if(elementnumber_1==3) {
                  UpdateElementeThree();
                }
				if(elementnumber_1==4) {
                  UpdateElementeFour();
                }
				if(elementnumber_1==5) {
                  UpdateElementeFive();
                }
				if(elementnumber_1==6) {
                  UpdateElementeSix();
                }
            if(elementnumber_1==1) hmUI.showToast({text: 'TIME'});
			if(elementnumber_1==2) hmUI.showToast({text: 'STEPS'});
            if(elementnumber_1==3) hmUI.showToast({text: 'HEART RATE'});
			if(elementnumber_1==4) hmUI.showToast({text: 'ALTIMETER'});
			if(elementnumber_1==5) hmUI.showToast({text: 'BAROMETER'});
			if(elementnumber_1==6) hmUI.showToast({text: 'COMPASS'});
        }

        // TIME
        function UpdateElementeOne(){
        normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_body_temp_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
        normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
        normal_time_gmt_text.setProperty(hmUI.prop.VISIBLE, false);
        }
        // STEP
        function UpdateElementeTwo(){
        normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_body_temp_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_time_gmt_text.setProperty(hmUI.prop.VISIBLE, true);
        }    
		// HEART
        function UpdateElementeThree(){
        normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_body_temp_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_time_gmt_text.setProperty(hmUI.prop.VISIBLE, true);
        }
		// ALTIMETER
        function UpdateElementeFour(){
        normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_body_temp_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
        normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_time_gmt_text.setProperty(hmUI.prop.VISIBLE, true);
        }        
		// BAROMETER
        function UpdateElementeFive(){
        normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
        normal_body_temp_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_time_gmt_text.setProperty(hmUI.prop.VISIBLE, true);
		}
        // COMPASS
        function UpdateElementeSix(){
        normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, true);
        normal_body_temp_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_hour_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
        normal_time_gmt_text.setProperty(hmUI.prop.VISIBLE, true);

        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_compass_text_img = ''
        let normal_compass_separator_img = ''
        let normal_compass_direction_img_level = ''
        let normal_compass_direction_arr = ["C1.png", "C2.png", "C3.png", "C4.png", "C5.png", "C6.png", "C7.png", "C8.png"];
        let normal_body_temp_current_text_font = ''
        let normal_altitude_target_text_img = ''
        let normal_altitude_target_separator_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_font = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_image_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_date_img_date_week_img = ''
        let normal_second_circle_scale = ''
        let normal_timerUpdateSecCircle = undefined;
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_time_gmt_text = ''
        let worldClockIndex = 0
        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_second_circle_scale = ''
        let idle_timerUpdateSec = undefined;
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_second_separator_img = ''
        let GMT_Button_NextSity = ''
        let GMT_Button_PreviewSity = ''
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = '';
        let worldClock = '';
        worldClockIndex = hmFS.SysProGetInt('worldClockIndex') ?? 0;;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: nothing-font-5x7.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 652,
              h: 54,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/nothing-font-5x7.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: nothing-font-5x7.ttf; FontSize: 40; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 48,
              h: 48,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/nothing-font-5x7.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 145,
              font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 355,
              y: 306,
              src: 'COMPASS ICON.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_direction_img_level = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 84,
              src: 'C1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
              // type: hmUI.data_type.COMPASS,
            });

            normal_body_temp_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 211,
              y: 84,
              w: 76,
              h: 40,
              text_size: 40,
              char_space: 0,
              font: 'fonts/nothing-font-5x7.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 145,
              font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 237,
              y: 306,
              src: 'ALTI ICON.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 145,
              font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 296,
              y: 306,
              src: 'BARO ICON.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 179,
              y: 306,
              src: 'HR ICON.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 145,
              font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 137,
              y: 87,
              w: 196,
              h: 40,
              text_size: 40,
              char_space: 0,
              font: 'fonts/nothing-font-5x7.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              padding: true,
              unit_type: 1,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 121,
              y: 306,
              src: 'STEP ICON.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 145,
              font_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 410,
              src: 'b_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 224,
              y: 410,
              image_array: ["b_01.png","b_02.png","b_03.png","b_04.png","b_05.png","b_06.png","b_07.png","b_08.png","b_09.png","b_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 303,
              year_startY: 349,
              year_sc_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              year_tc_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              year_en_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              year_zero: 0,
              year_space: 5,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 209,
              month_startY: 349,
              month_sc_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              month_tc_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              month_en_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              month_zero: 1,
              month_space: 5,
              month_unit_sc: 'dateseparator.png',
              month_unit_tc: 'dateseparator.png',
              month_unit_en: 'dateseparator.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 115,
              day_startY: 349,
              day_sc_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              day_tc_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              day_en_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              day_zero: 0,
              day_space: 5,
              day_unit_sc: 'dateseparator.png',
              day_unit_tc: 'dateseparator.png',
              day_unit_en: 'dateseparator.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 217,
              y: 36,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 203,
              y: 89,
              w: 98,
              h: 40,
              text_size: 40,
              char_space: 0,
              font: 'fonts/nothing-font-5x7.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 104,
              y: 93,
              week_en: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              week_tc: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              week_sc: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_second_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 229,
              // line_width: 15,
              // line_cap: Flat,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_second_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 0,
              end_angle: 360,
              radius: 222,
              line_width: 15,
              corner_flag: 3,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            // normal_time_circle_options = hmUI.createWidget(hmUI.widget.TIME_CIRCLE_OPTIONS, {
              // smooth: true,
              // format24h: false,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 63,
              hour_startY: 145,
              hour_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'separat.png',
              hour_unit_tc: 'separat.png',
              hour_unit_en: 'separat.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 213,
              minute_startY: 145,
              minute_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 342,
              second_startY: 186,
              second_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 62,
              y: 306,
              src: 'TIME ICON.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 1,
              y: 0,
              src: 'wicon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            if (!worldClock) {
              worldClock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);
              worldClock.init();
            };

            normal_time_gmt_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 153,
              y: 344,
              w: 178,
              h: 46,
              text_size: 40,
              char_space: 0,
              font: 'fonts/nothing-font-5x7.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              // unit_end: 1,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //#region updateTimeGMT
            function updateTimeGMT() {
              console.log('updateTimeGMT()');
              let normal_timeStr = '--:--';
              let count = worldClock.getWorldClockCount();
              if (count > 0) {
                if (worldClockIndex >= count) worldClockIndex = count-1;
                let worldData = worldClock.getWorldClockInfo(worldClockIndex);
                let hour = worldData.hour;
                let minute = worldData.minute;
                if (!timeSensor.is24Hour) hour = hour % 12 || 12;
                let normal_hourStr = hour.toString().padStart(2, '0');
                let normal_minuteStr = minute.toString().padStart(2, '0');
                normal_timeStr = normal_hourStr + ':' + normal_minuteStr;
                if (!timeSensor.is24Hour) {
                  if (hour > 11) normal_timeStr = normal_timeStr + ' pm';
                  else normal_timeStr = normal_timeStr + ' am';
                };
              } // count
              if (normal_time_gmt_text) normal_time_gmt_text.setProperty(hmUI.prop.TEXT, normal_timeStr);
            };
            //#endregion

            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 410,
              src: 'b_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 224,
              y: 410,
              image_array: ["b_01.png","b_02.png","b_03.png","b_04.png","b_05.png","b_06.png","b_07.png","b_08.png","b_09.png","b_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 303,
              year_startY: 349,
              year_sc_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              year_tc_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              year_en_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              year_zero: 0,
              year_space: 5,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 209,
              month_startY: 349,
              month_sc_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              month_tc_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              month_en_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              month_zero: 1,
              month_space: 5,
              month_unit_sc: 'dateseparator.png',
              month_unit_tc: 'dateseparator.png',
              month_unit_en: 'dateseparator.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 115,
              day_startY: 349,
              day_sc_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              day_tc_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              day_en_array: ["20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              day_zero: 0,
              day_space: 5,
              day_unit_sc: 'dateseparator.png',
              day_unit_tc: 'dateseparator.png',
              day_unit_en: 'dateseparator.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 217,
              y: 36,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 104,
              y: 93,
              week_en: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              week_tc: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              week_sc: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","D7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_second_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 229,
              // line_width: 15,
              // line_cap: Flat,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_second_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 0,
              end_angle: 360,
              radius: 222,
              line_width: 15,
              corner_flag: 3,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_time_circle_options = hmUI.createWidget(hmUI.widget.TIME_CIRCLE_OPTIONS, {
              // smooth: false,
              // format24h: false,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 63,
              hour_startY: 145,
              hour_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'separat.png',
              hour_unit_tc: 'separat.png',
              hour_unit_en: 'separat.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 213,
              minute_startY: 145,
              minute_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 342,
              second_startY: 186,
              second_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 62,
              y: 306,
              src: 'TIME ICON.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 1,
              y: 0,
              src: 'wicon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            GMT_Button_NextSity = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              radius: 12,
              press_color: 0xFFA0A0A0,
              normal_color: 0xFF696969,
              click_func: (button_widget) => {
                toggleWorldClock(1);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            GMT_Button_PreviewSity = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 0,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              radius: 12,
              press_color: 0xFFA0A0A0,
              normal_color: 0xFF696969,
              click_func: (button_widget) => {
                toggleWorldClock(-1);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region toggleWorldClock
            function toggleWorldClock(step = 1) {
              const count = worldClock.getWorldClockCount();
              if (count) {
                worldClockIndex += step;
                worldClockIndex = worldClockIndex < 0 ? count + worldClockIndex : worldClockIndex % count;
                updateWorldTime(true);
                hmFS.SysProSetInt('worldClockIndex', worldClockIndex);
              }
            };
            //#endregion

            //#region updateWorldTime
            function updateWorldTime(updateSity = false) {
              updateTimeGMT();
            };
            //#endregion

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: -1,
              y: 183,
              w: 57,
              h: 113,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                click_PREV()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 429,
              y: 183,
              w: 57,
              h: 114,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                click_NEXT()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if (cc ==0 ){
        normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
		normal_body_temp_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altitude_target_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
        normal_time_gmt_text.setProperty(hmUI.prop.VISIBLE, false);
		cc = 1;
			}
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              // Second Circle
              let normal_secondCircleProgress = 100 * (second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_second_circle_scale) normal_second_circle_scale.setProperty(hmUI.prop.LEVEL, normal_secondCircleProgress );

              // Second Circle
              let idle_secondCircleProgress = 100 * second/60;
              if (idle_second_circle_scale) idle_second_circle_scale.setProperty(hmUI.prop.LEVEL, idle_secondCircleProgress );

            };

            //#endregion
            //#region compass_update
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Number
                let compass_direction_angle = parseInt(compass.direction_angle);
                let normal_compass_direction_angle_text = compass_direction_angle.toString().padStart(3, '0');
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);
                // Compass Images
                let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                let compass_direction_index = parseInt(compass_direction_angle_img/45);
                if (compass_direction_index > 7) compass_direction_index = 0;
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

              } else { // error data
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[0]);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Number
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  let normal_compass_direction_angle_text = compass_direction_angle.toString().padStart(3, '0');
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);
                  // Compass Images
                  let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                  let compass_direction_index = parseInt(compass_direction_angle_img/45);
                  if (compass_direction_index > 7) compass_direction_index = 0;
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

                } else { // error data
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[0]);

                }

              }); // Listener end

            };
            //#endregion

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecCircle) {
                    let animDelay = 0;
                    let animRepeat = 1000/12;
                    normal_timerUpdateSecCircle = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                updateWorldTime();
                setTimeout(() => {
                  if (worldClock) {
                    worldClock.uninit();
                    worldClock.init();
                  };
                }, 500);
                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();
                if (normal_timerUpdateSecCircle) {
                  timer.stopTimer(normal_timerUpdateSecCircle);
                  normal_timerUpdateSecCircle = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                worldClock.uninit();
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}