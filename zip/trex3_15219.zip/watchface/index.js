/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_hour_imagecombo2 = '';
		let normal_second_imagecombo3 = '';
		let normal_minute_imagecombo4 = '';
		let normal_img5 = '';
		let timeInterval;
		let normal_ampm24_imageset6 = '';
		let normal_ampm24_imageset6_array = ['0024.png','0025.png','0026.png'];
		let normal_img8 = '';
		let normal_heart_rate_imageset9 = '';
		let normal_heart_current_imagecombo10 = '';
		let normal_img12 = '';
		let normal_img13 = '';
		let normal_steps_imagecombo14 = '';
		let normal_steps_imageset15 = '';
		let normal_img16 = '';
		let normal_img18 = '';
		let normal_calories_imagecombo19 = '';
		let normal_img21 = '';
		let normal_distance_imagecombo22 = '';
		let normal_battery_imageset24 = '';
		let normal_img25 = '';
		let normal_img26 = '';
		let normal_weather_imageset28 = '';
		let normal_temperature_current_imagecombo29 = '';
		let normal_img31 = '';
		let normal_sunrise_text32 = '';
		let normal_img33 = '';
		let normal_sunset_text34 = '';
		let normal_user_nickname_text36 = '';
		let idle_img39 = '';
		let idle_hour_imagecombo41 = '';
		let idle_minute_imagecombo42 = '';
		let idle_img43 = '';
		let idle_ampm24_imageset44 = '';
		let idle_ampm24_imageset44_array = ['0024.png','0025.png','0026.png'];
		let idle_img46 = '';
		let idle_heart_rate_imageset47 = '';
		let idle_heart_current_imagecombo48 = '';
		let idle_img50 = '';
		let idle_img51 = '';
		let idle_steps_imagecombo52 = '';
		let idle_steps_imageset53 = '';
		let idle_img54 = '';
		let idle_img56 = '';
		let idle_calories_imagecombo57 = '';
		let idle_img59 = '';
		let idle_distance_imagecombo60 = '';
		let idle_battery_imageset62 = '';
		let idle_img63 = '';
		let idle_img64 = '';
		let idle_weather_imageset66 = '';
		let idle_temperature_current_imagecombo67 = '';
		let idle_img69 = '';
		let idle_sunrise_text70 = '';
		let idle_img71 = '';
		let idle_sunset_text72 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo2 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 179,
					hour_startY: 20,
					hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.RIGHT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo3 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 308,
					second_startY: 42,
					second_array: ["0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo4 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 248,
					minute_startY: 20,
					minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 137,
					y: 34,
					w: 26,
					h: 20,
					src: '0023.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_ampm24_imageset6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 138,
					y: 35,
					w: 138,
					h: 35,
					src: '0026.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_img8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 236,
					y: 15,
					w: 11,
					h: 57,
					src: '0027.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_rate_imageset9 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 233,
					y: 190,
					image_array: ["0028.png","0029.png","0030.png"],
					image_length: 3,
					type: hmUI.data_type.HEART,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo10 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 163,
					y: 216,
					font_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
					padding: true,
					h_space: 0,
					invalid_image: '0041.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 174,
					y: 192,
					w: 25,
					h: 23,
					src: '0042.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 159,
					y: 248,
					w: 30,
					h: 30,
					src: '0043.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo14 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 202,
					y: 250,
					font_array: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
					padding: true,
					h_space: 0,
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imageset15 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 27,
					y: 206,
					image_array: ["0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png"],
					image_length: 9,
					type: hmUI.data_type.STEP,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 3,
					y: 246,
					w: 45,
					h: 57,
					src: '0063.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img18 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 102,
					y: 202,
					w: 27,
					h: 27,
					src: '0064.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo19 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 88,
					y: 252,
					font_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img21 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 354,
					y: 204,
					w: 18,
					h: 25,
					src: '0075.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo22 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 339,
					y: 253,
					font_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
					padding: false,
					h_space: 0,
					dot_image: '0076.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imageset24 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 290,
					y: 205,
					image_array: ["0077.png","0078.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png"],
					image_length: 9,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 430,
					y: 254,
					w: 38,
					h: 54,
					src: '0085.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img26 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 153,
					y: 273,
					w: 175,
					h: 175,
					src: '0086.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset28 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 213,
					y: 305,
					image_array: ["0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0094.png","0101.png","0095.png","0102.png","0102.png","0095.png","0103.png","0104.png","0095.png","0105.png","0106.png","0107.png","0108.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo29 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 214,
					y: 375,
					font_array: ["0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0120.png"],
					unit_tc: ["0120.png"],
					unit_en: ["0120.png"],
					negative_image: ["0119.png"],
					invalid_image: ["0121.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img31 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 151,
					y: 109,
					w: 28,
					h: 21,
					src: '0122.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sunrise_text32 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 183,
					y: 112,
					w: 52,
					h: 18,
					color: 0xA8A8A8,
					text_size: 18,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Roboto-Medium.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img33 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 250,
					y: 109,
					w: 28,
					h: 21,
					src: '0123.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sunset_text34 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 280,
					y: 112,
					w: 57,
					h: 18,
					color: 0xA3A3A3,
					text_size: 18,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Roboto-Medium.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_user_nickname_text36 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 145,
					y: 438,
					w: 188,
					h: 20,
					color: 0xB7B8BD,
					text_size: 20,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/nebula-regular-webfont.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img39 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0124.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_imagecombo41 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 179,
					hour_startY: 20,
					hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.RIGHT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo42 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 248,
					minute_startY: 20,
					minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img43 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 137,
					y: 34,
					w: 26,
					h: 20,
					src: '0023.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_ampm24_imageset44 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 138,
					y: 35,
					w: 138,
					h: 35,
					src: '0026.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_img46 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 236,
					y: 15,
					w: 11,
					h: 57,
					src: '0027.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_heart_rate_imageset47 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 233,
					y: 190,
					image_array: ["0028.png","0029.png","0030.png"],
					image_length: 3,
					type: hmUI.data_type.HEART,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_heart_current_imagecombo48 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 163,
					y: 216,
					font_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
					padding: true,
					h_space: 0,
					invalid_image: '0041.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img50 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 174,
					y: 192,
					w: 25,
					h: 23,
					src: '0042.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img51 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 159,
					y: 248,
					w: 30,
					h: 30,
					src: '0043.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_steps_imagecombo52 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 202,
					y: 250,
					font_array: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
					padding: true,
					h_space: 0,
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_steps_imageset53 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 27,
					y: 206,
					image_array: ["0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png"],
					image_length: 9,
					type: hmUI.data_type.STEP,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img54 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 3,
					y: 246,
					w: 45,
					h: 57,
					src: '0063.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img56 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 102,
					y: 202,
					w: 27,
					h: 27,
					src: '0064.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_calories_imagecombo57 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 88,
					y: 252,
					font_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img59 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 354,
					y: 204,
					w: 18,
					h: 25,
					src: '0075.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_distance_imagecombo60 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 339,
					y: 253,
					font_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png"],
					padding: false,
					h_space: 0,
					dot_image: '0076.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_battery_imageset62 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 290,
					y: 205,
					image_array: ["0077.png","0078.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png"],
					image_length: 9,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img63 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 430,
					y: 254,
					w: 38,
					h: 54,
					src: '0085.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img64 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 153,
					y: 273,
					w: 175,
					h: 175,
					src: '0086.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_weather_imageset66 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 213,
					y: 305,
					image_array: ["0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0094.png","0101.png","0095.png","0102.png","0102.png","0095.png","0103.png","0104.png","0095.png","0105.png","0106.png","0107.png","0108.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_temperature_current_imagecombo67 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 214,
					y: 375,
					font_array: ["0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0120.png"],
					unit_tc: ["0120.png"],
					unit_en: ["0120.png"],
					negative_image: ["0119.png"],
					invalid_image: ["0121.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img69 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 151,
					y: 109,
					w: 28,
					h: 21,
					src: '0125.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_sunrise_text70 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 183,
					y: 112,
					w: 52,
					h: 18,
					color: 0x6D7ACC,
					text_size: 18,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Roboto-Medium.ttf',
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img71 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 250,
					y: 109,
					w: 28,
					h: 21,
					src: '0126.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_sunset_text72 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 280,
					y: 112,
					w: 57,
					h: 18,
					color: 0x6D7ACC,
					text_size: 18,
					align_h: hmUI.align.CENTER_H,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Roboto-Medium.ttf',
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateTime() {
					normal_ampm24_imageset6.setProperty(hmUI.prop.MORE, {
						src: normal_ampm24_imageset6_array[(hmSetting.getTimeFormat() == 0 ? (timeSensor.hour >= 0 && timeSensor.hour < 12 ? 0 : 1) : 2)]
					})
					idle_ampm24_imageset44.setProperty(hmUI.prop.MORE, {
						src: idle_ampm24_imageset44_array[(hmSetting.getTimeFormat() == 0 ? (timeSensor.hour >= 0 && timeSensor.hour < 12 ? 0 : 1) : 2)]
					})
				}

				function updateWeather() {
					let tideData = weatherSensor.getForecastWeather().tideData;
					normal_sunrise_text32.setProperty(hmUI.prop.TEXT, tideData.data[0].sunrise.hour.toString().padStart(2, '0') + ':' + tideData.data[0].sunrise.minute.toString().padStart(2, '0'));
					normal_sunset_text34.setProperty(hmUI.prop.TEXT, tideData.data[0].sunset.hour.toString().padStart(2, '0') + ':' + tideData.data[0].sunset.minute.toString().padStart(2, '0'));
					idle_sunrise_text70.setProperty(hmUI.prop.TEXT, tideData.data[0].sunrise.hour.toString().padStart(2, '0') + ':' + tideData.data[0].sunrise.minute.toString().padStart(2, '0'));
					idle_sunset_text72.setProperty(hmUI.prop.TEXT, tideData.data[0].sunset.hour.toString().padStart(2, '0') + ':' + tideData.data[0].sunset.minute.toString().padStart(2, '0'));
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				weatherSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateWeather();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						updateWeather();
						normal_user_nickname_text36.setProperty(hmUI.prop.TEXT, hmSetting.getUserData().nickName.toString());
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}