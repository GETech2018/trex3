﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_altimeter_icon_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_step_icon_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_battery_text_text_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let image_top_img = ''
        let normal_cal_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_walking_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''
        let Button_9 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Rajdhani SemiBold.ttf; FontSize: 40
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 482,
              h: 61,
              text_size: 40,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Rajdhani SemiBold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main_bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 285,
              y: 428,
              src: 'icon_graph=hpa.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 422,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 168,
              y: 428,
              src: 'icon_graph=bar.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 374,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 253,
              y: 349,
              src: 'icon_graph=callor.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 374,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'digits_small=km.png',
              unit_tc: 'digits_small=km.png',
              unit_en: 'digits_small=km.png',
              imperial_unit_sc: 'digits_small=ml.png',
              imperial_unit_tc: 'digits_small=ml.png',
              imperial_unit_en: 'digits_small=ml.png',
              dot_image: 'digits_small=dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 145,
              y: 349,
              src: 'icon_graph=dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 344,
              y: 300,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 315,
              y: 302,
              src: 'icon_graph=droplet.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 235,
              y: 300,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 204,
              y: 302,
              src: 'icon_graph=heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 300,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 300,
              src: 'icon_graph=PAI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 47,
              y: 194,
              src: 'icon_graph=bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 396,
              y: 194,
              src: 'icon_graph=alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 258,
              y: 139,
              src: 'icon_graph=goal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 307,
              // start_y: 130,
              // color: 0xFFFFFFFF,
              // lenght: 97,
              // line_width: 30,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 286,
              y: 84,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 254,
              y: 84,
              src: 'icon_graph=steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 110,
              y: 135,
              week_en: ["days_week=1.png","days_week=2.png","days_week=3.png","days_week=4.png","days_week=5.png","days_week=6.png","days_week=7.png"],
              week_tc: ["days_week=1.png","days_week=2.png","days_week=3.png","days_week=4.png","days_week=5.png","days_week=6.png","days_week=7.png"],
              week_sc: ["days_week=1.png","days_week=2.png","days_week=3.png","days_week=4.png","days_week=5.png","days_week=6.png","days_week=7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 184,
              day_startY: 135,
              day_sc_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              day_tc_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              day_en_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 78,
              y: 135,
              src: 'icon_graph=cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 98,
              y: 76,
              image_array: ["icon_weather=_0.png","icon_weather=_1.png","icon_weather=_2.png","icon_weather=_3.png","icon_weather=_4.png","icon_weather=_5.png","icon_weather=_6.png","icon_weather=_7.png","icon_weather=_8.png","icon_weather=_9.png","icon_weather=_10.png","icon_weather=_11.png","icon_weather=_12.png","icon_weather=_13.png","icon_weather=_14.png","icon_weather=_15.png","icon_weather=_16.png","icon_weather=_17.png","icon_weather=_18.png","icon_weather=_19.png","icon_weather=_20.png","icon_weather=_21.png","icon_weather=_22.png","icon_weather=_23.png","icon_weather=_24.png","icon_weather=_25.png","icon_weather=_26.png","icon_weather=_27.png","icon_weather=_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 160,
              y: 72,
              w: 150,
              h: 50,
              text_size: 40,
              char_space: 0,
              font: 'fonts/Rajdhani SemiBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 32,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'digits_small=procent.png',
              unit_tc: 'digits_small=procent.png',
              unit_en: 'digits_small=procent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'seconds.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 40,
              am_y: 249,
              am_sc_path: 'icon_graph=AM.png',
              am_en_path: 'icon_graph=AM.png',
              pm_x: 40,
              pm_y: 249,
              pm_sc_path: 'icon_graph=PM.png',
              pm_en_path: 'icon_graph=PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 85,
              hour_startY: 188,
              hour_array: ["digits_big=0.png","digits_big=1.png","digits_big=2.png","digits_big=3.png","digits_big=4.png","digits_big=5.png","digits_big=6.png","digits_big=7.png","digits_big=8.png","digits_big=9.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              // alpha: 100,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 255,
              minute_startY: 188,
              minute_array: ["digits_big=0.png","digits_big=1.png","digits_big=2.png","digits_big=3.png","digits_big=4.png","digits_big=5.png","digits_big=6.png","digits_big=7.png","digits_big=8.png","digits_big=9.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              // alpha: 100,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 399,
              second_startY: 249,
              second_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              second_zero: 1,
              second_space: -2,
              second_angle: 0,
              second_follow: 0,
              // alpha: 100,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time.setAlpha(100);

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 221,
              y: 186,
              src: 'digits_big=separation.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 360,
              font_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 203,
              y: 58,
              week_en: ["days_week=1.png","days_week=2.png","days_week=3.png","days_week=4.png","days_week=5.png","days_week=6.png","days_week=7.png"],
              week_tc: ["days_week=1.png","days_week=2.png","days_week=3.png","days_week=4.png","days_week=5.png","days_week=6.png","days_week=7.png"],
              week_sc: ["days_week=1.png","days_week=2.png","days_week=3.png","days_week=4.png","days_week=5.png","days_week=6.png","days_week=7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 267,
              year_startY: 113,
              year_sc_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              year_tc_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              year_en_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 201,
              month_startY: 113,
              month_sc_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              month_tc_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              month_en_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              month_zero: 1,
              month_space: 5,
              month_unit_sc: 'digits_small=dot.png',
              month_unit_tc: 'digits_small=dot.png',
              month_unit_en: 'digits_small=dot.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 137,
              day_startY: 113,
              day_sc_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              day_tc_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              day_en_array: ["digits_small=0.png","digits_small=1.png","digits_small=2.png","digits_small=3.png","digits_small=4.png","digits_small=5.png","digits_small=6.png","digits_small=7.png","digits_small=8.png","digits_small=9.png"],
              day_zero: 1,
              day_space: 5,
              day_unit_sc: 'digits_small=dot.png',
              day_unit_tc: 'digits_small=dot.png',
              day_unit_en: 'digits_small=dot.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 85,
              hour_startY: 188,
              hour_array: ["digits_big=0.png","digits_big=1.png","digits_big=2.png","digits_big=3.png","digits_big=4.png","digits_big=5.png","digits_big=6.png","digits_big=7.png","digits_big=8.png","digits_big=9.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_unit_sc: 'digits_big=separation.png',
              hour_unit_tc: 'digits_big=separation.png',
              hour_unit_en: 'digits_big=separation.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 255,
              minute_startY: 188,
              minute_array: ["digits_big=0.png","digits_big=1.png","digits_big=2.png","digits_big=3.png","digits_big=4.png","digits_big=5.png","digits_big=6.png","digits_big=7.png","digits_big=8.png","digits_big=9.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 300,
              y: 123,
              src: 'indicator.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 75,
              y: 345,
              w: 160,
              h: 65,
              src: 'trans.png',
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 150,
              y: 415,
              w: 190,
              h: 40,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_walking_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 125,
              w: 175,
              h: 40,
              src: 'trans.png',
              type: hmUI.data_type.WALKING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 306,
              y: 285,
              w: 133,
              h: 60,
              src: 'trans.png',
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 141,
              y: 28,
              w: 198,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trans.png',
              normal_src: 'trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 85,
              y: 75,
              w: 150,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trans.png',
              normal_src: 'trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 55,
              y: 125,
              w: 180,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trans.png',
              normal_src: 'trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 250,
              y: 75,
              w: 150,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trans.png',
              normal_src: 'trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 85,
              y: 185,
              w: 135,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trans.png',
              normal_src: 'trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 260,
              y: 185,
              w: 135,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trans.png',
              normal_src: 'trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 41,
              y: 284,
              w: 144,
              h: 61,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trans.png',
              normal_src: 'trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PAI_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 187,
              y: 285,
              w: 117,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trans.png',
              normal_src: 'trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_9 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 245,
              y: 345,
              w: 125,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'trans.png',
              normal_src: 'trans.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityWeekShowScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 307;
                  let start_y_normal_step = 130;
                  let lenght_ls_normal_step = 97;
                  let line_width_ls_normal_step = 30;
                  let color_ls_normal_step = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}