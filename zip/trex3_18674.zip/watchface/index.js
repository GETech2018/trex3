﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_image_progress_img_level = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_altitude_target_text_img = ''
        let normal_city_name_text = ''
        let normal_battery_image_progress_img_level = ''
        let normal_image_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_time_pointer_hour = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_wind_text_separator_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Goldman-Regular.ttf; FontSize: 26; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 31,
              h: 31,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Goldman-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'BACKGROUND_02.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 255,
              y: 62,
              image_array: ["MOON155_01.png","MOON155_02.png","MOON155_03.png","MOON155_04.png","MOON155_05.png","MOON155_06.png","MOON155_07.png","MOON155_08.png","MOON155_09.png","MOON155_10.png","MOON155_11.png","MOON155_12.png","MOON155_13.png","MOON155_14.png","MOON155_15.png","MOON155_16.png","MOON155_17.png","MOON155_18.png","MOON155_19.png","MOON155_20.png","MOON155_21.png","MOON155_22.png","MOON155_23.png","MOON155_24.png","MOON155_25.png","MOON155_26.png","MOON155_27.png","MOON155_28.png","MOON155_29.png","MOON155_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 52,
              y: 52,
              image_array: ["Sunsine_01.png","Sunsine_02.png","Sunsine_03.png","Sunsine_04.png","Sunsine_05.png","Sunsine_06.png","Sunsine_07.png","Sunsine_08.png","Sunsine_09.png","Sunsine_10.png","Sunsine_11.png","Sunsine_12.png","Sunsine_13.png","Sunsine_14.png","Sunsine_15.png","Sunsine_16.png","Sunsine_17.png","Sunsine_18.png","Sunsine_19.png","Sunsine_20.png","Sunsine_21.png"],
              image_length: 21,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 51,
              y: 200,
              font_array: ["goldm24_001.png","goldm24_002.png","goldm24_003.png","goldm24_004.png","goldm24_005.png","goldm24_006.png","goldm24_007.png","goldm24_008.png","goldm24_009.png","goldm24_010.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'NO_DATA.png',
              dot_image: 'separ24_02.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 350,
              y: 200,
              font_array: ["goldm24_001.png","goldm24_002.png","goldm24_003.png","goldm24_004.png","goldm24_005.png","goldm24_006.png","goldm24_007.png","goldm24_008.png","goldm24_009.png","goldm24_010.png"],
              padding: false,
              h_space: -1,
              invalid_image: 'NO_DATA.png',
              dot_image: 'separ24_02.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 280,
              font_array: ["goldm24_001.png","goldm24_002.png","goldm24_003.png","goldm24_004.png","goldm24_005.png","goldm24_006.png","goldm24_007.png","goldm24_008.png","goldm24_009.png","goldm24_010.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'separ24_01.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 2,
              y: -2,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 332,
              y: 280,
              font_array: ["goldm24_001.png","goldm24_002.png","goldm24_003.png","goldm24_004.png","goldm24_005.png","goldm24_006.png","goldm24_007.png","goldm24_008.png","goldm24_009.png","goldm24_010.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'm.png',
              unit_tc: 'm.png',
              unit_en: 'm.png',
              negative_image: 'GOLDMAN27_POM.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 110,
              y: 308,
              w: 260,
              h: 33,
              text_size: 26,
              char_space: 0,
              font: 'fonts/Goldman-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 119,
              y: 259,
              image_array: ["Batt_001.png","Batt_002.png","Batt_003.png","Batt_004.png","Batt_005.png","Batt_006.png","Batt_007.png","Batt_008.png","Batt_009.png","Batt_010.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'PICTURE.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hour24.png',
              // center_x: 240,
              // center_y: 240,
              // x: 27,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
              // format24h: true,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 27,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'Hour24.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'min24.png',
              // center_x: 240,
              // center_y: 240,
              // x: 27,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 27,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'min24.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'SEC_15X231.png',
              // center_x: 240,
              // center_y: 240,
              // x: 15,
              // y: 231,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 15,
              pos_y: 240 - 231,
              center_x: 240,
              center_y: 240,
              src: 'SEC_15X231.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hOUR_35X226.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 34,
              hour_posY: 215,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 82,
              y: 81,
              image_array: ["WIND_01.png","WIND_02.png","WIND_03.png","WIND_04.png","WIND_05.png","WIND_06.png","WIND_07.png","WIND_08.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 245,
              font_array: ["GOLDM30sha_01.png","GOLDM30sha_02.png","GOLDM30sha_03.png","GOLDM30sha_04.png","GOLDM30sha_05.png","GOLDM30sha_06.png","GOLDM30sha_07.png","GOLDM30sha_08.png","GOLDM30sha_09.png","GOLDM30sha_10.png"],
              padding: false,
              h_space: -6,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 236,
              y: 242,
              src: 'BFT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 248,
              month_startY: 372,
              month_sc_array: ["GOLDM30sha_01.png","GOLDM30sha_02.png","GOLDM30sha_03.png","GOLDM30sha_04.png","GOLDM30sha_05.png","GOLDM30sha_06.png","GOLDM30sha_07.png","GOLDM30sha_08.png","GOLDM30sha_09.png","GOLDM30sha_10.png"],
              month_tc_array: ["GOLDM30sha_01.png","GOLDM30sha_02.png","GOLDM30sha_03.png","GOLDM30sha_04.png","GOLDM30sha_05.png","GOLDM30sha_06.png","GOLDM30sha_07.png","GOLDM30sha_08.png","GOLDM30sha_09.png","GOLDM30sha_10.png"],
              month_en_array: ["GOLDM30sha_01.png","GOLDM30sha_02.png","GOLDM30sha_03.png","GOLDM30sha_04.png","GOLDM30sha_05.png","GOLDM30sha_06.png","GOLDM30sha_07.png","GOLDM30sha_08.png","GOLDM30sha_09.png","GOLDM30sha_10.png"],
              month_zero: 1,
              month_space: -2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 191,
              day_startY: 372,
              day_sc_array: ["GOLDM30sha_01.png","GOLDM30sha_02.png","GOLDM30sha_03.png","GOLDM30sha_04.png","GOLDM30sha_05.png","GOLDM30sha_06.png","GOLDM30sha_07.png","GOLDM30sha_08.png","GOLDM30sha_09.png","GOLDM30sha_10.png"],
              day_tc_array: ["GOLDM30sha_01.png","GOLDM30sha_02.png","GOLDM30sha_03.png","GOLDM30sha_04.png","GOLDM30sha_05.png","GOLDM30sha_06.png","GOLDM30sha_07.png","GOLDM30sha_08.png","GOLDM30sha_09.png","GOLDM30sha_10.png"],
              day_en_array: ["GOLDM30sha_01.png","GOLDM30sha_02.png","GOLDM30sha_03.png","GOLDM30sha_04.png","GOLDM30sha_05.png","GOLDM30sha_06.png","GOLDM30sha_07.png","GOLDM30sha_08.png","GOLDM30sha_09.png","GOLDM30sha_10.png"],
              day_zero: 1,
              day_space: -2,
              day_unit_sc: 'separ24_03.png',
              day_unit_tc: 'separ24_03.png',
              day_unit_en: 'separ24_03.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 163,
              hour_startY: 342,
              hour_array: ["GOLDM30sha_01.png","GOLDM30sha_02.png","GOLDM30sha_03.png","GOLDM30sha_04.png","GOLDM30sha_05.png","GOLDM30sha_06.png","GOLDM30sha_07.png","GOLDM30sha_08.png","GOLDM30sha_09.png","GOLDM30sha_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'DOUBLE.png',
              hour_unit_tc: 'DOUBLE.png',
              hour_unit_en: 'DOUBLE.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["GOLDM30sha_01.png","GOLDM30sha_02.png","GOLDM30sha_03.png","GOLDM30sha_04.png","GOLDM30sha_05.png","GOLDM30sha_06.png","GOLDM30sha_07.png","GOLDM30sha_08.png","GOLDM30sha_09.png","GOLDM30sha_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: 'DOUBLE.png',
              minute_unit_tc: 'DOUBLE.png',
              minute_unit_en: 'DOUBLE.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 0,
              second_startY: 0,
              second_array: ["GOLDM30sha_01.png","GOLDM30sha_02.png","GOLDM30sha_03.png","GOLDM30sha_04.png","GOLDM30sha_05.png","GOLDM30sha_06.png","GOLDM30sha_07.png","GOLDM30sha_08.png","GOLDM30sha_09.png","GOLDM30sha_10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 190,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'P_VISIBLE.png',
              normal_src: 'P_UNVISIBLE.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'SportDiveCompassSetTargetScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 279,
              y: 80,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'P_VISIBLE.png',
              normal_src: 'P_UNVISIBLE.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 108,
              y: 80,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'P_VISIBLE.png',
              normal_src: 'P_UNVISIBLE.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'OfflineMapScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'BaroAltimeterScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 146,
              y: 312,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'P_VISIBLE.png',
              normal_src: 'P_UNVISIBLE.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 265,
              y: 312,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'P_VISIBLE.png',
              normal_src: 'P_UNVISIBLE.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 209,
              y: 383,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'P_VISIBLE.png',
              normal_src: 'P_UNVISIBLE.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              if (updateMinute) { // Hour Pointer
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/24 + (normal_fullAngle_hour/24)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) { // Minute Pointer
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              // Second Pointer
              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}