/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_calories_imagecombo3 = '';
		let normal_img4 = '';
		let normal_calories_imageset5 = '';
		let normal_steps_imagecombo7 = '';
		let normal_img8 = '';
		let normal_steps_imageset9 = '';
		let normal_heart_current_imagecombo11 = '';
		let normal_img12 = '';
		let normal_heart_rate_imageset13 = '';
		let normal_img15 = '';
		let normal_distance_imagecombo16 = '';
		let normal_battery_imagecombo18 = '';
		let normal_battery_rotary19 = '';
		let normal_hour_imagecombo21 = '';
		let normal_minute_imagecombo22 = '';
		let normal_img23 = '';
		let normal_second_imagecombo24 = '';
		let normal_temperature_current_imagecombo26 = '';
		let normal_date_imagecombo28 = '';
		let normal_month_imageset29 = '';
		let normal_week_imageset30 = '';
		let idle_img33 = '';
		let idle_img34 = '';
		let idle_calories_imagecombo36 = '';
		let idle_img37 = '';
		let idle_calories_imageset38 = '';
		let idle_steps_imagecombo40 = '';
		let idle_img41 = '';
		let idle_steps_imageset42 = '';
		let idle_heart_current_imagecombo44 = '';
		let idle_heart_rate_imageset45 = '';
		let idle_img46 = '';
		let idle_img48 = '';
		let idle_distance_imagecombo49 = '';
		let idle_battery_imagecombo51 = '';
		let idle_battery_rotary52 = '';
		let idle_hour_imagecombo54 = '';
		let idle_minute_imagecombo55 = '';
		let idle_img56 = '';
		let idle_temperature_current_imagecombo58 = '';
		let idle_date_imagecombo60 = '';
		let idle_month_imageset61 = '';
		let idle_week_imageset62 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo3 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 105,
					y: 337,
					font_array: ["0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
					padding: true,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 64,
					y: 337,
					w: 27,
					h: 27,
					src: '0014.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imageset5 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 6,
					y: 192,
					image_array: ["0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
					image_length: 9,
					type: hmUI.data_type.CAL,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo7 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 297,
					y: 337,
					font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
					padding: true,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 259,
					y: 321,
					w: 28,
					h: 46,
					src: '0034.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imageset9 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 317,
					y: 189,
					image_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
					image_length: 9,
					type: hmUI.data_type.STEP,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo11 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 258,
					y: 383,
					font_array: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
					padding: true,
					h_space: 0,
					invalid_image: '0054.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0055.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_rate_imageset13 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 332,
					y: 378,
					image_array: ["0056.png","0057.png","0057.png","0057.png","0058.png","0058.png"],
					image_length: 6,
					type: hmUI.data_type.HEART,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 89,
					y: 384,
					w: 24,
					h: 34,
					src: '0059.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo16 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 120,
					y: 384,
					font_array: ["0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
					padding: false,
					h_space: 0,
					dot_image: '0060.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo18 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 214,
					y: 271,
					font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
					padding: false,
					h_space: 0,
					unit_sc: '0071.png',
					unit_tc: '0071.png',
					unit_en: '0071.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_rotary19 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0072.png',
					center_x: 241,
					center_y: 316,
					x: 20,
					y: 98,
					start_angle: -58,
					end_angle: 58,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo21 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 117,
					hour_startY: 144,
					hour_array: ["0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.RIGHT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo22 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 250,
					minute_startY: 144,
					minute_array: ["0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img23 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 226,
					y: 137,
					w: 28,
					h: 83,
					src: '0083.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo24 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 341,
					second_startY: 222,
					second_array: ["0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.RIGHT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo26 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 97,
					y: 103,
					font_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0105.png"],
					unit_tc: ["0105.png"],
					unit_en: ["0105.png"],
					negative_image: ["0104.png"],
					invalid_image: ["0104.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo28 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 181,
					day_startY: 103,
					day_sc_array: ["0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png"],
					day_tc_array: ["0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png"],
					day_en_array: ["0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.RIGHT,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset29 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 229,
					month_startY: 103,
					month_sc_array: ["0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
					month_tc_array: ["0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
					month_en_array: ["0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset30 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 295,
					y: 103,
					week_en: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png"],
					week_tc: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png"],
					week_sc: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img33 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0135.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img34 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0136.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_calories_imagecombo36 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 105,
					y: 337,
					font_array: ["0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
					padding: true,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img37 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 64,
					y: 337,
					w: 27,
					h: 27,
					src: '0014.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_calories_imageset38 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 6,
					y: 192,
					image_array: ["0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png"],
					image_length: 9,
					type: hmUI.data_type.CAL,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_steps_imagecombo40 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 297,
					y: 337,
					font_array: ["0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png"],
					padding: true,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img41 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 259,
					y: 321,
					w: 28,
					h: 46,
					src: '0034.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_steps_imageset42 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 317,
					y: 189,
					image_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
					image_length: 9,
					type: hmUI.data_type.STEP,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_heart_current_imagecombo44 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 258,
					y: 383,
					font_array: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png"],
					padding: true,
					h_space: 0,
					invalid_image: '0054.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_heart_rate_imageset45 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 332,
					y: 378,
					image_array: ["0056.png","0057.png","0057.png","0057.png","0058.png","0058.png"],
					image_length: 6,
					type: hmUI.data_type.HEART,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img46 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -3,
					y: -3,
					w: 486,
					h: 486,
					src: '0146.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img48 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 89,
					y: 384,
					w: 24,
					h: 34,
					src: '0059.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_distance_imagecombo49 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 120,
					y: 384,
					font_array: ["0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
					padding: false,
					h_space: 0,
					dot_image: '0060.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_battery_imagecombo51 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 214,
					y: 271,
					font_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png"],
					padding: false,
					h_space: 0,
					unit_sc: '0071.png',
					unit_tc: '0071.png',
					unit_en: '0071.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_battery_rotary52 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0072.png',
					center_x: 241,
					center_y: 316,
					x: 20,
					y: 98,
					start_angle: -58,
					end_angle: 58,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_imagecombo54 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 117,
					hour_startY: 144,
					hour_array: ["0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.RIGHT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo55 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 250,
					minute_startY: 144,
					minute_array: ["0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img56 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 226,
					y: 137,
					w: 28,
					h: 83,
					src: '0083.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_temperature_current_imagecombo58 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 97,
					y: 103,
					font_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0105.png"],
					unit_tc: ["0105.png"],
					unit_en: ["0105.png"],
					negative_image: ["0104.png"],
					invalid_image: ["0104.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_imagecombo60 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 181,
					day_startY: 103,
					day_sc_array: ["0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png"],
					day_tc_array: ["0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png"],
					day_en_array: ["0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.RIGHT,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_month_imageset61 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 229,
					month_startY: 103,
					month_sc_array: ["0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
					month_tc_array: ["0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
					month_en_array: ["0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_week_imageset62 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 295,
					y: 103,
					week_en: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png"],
					week_tc: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png"],
					week_sc: ["0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png"],
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}