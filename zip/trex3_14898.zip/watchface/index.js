﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_uvi_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_week_img = ''
        let normal_humidity_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'pozadi.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 17,
              font_array: ["male_0.png","male_1.png","male_2.png","male_3.png","male_4.png","male_5.png","male_6.png","male_7.png","male_8.png","male_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 241,
              month_startY: 53,
              month_sc_array: ["male_0.png","male_1.png","male_2.png","male_3.png","male_4.png","male_5.png","male_6.png","male_7.png","male_8.png","male_9.png"],
              month_tc_array: ["male_0.png","male_1.png","male_2.png","male_3.png","male_4.png","male_5.png","male_6.png","male_7.png","male_8.png","male_9.png"],
              month_en_array: ["male_0.png","male_1.png","male_2.png","male_3.png","male_4.png","male_5.png","male_6.png","male_7.png","male_8.png","male_9.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 274,
              y: 49,
              src: 'tecka.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 200,
              day_startY: 53,
              day_sc_array: ["male_0.png","male_1.png","male_2.png","male_3.png","male_4.png","male_5.png","male_6.png","male_7.png","male_8.png","male_9.png"],
              day_tc_array: ["male_0.png","male_1.png","male_2.png","male_3.png","male_4.png","male_5.png","male_6.png","male_7.png","male_8.png","male_9.png"],
              day_en_array: ["male_0.png","male_1.png","male_2.png","male_3.png","male_4.png","male_5.png","male_6.png","male_7.png","male_8.png","male_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 234,
              y: 49,
              src: 'tecka.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 297,
              year_startY: 53,
              year_sc_array: ["male_0.png","male_1.png","male_2.png","male_3.png","male_4.png","male_5.png","male_6.png","male_7.png","male_8.png","male_9.png"],
              year_tc_array: ["male_0.png","male_1.png","male_2.png","male_3.png","male_4.png","male_5.png","male_6.png","male_7.png","male_8.png","male_9.png"],
              year_en_array: ["male_0.png","male_1.png","male_2.png","male_3.png","male_4.png","male_5.png","male_6.png","male_7.png","male_8.png","male_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 92,
              y: 53,
              week_en: ["den_1.png","den_2.png","den_3.png","den_4.png","den_5.png","den_6.png","den_7.png"],
              week_tc: ["den_1.png","den_2.png","den_3.png","den_4.png","den_5.png","den_6.png","den_7.png"],
              week_sc: ["den_1.png","den_2.png","den_3.png","den_4.png","den_5.png","den_6.png","den_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 132,
              font_array: ["male_0.png","male_1.png","male_2.png","male_3.png","male_4.png","male_5.png","male_6.png","male_7.png","male_8.png","male_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'procenta.png',
              unit_tc: 'procenta.png',
              unit_en: 'procenta.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 73,
              y: 91,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 293,
              y: 95,
              font_array: ["male_0.png","male_1.png","male_2.png","male_3.png","male_4.png","male_5.png","male_6.png","male_7.png","male_8.png","male_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'stupne.png',
              unit_tc: 'stupne.png',
              unit_en: 'stupne.png',
              negative_image: 'minus.png',
              invalid_image: 'chyba.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 95,
              font_array: ["male_0.png","male_1.png","male_2.png","male_3.png","male_4.png","male_5.png","male_6.png","male_7.png","male_8.png","male_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'stupne.png',
              unit_tc: 'stupne.png',
              unit_en: 'stupne.png',
              negative_image: 'minus.png',
              invalid_image: 'chyba.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 193,
              y: 132,
              font_array: ["male_0.png","male_1.png","male_2.png","male_3.png","male_4.png","male_5.png","male_6.png","male_7.png","male_8.png","male_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'stupne.png',
              unit_tc: 'stupne.png',
              unit_en: 'stupne.png',
              negative_image: 'minus.png',
              invalid_image: 'chyba.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 306,
              y: 416,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 264,
              y: 416,
              src: 'alarm_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 44,
              y: 233,
              font_array: ["vterina_0.png","vterina_1.png","vterina_2.png","vterina_3.png","vterina_4.png","vterina_5.png","vterina_6.png","vterina_7.png","vterina_8.png","vterina_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 363,
              y: 365,
              font_array: ["male_0.png","male_1.png","male_2.png","male_3.png","male_4.png","male_5.png","male_6.png","male_7.png","male_8.png","male_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'procenta.png',
              unit_tc: 'procenta.png',
              unit_en: 'procenta.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 365,
              font_array: ["male_0.png","male_1.png","male_2.png","male_3.png","male_4.png","male_5.png","male_6.png","male_7.png","male_8.png","male_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'tecka_km.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 58,
              y: 365,
              font_array: ["male_0.png","male_1.png","male_2.png","male_3.png","male_4.png","male_5.png","male_6.png","male_7.png","male_8.png","male_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 153,
              y: 365,
              font_array: ["male_0.png","male_1.png","male_2.png","male_3.png","male_4.png","male_5.png","male_6.png","male_7.png","male_8.png","male_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 146,
              hour_startY: 207,
              hour_array: ["velka_0.png","velka_1.png","velka_2.png","velka_3.png","velka_4.png","velka_5.png","velka_6.png","velka_7.png","velka_8.png","velka_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 322,
              minute_startY: 207,
              minute_array: ["velka_0.png","velka_1.png","velka_2.png","velka_3.png","velka_4.png","velka_5.png","velka_6.png","velka_7.png","velka_8.png","velka_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 382,
              second_startY: 126,
              second_array: ["vterina_0.png","vterina_1.png","vterina_2.png","vterina_3.png","vterina_4.png","vterina_5.png","vterina_6.png","vterina_7.png","vterina_8.png","vterina_9.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}