﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_pai_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main_graphics.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 122,
              month_startY: 401,
              month_sc_array: ["dig_m_0.png","dig_m_1.png","dig_m_2.png","dig_m_3.png","dig_m_4.png","dig_m_5.png","dig_m_6.png","dig_m_7.png","dig_m_8.png","dig_m_9.png"],
              month_tc_array: ["dig_m_0.png","dig_m_1.png","dig_m_2.png","dig_m_3.png","dig_m_4.png","dig_m_5.png","dig_m_6.png","dig_m_7.png","dig_m_8.png","dig_m_9.png"],
              month_en_array: ["dig_m_0.png","dig_m_1.png","dig_m_2.png","dig_m_3.png","dig_m_4.png","dig_m_5.png","dig_m_6.png","dig_m_7.png","dig_m_8.png","dig_m_9.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 88,
              year_startY: 381,
              year_sc_array: ["dig_xs_0.png","dig_xs_1.png","dig_xs_2.png","dig_xs_3.png","dig_xs_4.png","dig_xs_5.png","dig_xs_6.png","dig_xs_7.png","dig_xs_8.png","dig_xs_9.png"],
              year_tc_array: ["dig_xs_0.png","dig_xs_1.png","dig_xs_2.png","dig_xs_3.png","dig_xs_4.png","dig_xs_5.png","dig_xs_6.png","dig_xs_7.png","dig_xs_8.png","dig_xs_9.png"],
              year_en_array: ["dig_xs_0.png","dig_xs_1.png","dig_xs_2.png","dig_xs_3.png","dig_xs_4.png","dig_xs_5.png","dig_xs_6.png","dig_xs_7.png","dig_xs_8.png","dig_xs_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 257,
              day_startY: 359,
              day_sc_array: ["dig_md_0.png","dig_md_1.png","dig_md_2.png","dig_md_3.png","dig_md_4.png","dig_md_5.png","dig_md_6.png","dig_md_7.png","dig_md_8.png","dig_md_9.png"],
              day_tc_array: ["dig_md_0.png","dig_md_1.png","dig_md_2.png","dig_md_3.png","dig_md_4.png","dig_md_5.png","dig_md_6.png","dig_md_7.png","dig_md_8.png","dig_md_9.png"],
              day_en_array: ["dig_md_0.png","dig_md_1.png","dig_md_2.png","dig_md_3.png","dig_md_4.png","dig_md_5.png","dig_md_6.png","dig_md_7.png","dig_md_8.png","dig_md_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 177,
              y: 359,
              week_en: ["date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png"],
              week_tc: ["date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png"],
              week_sc: ["date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 347,
              y: 329,
              font_array: ["dig_lg_0.png","dig_lg_1.png","dig_lg_2.png","dig_lg_3.png","dig_lg_4.png","dig_lg_5.png","dig_lg_6.png","dig_lg_7.png","dig_lg_8.png","dig_lg_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 408,
              y: 224,
              src: 'ic_pai.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["pai_0.png","pai_1.png","pai_2.png","pai_3.png","pai_4.png","pai_5.png","pai_6.png","pai_7.png","pai_8.png","pai_9.png"],
              image_length: 10,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 82,
              y: 329,
              font_array: ["dig_lg_0.png","dig_lg_1.png","dig_lg_2.png","dig_lg_3.png","dig_lg_4.png","dig_lg_5.png","dig_lg_6.png","dig_lg_7.png","dig_lg_8.png","dig_lg_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dig_lg_proc.png',
              unit_tc: 'dig_lg_proc.png',
              unit_en: 'dig_lg_proc.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 42,
              y: 224,
              src: 'ic_lig.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["bat_0.png","bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 131,
              font_array: ["dig_lg_0.png","dig_lg_1.png","dig_lg_2.png","dig_lg_3.png","dig_lg_4.png","dig_lg_5.png","dig_lg_6.png","dig_lg_7.png","dig_lg_8.png","dig_lg_9.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'dig_lg_kcal.png',
              unit_tc: 'dig_lg_kcal.png',
              unit_en: 'dig_lg_kcal.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 392,
              y: 140,
              src: 'Fire.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 131,
              font_array: ["dig_lg_0.png","dig_lg_1.png","dig_lg_2.png","dig_lg_3.png","dig_lg_4.png","dig_lg_5.png","dig_lg_6.png","dig_lg_7.png","dig_lg_8.png","dig_lg_9.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'dig_lg_km.png',
              unit_tc: 'dig_lg_km.png',
              unit_en: 'dig_lg_km.png',
              dot_image: 'dig_lg_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 64,
              y: 140,
              src: 'Path.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 90,
              font_array: ["dig_lg_0.png","dig_lg_1.png","dig_lg_2.png","dig_lg_3.png","dig_lg_4.png","dig_lg_5.png","dig_lg_6.png","dig_lg_7.png","dig_lg_8.png","dig_lg_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 334,
              y: 80,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'temp1.png',
              unit_tc: 'temp1.png',
              unit_en: 'temp1.png',
              imperial_unit_sc: 'temp2.png',
              imperial_unit_tc: 'temp2.png',
              imperial_unit_en: 'temp2.png',
              negative_image: 'dig_sm_minus.png',
              invalid_image: 'dig_sm_error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 334,
                y: 80,
                font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'temp2.png',
                unit_tc: 'temp2.png',
                unit_en: 'temp2.png',
                imperial_unit_sc: 'temp1.png',
                imperial_unit_tc: 'temp1.png',
                imperial_unit_en: 'temp1.png',
                negative_image: 'dig_sm_minus.png',
                invalid_image: 'dig_sm_error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 80,
              font_array: ["dig_sm_0.png","dig_sm_1.png","dig_sm_2.png","dig_sm_3.png","dig_sm_4.png","dig_sm_5.png","dig_sm_6.png","dig_sm_7.png","dig_sm_8.png","dig_sm_9.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'dig_sm_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 55,
              am_y: 269,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 55,
              pm_y: 196,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 98,
              hour_startY: 190,
              hour_array: ["dig_xl_0.png","dig_xl_1.png","dig_xl_2.png","dig_xl_3.png","dig_xl_4.png","dig_xl_5.png","dig_xl_6.png","dig_xl_7.png","dig_xl_8.png","dig_xl_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 248,
              minute_startY: 190,
              minute_array: ["dig_xl_0.png","dig_xl_1.png","dig_xl_2.png","dig_xl_3.png","dig_xl_4.png","dig_xl_5.png","dig_xl_6.png","dig_xl_7.png","dig_xl_8.png","dig_xl_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 338,
              second_startY: 385,
              second_array: ["dig_sec_0.png","dig_sec_1.png","dig_sec_2.png","dig_sec_3.png","dig_sec_4.png","dig_sec_5.png","dig_sec_6.png","dig_sec_7.png","dig_sec_8.png","dig_sec_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'base_sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 4,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 257,
              day_startY: 359,
              day_sc_array: ["50_dig_md_0.png","50_dig_md_1.png","50_dig_md_2.png","50_dig_md_3.png","50_dig_md_4.png","50_dig_md_5.png","50_dig_md_6.png","50_dig_md_7.png","50_dig_md_8.png","50_dig_md_9.png"],
              day_tc_array: ["50_dig_md_0.png","50_dig_md_1.png","50_dig_md_2.png","50_dig_md_3.png","50_dig_md_4.png","50_dig_md_5.png","50_dig_md_6.png","50_dig_md_7.png","50_dig_md_8.png","50_dig_md_9.png"],
              day_en_array: ["50_dig_md_0.png","50_dig_md_1.png","50_dig_md_2.png","50_dig_md_3.png","50_dig_md_4.png","50_dig_md_5.png","50_dig_md_6.png","50_dig_md_7.png","50_dig_md_8.png","50_dig_md_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 177,
              y: 359,
              week_en: ["50_date_1.png","50_date_2.png","50_date_3.png","50_date_4.png","50_date_5.png","50_date_6.png","50_date_7.png"],
              week_tc: ["50_date_1.png","50_date_2.png","50_date_3.png","50_date_4.png","50_date_5.png","50_date_6.png","50_date_7.png"],
              week_sc: ["50_date_1.png","50_date_2.png","50_date_3.png","50_date_4.png","50_date_5.png","50_date_6.png","50_date_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 55,
              am_y: 269,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 55,
              pm_y: 196,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 98,
              hour_startY: 190,
              hour_array: ["dig_aod_0.png","dig_aod_1.png","dig_aod_2.png","dig_aod_3.png","dig_aod_4.png","dig_aod_5.png","dig_aod_6.png","dig_aod_7.png","dig_aod_8.png","dig_aod_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 248,
              minute_startY: 190,
              minute_array: ["dig_aod_0.png","dig_aod_1.png","dig_aod_2.png","dig_aod_3.png","dig_aod_4.png","dig_aod_5.png","dig_aod_6.png","dig_aod_7.png","dig_aod_8.png","dig_aod_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 189,
              y: 17,
              w: 111,
              h: 106,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 62,
              y: 123,
              w: 165,
              h: 53,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 85,
              y: 52,
              w: 74,
              h: 68,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 336,
              y: 317,
              w: 82,
              h: 53,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 67,
              y: 317,
              w: 79,
              h: 53,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 331,
              y: 53,
              w: 74,
              h: 66,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 254,
              y: 183,
              w: 137,
              h: 126,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 96,
              y: 182,
              w: 132,
              h: 124,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 252,
              y: 124,
              w: 168,
              h: 53,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}