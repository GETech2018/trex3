﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_calorie_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_date_img_date_month_img = ''
        let idle_calorie_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 16,
              y: 178,
              src: 'Off_01.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 48,
              y: 111,
              src: 'Sveglia_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 35,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Nr.Sist_11.png',
              dot_image: 'Nr.Sist_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 35,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Nr.Sist_11.png',
              dot_image: 'Nr.Sist_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 142,
              y: 89,
              week_en: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_tc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_sc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 173,
              day_startY: 219,
              day_sc_array: ["Numeri Attività_01.png","Numeri Attività_02.png","Numeri Attività_03.png","Numeri Attività_04.png","Numeri Attività_05.png","Numeri Attività_06.png","Numeri Attività_07.png","Numeri Attività_08.png","Numeri Attività_09.png","Numeri Attività_10.png"],
              day_tc_array: ["Numeri Attività_01.png","Numeri Attività_02.png","Numeri Attività_03.png","Numeri Attività_04.png","Numeri Attività_05.png","Numeri Attività_06.png","Numeri Attività_07.png","Numeri Attività_08.png","Numeri Attività_09.png","Numeri Attività_10.png"],
              day_en_array: ["Numeri Attività_01.png","Numeri Attività_02.png","Numeri Attività_03.png","Numeri Attività_04.png","Numeri Attività_05.png","Numeri Attività_06.png","Numeri Attività_07.png","Numeri Attività_08.png","Numeri Attività_09.png","Numeri Attività_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 217,
              src: 'Numeri Attività_12.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 241,
              month_startY: 219,
              month_sc_array: ["Mesi_01.png","Mesi_02.png","Mesi_03.png","Mesi_04.png","Mesi_05.png","Mesi_06.png","Mesi_07.png","Mesi_08.png","Mesi_09.png","Mesi_10.png","Mesi_11.png","Mesi_12.png"],
              month_tc_array: ["Mesi_01.png","Mesi_02.png","Mesi_03.png","Mesi_04.png","Mesi_05.png","Mesi_06.png","Mesi_07.png","Mesi_08.png","Mesi_09.png","Mesi_10.png","Mesi_11.png","Mesi_12.png"],
              month_en_array: ["Mesi_01.png","Mesi_02.png","Mesi_03.png","Mesi_04.png","Mesi_05.png","Mesi_06.png","Mesi_07.png","Mesi_08.png","Mesi_09.png","Mesi_10.png","Mesi_11.png","Mesi_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 410,
              font_array: ["Numeri Attività_01.png","Numeri Attività_02.png","Numeri Attività_03.png","Numeri Attività_04.png","Numeri Attività_05.png","Numeri Attività_06.png","Numeri Attività_07.png","Numeri Attività_08.png","Numeri Attività_09.png","Numeri Attività_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 279,
              y: 314,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 368,
              font_array: ["Numeri Attività_01.png","Numeri Attività_02.png","Numeri Attività_03.png","Numeri Attività_04.png","Numeri Attività_05.png","Numeri Attività_06.png","Numeri Attività_07.png","Numeri Attività_08.png","Numeri Attività_09.png","Numeri Attività_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Numeri Attività_14.png',
              unit_tc: 'Numeri Attività_14.png',
              unit_en: 'Numeri Attività_14.png',
              negative_image: 'Numeri Attività_12.png',
              invalid_image: 'Numeri Attività_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 127,
              y: 368,
              font_array: ["Numeri Attività_01.png","Numeri Attività_02.png","Numeri Attività_03.png","Numeri Attività_04.png","Numeri Attività_05.png","Numeri Attività_06.png","Numeri Attività_07.png","Numeri Attività_08.png","Numeri Attività_09.png","Numeri Attività_10.png"],
              padding: false,
              h_space: 2,
              dot_image: 'Numeri Attività_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 266,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 234,
              y: 330,
              image_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png"],
              image_length: 5,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Puntatore_01.png',
              center_x: 410,
              center_y: 284,
              x: 11,
              y: 57,
              start_angle: -166,
              end_angle: 90,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 382,
              y: 275,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Lancetta_01.png',
              center_x: 75,
              center_y: 284,
              x: 8,
              y: 42,
              start_angle: -90,
              end_angle: 90,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 48,
              y: 299,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 90,
              hour_startY: 134,
              hour_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 243,
              minute_startY: 134,
              minute_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 363,
              second_startY: 125,
              second_array: ["Numeri Secondi_01.png","Numeri Secondi_02.png","Numeri Secondi_03.png","Numeri Secondi_04.png","Numeri Secondi_05.png","Numeri Secondi_06.png","Numeri Secondi_07.png","Numeri Secondi_08.png","Numeri Secondi_09.png","Numeri Secondi_10.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 16,
              y: 178,
              src: 'Off_01.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 48,
              y: 111,
              src: 'Sveglia_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 35,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Nr.Sist_11.png',
              dot_image: 'Nr.Sist_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 35,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'Nr.Sist_11.png',
              dot_image: 'Nr.Sist_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 142,
              y: 89,
              week_en: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_tc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_sc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 173,
              day_startY: 219,
              day_sc_array: ["Numeri Attività_01.png","Numeri Attività_02.png","Numeri Attività_03.png","Numeri Attività_04.png","Numeri Attività_05.png","Numeri Attività_06.png","Numeri Attività_07.png","Numeri Attività_08.png","Numeri Attività_09.png","Numeri Attività_10.png"],
              day_tc_array: ["Numeri Attività_01.png","Numeri Attività_02.png","Numeri Attività_03.png","Numeri Attività_04.png","Numeri Attività_05.png","Numeri Attività_06.png","Numeri Attività_07.png","Numeri Attività_08.png","Numeri Attività_09.png","Numeri Attività_10.png"],
              day_en_array: ["Numeri Attività_01.png","Numeri Attività_02.png","Numeri Attività_03.png","Numeri Attività_04.png","Numeri Attività_05.png","Numeri Attività_06.png","Numeri Attività_07.png","Numeri Attività_08.png","Numeri Attività_09.png","Numeri Attività_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 217,
              src: 'Numeri Attività_12.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 241,
              month_startY: 219,
              month_sc_array: ["Mesi_01.png","Mesi_02.png","Mesi_03.png","Mesi_04.png","Mesi_05.png","Mesi_06.png","Mesi_07.png","Mesi_08.png","Mesi_09.png","Mesi_10.png","Mesi_11.png","Mesi_12.png"],
              month_tc_array: ["Mesi_01.png","Mesi_02.png","Mesi_03.png","Mesi_04.png","Mesi_05.png","Mesi_06.png","Mesi_07.png","Mesi_08.png","Mesi_09.png","Mesi_10.png","Mesi_11.png","Mesi_12.png"],
              month_en_array: ["Mesi_01.png","Mesi_02.png","Mesi_03.png","Mesi_04.png","Mesi_05.png","Mesi_06.png","Mesi_07.png","Mesi_08.png","Mesi_09.png","Mesi_10.png","Mesi_11.png","Mesi_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 410,
              font_array: ["Numeri Attività_01.png","Numeri Attività_02.png","Numeri Attività_03.png","Numeri Attività_04.png","Numeri Attività_05.png","Numeri Attività_06.png","Numeri Attività_07.png","Numeri Attività_08.png","Numeri Attività_09.png","Numeri Attività_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 279,
              y: 314,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 277,
              y: 368,
              font_array: ["Numeri Attività_01.png","Numeri Attività_02.png","Numeri Attività_03.png","Numeri Attività_04.png","Numeri Attività_05.png","Numeri Attività_06.png","Numeri Attività_07.png","Numeri Attività_08.png","Numeri Attività_09.png","Numeri Attività_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Numeri Attività_14.png',
              unit_tc: 'Numeri Attività_14.png',
              unit_en: 'Numeri Attività_14.png',
              negative_image: 'Numeri Attività_12.png',
              invalid_image: 'Numeri Attività_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 127,
              y: 368,
              font_array: ["Numeri Attività_01.png","Numeri Attività_02.png","Numeri Attività_03.png","Numeri Attività_04.png","Numeri Attività_05.png","Numeri Attività_06.png","Numeri Attività_07.png","Numeri Attività_08.png","Numeri Attività_09.png","Numeri Attività_10.png"],
              padding: false,
              h_space: 2,
              dot_image: 'Numeri Attività_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 266,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 234,
              y: 330,
              image_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png"],
              image_length: 5,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Puntatore_01.png',
              center_x: 410,
              center_y: 284,
              x: 11,
              y: 57,
              start_angle: -166,
              end_angle: 90,
              invalid_visible: false,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 382,
              y: 275,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Lancetta_01.png',
              center_x: 75,
              center_y: 284,
              x: 8,
              y: 42,
              start_angle: -90,
              end_angle: 90,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 48,
              y: 299,
              font_array: ["Nr.Sist_01.png","Nr.Sist_02.png","Nr.Sist_03.png","Nr.Sist_04.png","Nr.Sist_05.png","Nr.Sist_06.png","Nr.Sist_07.png","Nr.Sist_08.png","Nr.Sist_09.png","Nr.Sist_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 90,
              hour_startY: 134,
              hour_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 243,
              minute_startY: 134,
              minute_array: ["Nr.Ore_01.png","Nr.Ore_02.png","Nr.Ore_03.png","Nr.Ore_04.png","Nr.Ore_05.png","Nr.Ore_06.png","Nr.Ore_07.png","Nr.Ore_08.png","Nr.Ore_09.png","Nr.Ore_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}