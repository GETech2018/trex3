/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_battery_rotary2 = '';
		let normal_steps_rotary4 = '';
		let normal_stress_rotary6 = '';
		let timeInterval;
		let normal_date_high_imageset8 = '';
		let normal_date_high_imageset8_array = ['0004.png','0005.png','0006.png','0007.png'];
		let normal_date_low_imageset9 = '';
		let normal_date_low_imageset9_array = ['0008.png','0009.png','0010.png','0011.png','0012.png','0013.png','0014.png','0015.png','0016.png','0017.png'];
		let normal_minute_rotary11 = '';
		let normal_minute_rotary12 = '';
		let normal_hour_rotary13 = '';
		let normal_hour_rotary14 = '';
		let normal_second_rotary15 = '';
		let normal_second_rotary16 = '';
		let idle_img19 = '';
		let idle_battery_rotary21 = '';
		let idle_steps_rotary23 = '';
		let idle_stress_rotary25 = '';
		let idle_date_high_imageset27 = '';
		let idle_date_high_imageset27_array = ['0004.png','0005.png','0006.png','0007.png'];
		let idle_date_low_imageset28 = '';
		let idle_date_low_imageset28_array = ['0008.png','0009.png','0010.png','0011.png','0012.png','0013.png','0014.png','0015.png','0016.png','0017.png'];
		let idle_hour_rotary30 = '';
		let idle_hour_rotary31 = '';
		let idle_minute_rotary32 = '';
		let idle_minute_rotary33 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 485,
					h: 485,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_rotary2 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0003.png',
					center_x: 129,
					center_y: 220,
					x: 10,
					y: 70,
					start_angle: 0,
					end_angle: 360,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_rotary4 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0003.png',
					center_x: 351,
					center_y: 220,
					x: 10,
					y: 70,
					start_angle: 0,
					end_angle: 360,
					type: hmUI.data_type.STEP,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_rotary6 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0003.png',
					center_x: 240,
					center_y: 350,
					x: 10,
					y: 70,
					start_angle: 0,
					end_angle: 360,
					type: hmUI.data_type.STRESS,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_high_imageset8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 343,
					y: 344,
					w: 343,
					h: 344,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_date_low_imageset9 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 353,
					y: 353,
					w: 359,
					h: 354,
					src: '0017.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_minute_rotary11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 235,
					center_y: 236,
					pos_x: 217,
					pos_y: 22,
					src: '0018.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_rotary12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 222,
					pos_y: 26,
					src: '0019.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_rotary13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 235,
					center_y: 236,
					pos_x: 215,
					pos_y: 78,
					src: '0020.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_rotary14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 220,
					pos_y: 82,
					src: '0021.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 232,
					center_y: 235,
					pos_x: 219,
					pos_y: 21,
					src: '0022.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 227,
					pos_y: 26,
					src: '0023.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img19 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 485,
					h: 485,
					src: '0024.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_battery_rotary21 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0003.png',
					center_x: 129,
					center_y: 220,
					x: 10,
					y: 70,
					start_angle: 0,
					end_angle: 360,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_steps_rotary23 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0003.png',
					center_x: 351,
					center_y: 220,
					x: 10,
					y: 70,
					start_angle: 0,
					end_angle: 360,
					type: hmUI.data_type.STEP,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_stress_rotary25 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0003.png',
					center_x: 240,
					center_y: 350,
					x: 10,
					y: 70,
					start_angle: 0,
					end_angle: 360,
					type: hmUI.data_type.STRESS,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_high_imageset27 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 343,
					y: 344,
					w: 343,
					h: 344,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_date_low_imageset28 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 353,
					y: 354,
					w: 359,
					h: 354,
					src: '0017.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_hour_rotary30 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 235,
					center_y: 236,
					pos_x: 215,
					pos_y: 78,
					src: '0020.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_rotary31 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 220,
					pos_y: 82,
					src: '0021.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_rotary32 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 235,
					center_y: 236,
					pos_x: 217,
					pos_y: 22,
					src: '0018.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_rotary33 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 222,
					pos_y: 26,
					src: '0019.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateTime() {
					normal_date_high_imageset8.setProperty(hmUI.prop.MORE, {
						src: normal_date_high_imageset8_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(0) : 0)]
					})
					normal_date_low_imageset9.setProperty(hmUI.prop.MORE, {
						src: normal_date_low_imageset9_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(1) : timeSensor.day.toString().charAt(0))]
					})
					if (normal_minute_rotary11) {
						normal_minute_rotary11.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
					if (normal_minute_rotary12) {
						normal_minute_rotary12.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
					if (normal_hour_rotary13) {
						normal_hour_rotary13.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (normal_hour_rotary14) {
						normal_hour_rotary14.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (normal_second_rotary15) {
						normal_second_rotary15.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.second * (6 * 1))));
					}
					if (normal_second_rotary16) {
						normal_second_rotary16.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.second * (6 * 1))));
					}
					idle_date_high_imageset27.setProperty(hmUI.prop.MORE, {
						src: idle_date_high_imageset27_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(0) : 0)]
					})
					idle_date_low_imageset28.setProperty(hmUI.prop.MORE, {
						src: idle_date_low_imageset28_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(1) : timeSensor.day.toString().charAt(0))]
					})
					if (idle_hour_rotary30) {
						idle_hour_rotary30.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (idle_hour_rotary31) {
						idle_hour_rotary31.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (idle_minute_rotary32) {
						idle_minute_rotary32.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
					if (idle_minute_rotary33) {
						idle_minute_rotary33.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}