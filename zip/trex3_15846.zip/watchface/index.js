﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (()=>{
        //dynamic modify start

        const lang = DeviceRuntimeCore.HmUtils.getLanguage()
        let normal_background_bg_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altitude_target_separator_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_floor_current_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''
        let image_top_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
		let normal_heart_jumpable_img_click = ''
        let Button_1 = ''
		let objPreLine = ''
		let objTemLine = ''
		let objArtLine = ''
		
		const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT } = hmSetting.getDeviceInfo();
		
		let group1 = ''
		let group2 = ''
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 2
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			objTemLine.setProperty(hmUI.prop.VISIBLE, true);
			group1.setProperty(hmUI.prop.VISIBLE, false);
			group2.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			objTemLine.setProperty(hmUI.prop.VISIBLE, false);
			group1.setProperty(hmUI.prop.VISIBLE, true);
			group2.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 2) {
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			objTemLine.setProperty(hmUI.prop.VISIBLE, false);
			group1.setProperty(hmUI.prop.VISIBLE, false);
			group2.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dmonth=["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"]
			if(lang=='ru-RU'){
				dmonth=["mru_1.png","mru_2.png","mru_3.png","mru_4.png","mru_5.png","mru_6.png","mru_7.png","mru_8.png","mru_9.png","mru_10.png","mru_11.png","mru_12.png"]
			}
            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 110,
              month_startY: 166,
              month_sc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_tc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_en_array: dmonth,
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			let dned=["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"]
			if(lang=='ru-RU'){
				dned=["weekru_1.png","weekru_2.png","weekru_3.png","weekru_4.png","weekru_5.png","weekru_6.png","weekru_7.png"]
			}
            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 110,
              y: 140,
              week_en: dned,
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			objTemLine = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, {
               x:38,
               y:305,
               w:480,
               h:70,
               line_width:4,
               line_color:0x00AC6D,
               color_from:0x7f00AC6D,
               color_to:0x7f00AC6D,
               type:hmUI.data_type.WEATHER,
               show_level: hmUI.show_level.ONLY_NORMAL
            });
			
			group1 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });
			
			objArtLine = group1.createWidget(hmUI.widget.GRADKIENT_POLYLINE, {
				x:38,
                y:305,
                w:480,
                h:70,
                line_width:4,
                line_color:0x00AC6D,
                color_from:0x7f00AC6D,
                color_to:0x7f00AC6D,
                type:hmUI.data_type.ALTITUDE,
                show_level: hmUI.show_level.ONLY_NORMAL
            });

            normal_altitude_target_text_img = group1.createWidget(hmUI.widget.TEXT_IMG, {
              x: 38,
              y: 265,
              font_array: ["26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_separator_img = group1.createWidget(hmUI.widget.IMG, {
              x: 54,
              y: 220,
              src: 'pb_list_icon_altitude.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			group2 = hmUI.createWidget(hmUI.widget.GROUP, {
	                  x: 0,
	                  y: 0,
	                  w: DEVICE_WIDTH,
	                  h: DEVICE_HEIGHT,
            });

            objPreLine = group2.createWidget(hmUI.widget.GRADKIENT_POLYLINE, {
				x:38,
                y:305,
                w:480,
                h:70,
                line_width:4,
                line_color:0x0097E3,
                color_from:0x7f0097E3,
                color_to:0x7f0097E3,
                type:hmUI.data_type.BARO,
                show_level: hmUI.show_level.ONLY_NORMAL
            });
			
			normal_altimeter_text_text_img = group2.createWidget(hmUI.widget.TEXT_IMG, {
              x: 35,
              y: 265,
              font_array: ["26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = group2.createWidget(hmUI.widget.IMG, {
              x: 54,
              y: 220,
              src: 'pb_list_icon_altitudeup.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 51,
              y: 220,
              image_array: ["weather_0.png","weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 42,
              y: 265,
              font_array: ["26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png"],
              padding: false,
              h_space: 0,
              unit_sc: '96.png',
              unit_tc: '96.png',
              unit_en: '96.png',
              negative_image: '95.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 170,
              font_array: ["26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 218,
              y: 125,
              image_array: ["P_1.png","P_2.png","P_3.png","P_4.png","P_5.png","P_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 360,
              y: 252,
              font_array: ["26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png"],
              padding: false,
              h_space: 0,
              unit_sc: '70.png',
              unit_tc: '70.png',
              unit_en: '70.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 298,
              y: 240,
              image_array: ["59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 362,
              y: 199,
              font_array: ["26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 299,
              y: 187,
              image_array: ["37.png","38.png","39.png","40.png","41.png","42.png","43.png","44.png","45.png","46.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 353,
              y: 145,
              font_array: ["26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 299,
              y: 134,
              image_array: ["48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 45,
              day_startY: 142,
              day_sc_array: ["83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
              day_tc_array: ["83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
              day_en_array: ["83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_floor_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 137,
              y: 265,
              font_array: ["26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FLOOR,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 206,
              y: 265,
              font_array: ["26.png","27.png","28.png","29.png","30.png","31.png","32.png","33.png","34.png","35.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 126,
              y: 396,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 253,
              y: 394,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 319,
              y: 394,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 187,
              y: 395,
              src: 'clock.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 92,
              hour_startY: 35,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 5,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 257,
              minute_startY: 35,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 221,
              second_startY: 64,
              second_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 46,
              hour_startY: 162,
              hour_array: ["info_bricks_digital_time_num_0.png","info_bricks_digital_time_num_1.png","info_bricks_digital_time_num_2.png","info_bricks_digital_time_num_3.png","info_bricks_digital_time_num_4.png","info_bricks_digital_time_num_5.png","info_bricks_digital_time_num_6.png","info_bricks_digital_time_num_7.png","info_bricks_digital_time_num_8.png","info_bricks_digital_time_num_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colon1.png',
              hour_unit_tc: 'colon1.png',
              hour_unit_en: 'colon1.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 259,
              minute_startY: 162,
              minute_array: ["info_bricks_digital_time_num_0.png","info_bricks_digital_time_num_1.png","info_bricks_digital_time_num_2.png","info_bricks_digital_time_num_3.png","info_bricks_digital_time_num_4.png","info_bricks_digital_time_num_5.png","info_bricks_digital_time_num_6.png","info_bricks_digital_time_num_7.png","info_bricks_digital_time_num_8.png","info_bricks_digital_time_num_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 268,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 350,
              y: 125,
              w: 100,
              h: 55,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 350,
              y: 185,
              w: 100,
              h: 55,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			 normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 120,
              w: 90,
              h: 90,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 26,
              y: 220,
              text: '',
              w: 90,
              h: 125,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				click_zona1();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			group1.setProperty(hmUI.prop.VISIBLE, false);
			group2.setProperty(hmUI.prop.VISIBLE, false);

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 350,
              y: 245,
              w: 100,
              h: 55,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 205,
              y: 220,
              w: 75,
              h: 80,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 102,
              y: 45,
              w: 100,
              h: 65,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 275,
              y: 45,
              w: 100,
              h: 65,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 50,
              y: 130,
              w: 120,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}