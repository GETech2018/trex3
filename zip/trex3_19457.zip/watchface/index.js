try {
  (() => {
    var __$$app$$__ = __$$hmAppManager$$__.currentApp;
    var __$$module$$__ = __$$app$$__.current;
    var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');
    'use strict';
    const logger = DeviceRuntimeCore.HmLogger.getLogger('chrono');

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {

            hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 480, h: 480, src: 'bg.png', show_level: hmUI.show_level.ONLY_NORMAL });
            hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 288, y: 166,
              image_array: ["w00.png", "w01.png", "w02.png", "w03.png", "w04.png", "w05.png", "w06.png", "w07.png", "w08.png", "w09.png", "w10.png", "w11.png", "w12.png", "w13.png", "w14.png", "w15.png", "w16.png", "w17.png", "w18.png", "w19.png", "w20.png", "w21.png", "w22.png", "w23.png", "w24.png", "w25.png", "w26.png", "w27.png", "w28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_STATUS, { x: 164, y: 146, src: 'st_bt.png', type: hmUI.system_status.DISCONNECT, show_level: hmUI.show_level.ONLY_NORMAL });
            hmUI.createWidget(hmUI.widget.IMG_STATUS, { x: 138, y: 146, src: 'st_alarm.png', type: hmUI.system_status.CLOCK, show_level: hmUI.show_level.ONLY_NORMAL });
            hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 323, day_startY: 315,
              day_sc_array: ["dd0.png", "dd1.png", "dd2.png", "dd3.png", "dd4.png", "dd5.png", "dd6.png", "dd7.png", "dd8.png", "dd9.png"], day_tc_array: ["dd0.png", "dd1.png", "dd2.png", "dd3.png", "dd4.png", "dd5.png", "dd6.png", "dd7.png", "dd8.png", "dd9.png"], day_en_array: ["dd0.png", "dd1.png", "dd2.png", "dd3.png", "dd4.png", "dd5.png", "dd6.png", "dd7.png", "dd8.png", "dd9.png"],
              day_zero: 1, day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 131, y: 251,
              image_array: ["fuel_on.png","fuel_off.png","fuel_off.png","fuel_off.png","fuel_off.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326, y: 174, w: 44, h: 20,
              font_array: ["dw0.png", "dw1.png", "dw2.png", "dw3.png", "dw4.png", "dw5.png", "dw6.png", "dw7.png", "dw8.png", "dw9.png"],
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              negative_image: 'dw_minus.png',
              unit_sc: 'dw_deg.png', unit_tc: 'dw_deg.png', unit_en: 'dw_deg.png',
              invalid_image: 'dw_inv.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 118, y: 208, w: 60, h: 20,
              font_array: ["dw0.png", "dw1.png", "dw2.png", "dw3.png", "dw4.png", "dw5.png", "dw6.png", "dw7.png", "dw8.png", "dw9.png"],
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              unit_sc: 'dw_pct.png', unit_tc: 'dw_pct.png', unit_en: 'dw_pct.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 294, y: 214, w: 76, h: 24,
              font_array: ["dc0.png", "dc1.png", "dc2.png", "dc3.png", "dc4.png", "dc5.png", "dc6.png", "dc7.png", "dc8.png", "dc9.png"],
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300, y: 246, w: 64, h: 24,
              font_array: ["dc0.png", "dc1.png", "dc2.png", "dc3.png", "dc4.png", "dc5.png", "dc6.png", "dc7.png", "dc8.png", "dc9.png"],
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              dot_image: 'dc_dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210, y: 297, w: 40, h: 20,
              font_array: ["dw0.png", "dw1.png", "dw2.png", "dw3.png", "dw4.png", "dw5.png", "dw6.png", "dw7.png", "dw8.png", "dw9.png"],
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              invalid_image: 'dw_inv.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195, y: 317, w: 34, h: 20,
              font_array: ["dw0.png", "dw1.png", "dw2.png", "dw3.png", "dw4.png", "dw5.png", "dw6.png", "dw7.png", "dw8.png", "dw9.png"],
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211, y: 345, w: 44, h: 20,
              font_array: ["dw0.png", "dw1.png", "dw2.png", "dw3.png", "dw4.png", "dw5.png", "dw6.png", "dw7.png", "dw8.png", "dw9.png"],
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'n_white.png',
              center_x: 148, center_y: 240,
              x: 8, y: 48,
              start_angle: -180, end_angle: 180,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'n_white.png',
              center_x: 240, center_y: 328,
              x: 8, y: 48,
              start_angle: -180, end_angle: 180,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h_hour.png', hour_centerX: 240, hour_centerY: 240, hour_posX: 13, hour_posY: 118,
              minute_path: 'h_min.png', minute_centerX: 240, minute_centerY: 240, minute_posX: 12, minute_posY: 178,
              second_path: 'h_sec.png', second_centerX: 240, second_centerY: 240, second_posX: 15, second_posY: 204,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hmUI.createWidget(hmUI.widget.IMG, { x: 0, y: 0, w: 480, h: 480, src: 'bg_aod.png', show_level: hmUI.show_level.ONAL_AOD });
            hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'h_hour.png', hour_centerX: 240, hour_centerY: 240, hour_posX: 13, hour_posY: 118,
              minute_path: 'h_min.png', minute_centerX: 240, minute_centerY: 240, minute_posX: 12, minute_posY: 178,
              show_level: hmUI.show_level.ONAL_AOD,
            });
      },
      onInit() { this.init_view(); },
      onReady() {},
      onShow() {},
      onHide() {},
      onDestory() {},
    });
  })();
} catch (e) {
  console.log(e);
}
