﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
              
      
        const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT} = hmSetting.getDeviceInfo();
        const radius = DEVICE_WIDTH / 2, centerX = DEVICE_WIDTH / 2, centerY = DEVICE_HEIGHT / 2
      
        const curTime = hmSensor.createSensor(hmSensor.id.TIME);
        const weather = hmSensor.createSensor(hmSensor.id.WEATHER);
      
        let weatherImg, tempText, cityNameText, tempMinText, tempMaxText, tempFeelsText, descriptionText
        let weatherProvider
        
        const vibrator = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let stopVibro_Timer = null;
    
        function vibro(mode = 25, stopDelay = 30) {
            vibrator.stop();
            vibrator.scene = mode;
            vibrator.start();
            stopVibro_Timer = setTimeout(() => {
              stopVibro();
            }, stopDelay);
        }		
    
        function stopVibro(){
            vibrator.stop();
            if (stopVibro_Timer) clearTimeout(stopVibro_Timer);
        } 
 

        class WeatherProvider {
          constructor(props = {}) {
            this.props = {
              night_icons: [],											// индексы иконок для замены день-ночь
              index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,		// текущий индекс провайдера (сохраняется и считывается из памяти)
              show_toast: true,											// показывать всплывающее сообщение при переключении провайдера
              temp_widget: null,											// виджет TEXT для отображения температуры
              temp_max_widget: null,										// виджет TEXT для отображения максимальной температуры
              temp_min_widget: null,										// виджет TEXT для отображения минимальной температуры
              temp_feels_widget: null,									// виджет TEXT для отображения ощущаемой температуры
              description_widget: null,									// виджет TEXT для отображения текстового описания текущей погоды
              cityName_widget: null,										// виджет TEXT для отображения названия города
              icon_widget: null,											// виджет IMG для отображения значка погоды
              time_sensor: null,											// сенсор времени, если не задан, то создается новый
              weather_sensor: null,										// сенсор погоды, если не задан, то создается новый
              file_name: 'weather.json',									// имя файла с погодными данными
              auto_update: true,											// автоматическое обновление погоды (нет необходимости добавлять weatherProvider.update() в event.MINUTEEND и WIDGET_DELEGATE)
              lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
              ...props,
            };
            this.providers = [
              {name: ['Zepp', 'Zepp'], appId: null},							// 0
              {name: ['Погодный сервис', 'Weather service'], appId: 1065824},	// 1 
              //{name: ['RuWeather', 'RWeather'], appId: 1066654},				// 2
            ]

            this.description = [
                ['Облачно', 'Временами дождь', 'Временами снег', 'Ясно', 'Пасмурно', 'Слабый дождь', 'Слабый снег', 'Умеренный дождь', 'Умеренный снег', 'Сильный снегопад', 'Сильный дождь', 'Песчаная буря', 'Мокрый снег', 'Туман', 'Дымка', 'Дождь с грозой', 'Метель', 'Пыльно', 'Ливень', 'Дождь с градом', 'Сильный дождь с градом', 'Сильный дождь', 'Пыльная буря', 'Сильная песчаная буря', 'Сильный дождь', 'Обновите погоду', 'Облачно ночью', 'Дождливо ночью', 'Ясно ночью'],
                ['Cloudy', 'Showers', 'Snow Showers', 'Sunny', 'Overcast', 'Light Rain', 'Light Snow', 'Moderate Rain', 'Moderate Snow', 'Heavy Snow', 'Heavy Rain', 'Sandstorm', 'Rain and Snow', 'Fog', 'Hazy', 'T-Storms', 'Snowstorm', 'Floating dust', 'Very Heavy Rainstorm', 'Rain and Hail', 'T-Storms and Hail', 'Heavy Rainstorm', 'Dust', 'Heavy sand storm', 'Rainstorm', 'Unknown', 'Cloudy Nighttime', 'Showers Nighttime', 'Sunny Nighttime'],
              ]      
              
            this.last = {
                weatherIcon: 25,
                weatherDescription:  'Нет данных',
                temperature: '--',
                temperatureFeels: '--',
                temperatureMax: '--',
                temperatureMin: '--',
                cityName: '--',
                modTime: null,
            }      
            
            if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
            if (!this.props.weather_sensor) this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            if (isFinite(props.index)) hmFS.SysProSetInt('WeatherProviderIndex', props.index);
            if (this.props.auto_update) this.createHandlers();
        } 
        
        
        createHandlers() {
          this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

          this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
            resume_call: ( () => this.update() )
          })
        }   
        
        arrayBufferToCyrillic(buffer) {
          let result = '';
          const bytes = new Uint8Array(buffer);

          let i = 0;
          while (i < bytes.length) {
              let byte1 = bytes[i++];
          
              if (byte1 < 0x80) {								// Обработка 1-байтовых символов (ASCII)
                result += String.fromCharCode(byte1);
              } else if (byte1 >= 0xC0 && byte1 < 0xE0) {		// Обработка 2-байтовых символов (UTF-8 кодировка для кириллицы)
                let byte2 = bytes[i++];
                let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
                result += String.fromCharCode(charCode);
              } else if (byte1 >= 0xE0 && byte1 < 0xF0) {		// Обработка 3-байтовых символов (например, для UTF-8)
                let byte2 = bytes[i++];
                let byte3 = bytes[i++];
                let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
                result += String.fromCharCode(charCode);
              }
          }

          return result
        } 
        
        readFile(app_id) {
          if (!app_id) return null				
          let str_result = "";
          try {
              const [fs_stat, err] = hmFS.stat(this.props.file_name, {
                  appid: app_id,
              });
              if (err == 0) {
                  const fh = hmFS.open(this.props.file_name, hmFS.O_RDONLY, {
                  appid: app_id,
                  });

                  const len = fs_stat.size;
                  let array_buffer = new ArrayBuffer(len);
                  hmFS.read(fh, array_buffer, 0, len);
                  hmFS.close(fh);
                  str_result = this.arrayBufferToCyrillic(array_buffer);

                  return str_result;
              } else {
                  console.log("err:", err);
              }
          } catch (error) {
          console.log("error:", error);
          console.log("FAIL: No access to hmFS.");
          }
          return null;
        }    
        
        getFileModTime(app_id) {
          if (!app_id) return null
          try {
              const [fs_stat, err] = hmFS.stat(this.props.file_name, {
                  appid: app_id,
              });
          
              if (err == 0) {
                  return fs_stat.mtime
              } else {
                  console.log("ModTime err:", err);
              }
          } catch (error) {
            console.log("ModTime error:", error);
            console.log("FAIL: No access to hmFS.");
          }
            return null
        }  
        
        isDayNow() {
          const sunData = this.props.weather_sensor.getForecastWeather().tideData;
          let sunriseMins = 8 * 60;			// время восхода
          let sunsetMins = 20 * 60;			// и заката по умолчанию

          if (sunData.count > 0){
              const today = sunData.data[0];
              sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
              sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
          }

          const curMins = curTime.hour * 60 + curTime.minute;
          const nowIsDay = (curMins >= sunriseMins) && (curMins < sunsetMins);

          return nowIsDay
        }  
        
        getZeppIconIndex(index, app_id = null) {
                        
          if (!app_id)  return index;			//	если нет app_id, то не меняем индекс иконки

          let newIndex = 25;
          
          if (app_id == 1065824) {					// WeatherService
              switch(index) {
              case 1:
                      newIndex = 3;
                  break;
              case 2:
                      newIndex = 0;
                  break;
              case 3:
              case 4:
                      newIndex = 4;
                  break;
              case 5:
                      newIndex = 1;
                  break;
              case 6:
                      newIndex = 5;
                  break;
              case 7:
                      newIndex = 10;
                  break;
              case 8:
                      newIndex = 15;
                  break;
              case 9:
                      newIndex = 6;
                  break;
              case 10:
                      newIndex = 8;
                  break;
              case 11:
                      newIndex = 9;
                  break;
              case 12:
                      newIndex = 12;
                  break;
              case 13:
                      newIndex = 13;
                  break;
              case 14:
                      newIndex = 17;
                  break;
              default:
                      newIndex = 25;
                  break;
              }
          } else if (app_id == 1066654) {					// 
              newIndex = index - 1;
          }

          return newIndex
        }  
       
        tempWithSign(val){
          val = parseFloat(val);
          if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
          val = Math.round(val);
          if (val > 0) val = '+' + val;
          val += '°';
          
          return val
        }    
        
        getZeppWeatherData() {
          const iconIndex = this.props.weather_sensor.curAirIconIndex ?? 25;
          const data = {
              weatherIcon: iconIndex,
              weatherDescription:  this.description[this.props.lang][iconIndex],
              temperature: this.props.weather_sensor.current ?? '--',
              temperatureFeels: '--',
              temperatureMax: this.props.weather_sensor.high ?? '--',
              temperatureMin: this.props.weather_sensor.low ?? '--',
              cityName: this.props.weather_sensor.getForecastWeather().cityName ?? '--',
          }

          return data
        }  
        
        getAppWeatherData(app_id) {
          const data = {
              weatherIcon: 25,
              weatherDescription:  'Нет данных',
              temperature: '--',
              temperatureFeels: '--',
              temperatureMax: '--',
              temperatureMin: '--',
              cityName: '--',
          }
          
          let weather_str = this.readFile(app_id);
          let weatherJson = JSON.parse(weather_str);

          if (weatherJson) {
              if (isFinite(weatherJson.weatherIcon)) {		// считываем индекс иконки погоды и сразу переводим в нумерацию Zepp
                  data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon), app_id);
              }

              if (weatherJson?.weatherDescriptionExtended?.length) {
                  data.weatherDescription = weatherJson.weatherDescriptionExtended;
                  data.weatherDescription = data.weatherDescription.replace(data.weatherDescription[0], data.weatherDescription[0].toUpperCase());
              } else data.weatherDescription = this.description[data.weatherIcon];

              if (isFinite(weatherJson.temperature)) {
                  data.temperature = parseFloat(weatherJson.temperature);
                  data.temperature = Math.round(data.temperature);
              }
              
              if (isFinite(weatherJson.temperatureFeels)){
                  data.temperatureFeels = parseFloat(weatherJson.temperatureFeels);
                  data.temperatureFeels = Math.round(data.temperatureFeels);
              }
                  
              if (isFinite(weatherJson.temperatureMax)){
                  data.temperatureMax = parseFloat(weatherJson.temperatureMax);
                  data.temperatureMax = Math.round(data.temperatureMax);
              }
                  
              if (isFinite(weatherJson.temperatureMin)){
                  data.temperatureMin = parseFloat(weatherJson.temperatureMin);
                  data.temperatureMin = Math.round(data.temperatureMin);
              }
              
              if (weatherJson.city) {
                  data.cityName = weatherJson.city;
              }
          }
          
          return data
        }  
        
        getWeatherData(app_id = null) {
          if (!app_id) return this.getZeppWeatherData()		// если нет app_id, то получаем данные от Zepp
          else return this.getAppWeatherData(app_id);			// иначе читаем данные из файла данных приложения
        }  
        
        update() {
          let curIcon = parseInt(this.last.weatherIcon);				// текущий индекс значка погоды без учета времени суток (т.е. число без "n")

          const modTime = this.getFileModTime(this.providers[this.props.index].appId);		// время изменеия файла с данными
          
          if (!modTime || this.last.modTime != modTime){										// если не получено время изменеия или оно отличается от последнего времени изменеия
              const newData = this.getWeatherData(this.providers[this.props.index].appId);	// тогда читаем новые данные из файла
              this.last.modTime = modTime;

              let val = this.tempWithSign(newData.temperature);
              if (val != this.last.temperature){
                  this.last.temperature = val;
                  if (this.props.temp_widget) this.props.temp_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = this.tempWithSign(newData.temperatureMax);
              if (val != this.last.temperatureMax){
                  this.last.temperatureMax = val;
                  if (this.props.temp_max_widget) this.props.temp_max_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = this.tempWithSign(newData.temperatureMin);
              if (val != this.last.temperatureMin){
                  this.last.temperatureMin = val;
                  if (this.props.temp_min_widget) this.props.temp_min_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = this.tempWithSign(newData.temperatureFeels);
              if (val != this.last.temperatureFeels){
                  this.last.temperatureFeels = val;
                  if (this.props.temp_feels_widget) this.props.temp_feels_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = newData.cityName;
              if (val != this.last.cityName){
                  this.last.cityName = val;
                  if (this.props.cityName_widget) this.props.cityName_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = newData.weatherDescription;
              if (val != this.last.weatherDescription){
                  this.last.weatherDescription = val;
                  if (this.props.description_widget) this.props.description_widget.setProperty(hmUI.prop.TEXT, val);
              }

              
              curIcon = newData.weatherIcon;						// получаем текущий индекс значка погоды
          }

          if (this.props.night_icons.includes(curIcon) && !this.isDayNow()){		// если он в списке ночных иконок и сейчас "ночь", то добавляем суффикс 'n'
              curIcon += 'n';
          }

          if (curIcon != this.last.weatherIcon){
              this.last.weatherIcon = curIcon;
              if (this.props.icon_widget) this.props.icon_widget.setProperty(hmUI.prop.SRC, `w_${curIcon}.png`);
          }
        } 
        
        next(show_toast = this.props.show_toast) {
          const v = (this.props.index + 1) % this.providers.length;
          this.provider = v;
          if (show_toast) hmUI.showToast({text: this.name});
        }        
        
        prev(show_toast = this.props.show_toast) {
          const v = (this.props.index - 1 + this.providers.length) % this.providers.length;
          this.provider = v;
          if (show_toast) hmUI.showToast({text: this.name});
        }   
        
        toggle(dir, show_toast = this.props.show_toast) {
          if (dir > 0) this.next(show_toast)
          else this.prev(show_toast);
        }   
        
        set provider(v) {
          this.props.index = v;
          hmFS.SysProSetInt('WeatherProviderIndex', v);
          this.update();
        }   
        
        get index() {
          return this.props.index
        }     
      
        
        get name() {
            return this.providers[this.props.index].name[this.props.lang]
        }    
        
        get cityName() {
          return this.last.cityName
        }     
        
        get temperature() {
          return this.last.temperature
        }   
        
        get temperatureMax() {
          return this.last.temperatureMax
        }

        
        get temperatureMin() {
            return this.last.temperatureMin
        }        

          
        get weatherDescription() {
            return this.last.weatherDescription
        }      
        
       delete() {
          this.providers = null;
          this.props = null;
          this.last = null;
          this.description = null;
          if (this.widgetDelegate) {
              hmUI.deleteWidget(this.widgetDelegate);
              this.widgetDelegate = null;
          }
       }

      } 

      // start user_functions.js
const {
  width: D_W,
  height: D_H
} = hmSetting.getDeviceInfo();  

        // start zodiac
        function getZodiacSign(month, day) {
          
          if ((month === 1 && day >= 20) || (month === 2 && day <= 18)) return 0;
  
          
          if ((month === 2 && day >= 19) || (month === 3 && day <= 20)) return 1;
  
          
          if ((month === 3 && day >= 21) || (month === 4 && day <= 19)) return 2;
  
          
          if ((month === 4 && day >= 20) || (month === 5 && day <= 20)) return 3;
  
          
          if ((month === 5 && day >= 21) || (month === 6 && day <= 20)) return 4;
  
          
          if ((month === 6 && day >= 21) || (month === 7 && day <= 22)) return 5;
  
          
          if ((month === 7 && day >= 23) || (month === 8 && day <= 22)) return 6;
  
         
          if ((month === 8 && day >= 23) || (month === 9 && day <= 22)) return 7;
  
          
          if ((month === 9 && day >= 23) || (month === 10 && day <= 22)) return 8;
  
          
          if ((month === 10 && day >= 23) || (month === 11 && day <= 21)) return 9;
  
          
          if ((month === 11 && day >= 22) || (month === 12 && day <= 21)) return 10;
  
          
          return 11;
        }     
        
        function updateZodiacSign() {
          const date = new Date();
          const month = date.getMonth() + 1;
          const day = date.getDate();
          const newIndex = getZodiacSign(month, day);
  
          zodiacImage.setProperty(hmUI.prop.SRC, 'zodiac_' + newIndex + '.png');
        }    
        // end zodiac
        //end of ignored block
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 6  
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_heart_rate_text_font = ''
        let normal_step_current_text_font = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_current_text_font = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_timerUpdateSecSmooth = undefined;
        let normal_image_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_wind_icon_img = ''
        let idle_wind_current_text_font = ''
        let idle_system_disconnect_img = ''
        let idle_heart_rate_text_font = ''
        let idle_step_current_text_font = ''
        let idle_city_name_text = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота', 'воскресенье'];
        let idle_month_name_font = ''
        let idle_Month_Array = ['Янв.', 'Фев.', 'Мрт.', 'Апр.', 'Мая.', 'Июн.', 'Июл.', 'Авг.', 'Сен.', 'Окт.', 'Ноя.', 'Дек.', ];
        let idle_day_text_font = ''
        let idle_battery_icon_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_current_text_font = ''
        let idle_image_img = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''        
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
            function click_Bezel() {
              if(bezel_num>=bezel_all) {bezel_num=1;}
              else { bezel_num=bezel_num+1;}
              hmUI.showToast({text: "Цвет " + parseInt(bezel_num) });
                normal_background_bg_img.setProperty(hmUI.prop.SRC, "osn_" + parseInt(bezel_num) + ".png");

            }                     
                
            // FontName: Bicubik.ttf; FontSize: 35
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 615,
              h: 52,
              text_size: 35,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Bicubik.ttf; FontSize: 15
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 246,
              h: 21,
              text_size: 15,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Bicubik.ttf; FontSize: 25
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 450,
              h: 38,
              text_size: 25,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Bicubik.ttf; FontSize: 50
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 830,
              h: 74,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Bicubik.ttf; FontSize: 15; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 18,
              h: 18,
              text_size: 15,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Bicubik.ttf; FontSize: 35; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 42,
              h: 42,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Bicubik.ttf; FontSize: 50; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 60,
              h: 60,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

            let sleep_time_txt = ''
            let sleep_start_time_txt = ''
            let sleep_end_time_txt = ''
            let sleep_score_txt = ''
            let wake_time_txt = ''

            const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
            let sleepInfo = sleep.getBasicInfo();
            
            let sleepTotalTime = sleep.getTotalTime();		
            let sleepStartTime = sleepInfo.startTime;
            let sleepEndTime = sleepInfo.endTime + 1;
            let sleepScore = sleepInfo.score;

        //время пробуждений	
            let sleepStageArray = sleep.getSleepStageData();
            const modelData = sleep.getSleepStageModel();
        //		

            function updateSleepInfo() {
                sleepTotalTime = sleep.getTotalTime();
                sleepInfo = sleep.getBasicInfo();
                sleepStartTime = sleepInfo.startTime;
                if (sleepStartTime >= 24*60) {
                    sleepStartTime -= 24*60
                }
                
                sleepEndTime = sleepInfo.endTime + 1;
                if (sleepEndTime >= 24*60) {
                    sleepEndTime -= 24*60
                }

            // время пробуждений
                let wakeTime = 0;
                sleepStageArray = sleep.getSleepStageData();
                
                for (let i = 0; i < sleepStageArray.length; i++) {
                let data = sleepStageArray[i];
                if (data.model == modelData.WAKE_STAGE){
                        wakeTime += data.stop + 1 - data.start;
                }

                }
                
                sleepTotalTime -= wakeTime;
           //
                
                sleep_time_txt.setProperty(hmUI.prop.TEXT, ' ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
                sleep_start_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepStartTime / 60).toString().padStart(2, "0") + ':' + (sleepStartTime % 60).toString().padStart(2, "0"));
                sleep_end_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepEndTime / 60).toString().padStart(2, "0") + ':' + (sleepEndTime % 60).toString().padStart(2, "0"));
                wake_time_txt.setProperty(hmUI.prop.TEXT, 'Не спали: ' + String(wakeTime) + ' мин.');
                sleep_score_txt.setProperty(hmUI.prop.TEXT, ' ' + String(sleepScore));
            }
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
            sleep_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 162,
              y: 369,
              w: 150,
              h: 30,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "--",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //

            const weatherInfo = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
            });
              
            weatherImg = weatherInfo.createWidget(hmUI.widget.IMG, {
                x: 81,
                y: 85,
                w: 80,
                h: 80,
                src: 'w_25.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            }); 
              
            tempText = weatherInfo.createWidget(hmUI.widget.TEXT, {
                x: 65,
                y: 145,
                w: 100,
                h: 30,
                text_size: 25,
                char_space: 1,
                line_space: 0,
                font: 'fonts/Bicubik.ttf',
                text: '--',
                color: 0xFF000000,
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.TOP,
                unit_type: 1,
                text_style: hmUI.text_style.ELLIPSIS,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });   
              
            descriptionText = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 129,
                y: 59,
                w: 222,
                h: 30,
                text_size: 15,
                char_space: 0,
                line_space: 0,
                font: 'fonts/Bicubik.ttf',
                text: '--',
                color: 0xFFFFFFFF,
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.TOP,
                text_style: hmUI.text_style.ELLIPSIS,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });           

            // экземпляр класса
            weatherProvider = new WeatherProvider({
                night_icons: [0, 1, 2, 3, 14],
                show_toast: false,
                temp_widget: tempText,
                temp_max_widget: tempMaxText,
                temp_min_widget: tempMinText,
                temp_feels_widget: tempFeelsText,
                description_widget: descriptionText,
                cityName_widget: cityNameText,
                icon_widget: weatherImg,
                time_sensor: curTime,
                weather_sensor: weather,
            });              

  

            // end user_script.js

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 414,
              y: 280,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 234,
              y: 3,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_ALARM_CLOCK_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 19,
              font_array: ["alarm_0.png", "alarm_1.png", "alarm_2.png", "alarm_3.png", "alarm_4.png", "alarm_5.png", "alarm_6.png", "alarm_7.png", "alarm_8.png", "alarm_9.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'alarm_off.png',
              dot_image: 'alarm_dv.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });              

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 33,
              y: 280,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 166,
              y: 101,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 141,
              y: 147,
              w: 200,
              h: 50,
              text_size: 35,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 137,
              y: 374,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 195,
              y: 374,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 77,
              y: 328,
              week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 228,
              month_startY: 277,
              month_sc_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_tc_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_en_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 121,
              day_startY: 278,
              day_sc_array: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png"],
              day_tc_array: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png"],
              day_en_array: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 154,
              y: 399,
              src: 'bat100.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 160,
              // start_y: 404,
              // color: 0xFFFFFFFF,
              // lenght: 160,
              // line_width: 13,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 201,
              y: 429,
              w: 100,
              h: 35,
              text_size: 25,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sekk.png',
              // center_x: 422,
              // center_y: 118,
              // x: 61,
              // y: 61,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 422 - 61,
              pos_y: 118 - 61,
              center_x: 422,
              center_y: 118,
              src: 'sekk.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });            

            // Получаем текущую дату
            const date = new Date();
            const month = date.getMonth() + 1; // Месяцы от 1 до 12
            const day = date.getDate();
            // Определяем индекс знака зодиака
            const index_zodiac = getZodiacSign(month, day);
            // Создаем виджет изображения
            zodiacImage = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zodiac_' + index_zodiac + '.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            
            updateZodiacSign();              

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
           

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 332,
              am_y: 147,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 332,
              pm_y: 147,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 17,
              hour_startY: 168,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 246,
              minute_startY: 168,
              minute_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 332,
              y: 145,
              src: 'ms.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 293,
              y: 96,
              w: 150,
              h: 60,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 4,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 166,
              y: 101,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 141,
              y: 147,
              w: 200,
              h: 50,
              text_size: 35,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 129,
              y: 59,
              w: 222,
              h: 30,
              text_size: 15,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 81,
              y: 85,
              image_array: ["wAOD_0.png","wAOD_1.png","wAOD_2.png","wAOD_3.png","wAOD_4.png","wAOD_5.png","wAOD_6.png","wAOD_7.png","wAOD_8.png","wAOD_9.png","wAOD_10.png","wAOD_11.png","wAOD_12.png","wAOD_13.png","wAOD_14.png","wAOD_15.png","wAOD_16.png","wAOD_17.png","wAOD_18.png","wAOD_19.png","wAOD_20.png","wAOD_21.png","wAOD_22.png","wAOD_23.png","wAOD_24.png","wAOD_25.png","wAOD_26.png","wAOD_27.png","wAOD_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 65,
              y: 147,
              w: 100,
              h: 30,
              text_size: 25,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 70,
              y: 332,
              w: 350,
              h: 50,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: понедельник, вторник, среда, четверг, пятница, суббота, воскресенье,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 233,
              y: 279,
              w: 150,
              h: 60,
              text_size: 50,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: Янв., Фев., Мрт., Апр., Мая., Июн., Июл., Авг., Сен., Окт., Ноя., Дек.,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 92,
              y: 279,
              w: 150,
              h: 60,
              text_size: 50,
              char_space: 4,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 154,
              y: 399,
              src: 'bat100.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 160,
              // start_y: 404,
              // color: 0xFF000000,
              // lenght: 160,
              // line_width: 13,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 201,
              y: 429,
              w: 100,
              h: 35,
              text_size: 25,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Bicubik.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 17,
              hour_startY: 168,
              hour_array: ["HAOD_0.png","HAOD_1.png","HAOD_2.png","HAOD_3.png","HAOD_4.png","HAOD_5.png","HAOD_6.png","HAOD_7.png","HAOD_8.png","HAOD_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 246,
              minute_startY: 168,
              minute_array: ["HAOD_0.png","HAOD_1.png","HAOD_2.png","HAOD_3.png","HAOD_4.png","HAOD_5.png","HAOD_6.png","HAOD_7.png","HAOD_8.png","HAOD_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 128,
              w: 90,
              h: 45,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 81,
              w: 90,
              h: 45,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 196,
              y: 404,
              w: 100,
              h: 52,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 134,
              y: 365,
              w: 55,
              h: 30,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 34,
              y: 278,
              w: 38,
              h: 40,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 87,
              y: 83,
              w: 50,
              h: 50,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 304,
              y: 191,
              w: 100,
              h: 65,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 387,
              y: 85,
              w: 67,
              h: 65,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 196,
              y: 6,
              w: 89,
              h: 38,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 364,
              w: 80,
              h: 33,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 66,
              y: 356,
              w: 39,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 377,
              y: 358,
              w: 39,
              h: 49,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'MusicCommonScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 287,
              w: 77,
              h: 62,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 149,
              y: 192,
              w: 60,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 48,
              y: 200,
              w: 45,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 86,
              y: 140,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button    
            
            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 27,
              y: 151,
              w: 40,
              h: 40,
              text: '',
              text_size: 25,
              color: 0xFFFF8C00,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: () => {                
                weatherProvider.prev(true);                
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });    
            
            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 414,
              y: 309,
              text: '',
              w: 50,
              h: 50,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
               click_Bezel();               
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);              

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second); 

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('month font');
              if (updateHour) {
                let idle_Month_Str = idle_Month_Array[timeSensor.month-1];
                idle_month_name_font.setProperty(hmUI.prop.TEXT, idle_Month_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 160;
                  let start_y_normal_battery = 404;
                  let lenght_ls_normal_battery = 160;
                  let line_width_ls_normal_battery = 13;
                  let color_ls_normal_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 160;
                  let start_y_idle_battery = 404;
                  let lenght_ls_idle_battery = 160;
                  let line_width_ls_idle_battery = 13;
                  let color_ls_idle_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType                    


                console.log('resume_call.js');
                // start resume_call.js

//
              updateZodiacSign();
              updateSleepInfo();
            //
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }                    

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}