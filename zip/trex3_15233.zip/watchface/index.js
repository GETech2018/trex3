﻿	/********************************
	*								*
	*		ATM Pressure			*
	*		Balance / T-Rex 3		*
	*		2025 © leXxiR [4pda]	*
	*								*
	********************************/
   
    try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;


        const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT } = hmSetting.getDeviceInfo();
		const radius = DEVICE_WIDTH / 2, centerX = DEVICE_WIDTH / 2, centerY = DEVICE_HEIGHT / 2

		let isAOD = hmSetting.getScreenType() == hmSetting.screen_type.AOD;
        
		const curTime = hmSensor.createSensor(hmSensor.id.TIME);
		const step = hmSensor.createSensor(hmSensor.id.STEP);
        const battery = hmSensor.createSensor(hmSensor.id.BATTERY);

		let dateText, battText
		let stepScale, pointer


//------------- шкала ------------------
		let lastLevel = 0

		function updateScale() {
			if (!isAOD) {			
				let level = Math.round(step.current / step.target * 100);
				if (level > 100) level = 100;
				
				if (stepScale && lastLevel != level) {
					lastLevel = level;
					stepScale.setProperty(hmUI.prop.MORE, {
					  center_x: centerX,
					  center_y: centerY,
					  start_angle: 223,
					  end_angle: 41,
					  radius: 147,
					  line_width: 42,
					  corner_flag: 3,
					  color: 0xA70D1A,
					  show_level: hmUI.show_level.ONLY_NORMAL,
					  level: level,
					});
				}
			}
		}


//------------- дата ------------------
		let lastDate = 0

		function updateDate() {
			if (curTime.day != lastDate){
				lastDate = curTime.day;
				dateText.setProperty(hmUI.prop.TEXT, curTime.day.toString());
			}
		}



//--------------------- давление ----------------------
		
		function readPressureData() {		// чтение файла с данными атмосферного давления
			//console.log("read_pressure()");
			const file_name_alt = "../../../baro_altim/pressure.dat";
			const [fs_stat, err] = hmFS.stat(file_name_alt);
			if (err == 0) {
			  let file_size = fs_stat.size;
			  const len = file_size / 4;
			  //console.log(`size_alt: ${file_size}, lenght: ${len}`)
			  const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)
		  
			  let array_buffer = new Float32Array(len);
			  hmFS.read(fh, array_buffer.buffer, 0, file_size);
			  hmFS.close(fh);
			  console.log(`value ${array_buffer[array_buffer.length -1]}`);
			  return array_buffer;
			} else {
			  console.log('err:', err)
			}
			return null;
		}
	 
		function getPressureValue(pressure_array) {
			if(pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
			let start_index = pressure_array.length - 1;
			let end_index = start_index - 30 * 3; // 3 часа
			if(end_index < 0) end_index = 0;
			for (let index = start_index; index >= end_index; index--) {
			  if(pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
			}
			return 0;
		}
		  
		
		let lastAngle = 0
		
		function updatePressure() {						// получить текущее значение давления и установить указатель
														// угол поворота  228 .. 312
														// 740 мм рт.ст. соответствует углу 270, 	+10 мм ~ 12 градусов
			let pressure_array = readPressureData();
			const val = Math.round(getPressureValue(pressure_array) * 0.750064);		// получаем давление и переводим в мм рт. ст.
			//const val = randomInt(680, 850);
			//console.log('mmHg: ' + val);
			
			pointer.setProperty(hmUI.prop.VISIBLE, val);		// прячем указатель, если нет данных о давлении
	
			let angle = 270 + (val - 740) * 1.2;
			if (angle > 312) angle = 312
			else if (angle < 228) angle = 228;

			if (angle != lastAngle){
				lastAngle = angle;
				pointer.setProperty(hmUI.prop.MORE, {
				  x: 0,
				  y: 0,
				  w: DEVICE_WIDTH,
				  h: DEVICE_HEIGHT,
				  src: 'pointer.png',
				  pos_x: centerX - 28,
				  pos_y: 0,
				  center_x: centerX,
				  center_y: centerY,
				  angle: angle,			
				  show_level: hmUI.show_level.ONLY_NORMAL,
				});
			}
		}


		function randomInt(...args) {
			let min = 0;
			let max = args[0];
			if (args.length > 1) {
				min = args[0];
				max = args[1];
			}
			let rand = min + Math.random() * (max + 1 - min);
			return Math.floor(rand);
		}


//------------- батарея ------------------
		function updateBattery() {
			const val = battery.current.toString();
			battText.setProperty(hmUI.prop.TEXT, val);
		}

//------------- обновить все данные ------------------
		function updateAllInfo() {
			updatePressure();
			updateBattery();
			updateDate();
			updateScale();
		}



//-----------------------------------------
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                    
            hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: DEVICE_WIDTH,
              h: DEVICE_HEIGHT,
			  radius: radius,
              color: 0x4A4A4A,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            stepScale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: centerX,
              center_y: centerY,
              start_angle: 223,
              end_angle: 41,
              radius: 147,
              line_width: 42,
              corner_flag: 3,
              color: 0xA70D1A,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            

            hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


			hmUI.createWidget(hmUI.widget.TEXT, {
				x: DEVICE_WIDTH - 70,
				y: 30,
				w: 70,
				h: 30,
				text_size: 24,
				text: 'leXxiR',
				color: 0xffffff,
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V,
			});

			hmUI.createWidget(hmUI.widget.TEXT, {
				x: DEVICE_WIDTH - 59,
				y: 55,
				w: 70,
				h: 30,
				text_size: 24,
				text: '4pda',
				color: 0x4bd9da,
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V,
			});

            battText = hmUI.createWidget(hmUI.widget.TEXT, {	//_FONT
              x: 108,
              y: 232,
              w: 100,
              h: 48,
              text_size: 38,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              //type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            dateText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 274,
              y: 232,
              w: 100,
              h: 48,
              text_size: 38,
              char_space: 0,
              line_space: 0,
              color: 0xFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: DEVICE_WIDTH - 115,
              y: centerY - 155,
              src: 'status_bt.png',
              type: hmUI.system_status.DISCONNECT,
            });

            pointer = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
			  w: DEVICE_WIDTH,
			  h: DEVICE_HEIGHT,
              src: 'pointer.png',
              pos_x: centerX - 28,
              pos_y: 0,
              center_x: centerX,
              center_y: centerY,
			  angle: 270,			// 230 .. 310
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'handHS.png',
              hour_centerX: centerX + 4,
              hour_centerY: centerY + 7,
              hour_posX: 45,
              hour_posY: 200,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'handH.png',
              hour_centerX: centerX,
              hour_centerY: centerY,
              hour_posX: 45,
              hour_posY: 200,
            });

            hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'handMS.png',
              minute_centerX: centerX + 6,
              minute_centerY: centerY + 8,
              minute_posX: 42,
              minute_posY: 229,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'handM.png',
              minute_centerX: centerX,
              minute_centerY: centerY,
              minute_posX: 42,
              minute_posY: 229,
            });

            hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'handSS.png',
              second_centerX: centerX + 7,
              second_centerY: centerY + 10,
              second_posX: 38,
              second_posY: 232,
			  fresh_frequency: 25,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'handS.png',
              second_centerX: centerX,
              second_centerY: centerY,
              second_posX: 38,
              second_posY: 232,
			  fresh_frequency: 25,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hmUI.createWidget(hmUI.widget.IMG, {
              x: centerX - 10,
              y: centerY - 10,
              src: 'pin.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

			updateAllInfo();

            step.addEventListener(hmSensor.event.CHANGE, function() {
				updateScale();
            });

			curTime.addEventListener(curTime.event.MINUTEEND, function () {
				updateAllInfo();
			});

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                updateAllInfo();
              }),
            });


            },
            onInit() {
            },
            build() {
                this.init_view();
            },
            onDestroy() {
            }
        });
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}