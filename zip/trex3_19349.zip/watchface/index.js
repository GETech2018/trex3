﻿    /*
    ** Watch_Face_Editor tool v 18.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }
			
      let gybrbatt_num = 0
       let gybrbatt_all = 1
		function click_gybrbatt() {
		  gybrbatt_num = (gybrbatt_num + 1) % (gybrbatt_all + 1);
          if (gybrbatt_num == 0) {	
		  normal_bio_charge_circle_scale.setProperty(hmUI.prop.VISIBLE, true);	 
          normal_bio_charge_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);			  
          normal_bio_charge_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
		  normal_widget_text_2.setProperty(hmUI.prop.VISIBLE, true);
		  normal_bio_charge_icon_img.setProperty(hmUI.prop.VISIBLE, true);
          normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, false);	
          normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
          normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		  normal_widget_text_3.setProperty(hmUI.prop.VISIBLE, false);	
          		  
		  };
          if (gybrbatt_num == 1) {			  
		  normal_bio_charge_circle_scale.setProperty(hmUI.prop.VISIBLE, false);	  
		  normal_bio_charge_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
          normal_bio_charge_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
		  normal_widget_text_2.setProperty(hmUI.prop.VISIBLE, false);
          normal_bio_charge_icon_img.setProperty(hmUI.prop.VISIBLE, false);		  
          normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, true);
		  normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
          normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, true);
		  normal_widget_text_3.setProperty(hmUI.prop.VISIBLE, true);
		  };	 	  
		}	
		
        let DataColor = "0xFFd78454"
		let bg_img = "bg-1.png"
		let bio_pointer = "strelka-pr.png"
		let batt_pointer = "strelka-pr.png"
		let minute = ["Minute1-0.png","Minute1-1.png","Minute1-2.png","Minute1-3.png","Minute1-4.png","Minute1-5.png","Minute1-6.png","Minute1-7.png","Minute1-8.png","Minute1-9.png"]
        let step = "strelka-lev.png";
				
        let tap_dannye = 0;
        /* функция смены цветов массива данных */
            function click_dannye() {
            tap_dannye = (tap_dannye + 1) % 2;

        switch (tap_dannye) {
	
        case 0:
        /* кейс для первого цвета */
        DataColor = "0xFFd78454"
		bg_img = "bg-1.png";
		bio_pointer = "strelka-pr.png";
		batt_pointer = "strelka-pr.png";
		step = "strelka-lev.png";
		minute = ["Minute1-0.png","Minute1-1.png","Minute1-2.png","Minute1-3.png","Minute1-4.png","Minute1-5.png","Minute1-6.png","Minute1-7.png","Minute1-8.png","Minute1-9.png"];
        break;

        case 1:
        /* кейс для второго цвета */
        DataColor = "0xFF396c98"
		bg_img = "bg-2.png";
        bio_pointer = "strelka-pr2.png";
        batt_pointer = "strelka-pr2.png";
        step = "strelka-lev2.png";		
       minute = ["Minute2-0.png","Minute2-1.png","Minute2-2.png","Minute2-3.png","Minute2-4.png","Minute2-5.png","Minute2-6.png","Minute2-7.png","Minute2-8.png","Minute2-9.png"];		
        break;

        default:
        /* кейс для цвета по умолчанию/первого */	
        DataColor = "0xFFd78454"
		bg_img = "bg-1.png";	
        bio_pointer = "strelka-pr.png";
        batt_pointer = "strelka-pr.png";
        step = "strelka-lev.png";		
        minute = ["Minute1-0.png","Minute1-1.png","Minute1-2.png","Minute1-3.png","Minute1-4.png","Minute1-5.png","Minute1-6.png","Minute1-7.png","Minute1-8.png","Minute1-9.png"];		
}

            normal_background_bg_img.setProperty(hmUI.prop.MORE, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: bg_img,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           normal_bio_charge_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: bio_pointer,
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: 128,
              end_angle: 54,
              invalid_visible: false,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: batt_pointer,
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: 128,
              end_angle: 54,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });			

            normal_digital_clock_img_time.setProperty(hmUI.prop.MORE, {
              hour_startX: 48,
              hour_startY: 182,
              hour_array: ["Hour-0.png","Hour-1.png","Hour-2.png","Hour-3.png","Hour-4.png","Hour-5.png","Hour-6.png","Hour-7.png","Hour-8.png","Hour-9.png"],
              hour_zero: 1,
              hour_space: -18,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 196,
              minute_startY: 181,
              minute_array: minute,
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 370,
              second_startY: 191,
              second_array: ["Sec-0.png","Sec-1.png","Sec-2.png","Sec-3.png","Sec-4.png","Sec-5.png","Sec-6.png","Sec-7.png","Sec-8.png","Sec-9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font.setProperty(hmUI.prop.MORE, {
              x: 180,			
              y: 332,					
              w: 120,
              h: 61,
              text_size: 52,
              char_space: 0,
              font: 'fonts/EurostileBold.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_step_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 64,
              y: 68,
              w: 120,
              h: 42,
              text_size: 32,
              char_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_bio_charge_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 301,
              y: 68,
              w: 120,
              h: 42,
              text_size: 32,
              char_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_current_text_font.setProperty(hmUI.prop.MORE, {
              x: 301,
              y: 68,
              w: 120,
              h: 42,
              text_size: 32,
              char_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_widget_text_1.setProperty(hmUI.prop.MORE, {
              x: 72,
              y: 372,
              w: 90,
              h: 40,
              text_size: 22,
              char_space: 0,
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'ШАГИ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2.setProperty(hmUI.prop.MORE, {
              x: 320,
              y: 372,
              w: 90,
              h: 40,
              text_size: 22,
              char_space: 0,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'ГБРЗ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_3.setProperty(hmUI.prop.MORE, {
              x: 320,
              y: 372,
              w: 90,
              h: 40,
              text_size: 22,
              char_space: 0,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: DataColor,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'БАТ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_widget_text_4.setProperty(hmUI.prop.MORE, {
              // x: 195,
              // y: 301,
              // w: 90,
              // h: 40,
              // text_size: 22,
              // char_space: 0,
              // font: 'fonts/NotoSansMedium_ASm_01.ttf',
              // color: DataColor,
              // line_space: 0,
              // align_v: hmUI.align.CENTER_V,
              // text_style: hmUI.text_style.NONE,
              // align_h: hmUI.align.CENTER_H,
              // text: 'ЧСС',
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            normal_bio_charge_circle_scale.setProperty(hmUI.prop.MORE, {			
              center_x: 240,			
              center_y: 240,	
              start_angle: 127,
              end_angle: 54,
              radius: 223,
              line_width: 3,
              corner_flag: 3,
              type: hmUI.data_type.BIO_CHARGE,
              color: DataColor,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            // normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 127,
              // end_angle: 54,
              // radius: 223,
              // line_width: 3,
              // corner_flag: 3,
              // color: DataColor,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
			
            normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: step,
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -128,
              end_angle: -54,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
	}		
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_body_temp_current_text_font = ''
        let normal_day_text_font = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['ПНД', 'ВТР', 'СРЕ', 'ЧТВ', 'ПТН', 'СУБ', 'ВСК'];
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_step_circle_scale = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_font = ''
        let normal_bio_charge_icon_img = ''
        let normal_bio_charge_circle_scale = ''
        let normal_bio_charge_pointer_progress_img_pointer = ''
        let normal_bio_charge_current_text_font = ''
        let normal_battery_circle_scale = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_current_text_font = ''
        let normal_digital_clock_img_time = ''
        let normal_widget_text_1 = ''
        let normal_widget_text_2 = ''
        let normal_widget_text_3 = ''
        let normal_widget_text_4 = ''
        let idle_background_bg_img = ''
        let idle_body_temp_current_text_font = ''
        let idle_day_text_font = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['ПНД', 'ВТР', 'СРЕ', 'ЧТВ', 'ПТН', 'СУБ', 'ВСК'];
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_heart_rate_text_font = ''
        let idle_step_circle_scale = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_font = ''
        let idle_bio_charge_circle_scale = ''
        let idle_bio_charge_pointer_progress_img_pointer = ''
        let idle_bio_charge_current_text_font = ''
        let idle_digital_clock_img_time = ''
        let idle_widget_text_1 = ''
        let idle_widget_text_2 = ''
        let idle_widget_text_3 = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: allfontASm_01-regular.ttf; FontSize: 34
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 469,
              h: 58,
              text_size: 34,
              char_space: 0,
              line_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFA6A6A6,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: NotoSansMedium_ASm_01.ttf; FontSize: 32
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 444,
              h: 56,
              text_size: 32,
              char_space: 0,
              line_space: 0,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: allfontASm_01-regular.ttf; FontSize: 27; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 32,
              h: 32,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFA6A6A6,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: allfontASm_01-regular.ttf; FontSize: 36
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 524,
              h: 62,
              text_size: 36,
              char_space: 1,
              line_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFA6A6A6,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: EurostileBold.ttf; FontSize: 52
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 849,
              h: 75,
              text_size: 52,
              char_space: 0,
              line_space: 0,
              font: 'fonts/EurostileBold.ttf',
              color: 0xFFCB784B,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: allfontASm_01-regular.ttf; FontSize: 32
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 441,
              h: 56,
              text_size: 32,
              char_space: 0,
              line_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFCB784B,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: NotoSansMedium_ASm_01.ttf; FontSize: 22
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 302,
              h: 38,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFCB784B,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _+-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg-1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_body_temp_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 180,
              y: 387,
              w: 120,
              h: 42,
              text_size: 34,
              char_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFA6A6A6,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 370,
              y: 249,
              w: 70,
              h: 42,
              text_size: 32,
              char_space: 0,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 370,
              y: 222,
              w: 70,
              h: 42,
              text_size: 27,
              char_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFA6A6A6,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: ПНД, ВТР, СРЕ, ЧТВ, ПТН, СУБ, ВСК,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 216,
              y: 15,
              image_array: ["w_00.png","w_01.png","w_02.png","w_03.png","w_04.png","w_05.png","w_06.png","w_07.png","w_08.png","w_09.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 180,
              y: 68,
              w: 120,
              h: 42,
              text_size: 36,
              char_space: 1,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFA6A6A6,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 180,
              y: 332,
              w: 120,
              h: 61,
              text_size: 52,
              char_space: 0,
              font: 'fonts/EurostileBold.ttf',
              color: 0xFFCB784B,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -127,
              // end_angle: -53,
              // radius: 224,
              // line_width: 3,
              // line_cap: Flat,
              // color: 0xFF353535,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -53,
              end_angle: -127,
              radius: 223,
              line_width: 3,
              corner_flag: 3,
              color: 0xFF353535,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'strelka-lev.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -128,
              end_angle: -54,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 64,
              y: 68,
              w: 120,
              h: 42,
              text_size: 32,
              char_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFCB784B,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'img-hybryd.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 127,
              end_angle: 54,
              radius: 222,
              line_width: 4,
              corner_flag: 3,
              type: hmUI.data_type.BIO_CHARGE,
              color: 0xFFCB784B,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'strelka-pr.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: 128,
              end_angle: 54,
              invalid_visible: false,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_bio_charge_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 301,
              y: 68,
              w: 120,
              h: 42,
              text_size: 32,
              char_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFCB784B,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 127,
              // end_angle: 53,
              // radius: 224,
              // line_width: 3,
              // line_cap: Flat,
              // color: 0xFF353535,
              // mirror: False,
              // inversion: True,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 53,
              end_angle: 127,
              radius: 223,
              line_width: 3,
              corner_flag: 3,
              color: 0xFF353535,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'strelka-pr.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: 128,
              end_angle: 54,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 301,
              y: 68,
              w: 120,
              h: 42,
              text_size: 32,
              char_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFCB784B,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 48,
              hour_startY: 182,
              hour_array: ["Hour-0.png","Hour-1.png","Hour-2.png","Hour-3.png","Hour-4.png","Hour-5.png","Hour-6.png","Hour-7.png","Hour-8.png","Hour-9.png"],
              hour_zero: 1,
              hour_space: -18,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 196,
              minute_startY: 181,
              minute_array: ["Minute1-0.png","Minute1-1.png","Minute1-2.png","Minute1-3.png","Minute1-4.png","Minute1-5.png","Minute1-6.png","Minute1-7.png","Minute1-8.png","Minute1-9.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 370,
              second_startY: 191,
              second_array: ["Sec-0.png","Sec-1.png","Sec-2.png","Sec-3.png","Sec-4.png","Sec-5.png","Sec-6.png","Sec-7.png","Sec-8.png","Sec-9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 72,
              y: 372,
              w: 90,
              h: 40,
              text_size: 22,
              char_space: 0,
              color: 0xFFCB784B,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'ШАГИ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 320,
              y: 372,
              w: 90,
              h: 40,
              text_size: 22,
              char_space: 0,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFCB784B,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'ГБРЗ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 320,
              y: 372,
              w: 90,
              h: 40,
              text_size: 22,
              char_space: 0,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFCB784B,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'БАТ',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 195,
              y: 301,
              w: 90,
              h: 40,
              text_size: 22,
              char_space: 0,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFA6A6A6,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'ЧСС',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg-AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_body_temp_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 180,
              y: 387,
              w: 120,
              h: 42,
              text_size: 34,
              char_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFCDCDCD,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BODY_TEMP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 370,
              y: 249,
              w: 70,
              h: 42,
              text_size: 32,
              char_space: 0,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 370,
              y: 215,
              w: 70,
              h: 42,
              text_size: 27,
              char_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // unit_string: ПНД, ВТР, СРЕ, ЧТВ, ПТН, СУБ, ВСК,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 216,
              y: 15,
              image_array: ["w_00.png","w_01.png","w_02.png","w_03.png","w_04.png","w_05.png","w_06.png","w_07.png","w_08.png","w_09.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 180,
              y: 68,
              w: 120,
              h: 42,
              text_size: 36,
              char_space: 1,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 180,
              y: 332,
              w: 120,
              h: 61,
              text_size: 52,
              char_space: 0,
              font: 'fonts/EurostileBold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -127,
              // end_angle: -54,
              // radius: 224,
              // line_width: 3,
              // line_cap: Flat,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -127,
              end_angle: -54,
              radius: 223,
              line_width: 3,
              corner_flag: 3,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'strelka-levAOD.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: -128,
              end_angle: -54,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 64,
              y: 68,
              w: 120,
              h: 42,
              text_size: 32,
              char_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 127,
              end_angle: 54,
              radius: 223,
              line_width: 3,
              corner_flag: 3,
              type: hmUI.data_type.BIO_CHARGE,
              color: 0xFFFFFFFF,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'strelka-prAOD.png',
              center_x: 240,
              center_y: 240,
              x: 240,
              y: 240,
              start_angle: 128,
              end_angle: 54,
              invalid_visible: false,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_bio_charge_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 301,
              y: 68,
              w: 120,
              h: 42,
              text_size: 32,
              char_space: 0,
              font: 'fonts/allfontASm_01-regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 48,
              hour_startY: 182,
              hour_array: ["TimeAOD-0.png","TimeAOD-1.png","TimeAOD-2.png","TimeAOD-3.png","TimeAOD-4.png","TimeAOD-5.png","TimeAOD-6.png","TimeAOD-7.png","TimeAOD-8.png","TimeAOD-9.png"],
              hour_zero: 1,
              hour_space: -18,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 196,
              minute_startY: 181,
              minute_array: ["TimeAOD-0.png","TimeAOD-1.png","TimeAOD-2.png","TimeAOD-3.png","TimeAOD-4.png","TimeAOD-5.png","TimeAOD-6.png","TimeAOD-7.png","TimeAOD-8.png","TimeAOD-9.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 72,
              y: 372,
              w: 90,
              h: 40,
              text_size: 22,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'ШАГИ',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 320,
              y: 372,
              w: 90,
              h: 40,
              text_size: 22,
              char_space: 0,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'ГБРЗ',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 195,
              y: 301,
              w: 90,
              h: 40,
              text_size: 22,
              char_space: 0,
              font: 'fonts/NotoSansMedium_ASm_01.ttf',
              color: 0xFFCECECE,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'ЧСС',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 4,
              w: 100,
              h: 100,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
vibro(23);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 376,
              w: 70,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
vibro(23);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 330,
              y: 376,
              w: 70,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_gybrbatt();
vibro(23);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 74,
              y: 200,
              w: 100,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                click_dannye();
vibro(23);

              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 201,
              y: 341,
              w: 78,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'empty.png',
              normal_src: 'empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
vibro(23);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

        if (screenType != hmSetting.screen_type.AOD) {
          normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, false);	
          normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
          normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, false);
          normal_widget_text_3.setProperty(hmUI.prop.VISIBLE, false);			  
    	};	
            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -53,
                      end_angle: -127,
                      radius: 223,
                      line_width: 3,
                      corner_flag: 3,
                      color: 0xFF353535,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 53,
                      end_angle: 127,
                      radius: 223,
                      line_width: 3,
                      corner_flag: 3,
                      color: 0xFF353535,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -127,
                      end_angle: -54,
                      radius: 223,
                      line_width: 3,
                      corner_flag: 3,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}