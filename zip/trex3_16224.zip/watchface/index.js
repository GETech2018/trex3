﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_fat_burning_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_sun_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_max_min_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_vo2max_text_text_img = ''
        let normal_vo2max_image_progress_img_level = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 13;
        let normal_heart_rate_TextCircle_img_height = 18;
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_fat_burning_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_sun_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_max_min_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_vo2max_text_text_img = ''
        let idle_vo2max_image_progress_img_level = ''
        let idle_heart_rate_TextCircle = new Array(3);
        let idle_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let idle_heart_rate_TextCircle_img_width = 13;
        let idle_heart_rate_TextCircle_img_height = 18;
        let idle_heart_rate_image_progress_img_level = ''
        let idle_battery_image_progress_img_level = ''
        let idle_calorie_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_vo2max_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 191,
              y: 295,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 148,
              month_startY: 295,
              month_sc_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              month_tc_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              month_en_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 102,
              day_startY: 295,
              day_sc_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              day_tc_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              day_en_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              day_zero: 1,
              day_space: 2,
              day_unit_sc: 'fu.png',
              day_unit_tc: 'fu.png',
              day_unit_en: 'fu.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 299,
              y: 103,
              src: 'run.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 88,
              font_array: ["dist_0.png","dist_1.png","dist_2.png","dist_3.png","dist_4.png","dist_5.png","dist_6.png","dist_7.png","dist_8.png","dist_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 144,
              y: 373,
              font_array: ["fat_0.png","fat_1.png","fat_2.png","fat_3.png","fat_4.png","fat_5.png","fat_6.png","fat_7.png","fat_8.png","fat_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 373,
              font_array: ["fat_0.png","fat_1.png","fat_2.png","fat_3.png","fat_4.png","fat_5.png","fat_6.png","fat_7.png","fat_8.png","fat_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 318,
              y: 295,
              font_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'colon.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 82,
              y: 156,
              image_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 161,
              font_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'du.png',
              unit_tc: 'du.png',
              unit_en: 'du.png',
              negative_image: 'fu.png',
              dot_image: 'sl.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 118,
              y: 160,
              font_array: ["temp_0.png","temp_1.png","temp_2.png","temp_3.png","temp_4.png","temp_5.png","temp_6.png","temp_7.png","temp_8.png","temp_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'du.png',
              unit_tc: 'du.png',
              unit_en: 'du.png',
              negative_image: 'fu.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 43,
              y: 337,
              font_array: ["vo2num_0.png","vo2num_1.png","vo2num_2.png","vo2num_3.png","vo2num_4.png","vo2num_5.png","vo2num_6.png","vo2num_7.png","vo2num_8.png","vo2num_9.png"],
              padding: false,
              h_space: 0,
              angle: 58,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 16,
              y: 150,
              image_array: ["vo2lvl_1.png","vo2lvl_2.png","vo2lvl_3.png","vo2lvl_4.png","vo2lvl_5.png","vo2lvl_6.png","vo2lvl_7.png"],
              image_length: 7,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["vo2num_0.png","vo2num_1.png","vo2num_2.png","vo2num_3.png","vo2num_4.png","vo2num_5.png","vo2num_6.png","vo2num_7.png","vo2num_8.png","vo2num_9.png"],
              // radius: 224,
              // angle: 123,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'vo2num_0.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'vo2num_1.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'vo2num_2.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'vo2num_3.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'vo2num_4.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'vo2num_5.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'vo2num_6.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'vo2num_7.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'vo2num_8.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'vo2num_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 + 206,
                src: 'vo2num_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 425,
              y: 150,
              image_array: ["hrt_1.png","hrt_2.png","hrt_3.png","hrt_4.png","hrt_5.png","hrt_6.png","hrt_7.png","hrt_8.png","hrt_9.png","hrt_10.png"],
              image_length: 10,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 101,
              y: 402,
              image_array: ["batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 101,
              y: 19,
              image_array: ["cal_1.png","cal_2.png","cal_3.png","cal_4.png","cal_5.png","cal_6.png"],
              image_length: 6,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 79,
              hour_startY: 191,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colontime.png',
              hour_unit_tc: 'colontime.png',
              hour_unit_en: 'colontime.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 252,
              minute_startY: 191,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 191,
              y: 295,
              week_en: ["weekaod_1.png","weekaod_2.png","weekaod_3.png","weekaod_4.png","weekaod_5.png","weekaod_6.png","weekaod_7.png"],
              week_tc: ["weekaod_1.png","weekaod_2.png","weekaod_3.png","weekaod_4.png","weekaod_5.png","weekaod_6.png","weekaod_7.png"],
              week_sc: ["weekaod_1.png","weekaod_2.png","weekaod_3.png","weekaod_4.png","weekaod_5.png","weekaod_6.png","weekaod_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 148,
              month_startY: 295,
              month_sc_array: ["tempaod_0.png","tempaod_1.png","tempaod_2.png","tempaod_3.png","tempaod_4.png","tempaod_5.png","tempaod_6.png","tempaod_7.png","tempaod_8.png","tempaod_9.png"],
              month_tc_array: ["tempaod_0.png","tempaod_1.png","tempaod_2.png","tempaod_3.png","tempaod_4.png","tempaod_5.png","tempaod_6.png","tempaod_7.png","tempaod_8.png","tempaod_9.png"],
              month_en_array: ["tempaod_0.png","tempaod_1.png","tempaod_2.png","tempaod_3.png","tempaod_4.png","tempaod_5.png","tempaod_6.png","tempaod_7.png","tempaod_8.png","tempaod_9.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 102,
              day_startY: 295,
              day_sc_array: ["tempaod_0.png","tempaod_1.png","tempaod_2.png","tempaod_3.png","tempaod_4.png","tempaod_5.png","tempaod_6.png","tempaod_7.png","tempaod_8.png","tempaod_9.png"],
              day_tc_array: ["tempaod_0.png","tempaod_1.png","tempaod_2.png","tempaod_3.png","tempaod_4.png","tempaod_5.png","tempaod_6.png","tempaod_7.png","tempaod_8.png","tempaod_9.png"],
              day_en_array: ["tempaod_0.png","tempaod_1.png","tempaod_2.png","tempaod_3.png","tempaod_4.png","tempaod_5.png","tempaod_6.png","tempaod_7.png","tempaod_8.png","tempaod_9.png"],
              day_zero: 1,
              day_space: 2,
              day_unit_sc: 'fuaod.png',
              day_unit_tc: 'fuaod.png',
              day_unit_en: 'fuaod.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 299,
              y: 103,
              src: 'run.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 131,
              y: 88,
              font_array: ["distaod_0.png","distaod_1.png","distaod_2.png","distaod_3.png","distaod_4.png","distaod_5.png","distaod_6.png","distaod_7.png","distaod_8.png","distaod_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 144,
              y: 373,
              font_array: ["fataod_0.png","fataod_1.png","fataod_2.png","fataod_3.png","fataod_4.png","fataod_5.png","fataod_6.png","fataod_7.png","fataod_8.png","fataod_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 373,
              font_array: ["fataod_0.png","fataod_1.png","fataod_2.png","fataod_3.png","fataod_4.png","fataod_5.png","fataod_6.png","fataod_7.png","fataod_8.png","fataod_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dotaod.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 318,
              y: 295,
              font_array: ["tempaod_0.png","tempaod_1.png","tempaod_2.png","tempaod_3.png","tempaod_4.png","tempaod_5.png","tempaod_6.png","tempaod_7.png","tempaod_8.png","tempaod_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'colonaod.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 82,
              y: 156,
              image_array: ["aodw_0.png","aodw_1.png","aodw_2.png","aodw_3.png","aodw_4.png","aodw_5.png","aodw_6.png","aodw_7.png","aodw_8.png","aodw_9.png","aodw_10.png","aodw_11.png","aodw_12.png","aodw_13.png","aodw_14.png","aodw_15.png","aodw_16.png","aodw_17.png","aodw_18.png","aodw_19.png","aodw_20.png","aodw_21.png","aodw_22.png","aodw_23.png","aodw_24.png","aodw_25.png","aodw_26.png","aodw_27.png","aodw_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_max_min_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 161,
              font_array: ["tempaod_0.png","tempaod_1.png","tempaod_2.png","tempaod_3.png","tempaod_4.png","tempaod_5.png","tempaod_6.png","tempaod_7.png","tempaod_8.png","tempaod_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'duaod.png',
              unit_tc: 'duaod.png',
              unit_en: 'duaod.png',
              negative_image: 'fuaod.png',
              dot_image: 'slaod.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 118,
              y: 160,
              font_array: ["tempaod_0.png","tempaod_1.png","tempaod_2.png","tempaod_3.png","tempaod_4.png","tempaod_5.png","tempaod_6.png","tempaod_7.png","tempaod_8.png","tempaod_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'duaod.png',
              unit_tc: 'duaod.png',
              unit_en: 'duaod.png',
              negative_image: 'fuaod.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_vo2max_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 43,
              y: 337,
              font_array: ["vo2num_0.png","vo2num_1.png","vo2num_2.png","vo2num_3.png","vo2num_4.png","vo2num_5.png","vo2num_6.png","vo2num_7.png","vo2num_8.png","vo2num_9.png"],
              padding: false,
              h_space: 0,
              angle: 58,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_vo2max_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 16,
              y: 150,
              image_array: ["vo2lvl_1.png","vo2lvl_2.png","vo2lvl_3.png","vo2lvl_4.png","vo2lvl_5.png","vo2lvl_6.png","vo2lvl_7.png"],
              image_length: 7,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["vo2num_0.png","vo2num_1.png","vo2num_2.png","vo2num_3.png","vo2num_4.png","vo2num_5.png","vo2num_6.png","vo2num_7.png","vo2num_8.png","vo2num_9.png"],
              // radius: 224,
              // angle: 123,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_TextCircle_ASCIIARRAY[0] = 'vo2num_0.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[1] = 'vo2num_1.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[2] = 'vo2num_2.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[3] = 'vo2num_3.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[4] = 'vo2num_4.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[5] = 'vo2num_5.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[6] = 'vo2num_6.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[7] = 'vo2num_7.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[8] = 'vo2num_8.png';  // set of images with numbers
            idle_heart_rate_TextCircle_ASCIIARRAY[9] = 'vo2num_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              idle_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - idle_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 + 206,
                src: 'vo2num_0.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 425,
              y: 150,
              image_array: ["hrt_1.png","hrt_2.png","hrt_3.png","hrt_4.png","hrt_5.png","hrt_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 101,
              y: 402,
              image_array: ["batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 101,
              y: 19,
              image_array: ["cal_1.png","cal_2.png","cal_3.png","cal_4.png","cal_5.png","cal_6.png"],
              image_length: 6,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 79,
              hour_startY: 191,
              hour_array: ["timeaod_0.png","timeaod_1.png","timeaod_2.png","timeaod_3.png","timeaod_4.png","timeaod_5.png","timeaod_6.png","timeaod_7.png","timeaod_8.png","timeaod_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colontimeaod.png',
              hour_unit_tc: 'colontimeaod.png',
              hour_unit_en: 'colontimeaod.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 252,
              minute_startY: 191,
              minute_array: ["timeaod_0.png","timeaod_1.png","timeaod_2.png","timeaod_3.png","timeaod_4.png","timeaod_5.png","timeaod_6.png","timeaod_7.png","timeaod_8.png","timeaod_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 129,
              y: 72,
              w: 103,
              h: 67,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 252,
              y: 345,
              w: 103,
              h: 62,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 371,
              y: 330,
              w: 103,
              h: 103,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 191,
              y: 412,
              w: 103,
              h: 103,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 304,
              y: 275,
              w: 88,
              h: 52,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 129,
              y: 144,
              w: 129,
              h: 44,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 103,
              y: 191,
              w: 103,
              h: 77,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 278,
              y: 191,
              w: 103,
              h: 77,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_vo2max_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 10,
              y: 330,
              w: 103,
              h: 103,
              type: hmUI.data_type.VO2MAX,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 124,
              y: 345,
              w: 103,
              h: 62,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 294,
              y: 103,
              w: 88,
              h: 77,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'SportRecordListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 124,
              y: 276,
              w: 124,
              h: 62,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 303;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 224));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = -normal_heart_rate_TextCircle_angleOffset;
                  char_Angle -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let idle_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  idle_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 303;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && idle_heart_rate_circle_string.length > 0 && idle_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let idle_heart_rate_TextCircle_img_angle = 0;
                  let idle_heart_rate_TextCircle_dot_img_angle = 0;
                  idle_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(idle_heart_rate_TextCircle_img_width/2, 224));
                  // alignment = CENTER_H
                  let idle_heart_rate_TextCircle_angleOffset = idle_heart_rate_TextCircle_img_angle * (idle_heart_rate_circle_string.length - 1);
                  idle_heart_rate_TextCircle_angleOffset = -idle_heart_rate_TextCircle_angleOffset;
                  char_Angle -= idle_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - idle_heart_rate_TextCircle_img_width / 2);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, idle_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      idle_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}