/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_steps_imagecombo2 = '';
		let normal_battery_progress4 = '';
		let normal_img5 = '';
		let normal_heart_current_imagecombo7 = '';
		let normal_heart_rotary8 = '';
		let normal_date_imagecombo10 = '';
		let normal_week_imageset11 = '';
		let normal_distance_imagecombo13 = '';
		let normal_weather_imageset15 = '';
		let normal_temperature_current_imagecombo16 = '';
		let normal_temperature_low_imagecombo17 = '';
		let normal_temperature_high_imagecombo18 = '';
		let normal_hour_rotary20 = '';
		let timeInterval;
		let normal_minute_rotary21 = '';
		let clock_timer;
		let normal_second_sweep_rotary22 = '';
		let idle_img25 = '';
		let idle_hour_rotary27 = '';
		let idle_minute_rotary28 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				const batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo2 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 319,
					y: 257,
					font_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
					padding: true,
					h_space: 0,
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				if (screenType != hmSetting.screen_type.AOD) {
					normal_battery_progress4 = hmUI.createWidget(hmUI.widget.ARC, {
						enable: false,
					});
				}

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 66,
					y: 182,
					w: 116,
					h: 116,
					src: '0013.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo7 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 111,
					y: 115,
					font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
					padding: true,
					h_space: 0,
					invalid_image: '0024.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_rotary8 = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
					src: '0025.png',
					center_x: 200,
					center_y: 127,
					x: 18,
					y: 58,
					start_angle: -59,
					end_angle: 38,
					type: hmUI.data_type.HEART,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo10 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 284,
					day_startY: 117,
					day_sc_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
					day_tc_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
					day_en_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.LEFT,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset11 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 250,
					y: 82,
					week_en: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					week_tc: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					week_sc: ["0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo13 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 315,
					y: 306,
					font_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png"],
					padding: false,
					h_space: 0,
					dot_image: '0053.png',
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset15 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 219,
					y: 354,
					image_array: ["0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0058.png","0059.png","0060.png","0057.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0063.png","0070.png","0071.png","0072.png","0073.png","0061.png","0074.png","0075.png","0076.png","0077.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo16 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 148,
					y: 343,
					font_array: ["0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0089.png"],
					unit_tc: ["0089.png"],
					unit_en: ["0089.png"],
					negative_image: ["0088.png"],
					invalid_image: ["0088.png"],
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_low_imagecombo17 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 302,
					y: 353,
					font_array: ["0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0101.png"],
					unit_tc: ["0101.png"],
					unit_en: ["0101.png"],
					negative_image: ["0100.png"],
					invalid_image: ["0100.png"],
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.WEATHER_LOW,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_high_imagecombo18 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 254,
					y: 353,
					font_array: ["0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0101.png"],
					unit_tc: ["0101.png"],
					unit_en: ["0101.png"],
					negative_image: ["0100.png"],
					invalid_image: ["0100.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_HIGH,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_rotary20 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 215,
					pos_y: 90,
					src: '0102.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_rotary21 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 214,
					pos_y: 39,
					src: '0103.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_sweep_rotary22 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 221,
					pos_y: 16,
					src: '0104.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0105.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_rotary27 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 215,
					pos_y: 90,
					src: '0106.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_rotary28 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 214,
					pos_y: 39,
					src: '0107.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateTime() {
					if (normal_hour_rotary20) {
						normal_hour_rotary20.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (normal_minute_rotary21) {
						normal_minute_rotary21.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
					if (idle_hour_rotary27) {
						idle_hour_rotary27.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (idle_minute_rotary28) {
						idle_minute_rotary28.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
				}

				function updateBattery() {
					var current_normal_battery_progress4 = batterySensor.current;
					var target_normal_battery_progress4 = 100;
					var progress_normal_battery_progress4 = current_normal_battery_progress4 / target_normal_battery_progress4;

					if (progress_normal_battery_progress4 > 1) {
						progress_normal_battery_progress4 = 1;
					}

					var pcs_normal_battery_progress4 = progress_normal_battery_progress4;

					if (screenType != hmSetting.screen_type.AOD) {
						// initial parameters
						var sa_normal_battery_progress4 = -90;
						var ea_normal_battery_progress4 = 270;
						var cx_normal_battery_progress4 = 124;
						var cy_normal_battery_progress4 = 240;
						var r_normal_battery_progress4 = 58;
						var lw_normal_battery_progress4 = 34;
						var c_normal_battery_progress4 = 0xFF8F9393;

						// calculated parameters
						var ax_normal_battery_progress4 = cx_normal_battery_progress4 - r_normal_battery_progress4;
						var ay_normal_battery_progress4 = cy_normal_battery_progress4 - r_normal_battery_progress4;
						var cw_normal_battery_progress4 = 2 * r_normal_battery_progress4;
						var ao_normal_battery_progress4 = ea_normal_battery_progress4 - sa_normal_battery_progress4;
						ao_normal_battery_progress4 = ao_normal_battery_progress4 * pcs_normal_battery_progress4;
						var ea_normal_battery_progress4_draw = sa_normal_battery_progress4 + ao_normal_battery_progress4;

						normal_battery_progress4.setProperty(hmUI.prop.MORE, {
							x: ax_normal_battery_progress4,
							y: ay_normal_battery_progress4,
							w: cw_normal_battery_progress4,
							h: cw_normal_battery_progress4,
							start_angle: sa_normal_battery_progress4,
							end_angle: ea_normal_battery_progress4_draw,
							color: c_normal_battery_progress4,
							line_width: lw_normal_battery_progress4,
						});
					};

				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				batterySensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateBattery();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						const animFps = 60;
						const animRepeat = 1000/animFps;
						const animProgress = 6/animFps;
						let animAngle = 0;
						let animDelay = 0;
						clock_timer = timer.createTimer(animDelay, animRepeat, (function(option) {
							animAngle = timeSensor.second * 6 + ((timeSensor.utc % 1000) / 1000) * 6;
							normal_second_sweep_rotary22.setProperty(hmUI.prop.ANGLE, animAngle);
						}));

						updateTime();
						updateBattery();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						timer.stopTimer(clock_timer);
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
						timer.stopTimer(clock_timer);
		},
	});	})()
} catch (e) {
	console.log(e)
}