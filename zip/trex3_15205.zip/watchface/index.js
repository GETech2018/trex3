/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let timeInterval;
		let normal_date_high_imageset2 = '';
		let normal_date_high_imageset2_array = ['0003.png','0004.png','0005.png','0006.png'];
		let normal_date_low_imageset3 = '';
		let normal_date_low_imageset3_array = ['0003.png','0004.png','0005.png','0007.png','0008.png','0009.png','0010.png','0011.png','0012.png','0013.png'];
		let normal_hour_rotary5 = '';
		let normal_hour_rotary6 = '';
		let normal_minute_rotary7 = '';
		let normal_minute_rotary8 = '';
		let normal_second_rotary9 = '';
		let normal_second_rotary10 = '';
		let idle_img13 = '';
		let idle_date_high_imageset15 = '';
		let idle_date_high_imageset15_array = ['0021.png','0022.png','0023.png','0006.png'];
		let idle_date_low_imageset16 = '';
		let idle_date_low_imageset16_array = ['0021.png','0022.png','0023.png','0024.png','0025.png','0026.png','0027.png','0028.png','0029.png','0030.png'];
		let idle_minute_rotary18 = '';
		let idle_hour_rotary19 = '';
		let idle_second_rotary20 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_high_imageset2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 208,
					y: 119,
					w: 208,
					h: 119,
					src: '0006.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_date_low_imageset3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 248,
					y: 119,
					w: 248,
					h: 119,
					src: '0013.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_hour_rotary5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 241,
					pos_x: 221,
					pos_y: 100,
					src: '0014.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_rotary6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 244,
					center_y: 244,
					pos_x: 225,
					pos_y: 103,
					src: '0015.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_rotary7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 236,
					center_y: 237,
					pos_x: 216,
					pos_y: 36,
					src: '0016.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_rotary8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 220,
					pos_y: 39,
					src: '0017.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary9 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 238,
					center_y: 352,
					pos_x: 228,
					pos_y: 319,
					src: '0018.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 241,
					center_y: 353,
					pos_x: 231,
					pos_y: 320,
					src: '0019.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0020.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_date_high_imageset15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 208,
					y: 119,
					w: 208,
					h: 119,
					src: '0006.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_date_low_imageset16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 248,
					y: 119,
					w: 248,
					h: 119,
					src: '0030.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				})

				idle_minute_rotary18 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 220,
					pos_y: 39,
					src: '0031.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_rotary19 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 244,
					center_y: 244,
					pos_x: 225,
					pos_y: 103,
					src: '0032.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_second_rotary20 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 241,
					center_y: 353,
					pos_x: 231,
					pos_y: 320,
					src: '0033.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateTime() {
					normal_date_high_imageset2.setProperty(hmUI.prop.MORE, {
						src: normal_date_high_imageset2_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(0) : 0)]
					})
					normal_date_low_imageset3.setProperty(hmUI.prop.MORE, {
						src: normal_date_low_imageset3_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(1) : timeSensor.day.toString().charAt(0))]
					})
					if (normal_hour_rotary5) {
						normal_hour_rotary5.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (normal_hour_rotary6) {
						normal_hour_rotary6.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (normal_minute_rotary7) {
						normal_minute_rotary7.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
					if (normal_minute_rotary8) {
						normal_minute_rotary8.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
					if (normal_second_rotary9) {
						normal_second_rotary9.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.second * (6 * 1))));
					}
					if (normal_second_rotary10) {
						normal_second_rotary10.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.second * (6 * 1))));
					}
					idle_date_high_imageset15.setProperty(hmUI.prop.MORE, {
						src: idle_date_high_imageset15_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(0) : 0)]
					})
					idle_date_low_imageset16.setProperty(hmUI.prop.MORE, {
						src: idle_date_low_imageset16_array[(timeSensor.day.toString().length == 2 ? timeSensor.day.toString().charAt(1) : timeSensor.day.toString().charAt(0))]
					})
					if (idle_minute_rotary18) {
						idle_minute_rotary18.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
					if (idle_hour_rotary19) {
						idle_hour_rotary19.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (idle_second_rotary20) {
						idle_second_rotary20.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.second * (6 * 1))));
					}
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateTime();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}