﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_image_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 124,
              y: 415,
              font_array: ["temp_0001.png","temp_0002.png","temp_0003.png","temp_0004.png","temp_0005.png","temp_0006.png","temp_0007.png","temp_0008.png","temp_0009.png","temp_0010.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'temp_0013.png',
              unit_tc: 'temp_0013.png',
              unit_en: 'temp_0013.png',
              negative_image: 'temp_0011.png',
              invalid_image: 'temp_0012.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 270,
              y: 406,
              image_array: ["weather_0001.png","weather_0002.png","weather_0003.png","weather_0004.png","weather_0005.png","weather_0006.png","weather_0007.png","weather_0008.png","weather_0009.png","weather_0010.png","weather_0011.png","weather_0012.png","weather_0013.png","weather_0014.png","weather_0015.png","weather_0016.png","weather_0017.png","weather_0018.png","weather_0019.png","weather_0020.png","weather_0021.png","weather_0022.png","weather_0023.png","weather_0024.png","weather_0025.png","weather_0026.png","weather_0027.png","weather_0028.png","weather_0029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 354,
              y: 104,
              font_array: ["bat_0001.png","bat_0002.png","bat_0003.png","bat_0004.png","bat_0005.png","bat_0006.png","bat_0007.png","bat_0008.png","bat_0009.png","bat_0010.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'bat_0011.png',
              unit_tc: 'bat_0011.png',
              unit_en: 'bat_0011.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 383,
              y: 299,
              font_array: ["pulse_0001.png","pulse_0002.png","pulse_0003.png","pulse_0004.png","pulse_0005.png","pulse_0006.png","pulse_0007.png","pulse_0008.png","pulse_0009.png","pulse_0010.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 340,
              font_array: ["steps_0001.png","steps_0002.png","steps_0003.png","steps_0004.png","steps_0005.png","steps_0006.png","steps_0007.png","steps_0008.png","steps_0009.png","steps_0010.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 211,
              y: 334,
              src: '0003.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 292,
              month_startY: 29,
              month_sc_array: ["month_0001.png","month_0002.png","month_0003.png","month_0004.png","month_0005.png","month_0006.png","month_0007.png","month_0008.png","month_0009.png","month_0010.png","month_0011.png","month_0012.png"],
              month_tc_array: ["month_0001.png","month_0002.png","month_0003.png","month_0004.png","month_0005.png","month_0006.png","month_0007.png","month_0008.png","month_0009.png","month_0010.png","month_0011.png","month_0012.png"],
              month_en_array: ["month_0001.png","month_0002.png","month_0003.png","month_0004.png","month_0005.png","month_0006.png","month_0007.png","month_0008.png","month_0009.png","month_0010.png","month_0011.png","month_0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 195,
              day_startY: 25,
              day_sc_array: ["date_0001.png","date_0002.png","date_0003.png","date_0004.png","date_0005.png","date_0006.png","date_0007.png","date_0008.png","date_0009.png","date_0010.png"],
              day_tc_array: ["date_0001.png","date_0002.png","date_0003.png","date_0004.png","date_0005.png","date_0006.png","date_0007.png","date_0008.png","date_0009.png","date_0010.png"],
              day_en_array: ["date_0001.png","date_0002.png","date_0003.png","date_0004.png","date_0005.png","date_0006.png","date_0007.png","date_0008.png","date_0009.png","date_0010.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 113,
              y: 29,
              week_en: ["week_0001.png","week_0002.png","week_0003.png","week_0004.png","week_0005.png","week_0006.png","week_0007.png"],
              week_tc: ["week_0001.png","week_0002.png","week_0003.png","week_0004.png","week_0005.png","week_0006.png","week_0007.png"],
              week_sc: ["week_0001.png","week_0002.png","week_0003.png","week_0004.png","week_0005.png","week_0006.png","week_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 59,
              hour_startY: 115,
              hour_array: ["hour_0001.png","hour_0002.png","hour_0003.png","hour_0004.png","hour_0005.png","hour_0006.png","hour_0007.png","hour_0008.png","hour_0009.png","hour_0010.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 318,
              minute_startY: 174,
              minute_array: ["min_0001.png","min_0002.png","min_0003.png","min_0004.png","min_0005.png","min_0006.png","min_0007.png","min_0008.png","min_0009.png","min_0010.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 92,
              hour_startY: 197,
              hour_array: ["aod_0001.png","aod_0002.png","aod_0003.png","aod_0004.png","aod_0005.png","aod_0006.png","aod_0007.png","aod_0008.png","aod_0009.png","aod_0010.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_unit_sc: 'aod_0011.png',
              hour_unit_tc: 'aod_0011.png',
              hour_unit_en: 'aod_0011.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 255,
              minute_startY: 197,
              minute_array: ["aod_0001.png","aod_0002.png","aod_0003.png","aod_0004.png","aod_0005.png","aod_0006.png","aod_0007.png","aod_0008.png","aod_0009.png","aod_0010.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // disconneсnt_toast_text: Связь потеряна,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Связь потеряна"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 100,
              y: 15,
              w: 280,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 100,
              y: 410,
              w: 280,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WeatherScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 215,
              y: 340,
              w: 210,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'activityAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 293,
              y: 292,
              w: 170,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'heart_app_Screen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 325,
              y: 175,
              w: 140,
              h: 95,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 75,
              y: 121,
              w: 210,
              h: 145,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'null.png',
              normal_src: 'null.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}