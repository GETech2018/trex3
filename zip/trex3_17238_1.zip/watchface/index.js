﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let normal_battery_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_Switch_BG = ''

        let backgroundIndex = 0;
        let backgroundList = ['Quadrante_00.png', 'Quadrante_01.png', 'Quadrante_02.png', 'Quadrante_03.png', 'Quadrante_04.png', 'Quadrante_05.png', 'Quadrante_06.png'];
        let backgroundToastList = ['Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s', 'Sfondo %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            //#region SwitchBackground
            console.log('SwitchBackground');
            function switchBackground() {
              backgroundIndex++;
              if (backgroundIndex >= backgroundList.length) backgroundIndex = 0;
              hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
              let toastText = backgroundToastList[backgroundIndex].replace('%s', `${backgroundIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              vibro(28);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Quadrante_00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 193,
              y: 11,
              image_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 16,
              font_array: ["Nr.Batt_00.png","Nr.Batt_01.png","Nr.Batt_02.png","Nr.Batt_03.png","Nr.Batt_04.png","Nr.Batt_05.png","Nr.Batt_06.png","Nr.Batt_07.png","Nr.Batt_08.png","Nr.Batt_09.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'Nr.Batt_14.png',
              unit_tc: 'Nr.Batt_14.png',
              unit_en: 'Nr.Batt_14.png',
              imperial_unit_sc: 'Nr.Batt_14.png',
              imperial_unit_tc: 'Nr.Batt_14.png',
              imperial_unit_en: 'Nr.Batt_14.png',
              negative_image: 'Nr.Batt_12.png',
              invalid_image: 'Nr.Batt_13.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 218,
                y: 16,
                font_array: ["Nr.Batt_00.png","Nr.Batt_01.png","Nr.Batt_02.png","Nr.Batt_03.png","Nr.Batt_04.png","Nr.Batt_05.png","Nr.Batt_06.png","Nr.Batt_07.png","Nr.Batt_08.png","Nr.Batt_09.png"],
                padding: false,
                h_space: 4,
                unit_sc: 'Nr.Batt_14.png',
                unit_tc: 'Nr.Batt_14.png',
                unit_en: 'Nr.Batt_14.png',
                imperial_unit_sc: 'Nr.Batt_14.png',
                imperial_unit_tc: 'Nr.Batt_14.png',
                imperial_unit_en: 'Nr.Batt_14.png',
                negative_image: 'Nr.Batt_12.png',
                invalid_image: 'Nr.Batt_13.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 90,
              y: 309,
              week_en: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_tc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_sc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 434,
              font_array: ["Nr.Batt_00.png","Nr.Batt_01.png","Nr.Batt_02.png","Nr.Batt_03.png","Nr.Batt_04.png","Nr.Batt_05.png","Nr.Batt_06.png","Nr.Batt_07.png","Nr.Batt_08.png","Nr.Batt_09.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'Nr.Batt_10.png',
              unit_tc: 'Nr.Batt_10.png',
              unit_en: 'Nr.Batt_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 31,
              y: 136,
              src: 'Off_00.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 33,
              y: 195,
              src: 'Al_00.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 412,
              month_startY: 247,
              month_sc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_tc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_en_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 26,
              day_startY: 247,
              day_sc_array: ["Nr.Giorno_00.png","Nr.Giorno_01.png","Nr.Giorno_02.png","Nr.Giorno_03.png","Nr.Giorno_04.png","Nr.Giorno_05.png","Nr.Giorno_06.png","Nr.Giorno_07.png","Nr.Giorno_08.png","Nr.Giorno_09.png"],
              day_tc_array: ["Nr.Giorno_00.png","Nr.Giorno_01.png","Nr.Giorno_02.png","Nr.Giorno_03.png","Nr.Giorno_04.png","Nr.Giorno_05.png","Nr.Giorno_06.png","Nr.Giorno_07.png","Nr.Giorno_08.png","Nr.Giorno_09.png"],
              day_en_array: ["Nr.Giorno_00.png","Nr.Giorno_01.png","Nr.Giorno_02.png","Nr.Giorno_03.png","Nr.Giorno_04.png","Nr.Giorno_05.png","Nr.Giorno_06.png","Nr.Giorno_07.png","Nr.Giorno_08.png","Nr.Giorno_09.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 95,
              hour_startY: 60,
              hour_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 137,
              minute_startY: 247,
              minute_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 363,
              second_startY: 181,
              second_array: ["Nr.Giorno_00.png","Nr.Giorno_01.png","Nr.Giorno_02.png","Nr.Giorno_03.png","Nr.Giorno_04.png","Nr.Giorno_05.png","Nr.Giorno_06.png","Nr.Giorno_07.png","Nr.Giorno_08.png","Nr.Giorno_09.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Quadrante_00.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 193,
              y: 11,
              image_array: ["0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 16,
              font_array: ["Nr.Batt_00.png","Nr.Batt_01.png","Nr.Batt_02.png","Nr.Batt_03.png","Nr.Batt_04.png","Nr.Batt_05.png","Nr.Batt_06.png","Nr.Batt_07.png","Nr.Batt_08.png","Nr.Batt_09.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'Nr.Batt_14.png',
              unit_tc: 'Nr.Batt_14.png',
              unit_en: 'Nr.Batt_14.png',
              imperial_unit_sc: 'Nr.Batt_14.png',
              imperial_unit_tc: 'Nr.Batt_14.png',
              imperial_unit_en: 'Nr.Batt_14.png',
              negative_image: 'Nr.Batt_12.png',
              invalid_image: 'Nr.Batt_13.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //#region temperatureUnit
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 218,
                y: 16,
                font_array: ["Nr.Batt_00.png","Nr.Batt_01.png","Nr.Batt_02.png","Nr.Batt_03.png","Nr.Batt_04.png","Nr.Batt_05.png","Nr.Batt_06.png","Nr.Batt_07.png","Nr.Batt_08.png","Nr.Batt_09.png"],
                padding: false,
                h_space: 4,
                unit_sc: 'Nr.Batt_14.png',
                unit_tc: 'Nr.Batt_14.png',
                unit_en: 'Nr.Batt_14.png',
                imperial_unit_sc: 'Nr.Batt_14.png',
                imperial_unit_tc: 'Nr.Batt_14.png',
                imperial_unit_en: 'Nr.Batt_14.png',
                negative_image: 'Nr.Batt_12.png',
                invalid_image: 'Nr.Batt_13.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //#endregion

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 90,
              y: 309,
              week_en: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_tc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              week_sc: ["Giorno_00.png","Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 434,
              font_array: ["Nr.Batt_00.png","Nr.Batt_01.png","Nr.Batt_02.png","Nr.Batt_03.png","Nr.Batt_04.png","Nr.Batt_05.png","Nr.Batt_06.png","Nr.Batt_07.png","Nr.Batt_08.png","Nr.Batt_09.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'Nr.Batt_10.png',
              unit_tc: 'Nr.Batt_10.png',
              unit_en: 'Nr.Batt_10.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 31,
              y: 136,
              src: 'Off_00.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 33,
              y: 195,
              src: 'Al_00.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 412,
              month_startY: 247,
              month_sc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_tc_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_en_array: ["Mese_00.png","Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 26,
              day_startY: 247,
              day_sc_array: ["Nr.Giorno_00.png","Nr.Giorno_01.png","Nr.Giorno_02.png","Nr.Giorno_03.png","Nr.Giorno_04.png","Nr.Giorno_05.png","Nr.Giorno_06.png","Nr.Giorno_07.png","Nr.Giorno_08.png","Nr.Giorno_09.png"],
              day_tc_array: ["Nr.Giorno_00.png","Nr.Giorno_01.png","Nr.Giorno_02.png","Nr.Giorno_03.png","Nr.Giorno_04.png","Nr.Giorno_05.png","Nr.Giorno_06.png","Nr.Giorno_07.png","Nr.Giorno_08.png","Nr.Giorno_09.png"],
              day_en_array: ["Nr.Giorno_00.png","Nr.Giorno_01.png","Nr.Giorno_02.png","Nr.Giorno_03.png","Nr.Giorno_04.png","Nr.Giorno_05.png","Nr.Giorno_06.png","Nr.Giorno_07.png","Nr.Giorno_08.png","Nr.Giorno_09.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 95,
              hour_startY: 60,
              hour_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 137,
              minute_startY: 247,
              minute_array: ["Ore_00.png","Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 363,
              second_startY: 181,
              second_array: ["Nr.Giorno_00.png","Nr.Giorno_01.png","Nr.Giorno_02.png","Nr.Giorno_03.png","Nr.Giorno_04.png","Nr.Giorno_05.png","Nr.Giorno_06.png","Nr.Giorno_07.png","Nr.Giorno_08.png","Nr.Giorno_09.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 187,
              y: 412,
              w: 136,
              h: 71,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 199,
              y: 0,
              w: 100,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 376,
              y: 190,
              w: 100,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 4,
              y: 193,
              w: 100,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.SwitchBackground');
            // Button_Switch_BG = hmUI.createWidget(hmUI.widget.SwitchBackground, {
              // x: 192,
              // y: 187,
              // w: 111,
              // h: 111,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: 'Tasto_00.png',
              // normal_src: 'Tasto_00.png',
              // bg_list: Quadrante_00|Quadrante_01|Quadrante_02|Quadrante_03|Quadrante_04|Quadrante_05|Quadrante_06,
              // toast_list: Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s|Sfondo %s,
              // use_crown: False,
              // use_in_AOD: True,
              // vibro: True,
            // });

            Button_Switch_BG = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 192,
              y: 187,
              w: 111,
              h: 111,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Tasto_00.png',
              normal_src: 'Tasto_00.png',
              click_func: (button_widget) => {
                switchBackground();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            // vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                //SwitchBackground
                if (hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`) === undefined) {
                  backgroundIndex = 0;
                  hmFS.SysProSetInt(`backgroundIndex_${watchfaceId}`, backgroundIndex);
                } else {
                  backgroundIndex = hmFS.SysProGetInt(`backgroundIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg_img) normal_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
                if (screenType == hmSetting.screen_type.AOD && idle_background_bg_img) idle_background_bg_img.setProperty(hmUI.prop.SRC, backgroundList[backgroundIndex]);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}