﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start
        let currentTheme = hmFS.SysProGetInt('WatchTheme') ?? 1; 
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 5         
        // Sleep
        let sleep = null;
        let cachedSleepText = "00:00";
        let lastSleepDate = null;
        let lastShownSleepText = "--";
        let sleep_time_txt = null;
        let sleep_time_txt2 = null;
        let lastTotalMinutes = 0;
        let lastSleepUpdateMs = 0;
        const SLEEP_THROTTLE_MS = 15 * 60 * 1000; 
        
        let normal_background_bg_img = ''
        let normal_background_bg_img2 = ''

        let normal_image_colour = ''

        let normal_image_img = ''
        let normal_image_img2 = ''
        let normal_weather_image_progress_img_level = ''
        let normal_weather_image_progress_img_level2 = ''
        let normal_temperature_current_text_font = ''
        let normal_temperature_current_text_font2 = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_month_img2 = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_week_img2 = ''
        let normal_day_text_font = ''
        let normal_day_text_font2 = ''
        let normal_altitude_target_text_font = ''
        let normal_altitude_target_text_font2 = ''
        let normal_wind_current_text_font = ''
        let normal_wind_current_text_font2 = ''
        let normal_sun_high_text_font = ''
        let normal_sun_high_text_font2 = ''
        let normal_sun_low_text_font = ''
        let normal_sun_low_text_font2 = ''
        let normal_readiness_current_text_font = ''
        let normal_readiness_current_text_font2 = ''
        let normal_heart_rate_text_font = ''
        let normal_heart_rate_text_font2 = ''
        let normal_calorie_current_text_font = ''
        let normal_calorie_current_text_font2 = ''
        let normal_distance_current_text_font = ''
        let normal_distance_current_text_font2 = ''
        let normal_step_current_text_font = ''
        let normal_step_current_text_font2 = ''
        let normal_battery_circle_scale = ''
        let normal_battery_circle_scale2 = ''
        let normal_battery_current_text_font = ''
        let normal_battery_current_text_font2 = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time2 = ''
        let normal_system_lock_img = ''
        let normal_system_lock_img2 = ''
        let normal_system_disconnect_img = ''
        let normal_system_disconnect_img2 = ''
        let normal_system_clock_img = ''
        let normal_system_clock_img2 = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_hour2 = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_minute2 = ''

        let idle_background_bg_img = ''
        let idle_image_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_day_text_font = ''
        let idle_altitude_target_text_font = ''
        let idle_wind_current_text_font = ''
        let idle_sun_high_text_font = ''
        let idle_sun_low_text_font = ''
        let idle_readiness_current_text_font = ''
        let idle_heart_rate_text_font = ''
        let idle_calorie_current_text_font = ''
        let idle_distance_current_text_font = ''
        let idle_step_current_text_font = ''
        let idle_battery_circle_scale = ''
        let idle_battery_current_text_font = ''
        let idle_digital_clock_img_time = ''
        let idle_system_lock_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_altitude_jumpable_img_click = ''
        let normal_readiness_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let timeSensor = '';

            // Sleep helpers 1.1
            try {
                sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
                sleep.onSleepStateChange = () => {
                    if (sleep.state === hmSensor.sleep_state.END) {
                        calculateAndCacheRealSleep(true);
                    }
                };

            } catch (e) {
                console.log("Sleep sensor init failed:", e);
                sleep = null;
            }
            function formatMinutes(mins) {
                if (!mins || mins <= 0) return "00:00";

                const h = Math.floor(mins / 60);
                const m = mins % 60;
                return String(h).padStart(2, "0") + ":" + String(m).padStart(2, "0");
            }
            function calculateAndCacheRealSleep(force = false) {
                if (!sleep) {
                    cachedSleepText = "00:00";
                    updateSleepText();
                    return;
                }
                
                try {
                    const now = Date.now();
                    const today = new Date().toDateString();
                    
                    if (!force && (now - lastSleepUpdateMs < SLEEP_THROTTLE_MS) && lastSleepDate === today) {
                        updateSleepText();
                        return;
                    }

                    let currentTotal = sleep.getTotalTime();
                    
                    if (!force && lastSleepDate === today && currentTotal === lastTotalMinutes) {
                        lastSleepUpdateMs = now;
                        updateSleepText();
                        return;
                    }

                    sleep.updateInfo();
                    currentTotal = sleep.getTotalTime();

                    const info = sleep.getBasicInfo();
                    if (!info || info.startTime === 0 || currentTotal <= 0) {
                        cachedSleepText = "00:00";
                        lastTotalMinutes = 0;
                        updateSleepText();
                        return;
                    }

                    let totalMinutes = currentTotal;

                    if (totalMinutes > 1080) totalMinutes = 0;

                    if (totalMinutes > 90) {
                        try {
                            const stages = sleep.getSleepStageData();
                            const model = sleep.getSleepStageModel();
                            let wakeMinutes = 0;
                            for (let i = 0, len = stages.length; i < len; i++) {
                                const st = stages[i];
                                if (st.model === model.WAKE_STAGE) {
                                    wakeMinutes += (st.stop + 1 - st.start);
                                }
                            }
                            totalMinutes -= wakeMinutes;
                        } catch (e) {}
                    }

                    cachedSleepText = formatMinutes(totalMinutes);
                    lastSleepDate = today;
                    lastTotalMinutes = currentTotal;
                    lastSleepUpdateMs = now;
                    updateSleepText();
                } catch (e) {
                    console.log("calculateAndCacheRealSleep error:", e);
                    cachedSleepText = "00:00";
                    updateSleepText();
                }
            }
            function updateSleepText() {
                if (hmSetting.getScreenType() === hmSetting.screen_type.AOD) return;
                if (lastShownSleepText === cachedSleepText) return;

                try {
                    if (sleep_time_txt) {
                        sleep_time_txt.setProperty(hmUI.prop.TEXT, cachedSleepText);
                    }
                    if (sleep_time_txt2) {
                        sleep_time_txt2.setProperty(hmUI.prop.TEXT, cachedSleepText);
                    }
                    lastShownSleepText = cachedSleepText;
                } catch (e) {
                    console.log("updateSleepText error:", e);
                }
            }

            function click_Bezel() {
              if(bezel_num>=bezel_all) {bezel_num=1;}
              else { bezel_num=bezel_num+1;}
              hmUI.showToast({text: "Цвет " + parseInt(bezel_num) });

                normal_image_colour.setProperty(hmUI.prop.SRC, "colour_" + parseInt(bezel_num) + ".png");                
            }             
        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: pixelated.ttf; FontSize: 17
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 523,
              h: 52,
              text_size: 17,
              char_space: 0,
              line_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: pixelated.ttf; FontSize: 15
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 463,
              h: 46,
              text_size: 15,
              char_space: 0,
              line_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: pixelated.ttf; FontSize: 14
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 428,
              h: 43,
              text_size: 14,
              char_space: 0,
              line_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: pixelated.ttf; FontSize: 10
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 529,
              h: 15,
              text_size: 10,
              char_space: 8,
              line_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'OsnB.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_background_bg_img2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'OsnW.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_image_colour = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'colour_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_W.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_image_img2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_B.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 63,
              image_array: ["WB_0.png","WB_1.png","WB_2.png","WB_3.png","WB_4.png","WB_5.png","WB_6.png","WB_7.png","WB_8.png","WB_9.png","WB_10.png","WB_11.png","WB_12.png","WB_13.png","WB_14.png","WB_15.png","WB_16.png","WB_17.png","WB_18.png","WB_19.png","WB_20.png","WB_21.png","WB_22.png","WB_23.png","WB_24.png","WB_25.png","WB_26.png","WB_27.png","WB_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_weather_image_progress_img_level2 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 63,
              image_array: ["WW_0.png","WW_1.png","WW_2.png","WW_3.png","WW_4.png","WW_5.png","WW_6.png","WW_7.png","WW_8.png","WW_9.png","WW_10.png","WW_11.png","WW_12.png","WW_13.png","WW_14.png","WW_15.png","WW_16.png","WW_17.png","WW_18.png","WW_19.png","WW_20.png","WW_21.png","WW_22.png","WW_23.png","WW_24.png","WW_25.png","WW_26.png","WW_27.png","WW_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 170,
              y: 100,
              w: 150,
              h: 30,
              text_size: 17,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_current_text_font2 = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 170,
              y: 100,
              w: 150,
              h: 30,
              text_size: 17,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 269,
              month_startY: 246,
              month_sc_array: ["MB_0.png","MB_1.png","MB_2.png","MB_3.png","MB_4.png","MB_5.png","MB_6.png","MB_7.png","MB_8.png","MB_9.png","MB_10.png","MB_11.png"],
              month_tc_array: ["MB_0.png","MB_1.png","MB_2.png","MB_3.png","MB_4.png","MB_5.png","MB_6.png","MB_7.png","MB_8.png","MB_9.png","MB_10.png","MB_11.png"],
              month_en_array: ["MB_0.png","MB_1.png","MB_2.png","MB_3.png","MB_4.png","MB_5.png","MB_6.png","MB_7.png","MB_8.png","MB_9.png","MB_10.png","MB_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_date_img_date_month_img2 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 269,
              month_startY: 246,
              month_sc_array: ["MW_0.png","MW_1.png","MW_2.png","MW_3.png","MW_4.png","MW_5.png","MW_6.png","MW_7.png","MW_8.png","MW_9.png","MW_10.png","MW_11.png"],
              month_tc_array: ["MW_0.png","MW_1.png","MW_2.png","MW_3.png","MW_4.png","MW_5.png","MW_6.png","MW_7.png","MW_8.png","MW_9.png","MW_10.png","MW_11.png"],
              month_en_array: ["MW_0.png","MW_1.png","MW_2.png","MW_3.png","MW_4.png","MW_5.png","MW_6.png","MW_7.png","MW_8.png","MW_9.png","MW_10.png","MW_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 42,
              y: 247,
              week_en: ["DB_0.png","DB_1.png","DB_2.png","DB_3.png","DB_4.png","DB_5.png","DB_6.png"],
              week_tc: ["DB_0.png","DB_1.png","DB_2.png","DB_3.png","DB_4.png","DB_5.png","DB_6.png"],
              week_sc: ["DB_0.png","DB_1.png","DB_2.png","DB_3.png","DB_4.png","DB_5.png","DB_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_date_img_date_week_img2 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 42,
              y: 247,
              week_en: ["DW_0.png","DW_1.png","DW_2.png","DW_3.png","DW_4.png","DW_5.png","DW_6.png"],
              week_tc: ["DW_0.png","DW_1.png","DW_2.png","DW_3.png","DW_4.png","DW_5.png","DW_6.png"],
              week_sc: ["DW_0.png","DW_1.png","DW_2.png","DW_3.png","DW_4.png","DW_5.png","DW_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 169,
              y: 241,
              w: 150,
              h: 30,
              text_size: 17,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_day_text_font2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 169,
              y: 241,
              w: 150,
              h: 30,
              text_size: 17,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_altitude_target_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 310,
              y: 116,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_altitude_target_text_font2 = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 310,
              y: 116,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_wind_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 4,
              y: 116,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_wind_current_text_font2 = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 4,
              y: 116,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 120,
              y: 387,
              w: 150,
              h: 30,
              text_size: 14,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_sun_high_text_font2 = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 120,
              y: 387,
              w: 150,
              h: 30,
              text_size: 14,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 216,
              y: 387,
              w: 150,
              h: 30,
              text_size: 14,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_sun_low_text_font2 = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 216,
              y: 387,
              w: 150,
              h: 30,
              text_size: 14,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });          

            sleep_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 170,
              y: 352,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: "00:00",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            sleep_time_txt2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 170,
              y: 352,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: "00:00",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            
            calculateAndCacheRealSleep(true);  

            normal_readiness_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 266,
              y: 352,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_readiness_current_text_font2 = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 266,
              y: 352,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 70,
              y: 352,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_heart_rate_text_font2 = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 70,
              y: 352,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 40,
              y: 278,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_calorie_current_text_font2 = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 40,
              y: 278,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 300,
              y: 278,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_current_text_font2 = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 300,
              y: 278,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 169,
              y: 278,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_step_current_text_font2 = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 169,
              y: 278,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 63,
              // end_angle: 360,
              // radius: 231,
              // line_width: 12,
              // line_cap: Flat,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: True,
              // alpha: 160,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 360,
              end_angle: 63,
              radius: 225,
              line_width: 12,
              corner_flag: 3,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale.setAlpha(160);

            // normal_battery_circle_scale2 = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 63,
              // end_angle: 360,
              // radius: 231,
              // line_width: 12,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 160,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            normal_battery_circle_scale2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 360,
              end_angle: 63,
              radius: 225,
              line_width: 12,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale2.setAlpha(160);            
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 10,
              y: 10,
              w: 460,
              h: 460,
              text_size: 10,
              char_space: 8,
              font: 'fonts/pixelated.ttf',
              color: 0xFF000000,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 66,
              mode: 0,
              // radius: 230,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_current_text_font2 = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 10,
              y: 10,
              w: 460,
              h: 460,
              text_size: 10,
              char_space: 8,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 66,
              mode: 0,
              // radius: 230,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 69,
              hour_startY: 158,
              hour_array: ["HW_0.png","HW_1.png","HW_2.png","HW_3.png","HW_4.png","HW_5.png","HW_6.png","HW_7.png","HW_8.png","HW_9.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 189,
              minute_startY: 158,
              minute_array: ["HW_0.png","HW_1.png","HW_2.png","HW_3.png","HW_4.png","HW_5.png","HW_6.png","HW_7.png","HW_8.png","HW_9.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 309,
              second_startY: 158,
              second_array: ["HW_0.png","HW_1.png","HW_2.png","HW_3.png","HW_4.png","HW_5.png","HW_6.png","HW_7.png","HW_8.png","HW_9.png"],
              second_zero: 1,
              second_space: -4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_digital_clock_img_time2 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 69,
              hour_startY: 158,
              hour_array: ["HB_0.png","HB_1.png","HB_2.png","HB_3.png","HB_4.png","HB_5.png","HB_6.png","HB_7.png","HB_8.png","HB_9.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 189,
              minute_startY: 158,
              minute_array: ["HB_0.png","HB_1.png","HB_2.png","HB_3.png","HB_4.png","HB_5.png","HB_6.png","HB_7.png","HB_8.png","HB_9.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 309,
              second_startY: 158,
              second_array: ["HB_0.png","HB_1.png","HB_2.png","HB_3.png","HB_4.png","HB_5.png","HB_6.png","HB_7.png","HB_8.png","HB_9.png"],
              second_zero: 1,
              second_space: -4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 74,
              y: 138,
              src: 'LockB.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_system_lock_img2 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 74,
              y: 138,
              src: 'LockW.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 224,
              y: 422,
              src: 'Bt_offW.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_system_disconnect_img2 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 224,
              y: 422,
              src: 'Bt_offB.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 384,
              y: 139,
              src: 'AlarmB.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_system_clock_img2 = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 384,
              y: 139,
              src: 'AlarmW.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'HourB.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 45,
              hour_posY: 215,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_analog_clock_time_pointer_hour2 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'HourW.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 45,
              hour_posY: 215,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'MinnB.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 45,
              minute_posY: 215,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_analog_clock_time_pointer_minute2 = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'MinnW.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 45,
              minute_posY: 215,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'OsnW.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zaplAOD_B.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 63,
              image_array: ["WW_0.png","WW_1.png","WW_2.png","WW_3.png","WW_4.png","WW_5.png","WW_6.png","WW_7.png","WW_8.png","WW_9.png","WW_10.png","WW_11.png","WW_12.png","WW_13.png","WW_14.png","WW_15.png","WW_16.png","WW_17.png","WW_18.png","WW_19.png","WW_20.png","WW_21.png","WW_22.png","WW_23.png","WW_24.png","WW_25.png","WW_26.png","WW_27.png","WW_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 170,
              y: 100,
              w: 150,
              h: 30,
              text_size: 17,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 269,
              month_startY: 246,
              month_sc_array: ["MW_0.png","MW_1.png","MW_2.png","MW_3.png","MW_4.png","MW_5.png","MW_6.png","MW_7.png","MW_8.png","MW_9.png","MW_10.png","MW_11.png"],
              month_tc_array: ["MW_0.png","MW_1.png","MW_2.png","MW_3.png","MW_4.png","MW_5.png","MW_6.png","MW_7.png","MW_8.png","MW_9.png","MW_10.png","MW_11.png"],
              month_en_array: ["MW_0.png","MW_1.png","MW_2.png","MW_3.png","MW_4.png","MW_5.png","MW_6.png","MW_7.png","MW_8.png","MW_9.png","MW_10.png","MW_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 42,
              y: 247,
              week_en: ["DW_0.png","DW_1.png","DW_2.png","DW_3.png","DW_4.png","DW_5.png","DW_6.png"],
              week_tc: ["DW_0.png","DW_1.png","DW_2.png","DW_3.png","DW_4.png","DW_5.png","DW_6.png"],
              week_sc: ["DW_0.png","DW_1.png","DW_2.png","DW_3.png","DW_4.png","DW_5.png","DW_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 169,
              y: 241,
              w: 150,
              h: 30,
              text_size: 17,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altitude_target_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 310,
              y: 116,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_wind_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 4,
              y: 116,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 120,
              y: 387,
              w: 150,
              h: 30,
              text_size: 14,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 216,
              y: 387,
              w: 150,
              h: 30,
              text_size: 14,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_readiness_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 219,
              y: 352,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 114,
              y: 352,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 40,
              y: 278,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 300,
              y: 278,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 169,
              y: 278,
              w: 150,
              h: 30,
              text_size: 15,
              char_space: 0,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 63,
              // end_angle: 360,
              // radius: 231,
              // line_width: 12,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 160,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 360,
              end_angle: 63,
              radius: 225,
              line_width: 12,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_circle_scale.setAlpha(160);

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 10,
              y: 10,
              w: 460,
              h: 460,
              text_size: 10,
              char_space: 8,
              font: 'fonts/pixelated.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 66,
              mode: 0,
              // radius: 230,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 128,
              hour_startY: 158,
              hour_array: ["HB_0.png","HB_1.png","HB_2.png","HB_3.png","HB_4.png","HB_5.png","HB_6.png","HB_7.png","HB_8.png","HB_9.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 252,
              minute_startY: 158,
              minute_array: ["HB_0.png","HB_1.png","HB_2.png","HB_3.png","HB_4.png","HB_5.png","HB_6.png","HB_7.png","HB_8.png","HB_9.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 74,
              y: 138,
              src: 'LockW.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 224,
              y: 422,
              src: 'Bt_offB.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 384,
              y: 139,
              src: 'AlarmW.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'HourW.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 45,
              hour_posY: 215,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'MinnW.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 45,
              minute_posY: 215,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            applyTheme(currentTheme);

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 281,
              w: 100,
              h: 45,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 75,
              y: 282,
              w: 82,
              h: 45,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 122,
              y: 336,
              w: 58,
              h: 45,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 327,
              y: 281,
              w: 83,
              h: 45,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 305,
              y: 13,
              w: 76,
              h: 58,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 183,
              y: 387,
              w: 114,
              h: 40,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 216,
              y: 71,
              w: 51,
              h: 63,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 208,
              y: 170,
              w: 60,
              h: 60,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 329,
              y: 173,
              w: 60,
              h: 57,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 377,
              y: 134,
              w: 39,
              h: 36,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 198,
              y: 335,
              w: 87,
              h: 45,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 284,
              y: 105,
              w: 77,
              h: 45,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 300,
              y: 335,
              w: 61,
              h: 45,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 191,
              y: 238,
              w: 100,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 365,
              y: 77,
              w: 60,
              h: 51,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 366,
              y: 355,
              w: 61,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'MusicCommonScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 57,
              y: 355,
              w: 61,
              h: 63,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'MoreListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 96,
              y: 172,
              w: 55,
              h: 55,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'WorldClockScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 130,
              y: 105,
              w: 73,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CompassScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 113,
              y: 33,
              text: '',
              w: 50,
              h: 50,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
              click_Bezel();              
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);              

            const themeButton = hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 36,          
                y: 102,
                w: 50,
                h: 50,
                text: '',
                press_src: 'clean.png',
                normal_src: 'clean.png',
                click_func: () => {
                    currentTheme = (currentTheme % 2) + 1;  
                    applyTheme(currentTheme);
                    hmUI.showToast({ text: `Тема ${currentTheme}` });
                },
                show_level: hmUI.show_level.ONLY_NORMAL,  
            });             

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
                normal_day_text_font2.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

            };

            function applyTheme(theme) {
                console.log(`Применяем тему ${theme}`);

                // Normal            
                normal_background_bg_img.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_background_bg_img2.setProperty(hmUI.prop.VISIBLE, theme === 2);       
                normal_image_img.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_image_img2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_weather_image_progress_img_level2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_temperature_current_text_font.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_temperature_current_text_font2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_date_img_date_month_img.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_date_img_date_month_img2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_date_img_date_week_img.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_date_img_date_week_img2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_day_text_font.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_day_text_font2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_altitude_target_text_font.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_altitude_target_text_font2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_wind_current_text_font.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_wind_current_text_font2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_sun_high_text_font2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_sun_low_text_font2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                sleep_time_txt.setProperty(hmUI.prop.VISIBLE, theme === 1);
                sleep_time_txt2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_readiness_current_text_font.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_readiness_current_text_font2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_heart_rate_text_font.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_heart_rate_text_font2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_calorie_current_text_font.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_calorie_current_text_font2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_distance_current_text_font.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_distance_current_text_font2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_step_current_text_font.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_step_current_text_font2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_battery_circle_scale.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_battery_circle_scale2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_battery_current_text_font.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_battery_current_text_font2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_digital_clock_img_time2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_system_lock_img.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_system_lock_img2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_system_disconnect_img.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_system_disconnect_img2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_system_clock_img.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_system_clock_img2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_analog_clock_time_pointer_hour2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_analog_clock_time_pointer_minute2.setProperty(hmUI.prop.VISIBLE, theme === 2);                
                // Сохраняем выбор
                hmFS.SysProSetInt('WatchTheme', theme);
            }             

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 360,
                      end_angle: 63,
                      radius: 225,
                      line_width: 12,
                      corner_flag: 3,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                  
                  if (normal_battery_circle_scale2) {
                    normal_battery_circle_scale2.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 360,
                      end_angle: 63,
                      radius: 225,
                      line_width: 12,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };                  
                };

                
                let progress_cs_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 360,
                      end_angle: 63,
                      radius: 225,
                      line_width: 12,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                calculateAndCacheRealSleep();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {            
                if (sleep) {
                    sleep = null;
                }  

                // Правильная очистка
                try {
                    cachedSleepText = "--";
                    lastSleepDate = null;
                    lastShownSleepText = null;
                } catch (e) {}                  

                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}