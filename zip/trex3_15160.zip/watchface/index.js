/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_battery_imageset2 = '';
		let normal_steps_imagecombo4 = '';
		let normal_img5 = '';
		let normal_img6 = '';
		let normal_week_imageset8 = '';
		let normal_date_imagecombo9 = '';
		let normal_img11 = '';
		let normal_minute_rotary12 = '';
		let timeInterval;
		let normal_hour_rotary13 = '';
		let clock_timer;
		let normal_second_sweep_rotary14 = '';
		let normal_img16 = '';
		let idle_img18 = '';
		let idle_battery_imageset20 = '';
		let idle_minute_rotary22 = '';
		let idle_hour_rotary23 = '';
		let idle_img25 = '';
		let idle_img26 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imageset2 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 80,
					y: 140,
					image_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
					image_length: 11,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo4 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 319,
					y: 227,
					font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 355,
					y: 181,
					w: 28,
					h: 46,
					src: '0024.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img6 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 333,
					y: 259,
					w: 75,
					h: 18,
					src: '0025.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset8 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 216,
					y: 307,
					week_en: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					week_tc: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					week_sc: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo9 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 225,
					day_startY: 343,
					day_sc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					day_tc_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					day_en_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.LEFT,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0043.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_rotary12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: -14,
					pos_y: -14,
					src: '0044.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_rotary13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: -14,
					pos_y: -14,
					src: '0045.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_sweep_rotary14 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: -14,
					pos_y: -14,
					src: '0046.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0047.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img18 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0048.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_battery_imageset20 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 80,
					y: 137,
					image_array: ["0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png"],
					image_length: 11,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_rotary22 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: -14,
					pos_y: -14,
					src: '0044.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_rotary23 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: -14,
					pos_y: -14,
					src: '0045.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0047.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img26 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0047.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateTime() {
					if (normal_minute_rotary12) {
						normal_minute_rotary12.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
					if (normal_hour_rotary13) {
						normal_hour_rotary13.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (idle_minute_rotary22) {
						idle_minute_rotary22.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
					if (idle_hour_rotary23) {
						idle_hour_rotary23.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						const animFps = 60;
						const animRepeat = 1000/animFps;
						const animProgress = 6/animFps;
						let animAngle = 0;
						let animDelay = 0;
						clock_timer = timer.createTimer(animDelay, animRepeat, (function(option) {
							animAngle = timeSensor.second * 6 + ((timeSensor.utc % 1000) / 1000) * 6;
							normal_second_sweep_rotary14.setProperty(hmUI.prop.ANGLE, animAngle);
						}));

						updateTime();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						timer.stopTimer(clock_timer);
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
						timer.stopTimer(clock_timer);
		},
	});	})()
} catch (e) {
	console.log(e)
}