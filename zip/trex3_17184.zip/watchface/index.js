﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Artemushe
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() { return __$$app$$__.app; }
        function getCurrentPage() { return __$$app$$__.current && __$$app$$__.current.module; }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT } = hmSetting.getDeviceInfo();
        const radius = DEVICE_WIDTH / 2, centerX = DEVICE_WIDTH / 2, centerY = DEVICE_HEIGHT / 2; 
        //end of ignored block
        let curTime = null;
        try {
            curTime = hmSensor.createSensor(hmSensor.id.TIME);
        } catch (e) {
            curTime = null;
            console.log('TIME sensor not available or failed to create:', e);
        }
        let battery = null;
        try {
            battery = hmSensor.createSensor(hmSensor.id.BATTERY);
        } catch (e) {
            battery = null;
            console.log('BATTERY sensor not available or failed to create:', e);
        }

        const BK = {
            DATE: 'bl_date',
            BATT: 'bl_batt',
            DAYS: 'bl_days',
            DELTA: 'bl_delta', 
            FLAG: 'bl_flag',
            D1: 'bl_d1',
            D2: 'bl_d2' 
        };
        const DEFAULT_DELTA = 8;
        const MIN_DAILY_DRAIN = 2;
        const MAX_DAILY_DRAIN = 15;

        function readIntSafe(key, fallback = 0) {
            const v = hmFS.SysProGetInt(key);
            const n = Number(v);
            if (typeof n === 'number' && !isNaN(n)) return n; 
            return fallback;
        }         
        // Handler references 
        let curTimeDayChangeHandler = null;
        let curTimeMinuteHandler = null;
        let batteryChangeHandler = null;
        let lastProcessedMinute = -1;
        //
        let normal_year_icon_img = null;
        let lastHolidayDate = -1;
        const HOLIDAYS = {
          1231: 'calendar_1.png', 
          101: 'calendar_1.png',  
        };         
        //dynamic modify start
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 9            
        let btn_bezel2 = ''
        let bezel_num2 = 1
        let bezel_all2 = 6       
        // Widgets & globals
        let weatherImg, tempText, cityNameText, tempMinText, tempMaxText, tempFeelsText, descriptionText;
        let weatherProvider = null;  
        // Sleep / zodiac / day caches
        let sleep = null;
        let cachedSleepText = "00:00";
        let lastSleepDate = null;
        let lastShownSleepText = "--";
        let sleep_time_txt = null;
        let lastTotalMinutes = 0;
        let lastSleepUpdateMs = 0;
        const SLEEP_THROTTLE_MS = 5 * 60 * 1000;                 
        //        
        let normal_background_bg_img = ''        
        let normal_battery_circle_scale = ''
        let normal_image_img = ''        
        let normal_battery_current_text_font = ''
        let sleep_time_img = ''
        let normal_battery_life = null;
        let bio_icon_img = ''
        let bio_current_text_font = ''
        let bio_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_distance_icon_img = ''
        let normal_distance_current_text_font = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_step_image_progress_img_level = ''
        let normal_alarm_clock_icon_img = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_day_text_font = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;        
        //
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 26;
        let normal_img_height = 30;
        let normal_timerTextUpdate = undefined;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 26;  
        //
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_circle_scale = ''
        let idle_image_img = ''        
        let idle_battery_current_text_font = ''
        let idle_alarm_clock_current_text_font = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_day_text_font = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''                      
        
            // --------------------
            // WeatherProvider v4.3
            // --------------------
            class WeatherProvider {
                constructor(props = {}) {
                    // Оптимизация: статические словари 
                    this.iconMapService = {
                        1: 3, 2: 0, 3: 4, 4: 4, 5: 1, 6: 5, 7: 10, 8: 15, 
                        9: 6, 10: 8, 11: 9, 12: 12, 13: 13, 14: 17
                    };
                    
                    this.description = [
                        ['Облачно','Временами дождь','Временами снег','Ясно','Пасмурно','Слабый дождь','Слабый снег','Умеренный дождь','Умеренный снег','Сильный снегопад','Сильный дождь','Песчаная буря','Мокрый снег','Туман','Дымка','Дождь с грозой','Метель','Пыльно','Ливень','Дождь с градом','Сильный дождь с градом','Сильный дождь','Пыльная буря','Сильная песчаная буря','Сильный дождь','Обновите погоду','Облачно ночью','Дождливо ночью','Ясно ночью'],
                        ['Cloudy','Showers','Snow Showers','Sunny','Overcast','Light Rain','Light Snow','Moderate Rain','Moderate Snow','Heavy Snow','Heavy Rain','Sandstorm','Rain and Snow','Fog','Hazy','T-Storms','Snowstorm','Floating dust','Very Heavy Rainstorm','Rain and Hail','T-Storms and Hail','Heavy Rainstorm','Dust','Heavy sand storm','Rainstorm','Unknown','Cloudy Nighttime','Showers Nighttime','Sunny Nighttime']
                    ];

                    this.props = {
                        night_icons: [0, 1, 2, 3, 14],
                        index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,
                        show_toast: true,
                        temp_widget: null,
                        temp_max_widget: null,
                        temp_min_widget: null,
                        temp_feels_widget: null,
                        description_widget: null,
                        cityName_widget: null,
                        icon_widget: null,
                        time_sensor: null,
                        weather_sensor: null,
                        auto_update: true,
                        lang: (hmSetting.getLanguage() === 4 ? 0 : 1), 
                        ...props
                    };

                    this.providers = [
                        { name: ['Zepp','Zepp'], appId: null },
                        { name: ['Погодный сервис','Weather service'], appId: 1065824 }
                    ];

                    this.last = {
                        weatherIcon: 25,
                        displayedIcon: '25',
                        weatherDescription: 'Нет данных',
                        temperature: '--',
                        temperatureFeels: '--',
                        temperatureMax: '--',
                        temperatureMin: '--',
                        cityName: '--',
                        modTime: null,
                        sunData: -1,
                        sunriseMins: 6 * 60, 
                        sunsetMins: 20 * 60  
                    };

                    if (!this.props.time_sensor) {
                        try { this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME); } catch (e) { this.props.time_sensor = null; }
                    }
                    if (!this.props.weather_sensor) {
                        try { this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER); } catch (e) { this.props.weather_sensor = null; }
                    }
                    this._zeppHandlerRef = null;
                    this.minuteEndHandler = null;
                    this.widgetDelegate = null;
                    this._THROTTLE_MS = 10 * 60 * 1000;

                    if (isFinite(this.props.index)) hmFS.SysProSetInt('WeatherProviderIndex', this.props.index);

                    if (this.props.auto_update) this.createHandlers();

                    if (this.props.auto_update && this.props.index === 0) {
                        this._zeppHandlerRef = () => this.update(true); 
                        try {
                            if (this.props.weather_sensor && this.props.weather_sensor.addEventListener) {
                                this.props.weather_sensor.addEventListener(hmSensor.event.CHANGE, this._zeppHandlerRef);
                            }
                        } catch (e) {
                            console.log('Error adding weather CHANGE listener:', e);
                            this._zeppHandlerRef = null;
                        }
                    }
                }

                createHandlers() {
                    this.minuteEndHandler = () => this.update(false);
                    try {
                        if (this.props.time_sensor && this.props.time_sensor.addEventListener) {
                            this.props.time_sensor.addEventListener(hmSensor.event.MINUTEEND, this.minuteEndHandler);
                        }
                    } catch (e) { console.log('createHandlers TIME listener error:', e); }

                    try {
                        this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                            resume_call: () => {
                                this.update(true); 
                            }
                        });
                    } catch (e) { console.log('createHandlers widgetDelegate error:', e); }
                }

                arrayBufferToCyrillic(buffer) {
                    let result = '';
                    const bytes = new Uint8Array(buffer);
                    const len = bytes.length;
                    for (let i = 0; i < len;) {
                        let byte1 = bytes[i++];
                        if (byte1 < 0x80) {
                            result += String.fromCharCode(byte1);
                        } else if (byte1 >= 0xC0 && byte1 < 0xE0) {
                            let byte2 = bytes[i++];
                            result += String.fromCharCode(((byte1 & 0x1F) << 6) | (byte2 & 0x3F));
                        } else if (byte1 >= 0xE0 && byte1 < 0xF0) {
                            let byte2 = bytes[i++];
                            let byte3 = bytes[i++];
                            result += String.fromCharCode(((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F));
                        }
                    }
                    return result;
                }

                readFile(app_id) {
                    if (!app_id) return null;
                    try {
                        const [fs_stat, err] = hmFS.stat('weather.json', { appid: app_id });
                        if (err === 0 && fs_stat.size > 0) {
                            const fh = hmFS.open('weather.json', hmFS.O_RDONLY, { appid: app_id });
                            const array_buffer = new ArrayBuffer(fs_stat.size);
                            hmFS.read(fh, array_buffer, 0, fs_stat.size);
                            hmFS.close(fh);
                            return this.arrayBufferToCyrillic(array_buffer);
                        }
                    } catch (e) { console.log('readFile error:', e); }
                    return null;
                }

                getFileModTime(app_id) {
                    if (!app_id) return null;
                    try {
                        const [fs_stat, err] = hmFS.stat('weather.json', { appid: app_id });
                        if (err === 0) return fs_stat.mtime;
                    } catch (e) { /* ignore */ }
                    return null;
                }

                getZeppIconIndex(index, app_id = null) {
                    if (!app_id) return index;
                    if (app_id === 1065824) {
                        return this.iconMapService[index] ?? 25;
                    } else if (app_id === 1066654) {
                        return index - 1;
                    }
                    return index;
                }

                tempWithSign(val) {
                    let fVal = parseFloat(val);
                    if (isNaN(fVal) || !isFinite(fVal)) return '--'; 
                    fVal = Math.round(fVal);
                    return (fVal > 0 ? '+' : '') + fVal + '°';
                }

                getZeppWeatherData() {
                    try {
                        const ws = this.props.weather_sensor;
                        if (!ws) throw new Error("No Sensor");

                        const fw = ws.getForecastWeather ? ws.getForecastWeather() : null;
                        const cityName = fw ? fw.cityName : '--';
                        
                        const iconIndex = ws.curAirIconIndex ?? 25;
                        
                        return {
                            weatherIcon: iconIndex,
                            weatherDescription: this.description[this.props.lang][iconIndex] || 'Нет данных',
                            temperature: ws.current ?? '--',
                            temperatureFeels: ws.feelsLike ?? '--',
                            temperatureMax: ws.high ?? '--',
                            temperatureMin: ws.low ?? '--',
                            cityName: cityName
                        };
                    } catch (e) {
                        return { weatherIcon:25, weatherDescription:'Нет данных', temperature:'--', temperatureFeels:'--', temperatureMax:'--', temperatureMin:'--', cityName:'--' };
                    }
                }

                getAppWeatherData(app_id) {
                    const data = { weatherIcon: 25, weatherDescription: 'Нет данных', temperature: '--', temperatureFeels: '--', temperatureMax: '--', temperatureMin: '--', cityName: '--' };
                    const weather_str = this.readFile(app_id);
                    if (!weather_str) return data;

                    try {
                        const weatherJson = JSON.parse(weather_str);
                        if (weatherJson) {
                            data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon || 25), app_id);
                            
                            if (weatherJson.weatherDescriptionExtended) {
                                const desc = weatherJson.weatherDescriptionExtended;
                                data.weatherDescription = desc.charAt(0).toUpperCase() + desc.slice(1);
                            } else {
                                data.weatherDescription = this.description[this.props.lang][data.weatherIcon] || 'Нет данных';
                            }

                            data.temperature = weatherJson.temperature ?? '--';
                            data.temperatureFeels = weatherJson.temperatureFeels ?? '--';
                            data.temperatureMax = weatherJson.temperatureMax ?? '--';
                            data.temperatureMin = weatherJson.temperatureMin ?? '--';
                            data.cityName = weatherJson.city || '--';
                        }
                    } catch (e) { console.log('JSON Parse error:', e); }
                    return data;
                }

                getWeatherData(app_id = null) {
                    return !app_id ? this.getZeppWeatherData() : this.getAppWeatherData(app_id);
                }

                update(force = false) {
                    try {
                        let lastUpdateMs = hmFS.SysProGetInt64("weatherLastUpdateMs") || 0;
                        const nowMs = Date.now();
                        
                        if (!force && (nowMs - lastUpdateMs < this._THROTTLE_MS)) return;

                        const prov = this.providers[this.props.index];
                        const isZepp = prov.appId === null;

                        let modTime = null;
                        if (!isZepp) {
                            modTime = this.getFileModTime(prov.appId);
                            if (!force && (modTime === null || this.last.modTime === modTime)) return;
                        } else {
                            try {
                                const fw = this.props.weather_sensor && this.props.weather_sensor.getForecastWeather && this.props.weather_sensor.getForecastWeather();
                                if (fw && fw.mtime) modTime = fw.mtime;
                            } catch (e) {}
                        }

                        const newData = this.getWeatherData(prov.appId);
                        this.last.modTime = modTime;

                        const tVal = this.tempWithSign(newData.temperature);
                        if (tVal !== this.last.temperature) {
                            this.last.temperature = tVal;
                            if (this.props.temp_widget) this.props.temp_widget.setProperty(hmUI.prop.TEXT, tVal);
                        }

                        const tMax = this.tempWithSign(newData.temperatureMax);
                        if (tMax !== this.last.temperatureMax) {
                            this.last.temperatureMax = tMax;
                            if (this.props.temp_max_widget) this.props.temp_max_widget.setProperty(hmUI.prop.TEXT, tMax);
                        }

                        const tMin = this.tempWithSign(newData.temperatureMin);
                        if (tMin !== this.last.temperatureMin) {
                            this.last.temperatureMin = tMin;
                            if (this.props.temp_min_widget) this.props.temp_min_widget.setProperty(hmUI.prop.TEXT, tMin);
                        }

                        const tFeels = this.tempWithSign(newData.temperatureFeels);
                        if (tFeels !== this.last.temperatureFeels) {
                            this.last.temperatureFeels = tFeels;
                            if (this.props.temp_feels_widget) this.props.temp_feels_widget.setProperty(hmUI.prop.TEXT, tFeels);
                        }

                        if (newData.cityName !== this.last.cityName) {
                            this.last.cityName = newData.cityName;
                            if (this.props.cityName_widget) this.props.cityName_widget.setProperty(hmUI.prop.TEXT, newData.cityName);
                        }

                        if (newData.weatherDescription !== this.last.weatherDescription) {
                            this.last.weatherDescription = newData.weatherDescription;
                            if (this.props.description_widget) this.props.description_widget.setProperty(hmUI.prop.TEXT, newData.weatherDescription);
                        }

                        let curIcon = parseInt(newData.weatherIcon);
                        let iconSuffix = '';
                        
                        if (this.props.night_icons.includes(curIcon) && !this.isDayNow()) {
                            iconSuffix = 'n';
                        }
                        
                        const finalIconStr = `${curIcon}${iconSuffix}`;
                        if (finalIconStr !== this.last.displayedIcon) {
                            this.last.displayedIcon = finalIconStr;
                            this.last.weatherIcon = curIcon; // save raw numeric
                            if (this.props.icon_widget) this.props.icon_widget.setProperty(hmUI.prop.SRC, `w_${finalIconStr}.png`);
                        }

                        hmFS.SysProSetInt64("weatherLastUpdateMs", nowMs);
                    } catch (e) {
                        console.log('WeatherProvider.update error:', e);
                    }
                }

                next(show_toast = this.props.show_toast) {
                    this.props.index = (this.props.index + 1) % this.providers.length;
                    hmFS.SysProSetInt('WeatherProviderIndex', this.props.index);
                    if (show_toast) hmUI.showToast({ text: this.providers[this.props.index].name[this.props.lang] });
                    this.update(true);
                }
                prev(show_toast = this.props.show_toast) {
                    this.props.index = (this.props.index - 1 + this.providers.length) % this.providers.length;
                    hmFS.SysProSetInt('WeatherProviderIndex', this.props.index);
                    if (show_toast) hmUI.showToast({ text: this.providers[this.props.index].name[this.props.lang] });
                    this.update(true);
                }

                get cityName() { return this.last.cityName ?? '--'; }
                get temperature() { return this.last.temperature ?? '--'; }
                get temperatureFeels() { return this.last.temperatureFeels ?? '--'; }
                get temperatureMax() { return this.last.temperatureMax ?? '--'; }
                get temperatureMin() { return this.last.temperatureMin ?? '--'; }
                get weatherDescription() { return this.last.weatherDescription ?? 'Нет данных'; }
                get weatherIcon() { return this.last.weatherIcon ?? 25; }

                delete() {
                    if (this._zeppHandlerRef && this.props.weather_sensor) {
                        try {
                            this.props.weather_sensor.removeEventListener(hmSensor.event.CHANGE, this._zeppHandlerRef);
                        } catch (e) {}
                    }
                    this._zeppHandlerRef = null;

                    if (this.minuteEndHandler && this.props.time_sensor) {
                        try {
                            this.props.time_sensor.removeEventListener(hmSensor.event.MINUTEEND, this.minuteEndHandler);
                        } catch (e) {}
                    }
                    this.minuteEndHandler = null;

                    if (this.widgetDelegate) {
                        try { hmUI.deleteWidget(this.widgetDelegate); } catch(e){}
                        this.widgetDelegate = null;
                    }

                    this.providers = null;
                    this.props = null;
                    this.last = null;
                    this.description = null;
                    this.iconMapService = null;
                }

                isDayNow() {
                    const ts = this.props.time_sensor;
                    const curHour = ts ? ts.hour : (new Date()).getHours();
                    const curMin = ts ? ts.minute : (new Date()).getMinutes();
                    const curMins = curHour * 60 + curMin;
                    const currentDay = ts ? ts.day : (new Date()).getDate();
                    
                    if (currentDay !== this.last.sunData) {
                        this.last.sunData = currentDay;
                        try {
                            const ws = this.props.weather_sensor;
                            if (ws && ws.getForecastWeather) {
                                const fw = ws.getForecastWeather();
                                if (fw.forecastData && fw.forecastData.count > 0) {
                                    const today = fw.forecastData.data[0];
                                    if (today.sunrise && today.sunset) {
                                        this.last.sunriseMins = parseInt(today.sunrise.hour) * 60 + parseInt(today.sunrise.minute);
                                        this.last.sunsetMins = parseInt(today.sunset.hour) * 60 + parseInt(today.sunset.minute);
                                        return curMins >= this.last.sunriseMins && curMins < this.last.sunsetMins;
                                    }
                                }
                                if (fw.tideData && fw.tideData.count > 0) {
                                    const today = fw.tideData.data[0];
                                    this.last.sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
                                    this.last.sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
                                }
                            }
                        } catch (e) { console.log('isDayNow update error:', e); }
                    }
                    
                    return curMins >= this.last.sunriseMins && curMins < this.last.sunsetMins;
                }
            }   
            
            
            // -------------
            // Sleep helpers
            // -------------
            try {
                sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
                sleep.onSleepStateChange = () => {
                    if (sleep.state === hmSensor.sleep_state.END) {
                        calculateAndCacheRealSleep(true);
                    }
                };

            } catch (e) {
                console.log("Sleep sensor init failed:", e);
                sleep = null;
            }
            function formatMinutes(mins) {
                if (!mins || mins <= 0) return "00:00";

                const h = Math.floor(mins / 60);
                const m = mins % 60;
                return String(h).padStart(2, "0") + ":" + String(m).padStart(2, "0");
            }
            function calculateAndCacheRealSleep(force = false) {
                if (!sleep) {
                    cachedSleepText = "00:00";
                    updateSleepText();
                    return;
                }
                try {
                    const now = Date.now();
                    const today = new Date().toDateString();
                    let currentTotal = sleep.getTotalTime();
                    if (!force && (now - lastSleepUpdateMs < SLEEP_THROTTLE_MS) && lastSleepDate === today && currentTotal === lastTotalMinutes) {
                        updateSleepText();
                        return;
                    }
                    sleep.updateInfo();
                    currentTotal = sleep.getTotalTime();
                    if (!force && lastSleepDate === today && currentTotal === lastTotalMinutes) {
                        updateSleepText();
                        return;
                    }
                    const info = sleep.getBasicInfo();
                    if (!info || info.startTime === 0 || info.endTime === 0) {
                        cachedSleepText = "00:00";
                        updateSleepText();
                        return;
                    }
                    let totalMinutes = currentTotal;
                    if (!totalMinutes || totalMinutes < 0) {
                        cachedSleepText = "00:00";
                        updateSleepText();
                        return;
                    }
                    if (totalMinutes > 18 * 60) totalMinutes = 0;
                    if (totalMinutes > 90) {
                        try {
                            const stages = sleep.getSleepStageData();
                            const model = sleep.getSleepStageModel();
                            let wakeMinutes = 0;
                            for (const st of stages) {
                                if (st.model === model.WAKE_STAGE) {
                                    wakeMinutes += (st.stop + 1 - st.start);
                                }
                            }
                            totalMinutes -= wakeMinutes;
                        } catch (e) {
                            // Ignore
                        }
                    }
                    cachedSleepText = formatMinutes(totalMinutes);
                    lastSleepDate = today;
                    lastTotalMinutes = currentTotal;
                    lastSleepUpdateMs = now;
                    updateSleepText();
                } catch (e) {
                    console.log("calculateAndCacheRealSleep error:", e);
                    cachedSleepText = "00:00";
                    updateSleepText();
                }
            }
            function updateSleepText() {
                if (!sleep_time_txt) return;
                if (hmSetting.getScreenType() === hmSetting.screen_type.AOD) return;
                if (lastShownSleepText !== cachedSleepText) {
                    try {
                        sleep_time_txt.setProperty(hmUI.prop.TEXT, cachedSleepText);
                    } catch (e) { }
                    lastShownSleepText = cachedSleepText;
                }
            }
            
            // -------------------
            // updateBatteryLife v3.0
            // -------------------
            function drawBatteryWidget(currentBatt, delta, daysWorked) {
                try {
                    if (!normal_battery_life) return;
                    delta = Math.round(Number(delta)) || DEFAULT_DELTA;
                    if (delta < 1) delta = DEFAULT_DELTA;
                    let daysLeft = Math.max(0, Math.ceil(currentBatt / delta));
                    normal_battery_life.setProperty(hmUI.prop.TEXT, `${Math.round(delta)}% ${daysWorked}-${daysLeft}`);
                } catch (e) {
                    normal_battery_life && normal_battery_life.setProperty(hmUI.prop.TEXT, `${Math.round(delta || DEFAULT_DELTA)}% ${daysWorked}-??`);
                    console.log('drawBatteryWidget error:', e);
                }
            }

            function resetChargingStats(todayKey, currentBatt, oldDelta) {
                const prevDate = readIntSafe(BK.DATE, 0);
                const prevBatt = readIntSafe(BK.BATT, -1);
                
                if (prevDate !== todayKey) hmFS.SysProSetInt(BK.DATE, todayKey);
                if (prevBatt !== currentBatt) hmFS.SysProSetInt(BK.BATT, currentBatt);

                hmFS.SysProSetInt(BK.DAYS, 0);
                hmFS.SysProSetInt(BK.FLAG, 0);
                hmFS.SysProSetInt(BK.D1, 0);
                hmFS.SysProSetInt(BK.D2, 0);

                drawBatteryWidget(currentBatt, oldDelta, 0); 
            }

            function checkDayAndLearn() {
                try {
                    if (!battery || !curTime) return;
                    const cur = battery.current;
                    if (typeof cur !== 'number' || cur < 0 || cur > 100) return;

                    const todayKey = curTime.year * 10000 + curTime.month * 100 + curTime.day;

                    let cacheDate = readIntSafe(BK.DATE, 0);
                    let cacheBatt = readIntSafe(BK.BATT, -1);
                    let days = readIntSafe(BK.DAYS, 0);
                    const oldDays = days; 

                    let delta = readIntSafe(BK.DELTA, DEFAULT_DELTA);
                    if (delta < MIN_DAILY_DRAIN || delta > MAX_DAILY_DRAIN) delta = DEFAULT_DELTA;

                    if (cacheDate === 0) return;

                    if (cur > cacheBatt) {
                        resetChargingStats(todayKey, cur, delta);
                        return;
                    }

                    if (todayKey > cacheDate) {
                        
                        const drain = Math.max(0, cacheBatt - cur); 
                        days = days + 1;

                        let flag = readIntSafe(BK.FLAG, 0);
                        let currentDelta = delta; 

                        if (days > 1) {
                            if (flag === 0) {
                                hmFS.SysProSetInt(BK.D1, drain);
                                hmFS.SysProSetInt(BK.FLAG, 1);
                            } else if (flag === 1) {
                                hmFS.SysProSetInt(BK.D2, drain);
                                hmFS.SysProSetInt(BK.FLAG, 2);
                            } else if (flag === 2) {
                                const d1 = readIntSafe(BK.D1, 0);
                                const d2 = readIntSafe(BK.D2, 0);
                                const avg = Math.round((d1 + d2 + drain) / 3);
                                let newDelta = avg;
                                if (avg < MIN_DAILY_DRAIN || avg > MAX_DAILY_DRAIN) {
                                    newDelta = (delta >= MIN_DAILY_DRAIN && delta <= MAX_DAILY_DRAIN) ? delta : DEFAULT_DELTA;
                                }
                                if (newDelta !== delta) {
                                    hmFS.SysProSetInt(BK.DELTA, newDelta);
                                    currentDelta = newDelta; 
                                }

                                hmFS.SysProSetInt(BK.FLAG, 0);
                                hmFS.SysProSetInt(BK.D1, 0);
                                hmFS.SysProSetInt(BK.D2, 0);
                            }
                        }

                        if (cacheDate !== todayKey) hmFS.SysProSetInt(BK.DATE, todayKey);
                        if (cacheBatt !== cur) hmFS.SysProSetInt(BK.BATT, cur);
                        if (days !== oldDays) hmFS.SysProSetInt(BK.DAYS, days);
                        
                        updateBatteryLife(true, days, currentDelta); 

                    } else if (todayKey < cacheDate) {
                        resetChargingStats(todayKey, cur, delta);
                    }
                } catch (e) {
                    console.log('checkDayAndLearn error:', e);
                }
            }

            function updateBatteryLife(forceDraw = false, daysOverride, deltaOverride) {
                try {
                    if (!battery || !curTime) return;
                    if (!normal_battery_life) return;

                    const cur = battery.current;
                    if (typeof cur !== 'number' || cur < 0 || cur > 100) return;

                    const todayKey = curTime.year * 10000 + curTime.month * 100 + curTime.day;

                    let cacheDate = readIntSafe(BK.DATE, 0);
                    let cacheBatt = readIntSafe(BK.BATT, -1);
                    let days = readIntSafe(BK.DAYS, 0);
                    let delta = readIntSafe(BK.DELTA, DEFAULT_DELTA);
                    if (delta < MIN_DAILY_DRAIN || delta > MAX_DAILY_DRAIN) delta = DEFAULT_DELTA;
                    
                    const daysToDraw = daysOverride !== undefined ? daysOverride : days;
                    const deltaToDraw = deltaOverride !== undefined ? deltaOverride : delta;

                    if (!cacheDate || cur > cacheBatt) {
                        resetChargingStats(todayKey, cur, deltaToDraw); 
                        return;
                    }

                    if (!forceDraw && cacheDate === todayKey) return;

                    drawBatteryWidget(cur, deltaToDraw, daysToDraw);
                } catch (e) {
                    console.log('updateBatteryLife error:', e);
                }
            }
            
            // -----------
            // UI creation
            // -----------
            function click_Bezel() {
              if(bezel_num>=bezel_all) {bezel_num=1;}
              else { bezel_num=bezel_num+1;}
              hmUI.showToast({text: "Цвет " + parseInt(bezel_num) });
                normal_background_bg_img.setProperty(hmUI.prop.SRC, "osn_" + parseInt(bezel_num) + ".png");
            }   
      
            function click_Bezel2() {
              if(bezel_num2>=bezel_all2) {bezel_num2=1;}
              else { bezel_num2=bezel_num2+1;}
              hmUI.showToast({text: "Цвет " + parseInt(bezel_num2) });
                normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.SRC, "hour_" + parseInt(bezel_num2) + ".png");
                normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.SRC, "min_" + parseInt(bezel_num2) + ".png");
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "sekk_" + parseInt(bezel_num2) + ".png");               
            }             

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: GoogleSans-Regular.ttf; FontSize: 25
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 333,
              h: 37,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: GoogleSans-Regular.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 412,
              h: 46,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: GoogleSans-Regular.ttf; FontSize: 20; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 24,
              h: 24,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: GoogleSans-Regular.ttf; FontSize: 27
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 358,
              h: 40,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: GoogleSans-Regular.ttf; FontSize: 21; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 25,
              h: 25,
              text_size: 21,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: GoogleSans-Regular.ttf; FontSize: 38
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 519,
              h: 58,
              text_size: 38,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 239,
              // center_y: 395,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 39,
              // line_width: 18,
              // line_cap: Flat,
              // color: 0xFF282828,
              // mirror: False,
              // inversion: True,
              // alpha: 200,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 239,
              center_y: 395,
              start_angle: 360,
              end_angle: 0,
              radius: 30,
              line_width: 18,
              corner_flag: 3,
              color: 0xFF282828,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_circle_scale.setAlpha(200);         

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_9.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 166,
              y: 380,
              w: 150,
              h: 50,
              text_size: 25,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_year_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'calendar_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });             

            sleep_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 28,
              y: 28,
              w: 424,
              h: 424,
              text_size: 25,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -218,
              end_angle: 0,
              mode: 1,
              // radius: 212,
              align_h: hmUI.align.CENTER_H,
              text: "00:00",
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); 
            calculateAndCacheRealSleep(true);   
            
            sleep_time_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 38,
              y: 245,
              src: 'sleep.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });   
            
            normal_battery_life = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 24,
              y: 24,
              w: 432,
              h: 432,
              text_size: 25,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 90,
              end_angle: 270,
              mode: 1,
              // radius: 216,
              align_h: hmUI.align.CENTER_H,
              text: "8% 0-12",
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); 
            updateBatteryLife(true);           

            bio_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 353,
              y: 79,
              src: 'kkal1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            bio_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              text_size: 30,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -50,
              end_angle: 141,
              mode: 0,
              // radius: 240,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            bio_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["Kkal_0.png","Kkal_1.png","Kkal_2.png","Kkal_3.png","Kkal_4.png","Kkal_5.png","Kkal_6.png","Kkal_7.png","Kkal_8.png"],
              image_length: 9,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 75,
              y: 72,
              src: 'heart1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              text_size: 30,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -180,
              end_angle: 93,
              mode: 0,
              // radius: 240,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["pulse_0.png","pulse_1.png","pulse_2.png","pulse_3.png","pulse_4.png","pulse_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 75,
              y: 353,
              src: 'dist1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              text_size: 30,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -240,
              end_angle: -31,
              mode: 1,
              // radius: 240,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 349,
              y: 352,
              src: 'step1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              text_size: 30,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 1,
              end_angle: 270,
              mode: 1,
              // radius: 240,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["stepp_0.png","stepp_1.png","stepp_2.png","stepp_3.png","stepp_4.png","stepp_5.png","stepp_6.png","stepp_7.png","stepp_8.png"],
              image_length: 9,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const weatherInfo = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
            });

            weatherImg = weatherInfo.createWidget(hmUI.widget.IMG, {
                x: 279,
                y: 58,
                w: 80,
                h: 80,
                src: 'w_25.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });

            descriptionText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 114,
              y: 120,
              w: 260,
              h: 50,
              text_size: 21,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: '--',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            tempText = weatherInfo.createWidget(hmUI.widget.TEXT, {
              x: 58,
              y: 56,
              w: 150,
              h: 50,
              text_size: 27,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              text: '--',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            cityNameText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 172,
              y: 97,
              w: 140,
              h: 50,
              text_size: 20,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: "--",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            weatherProvider = new WeatherProvider({
                time_sensor: curTime,
                temp_widget: tempText,
                icon_widget: weatherImg,
                description_widget: descriptionText,
                cityName_widget: cityNameText,
                night_icons: [0, 1, 2, 3, 14],
                show_toast: true
            });
            weatherProvider.update();

            normal_alarm_clock_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 38,
              y: 245,
              src: 'sleep.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 28,
              y: 28,
              w: 424,
              h: 424,
              text_size: 25,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 37,
              end_angle: 180,
              mode: 1,
              // radius: 212,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 117,
              src: 'alarm.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 421,
              y: 245,
              src: 'alarm1.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });           

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 166,
              y: 51,
              w: 150,
              h: 50,
              text_size: 38,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 20,
              week_en: ["DD_0.png","DD_1.png","DD_2.png","DD_3.png","DD_4.png","DD_5.png","DD_6.png"],
              week_tc: ["DD_0.png","DD_1.png","DD_2.png","DD_3.png","DD_4.png","DD_5.png","DD_6.png"],
              week_sc: ["DD_0.png","DD_1.png","DD_2.png","DD_3.png","DD_4.png","DD_5.png","DD_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });           
            
            const deviceInfo = hmSetting.getDeviceInfo();
            curTimeMinuteHandler = () => {
                let updateHour = curTime.minute == 0;                
                time_update(updateHour, true); 
                checkDayAndLearn();  
                digital_update();                
            };
            try {
                curTime.addEventListener(hmSensor.event.MINUTEEND, curTimeMinuteHandler);
            } catch (e) {
                console.log('Error adding TIME listener:', e);
            }

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'hour_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 44,
              // y: 243,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 44,
              pos_y: 240 - 243,
              center_x: 240,
              center_y: 240,
              src: 'hour_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'min_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 44,
              // y: 243,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 44,
              pos_y: 240 - 243,
              center_x: 240,
              center_y: 240,
              src: 'min_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sekk_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 44,
              // y: 243,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 44,
              pos_y: 240 - 243,
              center_x: 240,
              center_y: 240,
              src: 'sekk_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // массивы картинок для цифр
            for (let i = 0; i < 10; i++) {
              normal_hour_TextRotate_ASCIIARRAY[i] = `H_${i}.png`;
              normal_minute_TextRotate_ASCIIARRAY[i] = `H_${i}.png`;
            }
            // IMG для часов
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0, y: 0, w: 480, h: 480,
                center_x: 240, center_y: 240,
                src: 'H_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            }
            // IMG для минут
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0, y: 0, w: 480, h: 480,
                center_x: 240, center_y: 240,
                src: 'H_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            }      
                      

            
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_AOD1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 197,
              y: 66,
              week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 239,
              // center_y: 395,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 39,
              // line_width: 18,
              // line_cap: Flat,
              // color: 0xFF282828,
              // mirror: False,
              // inversion: True,
              // alpha: 200,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 239,
              center_y: 395,
              start_angle: 360,
              end_angle: 0,
              radius: 30,
              line_width: 18,
              corner_flag: 3,
              color: 0xFF282828,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_circle_scale.setAlpha(200);            

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_AOD2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 166,
              y: 380,
              w: 150,
              h: 50,
              text_size: 25,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 335,
              w: 150,
              h: 50,
              text_size: 25,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 117,
              src: 'alarm.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 229,
              y: 315,
              src: 'alarm1.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 165,
              y: 30,
              w: 150,
              h: 50,
              text_size: 38,
              char_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });


            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_AOD1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 44,
              hour_posY: 243,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_AOD1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 44,
              minute_posY: 243,
              show_level: hmUI.show_level.ONLY_AOD,
            });          
                       

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 355,
              y: 351,
              w: 61,
              h: 61,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 63,
              y: 359,
              w: 61,
              h: 61,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 67,
              y: 62,
              w: 61,
              h: 61,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 209,
              y: 376,
              w: 61,
              h: 40,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 286,
              y: 397,
              w: 61,
              h: 61,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 132,
              y: 395,
              w: 61,
              h: 61,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 398,
              y: 260,
              w: 60,
              h: 70,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 22,
              y: 259,
              w: 60,
              h: 70,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 350,
              y: 65,
              w: 61,
              h: 61,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 30,
              y: 164,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 399,
              y: 165,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'LocalMusicScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 218,
              y: 52,
              w: 45,
              h: 60,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 168,
              y: 55,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button   
            
            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 275,
              y: 55,
              w: 40,
              h: 40,
              text: '',
              text_size: 25,
              color: 0xFFFF8C00,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: () => {                
                weatherProvider.prev(true);                
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });             

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 215,
              y: 430,
              text: '',
              w: 60,
              h: 50,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
              click_Bezel();
              
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true); 
              
            
            btn_bezel2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 218,
              y: 215,
              text: '',
              w: 50,
              h: 50,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
              click_Bezel2();
              
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel2.setProperty(hmUI.prop.VISIBLE, true);     

 
            curTimeDayChangeHandler = () => {                
                time_update(true, true);
                if (typeof checkDayAndLearn === 'function') checkDayAndLearn();
            };
            try {
                if (curTime) {
                    curTime.addEventListener(hmSensor.event.DAYCHANGE, curTimeDayChangeHandler);
                }
            } catch (e) {
                console.log('Error adding DAYCHANGE listener:', e);
            }    

            batteryChangeHandler = () => {               
                scale_call();
                updateBatteryLife();
            };                         
            try {                
                time_update(true, true); 
                scale_call();                
            } catch (e) {
                console.log('Initial update error:', e);
            }    
            try {                
                if (battery) battery.addEventListener(hmSensor.event.CHANGE, batteryChangeHandler);
            } catch (e) {
                console.log('Listeners error:', e);
            }
                         
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              if (!curTime) return;
              let hour = curTime.hour;
              let minute = curTime.minute;
              let second = curTime.second;
              let format_hour = curTime.format_hour;
              let day = curTime.day; 

              if (updateMinute) { // Hour Pointer
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) { // Minute Pointer
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              }; 

              if (normal_analog_clock_pro_second_pointer_img) {
                  let ms = Date.now() % 1000;
                  let angle = 360 * (second + ms / 1000) / 60;
                  normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, angle);
              }
                                                      
              if (updateHour) {
                  let dayStr = curTime.day.toString();
                  if (normal_day_text_font) normal_day_text_font.setProperty(hmUI.prop.TEXT, dayStr);
                  if (idle_day_text_font) idle_day_text_font.setProperty(hmUI.prop.TEXT, dayStr);
              }    
              
              if (updateHour) {
                if (normal_year_icon_img) {
                  const dateKey = curTime.month * 100 + curTime.day;
                  if (dateKey !== lastHolidayDate) {
                    const calendarSrc = HOLIDAYS[dateKey] || 'calendar_0.png';
                    try {
                      normal_year_icon_img.setProperty(hmUI.prop.SRC, calendarSrc);
                    } catch (e) {
                      console.log('Holiday icon update error:', e);
                    }
                    lastHolidayDate = dateKey;
                  }
                }                
              };              

            };

            function digital_update() {  
                const currentScreen = hmSetting.getScreenType();              
                if (currentScreen === hmSetting.screen_type.AOD) return;
                //if (!curTime) return;
                let valueHour = curTime.format_hour;
                let valueMinute = curTime.minute;
                let valueSecond = curTime.second;
                // угол минутной стрелки
                let angle = valueMinute * 6;
                let rad = angle * Math.PI / 180;
                // направление стрелки
                let dx = Math.sin(rad);
                let dy = -Math.cos(rad);
                // радиус до центра блока (подгони под длину стрелки)
                let R = 74;
                // точка привязки блока (центр строки)
                let baseX = 240 + R * dx;
                let baseY = 240 + R * dy;
                // строка HHMM
                let hourStr = String(valueHour).padStart(2, '0');
                let minStr = String(valueMinute).padStart(2, '0');
                let fullStr = hourStr + minStr;
                // угол для блока
                let displayAngle = (valueMinute < 30 ? angle - 90 : angle + 90);
                // ширина строки
                let extra_space = 12; // Задайте здесь желаемый отступ в пикселях между часами и минутами
                let totalWidth = (fullStr.length * normal_hour_TextRotate_img_width) + extra_space; // Учитываем отступ в общей ширине
                let initialOffset = -totalWidth / 2;
                let offset = initialOffset;
                let displayRad = displayAngle * Math.PI / 180;
                let cos = Math.cos(displayRad);
                let sin = Math.sin(displayRad);
                let centerX = 240;
                let centerY = 240;
                let width = normal_hour_TextRotate_img_width;
                let height = normal_img_height;
                // Вычисляем перпендикулярное направление для сдвига
                let perpX = -sin; // Перпендикуляр к направлению строки
                let perpY = cos;
                // Фиксированный сдвиг для центрирования цифры по высоте (верхний левый -> центр)
                let fixedShift = -height / 2;
                // Переменный сдвиг для корректировки расстояния (max при 0/30, min при 15/45)
                let cosAbs = Math.abs(Math.cos(rad));
                let maxShift = 0; // Подгони значение max расстояния
                let minShift = 0;
                let variableShift = minShift + (maxShift - minShift) * cosAbs;
                // Общий сдвиг (можно изменить знак для направления)
                let shiftAmount = fixedShift + variableShift;
                // Применяем сдвиг к base
                baseX += shiftAmount * perpX;
                baseY += shiftAmount * perpY;
                // отрисовка
                for (let i = 0; i < fullStr.length; i++) {
                  let charCode = fullStr.charCodeAt(i) - 48;
                  if (charCode >= 0 && charCode <= 9) {
                    // desired top-left D
                    let desired_D_x = baseX + offset * cos;
                    let desired_D_y = baseY + offset * sin;
                    // vector from rotation center
                    let vx = desired_D_x - centerX;
                    let vy = desired_D_y - centerY;
                    // apply inverse rotation: R(-displayAngle)
                    let pre_vx = cos * vx + sin * vy;
                    let pre_vy = -sin * vx + cos * vy;
                    let pre_pos_x = centerX + pre_vx;
                    let pre_pos_y = centerY + pre_vy;
                    let pos_x = Math.round(pre_pos_x);
                    let pos_y = Math.round(pre_pos_y);
                    let widget = (i < 2 ? normal_hour_TextRotate[i] : normal_minute_TextRotate[i - 2]);
                    widget.setProperty(hmUI.prop.POS_X, pos_x);
                    widget.setProperty(hmUI.prop.POS_Y, pos_y);
                    widget.setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                    widget.setProperty(hmUI.prop.ANGLE, displayAngle);
                    widget.setProperty(hmUI.prop.VISIBLE, true);
                    offset += width;
                    if (i === 1) { // Добавляем отступ после второй цифры часов (перед минутами)
                      offset += extra_space;
                    }
                  }
                }
            }              


            //#endregion
            function scale_call() {                                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 239,
                      center_y: 395,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 30,
                      line_width: 18,
                      corner_flag: 3,
                      color: 0xFF282828,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                let progress_cs_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 239,
                      center_y: 395,
                      start_angle: 360,
                      end_angle: 0,
                      radius: 30,
                      line_width: 18,
                      corner_flag: 3,
                      color: 0xFF282828,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                const currentScreen = hmSetting.getScreenType();
                scale_call();
                time_update(true, true);
                if (currentScreen === hmSetting.screen_type.WATCHFACE) {
                    if (!normal_timerUpdateSec) {
                        lastProcessedMinute = curTime.minute;
                        const delay = Date.now() % 1000;
                        normal_timerUpdateSec = timer.createTimer(
                            delay,
                            250,
                            () => {
                                time_update(false, false);                                
                                if (curTime.minute !== lastProcessedMinute) {
                                    lastProcessedMinute = curTime.minute;
                                    digital_update();
                                    time_update(false, true);
                                }
                            }
                        );
                    }
                }                                

                digital_update();
                calculateAndCacheRealSleep();   
                checkDayAndLearn();                
                updateBatteryLife(true);
                lastHolidayDate = -1;
              }),
              pause_call: (function () {
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {    
                    if (normal_timerUpdateSec) {
                        timer.stopTimer(normal_timerUpdateSec);
                        normal_timerUpdateSec = undefined;
                    }                            

                    if (curTime) {
                        try {
                            if (curTimeMinuteHandler) {
                                curTime.removeEventListener(hmSensor.event.MINUTEEND, curTimeMinuteHandler);
                            }
                            if (curTimeDayChangeHandler) {
                                curTime.removeEventListener(hmSensor.event.DAYCHANGE, curTimeDayChangeHandler);
                            }                            
                        } catch (e) {
                            console.log('Error cleaning curTime:', e);
                        }
                        curTime = null;
                    }
                    curTimeMinuteHandler = null;
                    curTimeDayChangeHandler = null;

                    if (battery) {
                        try {
                            if (batteryChangeHandler) {
                                battery.removeEventListener(hmSensor.event.CHANGE, batteryChangeHandler);
                            }
                        } catch (e) {
                            console.log('Error cleaning battery:', e);
                        }
                        battery = null;
                    }
                    batteryChangeHandler = null;

                    if (sleep) {
                        sleep = null;
                    }                    

                    try {                                                                         
                        cachedSleepText = "--";
                        lastSleepDate = null;
                        lastShownSleepText = null;
                        lastHolidayDate = -1;
                    } catch (e) {}
                    logger.log('watchface destroyed — all cleaned OK');
                }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}