﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
		let alarm_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_stand_target_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_sun_low_text_img = ''
        let idle_system_lock_img = ''
        let idle_system_disconnect_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
		
		let cc = 0
		
		let element_index = 0; 
        let element_count = 6;
		
		function click_PLUS() {
			element_index = (element_index + 1) % element_count;
			apply_content_switch();
		}
		
		function click_MINUS() {
			if (element_index == 0) {
			element_index = element_count - 1;
				} else {
			element_index = (element_index - 1) % element_count;
				}	
			apply_content_switch();
		}

		function apply_content_switch() {

			  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 0);
			  
			  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
			  normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);

			  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 2);
			  
			  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 3);
			  
			  normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  normal_stand_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 4);
			  
			  normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 5);
			  normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, element_index == 5);
        };


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			alarm_clock_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 66,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: true,
              h_space: 0,
              dot_image: 'dots.png',
			  invalid_image: 'invalid.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 387,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '%.png',
              unit_tc: '%.png',
              unit_en: '%.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 178,
              y: 385,
              src: 'btr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 254,
              y: 387,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 175,
              y: 387,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'sl.png',
              unit_tc: 'sl.png',
              unit_en: 'sl.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 178,
              y: 385,
              src: 'A100_041.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 223,
              y: 387,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 181,
              y: 385,
              src: 'A100_045.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 387,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 187,
              y: 386,
              src: 'A100_042.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 387,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 178,
              y: 385,
              src: 'dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 387,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 178,
              y: 385,
              src: 'A100_002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 435,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 17,
              src: 'bts.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 69,
              y: 308,
              week_en: ["weeks_1.png","weeks_2.png","weeks_3.png","weeks_4.png","weeks_5.png","weeks_6.png","weeks_7.png"],
              week_tc: ["weeks_1.png","weeks_2.png","weeks_3.png","weeks_4.png","weeks_5.png","weeks_6.png","weeks_7.png"],
              week_sc: ["weeks_1.png","weeks_2.png","weeks_3.png","weeks_4.png","weeks_5.png","weeks_6.png","weeks_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 265,
              year_startY: 132,
              year_sc_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              year_tc_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              year_en_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 221,
              month_startY: 132,
              month_sc_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              month_tc_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              month_en_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'dot.png',
              month_unit_tc: 'dot.png',
              month_unit_en: 'dot.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 180,
              day_startY: 132,
              day_sc_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              day_tc_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              day_en_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'dot.png',
              day_unit_tc: 'dot.png',
              day_unit_en: 'dot.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 85,
              hour_startY: 187,
              hour_array: ["time_hour_1.png","time_hour_2.png","time_hour_3.png","time_hour_4.png","time_hour_5.png","time_hour_6.png","time_hour_7.png","time_hour_8.png","time_hour_9.png","time_hour_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 257,
              minute_startY: 187,
              minute_array: ["time_min_1.png","time_min_2.png","time_min_3.png","time_min_4.png","time_min_5.png","time_min_6.png","time_min_7.png","time_min_8.png","time_min_9.png","time_min_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 391,
              second_startY: 258,
              second_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 387,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: '%.png',
              unit_tc: '%.png',
              unit_en: '%.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 178,
              y: 385,
              src: 'btr.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 66,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: true,
              h_space: 0,
              dot_image: 'dots.png',
			  invalid_image: 'invalid.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 435,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 227,
              y: 17,
              src: 'bts.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 69,
              y: 308,
              week_en: ["weeks_1.png","weeks_2.png","weeks_3.png","weeks_4.png","weeks_5.png","weeks_6.png","weeks_7.png"],
              week_tc: ["weeks_1.png","weeks_2.png","weeks_3.png","weeks_4.png","weeks_5.png","weeks_6.png","weeks_7.png"],
              week_sc: ["weeks_1.png","weeks_2.png","weeks_3.png","weeks_4.png","weeks_5.png","weeks_6.png","weeks_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 265,
              year_startY: 132,
              year_sc_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              year_tc_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              year_en_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 221,
              month_startY: 132,
              month_sc_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              month_tc_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              month_en_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'dot.png',
              month_unit_tc: 'dot.png',
              month_unit_en: 'dot.png',
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 180,
              day_startY: 132,
              day_sc_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              day_tc_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              day_en_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'dot.png',
              day_unit_tc: 'dot.png',
              day_unit_en: 'dot.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 85,
              hour_startY: 187,
              hour_array: ["time_hour_1.png","time_hour_2.png","time_hour_3.png","time_hour_4.png","time_hour_5.png","time_hour_6.png","time_hour_7.png","time_hour_8.png","time_hour_9.png","time_hour_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 257,
              minute_startY: 187,
              minute_array: ["time_min_1.png","time_min_2.png","time_min_3.png","time_min_4.png","time_min_5.png","time_min_6.png","time_min_7.png","time_min_8.png","time_min_9.png","time_min_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 376,
              w: 100,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 376,
              w: 100,
              h: 50,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 376,
              w: 100,
              h: 50,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 376,
              w: 100,
              h: 50,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 376,
              w: 100,
              h: 50,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 285,
              y: 185,
              w: 80,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 383,
              y: 236,
              w: 50,
              h: 50,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 185,
              w: 80,
              h: 100,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 195,
              y: 122,
              w: 100,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 317,
              y: 375,
              w: 60,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                click_PLUS();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 102,
              y: 375,
              w: 60,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                click_MINUS();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button
			
			if (cc ==0 ){
				
			  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			  
			  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_cal_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

			  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  
			  normal_stand_target_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_stand_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_stand_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_stand_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			  
			  normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
			  normal_battery_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			cc = 1;
			}


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}