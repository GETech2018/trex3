﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_stand_current_text_img = ''
        let normal_stand_current_separator_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 335,
              y: 93,
              week_en: ["yu00.png","yu01.png","yu02.png","yu03.png","yu04.png","yu05.png","yu06.png"],
              week_tc: ["yu00.png","yu01.png","yu02.png","yu03.png","yu04.png","yu05.png","yu06.png"],
              week_sc: ["yu00.png","yu01.png","yu02.png","yu03.png","yu04.png","yu05.png","yu06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 366,
              day_startY: 144,
              day_sc_array: ["iu00.png","iu01.png","iu02.png","iu03.png","iu04.png","iu05.png","iu06.png","iu07.png","iu08.png","iu09.png"],
              day_tc_array: ["iu00.png","iu01.png","iu02.png","iu03.png","iu04.png","iu05.png","iu06.png","iu07.png","iu08.png","iu09.png"],
              day_en_array: ["iu00.png","iu01.png","iu02.png","iu03.png","iu04.png","iu05.png","iu06.png","iu07.png","iu08.png","iu09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 134,
              y: 52,
              image_array: ["001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png","010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png","023.png","024.png","025.png","026.png","027.png","028.png","029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 217,
              y: 70,
              font_array: ["iu00.png","iu01.png","iu02.png","iu03.png","iu04.png","iu05.png","iu06.png","iu07.png","iu08.png","iu09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'DO.png',
              unit_tc: 'DO.png',
              unit_en: 'DO.png',
              negative_image: 'HI.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 406,
              font_array: ["iu00.png","iu01.png","iu02.png","iu03.png","iu04.png","iu05.png","iu06.png","iu07.png","iu08.png","iu09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'PER.png',
              unit_tc: 'PER.png',
              unit_en: 'PER.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 360,
              y: 347,
              font_array: ["iu00.png","iu01.png","iu02.png","iu03.png","iu04.png","iu05.png","iu06.png","iu07.png","iu08.png","iu09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 309,
              src: 'STAND.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 347,
              font_array: ["iu00.png","iu01.png","iu02.png","iu03.png","iu04.png","iu05.png","iu06.png","iu07.png","iu08.png","iu09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 212,
              y: 309,
              src: 'PAI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 84,
              y: 347,
              font_array: ["iu00.png","iu01.png","iu02.png","iu03.png","iu04.png","iu05.png","iu06.png","iu07.png","iu08.png","iu09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'DO2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 99,
              y: 309,
              src: 'DIST.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 277,
              font_array: ["iu00.png","iu01.png","iu02.png","iu03.png","iu04.png","iu05.png","iu06.png","iu07.png","iu08.png","iu09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 239,
              src: 'CAL.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 221,
              y: 277,
              font_array: ["iu00.png","iu01.png","iu02.png","iu03.png","iu04.png","iu05.png","iu06.png","iu07.png","iu08.png","iu09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 212,
              y: 237,
              src: 'BPM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 67,
              y: 277,
              font_array: ["iu00.png","iu01.png","iu02.png","iu03.png","iu04.png","iu05.png","iu06.png","iu07.png","iu08.png","iu09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 87,
              y: 237,
              src: 'STEP.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 76,
              hour_startY: 139,
              hour_array: ["ME00.png","ME01.png","ME02.png","ME03.png","ME04.png","ME05.png","ME06.png","ME07.png","ME08.png","ME09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 234,
              minute_startY: 139,
              minute_array: ["ME00.png","ME01.png","ME02.png","ME03.png","ME04.png","ME05.png","ME06.png","ME07.png","ME08.png","ME09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 368,
              second_startY: 188,
              second_array: ["iu00.png","iu01.png","iu02.png","iu03.png","iu04.png","iu05.png","iu06.png","iu07.png","iu08.png","iu09.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 202,
              y: 141,
              src: 'COL.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'anim_0.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'anim_0.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();

            console.log('Watch_Face.ScreenAOD');

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 244,
              day_startY: 141,
              day_sc_array: ["GO00.png","GO01.png","GO02.png","GO03.png","GO04.png","GO05.png","GO06.png","GO07.png","GO08.png","GO09.png"],
              day_tc_array: ["GO00.png","GO01.png","GO02.png","GO03.png","GO04.png","GO05.png","GO06.png","GO07.png","GO08.png","GO09.png"],
              day_en_array: ["GO00.png","GO01.png","GO02.png","GO03.png","GO04.png","GO05.png","GO06.png","GO07.png","GO08.png","GO09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 170,
              month_startY: 141,
              month_sc_array: ["GO00.png","GO01.png","GO02.png","GO03.png","GO04.png","GO05.png","GO06.png","GO07.png","GO08.png","GO09.png"],
              month_tc_array: ["GO00.png","GO01.png","GO02.png","GO03.png","GO04.png","GO05.png","GO06.png","GO07.png","GO08.png","GO09.png"],
              month_en_array: ["GO00.png","GO01.png","GO02.png","GO03.png","GO04.png","GO05.png","GO06.png","GO07.png","GO08.png","GO09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'DO2.png',
              month_unit_tc: 'DO2.png',
              month_unit_en: 'DO2.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 73,
              hour_startY: 195,
              hour_array: ["ME00.png","ME01.png","ME02.png","ME03.png","ME04.png","ME05.png","ME06.png","ME07.png","ME08.png","ME09.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 260,
              minute_startY: 192,
              minute_array: ["ME00.png","ME01.png","ME02.png","ME03.png","ME04.png","ME05.png","ME06.png","ME07.png","ME08.png","ME09.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 212,
              y: 195,
              src: 'COL.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}