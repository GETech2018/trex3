﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

let cc = 0

		let alt_var = 1
        let alt_all = 2
		let alt_text = ' '
		let pressure_array = read_pressure();
        let value = getPressureValue(pressure_array);
		
		let night_var = 1
        let night_all = 2
		let name_text = ' '
		
		let menu = 1
        let total_menu = 2
		
		let color_r = 1
        let colors_r = 8
		let namecolor_r = ' '
		
		let color_digt = 1
        let all_digt = 8
		let color_text = '0xFFFFFFFF'
		let namecolor_digt = ' '
		
		let color_bg = 1
        let totalcolors_bg = 8
		let namecolor_main = ' '
		
		let visabl_main = 1
		let totalvisabl_main = 4

	// vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
	
//# барометр в мм рт. ст.


function read_pressure() {
 console.log("read_pressure()");
 const file_name_alt = "../../../baro_altim/pressure.dat";
 const [fs_stat, err] = hmFS.stat(file_name_alt);
 if (err == 0) {
  let file_size = fs_stat.size;
  const len = file_size / 4;
  console.log(`size_alt: ${file_size}, lenght: ${len}`)
  const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)

  let array_buffer = new Float32Array(len);
  hmFS.read(fh, array_buffer.buffer, 0, file_size);
  hmFS.close(fh);
  console.log(`value ${array_buffer[array_buffer.length -1]}`);
  return array_buffer;
 } else {
  console.log('err:', err)
 }
 return null;
}

function getPressureValue(pressure_array) {
 console.log("getPressureValue()");
 if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
 let start_index = pressure_array.length - 1;
 let end_index = start_index - 30 * 3; // 3 часа
 if (end_index < 0) end_index = 0;
 for (let index = start_index; index >= end_index; index--) {
  if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
 }
 return 0;
}



function hPa_To_mmHg(hPa_value = 0) {
 let mmHg = Math.round(hPa_value * 0.750064);
 return mmHg;
}
//# конец барометр в мм рт. ст.

// переключение едениц измерения давления

		

function click_ALT() {
            if(alt_var>=alt_all) {
            alt_var=1;
                }
            else {
                alt_var=alt_var+1;
            }
			if ( alt_var == 1) { 
			alt_text = "mmHg"  
			value = hPa_To_mmHg(value);              // перевод в мм.рт.ст.
			normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));
		    }			
			if ( alt_var == 2) { 
			alt_text = "hPa" 
			value = getPressureValue(pressure_array);              // перевод в гПа
			normal_altimeter_text_text_img.setProperty(hmUI.prop.TEXT, String(value));
			}
			
			hmUI.showToast({text: alt_text });
			vibro(28);
									
		}

// конец переключение едениц измерения давления

//	переход в ночной режим (подставлением полупрозрачной картинки поверх циферблата)
		

			
		function click_Night() {
            if(night_var>=night_all) {
            night_var=1;
                }
            else {
                night_var=night_var+1;
            }
			if ( night_var == 1) name_text = "DAYTIME MODE"
			if ( night_var == 2) name_text = "NIGHT MODE"
			hmUI.showToast({text: name_text });
			image_top_img.setProperty(hmUI.prop.SRC, "night_" + parseInt(night_var) + ".png");
			vibro(28);
		}
		
//	конец перехода в ночной режим 



 
 

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_pai_icon_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_altimeter_text_text_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_linear_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_alarm_clock_icon_img = ''
        let normal_alarm_clock_text_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_time_pointer_smooth_second = ''
        let normal_image_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_text_text_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let image_top_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: lcddisplaycapssskcyrillic.ttf; FontSize: 27; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 32,
              h: 32,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/lcddisplaycapssskcyrillic.ttf',
              color: 0xFF01FE1B,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'BG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'BT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 396,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 157,
              y: 396,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 2,
              unit_sc: '1_slesh.png',
              unit_tc: '1_slesh.png',
              unit_en: '1_slesh.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'lock_off.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 221,
              y: 51,
              image_array: ["5_WD_1_N.png","5_WD_2_NE.png","5_WD_3_E.png","5_WD_4_SE.png","5_WD_5_S.png","5_WD_6_SW.png","5_WD_7_W.png","5_WD_8_NW.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 148,
              y: 56,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 180,
              y: 96,
              w: 120,
              h: 30,
              text_size: 27,
              char_space: 0,
              line_space: 0,
              font: 'fonts/lcddisplaycapssskcyrillic.ttf',
              color: 0xFF01FE1B,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 305,
              y: 68,
              image_array: ["4_wth00.png","4_wth01.png","4_wth02.png","4_wth03.png","4_wth04.png","4_wth05.png","4_wth06.png","4_wth07.png","4_wth08.png","4_wth09.png","4_wth10.png","4_wth11.png","4_wth12.png","4_wth13.png","4_wth14.png","4_wth15.png","4_wth16.png","4_wth17.png","4_wth18.png","4_wth19.png","4_wth20.png","4_wth21.png","4_wth22.png","4_wth23.png","4_wth24.png","4_wth25.png","4_wth26.png","4_wth27.png","4_wth28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 255,
              y: 56,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_dig.png',
              unit_tc: '1_dig.png',
              unit_en: '1_dig.png',
              imperial_unit_sc: '1_dig.png',
              imperial_unit_tc: '1_dig.png',
              imperial_unit_en: '1_dig.png',
              negative_image: '1_minus.png',
              invalid_image: '1_eror.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 255,
                y: 56,
                font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
                padding: false,
                h_space: 0,
                unit_sc: '1_dig.png',
                unit_tc: '1_dig.png',
                unit_en: '1_dig.png',
                imperial_unit_sc: '1_dig.png',
                imperial_unit_tc: '1_dig.png',
                imperial_unit_en: '1_dig.png',
                negative_image: '1_minus.png',
                invalid_image: '1_eror.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 213,
              month_startY: 235,
              month_sc_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              month_tc_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              month_en_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 150,
              day_startY: 235,
              day_sc_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              day_tc_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              day_en_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              day_zero: 1,
              day_space: 2,
              day_unit_sc: '1_slesh.png',
              day_unit_tc: '1_slesh.png',
              day_unit_en: '1_slesh.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 39,
              y: 232,
              week_en: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_tc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              week_sc: ["1_023.png","1_024.png","1_025.png","1_026.png","1_027.png","1_028.png","1_029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_step_linear_scale.setAlpha(150);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 73,
              // start_y: 322,
              // color: 0xFF000000,
              // lenght: 90,
              // line_width: 16,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 282,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_heart_rate_linear_scale.setAlpha(150);
            };

            // normal_heart_rate_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 203,
              // start_y: 322,
              // color: 0xFF000000,
              // lenght: 46,
              // line_width: 15,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 282,
              font_array: ["1_040.png","1_041.png","1_042.png","1_043.png","1_044.png","1_045.png","1_046.png","1_047.png","1_048.png","1_049.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 119,
              hour_startY: 132,
              hour_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 242,
              minute_startY: 132,
              minute_array: ["1_001.png","1_002.png","1_003.png","1_004.png","1_005.png","1_006.png","1_007.png","1_008.png","1_009.png","1_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 345,
              second_startY: 134,
              second_array: ["1_013.png","1_014.png","1_015.png","1_016.png","1_017.png","1_018.png","1_019.png","1_020.png","1_021.png","1_022.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 132,
              src: '1_011.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 61,
              y: 163,
              src: '1_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 61,
              y: 163,
              src: '1_alarm.png',
              // alpha: 125,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_icon_img.setAlpha(125);

            normal_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 47,
              y: 193,
              font_array: ["1_050.png","1_051.png","1_052.png","1_053.png","1_054.png","1_055.png","1_056.png","1_057.png","1_058.png","1_059.png"],
              padding: true,
              h_space: 0,
              invalid_image: '1_eror_a.png',
              dot_image: '1_060.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_battery_linear_scale.setAlpha(150);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 176,
              // start_y: 368,
              // color: 0xFF000000,
              // lenght: 76,
              // line_width: 16,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 348,
              font_array: ["1_030.png","1_031.png","1_032.png","1_033.png","1_034.png","1_035.png","1_036.png","1_037.png","1_038.png","1_039.png"],
              padding: false,
              h_space: 0,
              unit_sc: '1_int.png',
              unit_tc: '1_int.png',
              unit_en: '1_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'BG0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'str_h.png',
              hour_centerX: 347,
              hour_centerY: 307,
              hour_posX: 8,
              hour_posY: 37,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'str_m.png',
              minute_centerX: 347,
              minute_centerY: 306,
              minute_posX: 8,
              minute_posY: 54,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'str_s.png',
              second_centerX: 347,
              second_centerY: 306,
              second_posX: 9,
              second_posY: 72,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '3_sek.png',
              // center_x: 240,
              // center_y: 240,
              // x: 134,
              // y: 251,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_time_pointer_smooth_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '3_sek.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 134,
              second_posY: 251,
              fresh_frequency: 17,
              fresh_freqency: 17,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 3,
              // fps: 17,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'top.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 211,
              month_startY: 235,
              month_sc_array: ["AOD_040.png","AOD_041.png","AOD_042.png","AOD_043.png","AOD_044.png","AOD_045.png","AOD_046.png","AOD_047.png","AOD_048.png","AOD_049.png"],
              month_tc_array: ["AOD_040.png","AOD_041.png","AOD_042.png","AOD_043.png","AOD_044.png","AOD_045.png","AOD_046.png","AOD_047.png","AOD_048.png","AOD_049.png"],
              month_en_array: ["AOD_040.png","AOD_041.png","AOD_042.png","AOD_043.png","AOD_044.png","AOD_045.png","AOD_046.png","AOD_047.png","AOD_048.png","AOD_049.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 148,
              day_startY: 235,
              day_sc_array: ["AOD_040.png","AOD_041.png","AOD_042.png","AOD_043.png","AOD_044.png","AOD_045.png","AOD_046.png","AOD_047.png","AOD_048.png","AOD_049.png"],
              day_tc_array: ["AOD_040.png","AOD_041.png","AOD_042.png","AOD_043.png","AOD_044.png","AOD_045.png","AOD_046.png","AOD_047.png","AOD_048.png","AOD_049.png"],
              day_en_array: ["AOD_040.png","AOD_041.png","AOD_042.png","AOD_043.png","AOD_044.png","AOD_045.png","AOD_046.png","AOD_047.png","AOD_048.png","AOD_049.png"],
              day_zero: 1,
              day_space: 2,
              day_unit_sc: 'AOD_slesh.png',
              day_unit_tc: 'AOD_slesh.png',
              day_unit_en: 'AOD_slesh.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 40,
              y: 232,
              week_en: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              week_tc: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              week_sc: ["AOD_023.png","AOD_024.png","AOD_025.png","AOD_026.png","AOD_027.png","AOD_028.png","AOD_029.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: 'AOD_am.png',
              am_en_path: 'AOD_am.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'AOD_pm.png',
              pm_en_path: 'AOD_pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 119,
              hour_startY: 132,
              hour_array: ["AOD_001.png","AOD_002.png","AOD_003.png","AOD_004.png","AOD_005.png","AOD_006.png","AOD_007.png","AOD_008.png","AOD_009.png","AOD_010.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 242,
              minute_startY: 132,
              minute_array: ["AOD_001.png","AOD_002.png","AOD_003.png","AOD_004.png","AOD_005.png","AOD_006.png","AOD_007.png","AOD_008.png","AOD_009.png","AOD_010.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 345,
              second_startY: 134,
              second_array: ["AOD_013.png","AOD_014.png","AOD_015.png","AOD_016.png","AOD_017.png","AOD_018.png","AOD_019.png","AOD_020.png","AOD_021.png","AOD_022.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 218,
              y: 132,
              src: 'AOD_011.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            idle_battery_linear_scale.setAlpha(150);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 176,
              // start_y: 368,
              // color: 0xFF000000,
              // lenght: 76,
              // line_width: 16,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: True,
              // alpha: 150,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 348,
              font_array: ["AOD_030.png","AOD_031.png","AOD_032.png","AOD_033.png","AOD_034.png","AOD_035.png","AOD_036.png","AOD_037.png","AOD_038.png","AOD_039.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'AOD_int.png',
              unit_tc: 'AOD_int.png',
              unit_en: 'AOD_int.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'AOD_str_h.png',
              hour_centerX: 347,
              hour_centerY: 307,
              hour_posX: 8,
              hour_posY: 37,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'AOD_str_m.png',
              minute_centerX: 347,
              minute_centerY: 306,
              minute_posX: 8,
              minute_posY: 54,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'AOD_str_s.png',
              second_centerX: 347,
              second_centerY: 306,
              second_posX: 9,
              second_posY: 72,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 0,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              console.log('checkConnection()');
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              if (scene != 1) timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function
            
            // repeatAlert = hmUI.createWidget(hmUI.widget.RepeatAlert, {
              // everyHour_vibrate_type: 0,
            // });


            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              repeat_alerts();
            });
            // repeat alerts
            function repeat_alerts() {
              let hourEnd = false;
              if(timeSensor.minute == 0) {
                hourEnd = true;
                vibro(0);
              }
            };

            // end repeat alerts

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'night_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 51,
              y: 278,
              w: 113,
              h: 67,
              src: '00_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 175,
              y: 279,
              w: 84,
              h: 67,
              src: '00_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 178,
              y: 393,
              w: 133,
              h: 61,
              src: '00_empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 95,
              y: 349,
              w: 162,
              h: 41,
              src: '00_empty.png',
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 245,
              y: 28,
              w: 65,
              h: 74,
              src: '00_empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 342,
              y: 134,
              w: 84,
              h: 67,
              src: '00_empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 43,
              y: 157,
              w: 74,
              h: 65,
              src: '00_empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 168,
              y: 132,
              w: 116,
              h: 89,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_Night()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 123,
              y: 43,
              w: 100,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                click_ALT()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 46,
              y: 227,
              w: 205,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 313,
              y: 75,
              w: 80,
              h: 54,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '00_empty.png',
              normal_src: '00_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
vibro(28);
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 163;
                  let start_y_normal_step = 322;
                  let lenght_ls_normal_step = -90;
                  let line_width_ls_normal_step = 16;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 184;
                let progressHeartRate = (valueHeartRate - 30)/(targetHeartRate - 30);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_ls_normal_heart_rate = 1 - progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_linear_scale
                  // initial parameters
                  let start_x_normal_heart_rate = 249;
                  let start_y_normal_heart_rate = 322;
                  let lenght_ls_normal_heart_rate = -46;
                  let line_width_ls_normal_heart_rate = 15;
                  let color_ls_normal_heart_rate = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_heart_rate_draw = start_x_normal_heart_rate;
                  let start_y_normal_heart_rate_draw = start_y_normal_heart_rate;
                  lenght_ls_normal_heart_rate = lenght_ls_normal_heart_rate * progress_ls_normal_heart_rate;
                  let lenght_ls_normal_heart_rate_draw = lenght_ls_normal_heart_rate;
                  let line_width_ls_normal_heart_rate_draw = line_width_ls_normal_heart_rate;
                  if (lenght_ls_normal_heart_rate < 0){
                    lenght_ls_normal_heart_rate_draw = -lenght_ls_normal_heart_rate;
                    start_x_normal_heart_rate_draw = start_x_normal_heart_rate - lenght_ls_normal_heart_rate_draw;
                  };
                  
                  normal_heart_rate_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_heart_rate_draw,
                    y: start_y_normal_heart_rate_draw,
                    w: lenght_ls_normal_heart_rate_draw,
                    h: line_width_ls_normal_heart_rate_draw,
                    color: color_ls_normal_heart_rate,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 252;
                  let start_y_normal_battery = 368;
                  let lenght_ls_normal_battery = -76;
                  let line_width_ls_normal_battery = 16;
                  let color_ls_normal_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 252;
                  let start_y_idle_battery = 368;
                  let lenght_ls_idle_battery = -76;
                  let line_width_ls_idle_battery = 16;
                  let color_ls_idle_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}