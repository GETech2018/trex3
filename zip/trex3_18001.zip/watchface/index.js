﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start
        let currentTheme = hmFS.SysProGetInt('WatchTheme') ?? 1;   // 1..4
        // Sleep
        let sleep = null;
        let cachedSleepText = "00:00";
        let lastSleepDate = null;
        let lastShownSleepText = "--";
        let sleep_time_txt = null;
        let lastTotalMinutes = 0;
        let lastSleepUpdateMs = 0;
        const SLEEP_THROTTLE_MS = 15 * 60 * 1000; 
        
        let normal_background_bg1_img = ''
        let normal_background_bg2_img = ''
        let normal_background_bg3_img = ''
        let normal_background_bg4_img = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_sleep_icon_img = ''
        let normal_sun_icon1_img = ''
        let normal_sun_icon2_img = ''
        let normal_sun_high_text_font = ''
        let normal_sun_low_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_max_min_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_font = ''
        let normal_battery_circle_scale = ''
        let normal_battery_current_text_font = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_day_text_font = ''
        let normal_distance_current_text_font = ''
        let normal_calorie_current_text_font = ''
        let normal_heart_rate_text_font = ''
        let normal_readiness_current_text_font = ''       

        let hour_tens1 = ''
        let hour_tens2 = ''
        let hour_tens3 = ''
        let hour_tens4 = ''
        let hour_units = ''

        let minute_tens1 = ''
        let minute_tens2 = ''
        let minute_tens3 = ''
        let minute_tens4 = ''
        let minute_units = ''

        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg1_img = ''
        let idle_background_bg2_img = ''
        let idle_background_bg3_img = ''
        let idle_background_bg4_img = ''
        let idle_image_img = ''
        let idle_alarm_clock_current_text_font = ''
        let idle_system_clock_img = ''
        let idle_system_disconnect_img = ''
        let idle_sun_icon1_img = ''
        let idle_sun_icon2_img = ''
        let idle_sun_high_text_font = ''
        let idle_sun_low_text_font = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_max_min_text_font = ''
        let idle_temperature_current_text_font = ''
        let idle_step_circle_scale = ''
        let idle_step_current_text_font = ''
        let idle_battery_circle_scale = ''
        let idle_battery_current_text_font = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_day_text_font = ''
        let idle_distance_current_text_font = ''
        let idle_calorie_current_text_font = ''
        let idle_heart_rate_text_font = ''
        let idle_readiness_current_text_font = ''

        let idle_hour_tens1 = ''
        let idle_hour_tens2 = ''
        let idle_hour_tens3 = ''
        let idle_hour_tens4 = ''
        let idle_hour_units = ''

        let idle_minute_tens1 = ''
        let idle_minute_tens2 = ''
        let idle_minute_tens3 = ''
        let idle_minute_tens4 = ''
        let idle_minute_units = ''

        let normal_step_jumpable_img_click = ''
        let normal_cal_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_readiness_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let timeSensor = '';

            // Sleep helpers 1.1
            try {
                sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
                sleep.onSleepStateChange = () => {
                    if (sleep.state === hmSensor.sleep_state.END) {
                        calculateAndCacheRealSleep(true);
                    }
                };

            } catch (e) {
                console.log("Sleep sensor init failed:", e);
                sleep = null;
            }
            function formatMinutes(mins) {
                if (!mins || mins <= 0) return "00:00";

                const h = Math.floor(mins / 60);
                const m = mins % 60;
                return String(h).padStart(2, "0") + ":" + String(m).padStart(2, "0");
            }
            function calculateAndCacheRealSleep(force = false) {
                if (!sleep) {
                    cachedSleepText = "00:00";
                    updateSleepText();
                    return;
                }
                
                try {
                    const now = Date.now();
                    const today = new Date().toDateString();
                    
                    if (!force && (now - lastSleepUpdateMs < SLEEP_THROTTLE_MS) && lastSleepDate === today) {
                        updateSleepText();
                        return;
                    }

                    let currentTotal = sleep.getTotalTime();
                    
                    if (!force && lastSleepDate === today && currentTotal === lastTotalMinutes) {
                        lastSleepUpdateMs = now;
                        updateSleepText();
                        return;
                    }

                    sleep.updateInfo();
                    currentTotal = sleep.getTotalTime();

                    const info = sleep.getBasicInfo();
                    if (!info || info.startTime === 0 || currentTotal <= 0) {
                        cachedSleepText = "00:00";
                        lastTotalMinutes = 0;
                        updateSleepText();
                        return;
                    }

                    let totalMinutes = currentTotal;

                    if (totalMinutes > 1080) totalMinutes = 0;

                    if (totalMinutes > 90) {
                        try {
                            const stages = sleep.getSleepStageData();
                            const model = sleep.getSleepStageModel();
                            let wakeMinutes = 0;
                            for (let i = 0, len = stages.length; i < len; i++) {
                                const st = stages[i];
                                if (st.model === model.WAKE_STAGE) {
                                    wakeMinutes += (st.stop + 1 - st.start);
                                }
                            }
                            totalMinutes -= wakeMinutes;
                        } catch (e) {}
                    }

                    cachedSleepText = formatMinutes(totalMinutes);
                    lastSleepDate = today;
                    lastTotalMinutes = currentTotal;
                    lastSleepUpdateMs = now;
                    updateSleepText();
                } catch (e) {
                    console.log("calculateAndCacheRealSleep error:", e);
                    cachedSleepText = "00:00";
                    updateSleepText();
                }
            }
            function updateSleepText() {
                if (!sleep_time_txt) return;
                if (hmSetting.getScreenType() === hmSetting.screen_type.AOD) return;
                if (lastShownSleepText !== cachedSleepText) {
                    try {
                        sleep_time_txt.setProperty(hmUI.prop.TEXT, cachedSleepText);
                    } catch (e) { }
                    lastShownSleepText = cachedSleepText;
                }
            } 
        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Oswald-Regular.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 300,
              h: 50,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFD5D5BF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald-Regular.ttf; FontSize: 20
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 242,
              h: 42,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFD5D5BF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald-Regular.ttf; FontSize: 28
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 333,
              h: 57,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFD5D5BF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald-Regular.ttf; FontSize: 22
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 272,
              h: 46,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFDFE0C9,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Oswald-Regular.ttf; FontSize: 35
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 422,
              h: 70,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            normal_background_bg1_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_HZ.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_background_bg2_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_HW.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });    
            
            normal_background_bg3_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_HR.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });  
            
            normal_background_bg4_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_HK.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 210,
              y: 378,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 308,
              y: 415,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 254,
              y: 413,
              w: 150,
              h: 50,
              text_size: 24,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFD5D5BF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 138,
              y: 416,
              src: 'sleep.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            sleep_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 79,
              y: 413,
              w: 150,
              h: 50,
              text_size: 24,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFD5D5BF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              text: "00:00",
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); 
            calculateAndCacheRealSleep(true);      
            
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_sun_icon1_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 132,
              y: 43,
              src: 'vs1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon2_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 132,
              y: 43,
              src: 'vs2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 78,
              y: 67,
              w: 150,
              h: 50,
              text_size: 24,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFD5D5BF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 78,
              y: 67,
              w: 150,
              h: 50,
              text_size: 24,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFD5D5BF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 197,
              y: 21,
              image_array: ["09_weather_01.png","09_weather_02.png","09_weather_03.png","09_weather_04.png","09_weather_05.png","09_weather_06.png","09_weather_07.png","09_weather_08.png","09_weather_09.png","09_weather_10.png","09_weather_11.png","09_weather_12.png","09_weather_13.png","09_weather_14.png","09_weather_15.png","09_weather_16.png","09_weather_17.png","09_weather_18.png","09_weather_19.png","09_weather_20.png","09_weather_21.png","09_weather_22.png","09_weather_23.png","09_weather_24.png","09_weather_25.png","09_weather_26.png","09_weather_27.png","09_weather_28.png","09_weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_max_min_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 281,
              y: 57,
              w: 150,
              h: 50,
              text_size: 20,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFD5D5BF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 281,
              y: 25,
              w: 150,
              h: 50,
              text_size: 28,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFD5D5BF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 66,
              // end_angle: 114,
              // radius: 236,
              // line_width: 9,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 160,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 114,
              end_angle: 66,
              radius: 232,
              line_width: 9,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_circle_scale.setAlpha(160);
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 22,
              y: 22,
              w: 436,
              h: 436,
              text_size: 22,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFDFE0C9,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 182,
              mode: 0,
              // radius: 218,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -114,
              // end_angle: -65,
              // radius: 237,
              // line_width: 9,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 160,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -65,
              end_angle: -114,
              radius: 233,
              line_width: 9,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale.setAlpha(160);
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 22,
              y: 22,
              w: 436,
              h: 436,
              text_size: 22,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFDFE0C9,
              // use_text_circle: true,
              start_angle: -177,
              end_angle: 0,
              mode: 0,
              // radius: 218,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 277,
              month_startY: 120,
              month_sc_array: ["M_0.png","M_1.png","M_2.png","M_3.png","M_4.png","M_5.png","M_6.png","M_7.png","M_8.png","M_9.png","M_10.png","M_11.png"],
              month_tc_array: ["M_0.png","M_1.png","M_2.png","M_3.png","M_4.png","M_5.png","M_6.png","M_7.png","M_8.png","M_9.png","M_10.png","M_11.png"],
              month_en_array: ["M_0.png","M_1.png","M_2.png","M_3.png","M_4.png","M_5.png","M_6.png","M_7.png","M_8.png","M_9.png","M_10.png","M_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 40,
              y: 120,
              week_en: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_tc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_sc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 166,
              y: 115,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 286,
              y: 327,
              w: 150,
              h: 50,
              text_size: 28,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 207,
              y: 327,
              w: 150,
              h: 50,
              text_size: 28,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 130,
              y: 327,
              w: 150,
              h: 50,
              text_size: 28,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 50,
              y: 327,
              w: 150,
              h: 50,
              text_size: 28,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });            


            // === ЧАСЫ ===
            hour_units = hmUI.createWidget(hmUI.widget.IMG, {     
              x: 125,           
              y: 157,          
              src: 'MM_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hour_tens1 = hmUI.createWidget(hmUI.widget.IMG, {     
              x: 51,
              y: 167,
              src: 'HZ_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            hour_tens2 = hmUI.createWidget(hmUI.widget.IMG, {     
              x: 51,
              y: 167,
              src: 'HW_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });   
            
            hour_tens3 = hmUI.createWidget(hmUI.widget.IMG, {     
              x: 51,
              y: 167,
              src: 'HR_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });  
            
            hour_tens4 = hmUI.createWidget(hmUI.widget.IMG, {     
              x: 51,
              y: 167,
              src: 'HK_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            



            // === МИНУТЫ ===
            minute_units = hmUI.createWidget(hmUI.widget.IMG, {   
              x: 327,          
              y: 157,          
              src: 'MM_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            minute_tens1 = hmUI.createWidget(hmUI.widget.IMG, {    
              x: 253,
              y: 167,
              src: 'HZ_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            minute_tens2 = hmUI.createWidget(hmUI.widget.IMG, {    
              x: 253,
              y: 167,
              src: 'HW_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            minute_tens3 = hmUI.createWidget(hmUI.widget.IMG, {    
              x: 253,
              y: 167,
              src: 'HR_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });  
            
            minute_tens4 = hmUI.createWidget(hmUI.widget.IMG, {    
              x: 253,
              y: 167,
              src: 'HK_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            



            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sekk.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 15,
              second_posY: 245,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            idle_background_bg1_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_HZ.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_background_bg2_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_HW.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });  
            
            idle_background_bg3_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_HR.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });  
            
            idle_background_bg4_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_HK.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });            

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 166,
              y: 412,
              w: 150,
              h: 50,
              text_size: 24,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFD5D5BF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 224,
              y: 389,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 210,
              y: 394,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_icon1_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 132,
              y: 43,
              src: 'vs1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_icon2_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 132,
              y: 43,
              src: 'vs2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });            

            idle_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 78,
              y: 67,
              w: 150,
              h: 50,
              text_size: 24,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFD5D5BF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 78,
              y: 67,
              w: 150,
              h: 50,
              text_size: 24,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFD5D5BF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 197,
              y: 21,
              image_array: ["09_weather_01.png","09_weather_02.png","09_weather_03.png","09_weather_04.png","09_weather_05.png","09_weather_06.png","09_weather_07.png","09_weather_08.png","09_weather_09.png","09_weather_10.png","09_weather_11.png","09_weather_12.png","09_weather_13.png","09_weather_14.png","09_weather_15.png","09_weather_16.png","09_weather_17.png","09_weather_18.png","09_weather_19.png","09_weather_20.png","09_weather_21.png","09_weather_22.png","09_weather_23.png","09_weather_24.png","09_weather_25.png","09_weather_26.png","09_weather_27.png","09_weather_28.png","09_weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_max_min_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 281,
              y: 57,
              w: 150,
              h: 50,
              text_size: 20,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFD5D5BF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH_LOW,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 281,
              y: 25,
              w: 150,
              h: 50,
              text_size: 28,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFD5D5BF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 66,
              // end_angle: 114,
              // radius: 236,
              // line_width: 9,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 160,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 114,
              end_angle: 66,
              radius: 232,
              line_width: 9,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_circle_scale.setAlpha(160);

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 22,
              y: 22,
              w: 436,
              h: 436,
              text_size: 22,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFDFE0C9,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 182,
              mode: 0,
              // radius: 218,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -114,
              // end_angle: -65,
              // radius: 237,
              // line_width: 9,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 160,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -65,
              end_angle: -114,
              radius: 233,
              line_width: 9,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_circle_scale.setAlpha(160);

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 22,
              y: 22,
              w: 436,
              h: 436,
              text_size: 22,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFFDFE0C9,
              // use_text_circle: true,
              start_angle: -177,
              end_angle: 0,
              mode: 0,
              // radius: 218,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 277,
              month_startY: 120,
              month_sc_array: ["M_0.png","M_1.png","M_2.png","M_3.png","M_4.png","M_5.png","M_6.png","M_7.png","M_8.png","M_9.png","M_10.png","M_11.png"],
              month_tc_array: ["M_0.png","M_1.png","M_2.png","M_3.png","M_4.png","M_5.png","M_6.png","M_7.png","M_8.png","M_9.png","M_10.png","M_11.png"],
              month_en_array: ["M_0.png","M_1.png","M_2.png","M_3.png","M_4.png","M_5.png","M_6.png","M_7.png","M_8.png","M_9.png","M_10.png","M_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 40,
              y: 120,
              week_en: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_tc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_sc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 166,
              y: 115,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 286,
              y: 327,
              w: 150,
              h: 50,
              text_size: 28,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 207,
              y: 327,
              w: 150,
              h: 50,
              text_size: 28,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 130,
              y: 327,
              w: 150,
              h: 50,
              text_size: 28,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_readiness_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 50,
              y: 327,
              w: 150,
              h: 50,
              text_size: 28,
              char_space: 0,
              font: 'fonts/Oswald-Regular.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // === ЧАСЫ ===
            idle_hour_units = hmUI.createWidget(hmUI.widget.IMG, {     
              x: 125,           
              y: 157,          
              src: 'MM_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_hour_tens1 = hmUI.createWidget(hmUI.widget.IMG, {     
              x: 51,
              y: 167,
              src: 'HZ_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_hour_tens2 = hmUI.createWidget(hmUI.widget.IMG, {     
              x: 51,
              y: 167,
              src: 'HW_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });   
            
            idle_hour_tens3 = hmUI.createWidget(hmUI.widget.IMG, {     
              x: 51,
              y: 167,
              src: 'HR_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });  
            
            idle_hour_tens4 = hmUI.createWidget(hmUI.widget.IMG, {     
              x: 51,
              y: 167,
              src: 'HK_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });            

            // === МИНУТЫ ===
            idle_minute_units = hmUI.createWidget(hmUI.widget.IMG, {   
              x: 327,          
              y: 157,          
              src: 'MM_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_minute_tens1 = hmUI.createWidget(hmUI.widget.IMG, {    
              x: 253,
              y: 167,
              src: 'HZ_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_minute_tens2 = hmUI.createWidget(hmUI.widget.IMG, {    
              x: 253,
              y: 167,
              src: 'HW_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_minute_tens3 = hmUI.createWidget(hmUI.widget.IMG, {    
              x: 253,
              y: 167,
              src: 'HR_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });  
            
            idle_minute_tens4 = hmUI.createWidget(hmUI.widget.IMG, {    
              x: 253,
              y: 167,
              src: 'HK_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });            

            applyTheme(currentTheme);



            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 431,
              y: 199,
              w: 50,
              h: 80,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_cal_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 327,
              y: 335,
              w: 65,
              h: 65,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 335,
              w: 65,
              h: 65,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 204,
              w: 45,
              h: 70,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 122,
              y: 47,
              w: 60,
              h: 60,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 281,
              y: 33,
              w: 60,
              h: 60,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 86,
              y: 195,
              w: 100,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 293,
              y: 195,
              w: 100,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 255,
              y: 409,
              w: 80,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 147,
              y: 410,
              w: 80,
              h: 50,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 92,
              y: 335,
              w: 65,
              h: 65,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 249,
              y: 335,
              w: 65,
              h: 65,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 205,
              y: 122,
              w: 70,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 115,
              y: 122,
              w: 70,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 292,
              y: 122,
              w: 70,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            
            const themeButton = hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 195,          // центр
                y: 180,
                w: 90,
                h: 110,
                text: '',
                press_src: 'clean.png',
                normal_src: 'clean.png',
                click_func: () => {
                    currentTheme = (currentTheme % 4) + 1;  
                    applyTheme(currentTheme);
                    hmUI.showToast({ text: `Тема ${currentTheme}` });
                },
                show_level: hmUI.show_level.ONLY_NORMAL,  
            });            

            
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
                console.log('time_update()');
                let hour = timeSensor.hour;
                let minute = timeSensor.minute;
                let format_hour = timeSensor.format_hour;

                // === ОБНОВЛЕНИЕ ДАТЫ ===
                if (updateHour) {
                    let normal_dayStr = timeSensor.day.toString();
                    normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr);
                    idle_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr);
                }

                // === ОБНОВЛЕНИЕ ВРЕМЕНИ (только десятки + единицы) ===
                if (updateMinute) {
                    let h_tens = Math.floor(hour / 10);
                    let h_units = hour % 10;
                    let m_tens = Math.floor(minute / 10);
                    let m_units = minute % 10;

                    // Normal экран
                    hour_tens1.setProperty(hmUI.prop.SRC, `HZ_${h_tens}.png`);
                    hour_tens2.setProperty(hmUI.prop.SRC, `HW_${h_tens}.png`);
                    hour_tens3.setProperty(hmUI.prop.SRC, `HR_${h_tens}.png`);
                    hour_tens4.setProperty(hmUI.prop.SRC, `HK_${h_tens}.png`);
                    hour_units.setProperty(hmUI.prop.SRC, `MM_${h_units}.png`);

                    minute_tens1.setProperty(hmUI.prop.SRC, `HZ_${m_tens}.png`);
                    minute_tens2.setProperty(hmUI.prop.SRC, `HW_${m_tens}.png`);
                    minute_tens3.setProperty(hmUI.prop.SRC, `HR_${m_tens}.png`);
                    minute_tens4.setProperty(hmUI.prop.SRC, `HK_${m_tens}.png`);
                    minute_units.setProperty(hmUI.prop.SRC, `MM_${m_units}.png`);

                    // AOD экран (точно такие же значения)
                    idle_hour_tens1.setProperty(hmUI.prop.SRC, `HZ_${h_tens}.png`);
                    idle_hour_tens2.setProperty(hmUI.prop.SRC, `HW_${h_tens}.png`);
                    idle_hour_tens3.setProperty(hmUI.prop.SRC, `HR_${h_tens}.png`);
                    idle_hour_tens4.setProperty(hmUI.prop.SRC, `HK_${h_tens}.png`);
                    idle_hour_units.setProperty(hmUI.prop.SRC, `MM_${h_units}.png`);

                    idle_minute_tens1.setProperty(hmUI.prop.SRC, `HZ_${m_tens}.png`);
                    idle_minute_tens2.setProperty(hmUI.prop.SRC, `HW_${m_tens}.png`);
                    idle_minute_tens3.setProperty(hmUI.prop.SRC, `HR_${m_tens}.png`);
                    idle_minute_tens4.setProperty(hmUI.prop.SRC, `HK_${m_tens}.png`);
                    idle_minute_units.setProperty(hmUI.prop.SRC, `MM_${m_units}.png`);
                }

                // === День/Ночь (солнце) ===
                const weatherData = weatherSensor.getForecastWeather();
                const tide = weatherData.tideData.data[0];
                let sunriseMinutes = tide.sunrise.hour * 60 + tide.sunrise.minute;
                let sunsetMinutes = tide.sunset.hour * 60 + tide.sunset.minute;
                let currentMinutes = timeSensor.hour * 60 + timeSensor.minute;
                let isDay = currentMinutes >= sunriseMinutes && currentMinutes < sunsetMinutes;

                if (isDay) {
                    normal_sun_icon1_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_sun_icon2_img.setProperty(hmUI.prop.VISIBLE, true);
                    normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, false);
                    normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, true);

                    idle_sun_icon1_img.setProperty(hmUI.prop.VISIBLE, false);
                    idle_sun_icon2_img.setProperty(hmUI.prop.VISIBLE, true);
                    idle_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, false);
                    idle_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, true);
                } else {
                    normal_sun_icon1_img.setProperty(hmUI.prop.VISIBLE, true);
                    normal_sun_icon2_img.setProperty(hmUI.prop.VISIBLE, false);
                    normal_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, true);
                    normal_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, false);

                    idle_sun_icon1_img.setProperty(hmUI.prop.VISIBLE, true);
                    idle_sun_icon2_img.setProperty(hmUI.prop.VISIBLE, false);
                    idle_sun_high_text_font.setProperty(hmUI.prop.VISIBLE, true);
                    idle_sun_low_text_font.setProperty(hmUI.prop.VISIBLE, false);
                }
            }

            function applyTheme(theme) {
                console.log(`Применяем тему ${theme}`);

                // Normal
                normal_background_bg1_img.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_background_bg2_img.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_background_bg3_img.setProperty(hmUI.prop.VISIBLE, theme === 3);
                normal_background_bg4_img.setProperty(hmUI.prop.VISIBLE, theme === 4);

                hour_tens1.setProperty(hmUI.prop.VISIBLE, theme === 1);
                hour_tens2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                hour_tens3.setProperty(hmUI.prop.VISIBLE, theme === 3);
                hour_tens4.setProperty(hmUI.prop.VISIBLE, theme === 4);

                minute_tens1.setProperty(hmUI.prop.VISIBLE, theme === 1);
                minute_tens2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                minute_tens3.setProperty(hmUI.prop.VISIBLE, theme === 3);
                minute_tens4.setProperty(hmUI.prop.VISIBLE, theme === 4);

                // AOD
                idle_background_bg1_img.setProperty(hmUI.prop.VISIBLE, theme === 1);
                idle_background_bg2_img.setProperty(hmUI.prop.VISIBLE, theme === 2);
                idle_background_bg3_img.setProperty(hmUI.prop.VISIBLE, theme === 3);
                idle_background_bg4_img.setProperty(hmUI.prop.VISIBLE, theme === 4);

                idle_hour_tens1.setProperty(hmUI.prop.VISIBLE, theme === 1);
                idle_hour_tens2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                idle_hour_tens3.setProperty(hmUI.prop.VISIBLE, theme === 3);
                idle_hour_tens4.setProperty(hmUI.prop.VISIBLE, theme === 4);

                idle_minute_tens1.setProperty(hmUI.prop.VISIBLE, theme === 1);
                idle_minute_tens2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                idle_minute_tens3.setProperty(hmUI.prop.VISIBLE, theme === 3);
                idle_minute_tens4.setProperty(hmUI.prop.VISIBLE, theme === 4);

                // Сохраняем выбор
                hmFS.SysProSetInt('WatchTheme', theme);
            }            


            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 114,
                      end_angle: 66,
                      radius: 232,
                      line_width: 9,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -65,
                      end_angle: -114,
                      radius: 233,
                      line_width: 9,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = 1 - progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 114,
                      end_angle: 66,
                      radius: 232,
                      line_width: 9,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -65,
                      end_angle: -114,
                      radius: 233,
                      line_width: 9,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                calculateAndCacheRealSleep();
                applyTheme(currentTheme);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                if (sleep) {
                  sleep = null;
                }  
                try {                                                                                                            
                  cachedSleepText = "--";
                  lastSleepDate = null;
                  lastShownSleepText = null;
                } catch (e) {}                  

                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}