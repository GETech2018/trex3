﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
              
      
        const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT} = hmSetting.getDeviceInfo();
        const radius = DEVICE_WIDTH / 2, centerX = DEVICE_WIDTH / 2, centerY = DEVICE_HEIGHT / 2
      
        const curTime = hmSensor.createSensor(hmSensor.id.TIME);
        const weather = hmSensor.createSensor(hmSensor.id.WEATHER);
      
        let weatherImg, tempText, cityNameText, tempMinText, tempMaxText, tempFeelsText, descriptionText
        let weatherProvider
        
        const vibrator = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let stopVibro_Timer = null;
    
        function vibro(mode = 25, stopDelay = 30) {
            vibrator.stop();
            vibrator.scene = mode;
            vibrator.start();
            stopVibro_Timer = setTimeout(() => {
              stopVibro();
            }, stopDelay);
        }		
    
        function stopVibro(){
            vibrator.stop();
            if (stopVibro_Timer) clearTimeout(stopVibro_Timer);
        } 
 

        class WeatherProvider {
          constructor(props = {}) {
            this.props = {
              night_icons: [],											// индексы иконок для замены день-ночь
              index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,		// текущий индекс провайдера (сохраняется и считывается из памяти)
              show_toast: true,											// показывать всплывающее сообщение при переключении провайдера
              temp_widget: null,											// виджет TEXT для отображения температуры
              temp_max_widget: null,										// виджет TEXT для отображения максимальной температуры
              temp_min_widget: null,										// виджет TEXT для отображения минимальной температуры
              temp_feels_widget: null,									// виджет TEXT для отображения ощущаемой температуры
              description_widget: null,									// виджет TEXT для отображения текстового описания текущей погоды
              cityName_widget: null,										// виджет TEXT для отображения названия города
              icon_widget: null,											// виджет IMG для отображения значка погоды
              time_sensor: null,											// сенсор времени, если не задан, то создается новый
              weather_sensor: null,										// сенсор погоды, если не задан, то создается новый
              file_name: 'weather.json',									// имя файла с погодными данными
              auto_update: true,											// автоматическое обновление погоды (нет необходимости добавлять weatherProvider.update() в event.MINUTEEND и WIDGET_DELEGATE)
              lang: hmSetting.getLanguage() == 4 ? 0 : 1,					// языка устройства	(Русский = 0 / Английский = 1)
              ...props,
            };
            this.providers = [
              {name: ['Zepp', 'Zepp'], appId: null},							// 0
              {name: ['Погодный сервис', 'Weather service'], appId: 1065824},	// 1 
              //{name: ['RuWeather', 'RWeather'], appId: 1066654},				// 2
            ]

            this.description = [
                ['Облачно', 'Временами дождь', 'Временами снег', 'Ясно', 'Пасмурно', 'Слабый дождь', 'Слабый снег', 'Умеренный дождь', 'Умеренный снег', 'Сильный снегопад', 'Сильный дождь', 'Песчаная буря', 'Мокрый снег', 'Туман', 'Дымка', 'Дождь с грозой', 'Метель', 'Пыльно', 'Ливень', 'Дождь с градом', 'Сильный дождь с градом', 'Сильный дождь', 'Пыльная буря', 'Сильная песчаная буря', 'Сильный дождь', 'Обновите погоду', 'Облачно ночью', 'Дождливо ночью', 'Ясно ночью'],
                ['Cloudy', 'Showers', 'Snow Showers', 'Sunny', 'Overcast', 'Light Rain', 'Light Snow', 'Moderate Rain', 'Moderate Snow', 'Heavy Snow', 'Heavy Rain', 'Sandstorm', 'Rain and Snow', 'Fog', 'Hazy', 'T-Storms', 'Snowstorm', 'Floating dust', 'Very Heavy Rainstorm', 'Rain and Hail', 'T-Storms and Hail', 'Heavy Rainstorm', 'Dust', 'Heavy sand storm', 'Rainstorm', 'Unknown', 'Cloudy Nighttime', 'Showers Nighttime', 'Sunny Nighttime'],
              ]      
              
            this.last = {
                weatherIcon: 25,
                weatherDescription:  'Нет данных',
                temperature: '--',
                temperatureFeels: '--',
                temperatureMax: '--',
                temperatureMin: '--',
                cityName: '--',
                modTime: null,
            }      
            
            if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
            if (!this.props.weather_sensor) this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
            if (isFinite(props.index)) hmFS.SysProSetInt('WeatherProviderIndex', props.index);
            if (this.props.auto_update) this.createHandlers();
        } 
        
        
        createHandlers() {
          this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

          this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
            resume_call: ( () => this.update() )
          })
        }   
        
        arrayBufferToCyrillic(buffer) {
          let result = '';
          const bytes = new Uint8Array(buffer);

          let i = 0;
          while (i < bytes.length) {
              let byte1 = bytes[i++];
          
              if (byte1 < 0x80) {								// Обработка 1-байтовых символов (ASCII)
                result += String.fromCharCode(byte1);
              } else if (byte1 >= 0xC0 && byte1 < 0xE0) {		// Обработка 2-байтовых символов (UTF-8 кодировка для кириллицы)
                let byte2 = bytes[i++];
                let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
                result += String.fromCharCode(charCode);
              } else if (byte1 >= 0xE0 && byte1 < 0xF0) {		// Обработка 3-байтовых символов (например, для UTF-8)
                let byte2 = bytes[i++];
                let byte3 = bytes[i++];
                let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
                result += String.fromCharCode(charCode);
              }
          }

          return result
        } 
        
        readFile(app_id) {
          if (!app_id) return null				
          let str_result = "";
          try {
              const [fs_stat, err] = hmFS.stat(this.props.file_name, {
                  appid: app_id,
              });
              if (err == 0) {
                  const fh = hmFS.open(this.props.file_name, hmFS.O_RDONLY, {
                  appid: app_id,
                  });

                  const len = fs_stat.size;
                  let array_buffer = new ArrayBuffer(len);
                  hmFS.read(fh, array_buffer, 0, len);
                  hmFS.close(fh);
                  str_result = this.arrayBufferToCyrillic(array_buffer);

                  return str_result;
              } else {
                  console.log("err:", err);
              }
          } catch (error) {
          console.log("error:", error);
          console.log("FAIL: No access to hmFS.");
          }
          return null;
        }    
        
        getFileModTime(app_id) {
          if (!app_id) return null
          try {
              const [fs_stat, err] = hmFS.stat(this.props.file_name, {
                  appid: app_id,
              });
          
              if (err == 0) {
                  return fs_stat.mtime
              } else {
                  console.log("ModTime err:", err);
              }
          } catch (error) {
            console.log("ModTime error:", error);
            console.log("FAIL: No access to hmFS.");
          }
            return null
        }  
        
        isDayNow() {
          const sunData = this.props.weather_sensor.getForecastWeather().tideData;
          let sunriseMins = 8 * 60;			// время восхода
          let sunsetMins = 20 * 60;			// и заката по умолчанию

          if (sunData.count > 0){
              const today = sunData.data[0];
              sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
              sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
          }

          const curMins = curTime.hour * 60 + curTime.minute;
          const nowIsDay = (curMins >= sunriseMins) && (curMins < sunsetMins);

          return nowIsDay
        }  
        
        getZeppIconIndex(index, app_id = null) {
                        
          if (!app_id)  return index;			//	если нет app_id, то не меняем индекс иконки

          let newIndex = 25;
          
          if (app_id == 1065824) {					// WeatherService
              switch(index) {
              case 1:
                      newIndex = 3;
                  break;
              case 2:
                      newIndex = 0;
                  break;
              case 3:
              case 4:
                      newIndex = 4;
                  break;
              case 5:
                      newIndex = 1;
                  break;
              case 6:
                      newIndex = 5;
                  break;
              case 7:
                      newIndex = 10;
                  break;
              case 8:
                      newIndex = 15;
                  break;
              case 9:
                      newIndex = 6;
                  break;
              case 10:
                      newIndex = 8;
                  break;
              case 11:
                      newIndex = 9;
                  break;
              case 12:
                      newIndex = 12;
                  break;
              case 13:
                      newIndex = 13;
                  break;
              case 14:
                      newIndex = 17;
                  break;
              default:
                      newIndex = 25;
                  break;
              }
          } else if (app_id == 1066654) {					// 
              newIndex = index - 1;
          }

          return newIndex
        }  
       
        tempWithSign(val){
          val = parseFloat(val);
          if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
          val = Math.round(val);
          if (val > 0) val = '+' + val;
          val += '°';
          
          return val
        }    
        
        getZeppWeatherData() {
          const iconIndex = this.props.weather_sensor.curAirIconIndex ?? 25;
          const data = {
              weatherIcon: iconIndex,
              weatherDescription:  this.description[this.props.lang][iconIndex],
              temperature: this.props.weather_sensor.current ?? '--',
              temperatureFeels: '--',
              temperatureMax: this.props.weather_sensor.high ?? '--',
              temperatureMin: this.props.weather_sensor.low ?? '--',
              cityName: this.props.weather_sensor.getForecastWeather().cityName ?? '--',
          }

          return data
        }  
        
        getAppWeatherData(app_id) {
          const data = {
              weatherIcon: 25,
              weatherDescription:  'Нет данных',
              temperature: '--',
              temperatureFeels: '--',
              temperatureMax: '--',
              temperatureMin: '--',
              cityName: '--',
          }
          
          let weather_str = this.readFile(app_id);
          let weatherJson = JSON.parse(weather_str);

          if (weatherJson) {
              if (isFinite(weatherJson.weatherIcon)) {		// считываем индекс иконки погоды и сразу переводим в нумерацию Zepp
                  data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon), app_id);
              }

              if (weatherJson?.weatherDescriptionExtended?.length) {
                  data.weatherDescription = weatherJson.weatherDescriptionExtended;
                  data.weatherDescription = data.weatherDescription.replace(data.weatherDescription[0], data.weatherDescription[0].toUpperCase());
              } else data.weatherDescription = this.description[data.weatherIcon];

              if (isFinite(weatherJson.temperature)) {
                  data.temperature = parseFloat(weatherJson.temperature);
                  data.temperature = Math.round(data.temperature);
              }
              
              if (isFinite(weatherJson.temperatureFeels)){
                  data.temperatureFeels = parseFloat(weatherJson.temperatureFeels);
                  data.temperatureFeels = Math.round(data.temperatureFeels);
              }
                  
              if (isFinite(weatherJson.temperatureMax)){
                  data.temperatureMax = parseFloat(weatherJson.temperatureMax);
                  data.temperatureMax = Math.round(data.temperatureMax);
              }
                  
              if (isFinite(weatherJson.temperatureMin)){
                  data.temperatureMin = parseFloat(weatherJson.temperatureMin);
                  data.temperatureMin = Math.round(data.temperatureMin);
              }
              
              if (weatherJson.city) {
                  data.cityName = weatherJson.city;
              }
          }
          
          return data
        }  
        
        getWeatherData(app_id = null) {
          if (!app_id) return this.getZeppWeatherData()		// если нет app_id, то получаем данные от Zepp
          else return this.getAppWeatherData(app_id);			// иначе читаем данные из файла данных приложения
        }  
        
        update() {
          let curIcon = parseInt(this.last.weatherIcon);				// текущий индекс значка погоды без учета времени суток (т.е. число без "n")

          const modTime = this.getFileModTime(this.providers[this.props.index].appId);		// время изменеия файла с данными
          
          if (!modTime || this.last.modTime != modTime){										// если не получено время изменеия или оно отличается от последнего времени изменеия
              const newData = this.getWeatherData(this.providers[this.props.index].appId);	// тогда читаем новые данные из файла
              this.last.modTime = modTime;

              let val = this.tempWithSign(newData.temperature);
              if (val != this.last.temperature){
                  this.last.temperature = val;
                  if (this.props.temp_widget) this.props.temp_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = this.tempWithSign(newData.temperatureMax);
              if (val != this.last.temperatureMax){
                  this.last.temperatureMax = val;
                  if (this.props.temp_max_widget) this.props.temp_max_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = this.tempWithSign(newData.temperatureMin);
              if (val != this.last.temperatureMin){
                  this.last.temperatureMin = val;
                  if (this.props.temp_min_widget) this.props.temp_min_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = this.tempWithSign(newData.temperatureFeels);
              if (val != this.last.temperatureFeels){
                  this.last.temperatureFeels = val;
                  if (this.props.temp_feels_widget) this.props.temp_feels_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = newData.cityName;
              if (val != this.last.cityName){
                  this.last.cityName = val;
                  if (this.props.cityName_widget) this.props.cityName_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = newData.weatherDescription;
              if (val != this.last.weatherDescription){
                  this.last.weatherDescription = val;
                  if (this.props.description_widget) this.props.description_widget.setProperty(hmUI.prop.TEXT, val);
              }

              
              curIcon = newData.weatherIcon;						// получаем текущий индекс значка погоды
          }

          if (this.props.night_icons.includes(curIcon) && !this.isDayNow()){		// если он в списке ночных иконок и сейчас "ночь", то добавляем суффикс 'n'
              curIcon += 'n';
          }

          if (curIcon != this.last.weatherIcon){
              this.last.weatherIcon = curIcon;
              if (this.props.icon_widget) this.props.icon_widget.setProperty(hmUI.prop.SRC, `w_${curIcon}.png`);
          }
        } 
        
        next(show_toast = this.props.show_toast) {
          const v = (this.props.index + 1) % this.providers.length;
          this.provider = v;
          if (show_toast) hmUI.showToast({text: this.name});
        }        
        
        prev(show_toast = this.props.show_toast) {
          const v = (this.props.index - 1 + this.providers.length) % this.providers.length;
          this.provider = v;
          if (show_toast) hmUI.showToast({text: this.name});
        }   
        
        toggle(dir, show_toast = this.props.show_toast) {
          if (dir > 0) this.next(show_toast)
          else this.prev(show_toast);
        }   
        
        set provider(v) {
          this.props.index = v;
          hmFS.SysProSetInt('WeatherProviderIndex', v);
          this.update();
        }   
        
        get index() {
          return this.props.index
        }     
      
        
        get name() {
            return this.providers[this.props.index].name[this.props.lang]
        }    
        
        get cityName() {
          return this.last.cityName
        }     
        
        get temperature() {
          return this.last.temperature
        }   
        
        get temperatureMax() {
          return this.last.temperatureMax
        }

        
        get temperatureMin() {
            return this.last.temperatureMin
        }        

          
        get weatherDescription() {
            return this.last.weatherDescription
        }      
        
       delete() {
          this.providers = null;
          this.props = null;
          this.last = null;
          this.description = null;
          if (this.widgetDelegate) {
              hmUI.deleteWidget(this.widgetDelegate);
              this.widgetDelegate = null;
          }
       }

      } 

      // start user_functions.js
const {
  width: D_W,
  height: D_H
} = hmSetting.getDeviceInfo();       
        //end of ignored block
        function getZodiacSign(month, day) {
          
          if ((month === 1 && day >= 20) || (month === 2 && day <= 18)) return 0;
  
          
          if ((month === 2 && day >= 19) || (month === 3 && day <= 20)) return 1;
  
          
          if ((month === 3 && day >= 21) || (month === 4 && day <= 19)) return 2;
  
          
          if ((month === 4 && day >= 20) || (month === 5 && day <= 20)) return 3;
  
          
          if ((month === 5 && day >= 21) || (month === 6 && day <= 20)) return 4;
  
          
          if ((month === 6 && day >= 21) || (month === 7 && day <= 22)) return 5;
  
          
          if ((month === 7 && day >= 23) || (month === 8 && day <= 22)) return 6;
  
         
          if ((month === 8 && day >= 23) || (month === 9 && day <= 22)) return 7;
  
          
          if ((month === 9 && day >= 23) || (month === 10 && day <= 22)) return 8;
  
          
          if ((month === 10 && day >= 23) || (month === 11 && day <= 21)) return 9;
  
          
          if ((month === 11 && day >= 22) || (month === 12 && day <= 21)) return 10;
  
          
          return 11;
        }     
        
        function updateZodiacSign() {
          const date = new Date();
          const month = date.getMonth() + 1;
          const day = date.getDate();
          const newIndex = getZodiacSign(month, day);
  
          zodiacImage.setProperty(hmUI.prop.SRC, 'zod_' + newIndex + '.png');
        } 
        //dynamic modify start
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 4

        let btn_bezel2 = ''
        let bezel_num2 = 1
        let bezel_all2 = 4   
        
        let btn_bezel3 = ''
        let bezel_num3 = 1
        let bezel_all3 = 4        
        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_day_text_font = ''
        let normal_altimeter_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_calorie_TextCircle = new Array(4);
        let normal_calorie_TextCircle_ASCIIARRAY = new Array(10);
        let normal_calorie_TextCircle_img_width = 22;
        let normal_calorie_TextCircle_img_height = 19;
        let normal_spo2_TextCircle = new Array(3);
        let normal_spo2_TextCircle_ASCIIARRAY = new Array(10);
        let normal_spo2_TextCircle_img_width = 22;
        let normal_spo2_TextCircle_img_height = 19;
        let normal_sunrise_TextCircle = new Array(5);
        let normal_sunrise_TextCircle_ASCIIARRAY = new Array(10);
        let normal_sunrise_TextCircle_img_width = 22;
        let normal_sunrise_TextCircle_img_height = 19;
        let normal_sunrise_TextCircle_unit = null;
        let normal_sunrise_TextCircle_unit_width = 13;
        let normal_sunrise_TextCircle_dot_width = 9;
        let normal_sunset_TextCircle = new Array(5);
        let normal_sunset_TextCircle_ASCIIARRAY = new Array(10);
        let normal_sunset_TextCircle_img_width = 22;
        let normal_sunset_TextCircle_img_height = 19;
        let normal_sunset_TextCircle_dot_width = 9;
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 22;
        let normal_battery_TextCircle_img_height = 19;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 22;
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 22;
        let normal_heart_rate_TextCircle_img_height = 19;
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 22;
        let normal_step_TextCircle_img_height = 19;
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_dow_text_font = ''
        let idle_DOW_Array = ['ПОНЕДЕЛЬНИК', 'ВТОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА', 'ВОСКРЕСЕНЬЕ'];
        let idle_day_text_font = ''
        let idle_city_name_text = ''
        let idle_temperature_current_text_font = ''
        let idle_battery_current_text_font = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_fatBurning_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''        
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
            function click_Bezel() {
              if(bezel_num>=bezel_all) {bezel_num=1;}
              else { bezel_num=bezel_num+1;}
              hmUI.showToast({text: "Центр " + parseInt(bezel_num) });
                normal_image_img.setProperty(hmUI.prop.SRC, "centr_" + parseInt(bezel_num) + ".png");                
            }   
            
            function click_Bezel2() {
              if(bezel_num2>=bezel_all2) {bezel_num2=1;}
              else { bezel_num2=bezel_num2+1;}
              hmUI.showToast({text: "Безель " + parseInt(bezel_num2) });
                normal_altimeter_icon_img.setProperty(hmUI.prop.SRC, "bezel_" + parseInt(bezel_num2) + ".png");                
            }   
            
            function click_Bezel3() {
              if(bezel_num3>=bezel_all3) {bezel_num3=1;}
              else { bezel_num3=bezel_num3+1;}
              hmUI.showToast({text: "Внешний " + parseInt(bezel_num3) });
                normal_background_bg_img.setProperty(hmUI.prop.SRC, "osn_" + parseInt(bezel_num3) + ".png");                
            }               
                
            // FontName: BrunoAce-Regular.ttf; FontSize: 35
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 585,
              h: 50,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/BrunoAce-Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: BrunoAce-Regular.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 30,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/BrunoAce-Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            // FontName: MYRIADPRO-REGULAR.ttf; FontSize: 30; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 36,
              h: 36,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/MYRIADPRO-REGULAR.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

            let sleep_time_txt = ''
            let sleep_start_time_txt = ''
            let sleep_end_time_txt = ''
            let sleep_score_txt = ''
            let wake_time_txt = ''

            const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
            let sleepInfo = sleep.getBasicInfo();
            
            let sleepTotalTime = sleep.getTotalTime();		
            let sleepStartTime = sleepInfo.startTime;
            let sleepEndTime = sleepInfo.endTime + 1;
            let sleepScore = sleepInfo.score;

        //время пробуждений	
            let sleepStageArray = sleep.getSleepStageData();
            const modelData = sleep.getSleepStageModel();
        //		

            function updateSleepInfo() {
                sleepTotalTime = sleep.getTotalTime();
                sleepInfo = sleep.getBasicInfo();
                sleepStartTime = sleepInfo.startTime;
                if (sleepStartTime >= 24*60) {
                    sleepStartTime -= 24*60
                }
                
                sleepEndTime = sleepInfo.endTime + 1;
                if (sleepEndTime >= 24*60) {
                    sleepEndTime -= 24*60
                }

            // время пробуждений
                let wakeTime = 0;
                sleepStageArray = sleep.getSleepStageData();
                
                for (let i = 0; i < sleepStageArray.length; i++) {
                let data = sleepStageArray[i];
                if (data.model == modelData.WAKE_STAGE){
                        wakeTime += data.stop + 1 - data.start;
                }

                }
                
                sleepTotalTime -= wakeTime;
           //
                
                sleep_time_txt.setProperty(hmUI.prop.TEXT, ' ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
                sleep_start_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepStartTime / 60).toString().padStart(2, "0") + ':' + (sleepStartTime % 60).toString().padStart(2, "0"));
                sleep_end_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepEndTime / 60).toString().padStart(2, "0") + ':' + (sleepEndTime % 60).toString().padStart(2, "0"));
                wake_time_txt.setProperty(hmUI.prop.TEXT, 'Не спали: ' + String(wakeTime) + ' мин.');
                sleep_score_txt.setProperty(hmUI.prop.TEXT, ' ' + String(sleepScore));
            }
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'centr_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 231,
              y: 172,
              src: 'bd_on.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_ALARM_CLOCK_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 275,
              y: 170,
              font_array: ["bd_0.png", "bd_1.png", "bd_2.png", "bd_3.png", "bd_4.png", "bd_5.png", "bd_6.png", "bd_7.png", "bd_8.png", "bd_9.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'clean.png',
              dot_image: 'bd_dv.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });              

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 75,
              second_startY: 170,
              second_array: ["sek_0.png","sek_1.png","sek_2.png","sek_3.png","sek_4.png","sek_5.png","sek_6.png","sek_7.png","sek_8.png","sek_9.png"],
              second_zero: 1,
              second_space: -5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 70,
              hour_startY: 202,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 241,
              minute_startY: 202,
              minute_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
            sleep_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 108,
              y: 286,
              w: 180,	
              h: 30,
              text_size: 24,
              font: 'fonts/BrunoAce-Regular.ttf',
              text: '',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              text_style: hmUI.text_style.ELLIPSIS,
              char_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //

  

            // end user_script.js

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 79,
              month_startY: 116,
              month_sc_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_tc_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_en_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 118,
              y: 107,
              week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 192,
              y: 79,
              w: 100,
              h: 40,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/BrunoAce-Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const weatherInfo = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
            });

            weatherImg = weatherInfo.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 2,
                w: 480,
                h: 480,
                src: 'w_25.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });             
                            
            tempText = weatherInfo.createWidget(hmUI.widget.TEXT, {
                x: 172,
                y: 359,
                w: 150,
                h: 40,
                text_size: 35,
                char_space: 0,
                line_space: 0,
                font: 'fonts/BrunoAce-Regular.ttf',
                text: '--',
                color: 0xFF000000,
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.TOP,
                unit_type: 1,
                text_style: hmUI.text_style.ELLIPSIS,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });         

            // экземпляр класса
            weatherProvider = new WeatherProvider({
                night_icons: [0, 1, 2, 3, 14],
                show_toast: false,
                temp_widget: tempText,
                temp_max_widget: tempMaxText,
                temp_min_widget: tempMinText,
                temp_feels_widget: tempFeelsText,
                description_widget: descriptionText,
                cityName_widget: cityNameText,
                icon_widget: weatherImg,
                time_sensor: curTime,
                weather_sensor: weather,
            });                 

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bezel_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 336,
              y: 348,
              image_array: ["wind_0.png","wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 374,
              y: 321,
              font_array: ["bd_0.png","bd_1.png","bd_2.png","bd_3.png","bd_4.png","bd_5.png","bd_6.png","bd_7.png","bd_8.png","bd_9.png"],
              padding: false,
              h_space: 0,
              angle: -60,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // Получаем текущую дату
            const date = new Date();
            const month = date.getMonth() + 1; // Месяцы от 1 до 12
            const day = date.getDate();
            // Определяем индекс знака зодиака
            const index_zodiac = getZodiacSign(month, day);
            // Создаем виджет изображения
            zodiacImage = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zod_' + index_zodiac + '.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });                  

            // normal_calorie_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["bd_0.png","bd_1.png","bd_2.png","bd_3.png","bd_4.png","bd_5.png","bd_6.png","bd_7.png","bd_8.png","bd_9.png"],
              // radius: 166,
              // angle: -50,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextCircle_ASCIIARRAY[0] = 'bd_0.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[1] = 'bd_1.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[2] = 'bd_2.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[3] = 'bd_3.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[4] = 'bd_4.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[5] = 'bd_5.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[6] = 'bd_6.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[7] = 'bd_7.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[8] = 'bd_8.png';  // set of images with numbers
            normal_calorie_TextCircle_ASCIIARRAY[9] = 'bd_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_calorie_TextCircle_img_width / 2,
                pos_y: 240 - 185,
                src: 'bd_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_spo2_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["bd_0.png","bd_1.png","bd_2.png","bd_3.png","bd_4.png","bd_5.png","bd_6.png","bd_7.png","bd_8.png","bd_9.png"],
              // radius: 166,
              // angle: -70,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.SPO2,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_spo2_TextCircle_ASCIIARRAY[0] = 'bd_0.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[1] = 'bd_1.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[2] = 'bd_2.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[3] = 'bd_3.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[4] = 'bd_4.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[5] = 'bd_5.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[6] = 'bd_6.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[7] = 'bd_7.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[8] = 'bd_8.png';  // set of images with numbers
            normal_spo2_TextCircle_ASCIIARRAY[9] = 'bd_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_spo2_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_spo2_TextCircle_img_width / 2,
                pos_y: 240 - 185,
                src: 'bd_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_spo2_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const spo2 = hmSensor.createSensor(hmSensor.id.SPO2);
            spo2.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_sunrise_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["bd_0.png","bd_1.png","bd_2.png","bd_3.png","bd_4.png","bd_5.png","bd_6.png","bd_7.png","bd_8.png","bd_9.png"],
              // radius: 165,
              // angle: 35,
              // char_space_angle: -1,
              // unit: 'bd_sl.png',
              // dot_image: 'bd_dv.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SUN_RISE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunrise_TextCircle_ASCIIARRAY[0] = 'bd_0.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[1] = 'bd_1.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[2] = 'bd_2.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[3] = 'bd_3.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[4] = 'bd_4.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[5] = 'bd_5.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[6] = 'bd_6.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[7] = 'bd_7.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[8] = 'bd_8.png';  // set of images with numbers
            normal_sunrise_TextCircle_ASCIIARRAY[9] = 'bd_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunrise_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_sunrise_TextCircle_img_width / 2,
                pos_y: 240 - 184,
                src: 'bd_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_sunrise_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_sunrise_TextCircle_unit_width / 2,
              pos_y: 240 - 184,
              src: 'bd_sl.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_sunrise_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            // normal_sunset_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["bd_0.png","bd_1.png","bd_2.png","bd_3.png","bd_4.png","bd_5.png","bd_6.png","bd_7.png","bd_8.png","bd_9.png"],
              // radius: 165,
              // angle: 63,
              // char_space_angle: -1,
              // dot_image: 'bd_dv.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.SUN_SET,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_sunset_TextCircle_ASCIIARRAY[0] = 'bd_0.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[1] = 'bd_1.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[2] = 'bd_2.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[3] = 'bd_3.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[4] = 'bd_4.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[5] = 'bd_5.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[6] = 'bd_6.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[7] = 'bd_7.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[8] = 'bd_8.png';  // set of images with numbers
            normal_sunset_TextCircle_ASCIIARRAY[9] = 'bd_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_sunset_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_sunset_TextCircle_img_width / 2,
                pos_y: 240 - 184,
                src: 'bd_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["bd_0.png","bd_1.png","bd_2.png","bd_3.png","bd_4.png","bd_5.png","bd_6.png","bd_7.png","bd_8.png","bd_9.png"],
              // radius: 186,
              // angle: -114,
              // char_space_angle: 0,
              // unit: 'bd_pr.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'bd_0.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'bd_1.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'bd_2.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'bd_3.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'bd_4.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'bd_5.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'bd_6.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'bd_7.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'bd_8.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'bd_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_battery_TextCircle_img_width / 2,
                pos_y: 240 + 167,
                src: 'bd_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 240 + 167,
              src: 'bd_pr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["bd_0.png","bd_1.png","bd_2.png","bd_3.png","bd_4.png","bd_5.png","bd_6.png","bd_7.png","bd_8.png","bd_9.png"],
              // radius: 186,
              // angle: -139,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'bd_0.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'bd_1.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'bd_2.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'bd_3.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'bd_4.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'bd_5.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'bd_6.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'bd_7.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'bd_8.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'bd_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 + 167,
                src: 'bd_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["bd_0.png","bd_1.png","bd_2.png","bd_3.png","bd_4.png","bd_5.png","bd_6.png","bd_7.png","bd_8.png","bd_9.png"],
              // radius: 185,
              // angle: 180,
              // char_space_angle: 2,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 'bd_0.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 'bd_1.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 'bd_2.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 'bd_3.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 'bd_4.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 'bd_5.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 'bd_6.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 'bd_7.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 'bd_8.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 'bd_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_step_TextCircle_img_width / 2,
                pos_y: 240 + 166,
                src: 'bd_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 16,
              hour_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minn.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 16,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sekk.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 16,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'bt_offAOD.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 70,
              hour_startY: 202,
              hour_array: ["HA_0.png","HA_1.png","HA_2.png","HA_3.png","HA_4.png","HA_5.png","HA_6.png","HA_7.png","HA_8.png","HA_9.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 241,
              minute_startY: 202,
              minute_array: ["HA_0.png","HA_1.png","HA_2.png","HA_3.png","HA_4.png","HA_5.png","HA_6.png","HA_7.png","HA_8.png","HA_9.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 112,
              y: 162,
              w: 255,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/MYRIADPRO-REGULAR.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: ПОНЕДЕЛЬНИК, ВТОРНИК, СРЕДА, ЧЕТВЕРГ, ПЯТНИЦА, СУББОТА, ВОСКРЕСЕНЬЕ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 192,
              y: 128,
              w: 100,
              h: 40,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/BrunoAce-Regular.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 140,
              y: 277,
              w: 200,
              h: 40,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/MYRIADPRO-REGULAR.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 228,
              y: 312,
              w: 150,
              h: 40,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/BrunoAce-Regular.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 89,
              y: 312,
              w: 150,
              h: 40,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/BrunoAce-Regular.ttf',
              color: 0xFFC0C0C0,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 192,
              y: 400,
              w: 100,
              h: 45,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 82,
              y: 346,
              w: 71,
              h: 52,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 50,
              y: 262,
              w: 47,
              h: 60,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 52,
              y: 155,
              w: 42,
              h: 49,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 129,
              y: 214,
              w: 70,
              h: 50,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 287,
              y: 215,
              w: 70,
              h: 50,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 280,
              y: 162,
              w: 73,
              h: 35,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 122,
              y: 280,
              w: 65,
              h: 34,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fatBurning_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 92,
              y: 83,
              w: 57,
              h: 53,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 45,
              w: 74,
              h: 35,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 91,
              w: 74,
              h: 44,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 214,
              y: 310,
              w: 50,
              h: 50,
              text: '',
              text_size: 25,
              color: 0xFFFF8C00,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: () => {                
                weatherProvider.prev(true);                
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });  
            
            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 225,
              y: 360,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button        
            
            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 320,
              y: 27,
              text: '',
              w: 50,
              h: 50,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
               click_Bezel();
               
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);  
            
            btn_bezel2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 400,
              y: 102,
              text: '',
              w: 50,
              h: 50,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
               click_Bezel2();
               
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel2.setProperty(hmUI.prop.VISIBLE, true);  
            
            btn_bezel3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 430,
              y: 215,
              text: '',
              w: 50,
              h: 50,
              normal_src: 'clean.png',
              press_src: 'clean.png',
              click_func: () => {
               click_Bezel3();
               
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel3.setProperty(hmUI.prop.VISIBLE, true);              

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day of week font');
              if (updateHour) {
                let idle_DOW_Str = idle_DOW_Array[timeSensor.week-1];
                idle_dow_text_font.setProperty(hmUI.prop.TEXT, idle_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

            };

            //end of ignored block
            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_circle_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -50;
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_circle_string.length > 0 && normal_calorie_circle_string.length <= 4) {  // display data if it was possible to get it
                  let normal_calorie_TextCircle_img_angle = 0;
                  let normal_calorie_TextCircle_dot_img_angle = 0;
                  normal_calorie_TextCircle_img_angle = toDegree(Math.atan2(normal_calorie_TextCircle_img_width/2, 166));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_calorie_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_calorie_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_calorie_TextCircle_img_width / 2);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.SRC, normal_calorie_TextCircle_ASCIIARRAY[charCode]);
                      normal_calorie_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_calorie_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle spo2_SPO2');
              let valueSpO2 = spo2.current;
              let normal_spo2_circle_string = parseInt(valueSpO2).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_spo2_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -70;
                if (valueSpO2 != null && valueSpO2 != undefined && isFinite(valueSpO2) && normal_spo2_circle_string.length > 0 && normal_spo2_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_spo2_TextCircle_img_angle = 0;
                  let normal_spo2_TextCircle_dot_img_angle = 0;
                  normal_spo2_TextCircle_img_angle = toDegree(Math.atan2(normal_spo2_TextCircle_img_width/2, 166));
                  // alignment = CENTER_H
                  let normal_spo2_TextCircle_angleOffset = normal_spo2_TextCircle_img_angle * (normal_spo2_circle_string.length - 1);
                  char_Angle -= normal_spo2_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_spo2_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_spo2_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_spo2_TextCircle_img_width / 2);
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.SRC, normal_spo2_TextCircle_ASCIIARRAY[charCode]);
                      normal_spo2_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_spo2_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };
              let weatherData = weatherSensor.getForecastWeather();
              let tideData = weatherData.tideData;
              let sunrise_hour = -1;
              let sunrise_minute = -1;
              if (tideData.count > 0) {
                sunrise_hour = tideData.data[0].sunrise.hour;
                sunrise_minute = tideData.data[0].sunrise.minute;
              }; // end tideData;

              console.log('update text circle sunrise_tideData');
              let sunriseTime = undefined;
              let normal_sunrise_circle_string = undefined;
              if (sunrise_hour >= 0 && sunrise_minute >= 0) {
                sunriseTime = 0;
                normal_sunrise_circle_string = String(sunrise_hour) + '.' + String(sunrise_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunrise_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_sunrise_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 35;
                if (sunriseTime != null && sunriseTime != undefined && isFinite(sunriseTime) && normal_sunrise_circle_string.length > 0 && normal_sunrise_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_sunrise_TextCircle_img_angle = 0;
                  let normal_sunrise_TextCircle_dot_img_angle = 0;
                  let normal_sunrise_TextCircle_unit_angle = 0;
                  normal_sunrise_TextCircle_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_img_width/2, 165));
                  normal_sunrise_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_dot_width/2, 165));
                  normal_sunrise_TextCircle_unit_angle = toDegree(Math.atan2(normal_sunrise_TextCircle_unit_width/2, 165));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_sunrise_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_sunrise_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_sunrise_TextCircle_img_width / 2);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunrise_TextCircle_ASCIIARRAY[charCode]);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunrise_TextCircle_img_angle + -1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_sunrise_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_sunrise_TextCircle_dot_width / 2);
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.SRC, 'bd_dv.png');
                      normal_sunrise_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunrise_TextCircle_dot_img_angle + -1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  char_Angle += normal_sunrise_TextCircle_unit_angle;
                  normal_sunrise_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_sunrise_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };
              let sunset_hour = -1;
              let sunset_minute = -1;
              if (tideData.count > 0) {
                sunset_hour = tideData.data[0].sunset.hour;
                sunset_minute = tideData.data[0].sunset.minute;
              }; // end tideData;

              console.log('update text circle sunset_tideData');
              let sunsetTime = undefined;
              let normal_sunset_circle_string = undefined;
              if (sunset_hour >= 0 && sunset_minute >= 0) {
                sunsetTime = 0;
                normal_sunset_circle_string = String(sunset_hour) + '.' + String(sunset_minute).padStart(2, '0');
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_sunset_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 63;
                if (sunsetTime != null && sunsetTime != undefined && isFinite(sunsetTime) && normal_sunset_circle_string.length > 0 && normal_sunset_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_sunset_TextCircle_img_angle = 0;
                  let normal_sunset_TextCircle_dot_img_angle = 0;
                  normal_sunset_TextCircle_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_img_width/2, 165));
                  normal_sunset_TextCircle_dot_img_angle = toDegree(Math.atan2(normal_sunset_TextCircle_dot_width/2, 165));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_sunset_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_sunset_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_sunset_TextCircle_img_width / 2);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, normal_sunset_TextCircle_ASCIIARRAY[charCode]);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunset_TextCircle_img_angle + -1;
                      index++;
                    }  // end if digit
                    else { 
                      if (!firstSymbol) char_Angle += normal_sunset_TextCircle_dot_img_angle; 
                      firstSymbol = false;
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_sunset_TextCircle_dot_width / 2);
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.SRC, 'bd_dv.png');
                      normal_sunset_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_sunset_TextCircle_dot_img_angle + -1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 66;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 186));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 186));
                  // alignment = RIGHT
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + (normal_battery_TextCircle_img_angle + normal_battery_TextCircle_unit_angle + 0) / 2;
                  normal_battery_TextCircle_angleOffset = -normal_battery_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 41;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 186));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = -normal_heart_rate_TextCircle_angleOffset;
                  char_Angle -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 360;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 185));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  normal_step_TextCircle_angleOffset = normal_step_TextCircle_angleOffset + 2 * (normal_step_circle_string.length - 1) / 2;
                  normal_step_TextCircle_angleOffset = -normal_step_TextCircle_angleOffset;
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_step_TextCircle_img_angle + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                text_update();

                console.log('resume_call.js');
                // start resume_call.js
                updateZodiacSign();
                updateSleepInfo();            
                // end resume_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}