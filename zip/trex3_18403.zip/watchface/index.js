﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

const {
 width: D_W,
 height: D_H
} = hmSetting.getDeviceInfo();
		
//let D_W = 480;
//let D_H = 480;
		
const packageInfo = hmApp.packageInfo();
WF_ID = packageInfo.appId;

let kf = D_W / 466;

const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

let normal_timerTimeUpdate2 = undefined;
let screenType2 = '';
let normal_battery_circle_scale_bg = '';
let normal_step_circle_scale_bg = '';
let normal_heart_rate_circle_scale_2_bg = '';
let normal_weather_circle_scale_bg = '';
let normal_WEATHER_progress = '';

function loadSettings() {

//    tip_grafik = hmFS.SysProGetInt(`${WF_ID}_tip_grafik`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_tip_grafik`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_tip_grafik`);
//	
//    fix_gsm = hmFS.SysProGetInt(`${WF_ID}_fix_gsm`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_fix_gsm`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_fix_gsm`);
	
	block = hmFS.SysProGetInt(`${WF_ID}_block`) === undefined ? (hmFS.SysProSetInt(`${WF_ID}_block`, 0), 0) : hmFS.SysProGetInt(`${WF_ID}_block`);

}

let normal_block_FILL_RECT = ""
let btn_block = ""
let block = 0

function clik_block() {
 block = (block + 1) % 2
 hmFS.SysProSetInt(`${WF_ID}_block`, block);
// normal_widget_text_4.setProperty(hmUI.prop.TEXT, block == 0 ? 'ОТКР' : 'БЛОК');
normal_widget_text_9.setProperty(hmUI.prop.TEXT, block == 0 ? '{' : '}');	
 normal_block_FILL_RECT.setProperty(hmUI.prop.VISIBLE, block == 1);
 btn_block.setProperty(hmUI.prop.VISIBLE, block == 1);
// vibro();
}

      function start_wg() {

       normal_battery_circle_scale_bg.setProperty(hmUI.prop.MORE, {
        center_x: D_W / 2,
        center_y: D_W / 2,
        start_angle: 280,
        end_angle: 337,
        radius: 217 * kf,
        line_width: 15 * kf,
        corner_flag: 0,
        color: bgColorList[bgColorIndex],
        level: 100,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });
       //  normal_battery_circle_scale_bg.setAlpha(80);

       normal_step_circle_scale_bg.setProperty(hmUI.prop.MORE, {
        center_x: D_W / 2,
        center_y: D_W / 2,
        start_angle: 100,
        end_angle: 157,
        radius: 217 * kf,
        line_width: 15 * kf,
        corner_flag: 0,
        color: bgColorList[bgColorIndex],
        level: 100,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });
       //  normal_step_circle_scale_bg.setAlpha(80);

       normal_heart_rate_circle_scale_2_bg.setProperty(hmUI.prop.MORE, {
        center_x: D_W / 2,
        center_y: D_W / 2,
        start_angle: 197,
        end_angle: 254,
        radius: 217 * kf,
        line_width: 15 * kf,
        corner_flag: 0,
        //type: hmUI.data_type.HEART,
        color: bgColorList[bgColorIndex],
        level: 100,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });
       //  normal_heart_rate_circle_scale_2_bg.setAlpha(80);

       normal_weather_circle_scale_bg.setProperty(hmUI.prop.MORE, {
        center_x: D_W / 2,
        center_y: D_W / 2,
        start_angle: 74,
        end_angle: 17,
        radius: 217 * kf,
        line_width: 15 * kf,
        corner_flag: 0,
        color: bgColorList[bgColorIndex],
        level: 100,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });
       // normal_weather_circle_scale_bg.setAlpha(80);

       normal_WEATHER_progress.setProperty(hmUI.prop.MORE, {
        center_x: D_W / 2,
        center_y: D_W / 2,
        start_angle: 74,
        end_angle: 17,
        radius: 217 * kf,
        line_width: 15 * kf,
        corner_flag: 0,
        color: bgColorList[bgColorIndex],
        show_level: hmUI.show_level.ONLY_NORMAL,
       });

       normal_widget_text_1.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
       normal_widget_text_2.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
       normal_widget_text_3.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
       normal_day_text_font.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);

       //idle_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]); 
       normal_heart_rate_circle_scale_2.setProperty(hmUI.prop.MORE, {
        center_x: D_W / 2,
        center_y: D_W / 2,
        start_angle: 197,
        end_angle: 254,
        radius: 217 * kf,
        line_width: 15 * kf,
        corner_flag: 0,
        type: hmUI.data_type.HEART,
        color: bgColorList[bgColorIndex],
        // mirror: False,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });

       normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
        center_x: D_W / 2,
        center_y: D_W / 2,
        start_angle: 100,
        end_angle: 157,
        radius: 217 * kf,
        line_width: 15 * kf,
        corner_flag: 0,
        color: bgColorList[bgColorIndex],
        show_level: hmUI.show_level.ONLY_NORMAL,
        // level: level,
       });

       normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
        center_x: D_W / 2,
        center_y: D_W / 2,
        start_angle: 280,
        end_angle: 337,
        radius: 217 * kf,
        line_width: 15 * kf,
        corner_flag: 0,
        color: bgColorList[bgColorIndex],
        show_level: hmUI.show_level.ONLY_NORMAL,
        // level: level,
       });
		  
      }





function time_update2(updateHour = false, updateMinute = false) {
 let hour = timeSensor.hour;
 let minute = timeSensor.minute;
 // let second = timeSensor.second;
 //let format_hour = timeSensor.format_hour;

 normal_stress_icon_img.setProperty(hmUI.prop.SRC, 'H_' + hour % 24 + '.png')
 normal_stand_icon_img.setProperty(hmUI.prop.SRC, 'M_' + minute % 60 + '.png')
 idle_stress_icon_img.setProperty(hmUI.prop.SRC, 'H_' + hour % 24 + '.png')
 idle_stand_icon_img.setProperty(hmUI.prop.SRC, 'M_' + minute % 60 + '.png')


};


function update_weather() {
    const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
    let weatherData = weatherSensor.getForecastWeather();
    let forecastData = weatherData.forecastData;
    
    // Безопасное получение текущей температуры
    let currentTemp = weatherSensor.current;
    if (typeof currentTemp !== 'number' || isNaN(currentTemp)) {
        return;
    }
    
    // Проверка наличия данных прогноза
    if (!forecastData || !forecastData.data || !forecastData.data[0]) {
        return;
    }
    
    let today = forecastData.data[0];
    let low = today.low;
    let high = today.high;
    
    // Защита от деления на ноль (если low == high)
    let range = high - low;
    if (Math.abs(range) < 0.01) range = 1;
    
    // Расчёт нормализованной позиции температуры между low и high
    let normalized = (currentTemp - low) / range;
    normalized = Math.min(1, Math.max(0, normalized)); // ограничиваем от 0 до 1
    
    // Обратный прогресс (чёрная маска)
    let progress = normalized;//1-normalized
    let level = Math.round(progress * 100);
    
    // Обновление кругового прогресса
    if (hmSetting.getScreenType() != hmSetting.screen_type.AOD) {
        if (normal_WEATHER_progress) {
            normal_WEATHER_progress.setProperty(hmUI.prop.MORE, {
                center_x: D_W/2,
                center_y: D_W/2,
                start_angle: 74,
                end_angle: 17,
                radius: 217*kf,
                line_width: 15*kf,
                corner_flag: 0,
                color: 0xFF96FD7F,
                show_level: hmUI.show_level.ONLY_NORMAL,
                level: level,
            });
        }
    }
    // Иконка (три состояния)
//    const HOT_ICON = "hot.png";
//    const COLD_ICON = "cold.png";
//    const NORM_ICON = "norm.png";
    
    let iconSrc = (currentTemp >= high) ? 0xff0000 :((currentTemp <= low) ? 0x00ffff : 0x000000);
    
    if (normal_widget_text_4) {
        normal_widget_text_4.setProperty(hmUI.prop.COLOR, iconSrc);
       // normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
    }
}


		// запуск приложения с заданным appId (если оно установлено) или системного приложения
function launchAppOrAppId(url, appId, page = 'page/index') {
 let appInstalled = false;
 try {
  const id16 = appId.toString(16).padStart(8, "0"); // переводим appId в 16-ричный формат
  const [fs_stat, err] = hmFS.stat_asset(`../../../js_apps/${id16}/app.json`); // проверяем наличие файла 'app.json' в папке приложения
  if (err == 0) { //  если файл есть,  то приложение установлено
   appInstalled = true;
  } else {
   console.log("err:", err);
  }
 } catch (error) {
  console.log("error:", error);
  console.log("FAIL: No access to hmFS.");
 }
 if (appInstalled) hmApp.startApp({
  appid: appId,
  url: page
 })
 else hmApp.startApp({
  url: url,
  native: true
 });
}

        // end user_functions.js

        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_stand_icon_img = ''
        let normal_stress_icon_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_font = ''
        let normal_battery_circle_scale = ''
        let normal_battery_current_text_font = ''
        let normal_heart_rate_circle_scale_2 = ''
        let normal_heart_rate_text_font = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_month_name_font = ''
        let normal_Month_Array = ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн', 'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек', ];
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['Пнд', 'Втр', 'Срд', 'Чтв', 'Птн', 'Сбт', 'Вск'];
        let normal_widget_text_1 = ''
        let normal_widget_text_2 = ''
        let normal_widget_text_3 = ''
        let normal_widget_text_4 = ''
        let normal_widget_text_5 = ''
        let normal_widget_text_6 = ''
        let normal_widget_text_7 = ''
        let normal_widget_text_8 = ''
        let normal_widget_text_9 = ''
        let normal_day_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_current_text_font = ''
        let normal_system_disconnect_img = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_stand_icon_img = ''
        let idle_stress_icon_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_Switch_BG_Color = ''

        let bgColorIndex = 0;
        let bgColorList = [0xFF96FD7F, 0xFF00FFFF, 0xFFFF0000, 0xFFFFFF00, 0xFFFF8000, 0xFF0080FF];
        let bgColorToastList = ['Цвет %s', 'Цвет %s', 'Цвет %s', 'Цвет %s', 'Цвет %s', 'Цвет %s'];
        const watchfaceId = hmApp.packageInfo().watchfaceId;
        
        let degreeSum = 0;
        let crownSensitivity = 70;  // crown sensitivity level
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Roboto-Black.ttf; FontSize: 25
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 339,
              h: 36,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Roboto_A2-Black.ttf; FontSize: 25
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 339,
              h: 36,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto_A2-Black.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Roboto-Black.ttf; FontSize: 31; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 37,
              h: 37,
              text_size: 31,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: HeadingSmallcaseProicv7-Bold.ttf; FontSize: 26
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 364,
              h: 38,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/HeadingSmallcaseProicv7-Bold.ttf',
              color: 0xFF96FD7F,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: HeadingSmallcaseProicv7-Bold.ttf; FontSize: 42
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 585,
              h: 60,
              text_size: 42,
              char_space: 0,
              line_space: 0,
              font: 'fonts/HeadingSmallcaseProicv7-Bold.ttf',
              color: 0xFFFF0000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: HeadingSmallcaseProicv7-Bold.ttf; FontSize: 37
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 508,
              h: 52,
              text_size: 37,
              char_space: 0,
              line_space: 0,
              font: 'fonts/HeadingSmallcaseProicv7-Bold.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script_start.js');
            // start user_script_start.js

loadSettings();
            // end user_script_start.js

            //#region onDigitalCrown
            console.log('onDigitalCrown()');
            function onDigitalCrown() {
              setTimeout(() => {
                hmApp.registerSpinEvent(function (key, degree) {
                  if (key === hmApp.key.HOME) {
			 if (block == 0)  

                  {  degreeSum += degree;
                    if (Math.abs(degreeSum) > crownSensitivity){
                      let step = degreeSum < 0 ? -1 : 1;
                      degreeSum = 0;
                      
                      console.log('SwitchBgColor use crown');
                      bgColorIndex += step;
                      bgColorIndex = bgColorIndex < 0 ? bgColorList.length + bgColorIndex : bgColorIndex % bgColorList.length;
                      hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
                      degreeSum = 0;
                      let toastText = bgColorToastList[bgColorIndex].replace('%s', `${bgColorIndex + 1}`);
                      if (toastText.length > 0) hmUI.showToast({text: toastText});
                      normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
						start_wg();
                      vibro(28);
                    }}
					  
					  
                  } // key
                }) // crown
              }, 250);
            }
            //#endregion

            //#region SwitchBG_Color
            console.log('SwitchBG_Color');
            function switchBG_Color() {
              bgColorIndex++;
              if (bgColorIndex >= bgColorList.length) bgColorIndex = 0;
              hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
              let toastText = bgColorToastList[bgColorIndex].replace('%s', `${bgColorIndex + 1}`);
              if (toastText.length > 0) hmUI.showToast({text: toastText});
              normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
				              vibro(28);
            };
            //#endregion

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF96FD7F',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 101,
              y: 240,
              src: 'M_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 101,
              y: 122,
              src: 'H_4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
if (!screenType2) screenType2 = hmSetting.getScreenType();


            normal_battery_circle_scale_bg = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: D_W/2,
              center_y: D_W/2,
              start_angle: 280,
              end_angle: 337,
              radius: 217*kf,
              line_width: 15*kf,
              corner_flag: 0,
              color: 0xFF96FD7F,
              level: 100,
				show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_circle_scale_bg.setAlpha(80);

            normal_step_circle_scale_bg  = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: D_W/2,
              center_y: D_W/2,
              start_angle: 100,
              end_angle: 157,
              radius: 217*kf,
              line_width: 15*kf,
              corner_flag: 0,
              color: 0xFF96FD7F,
              level: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_step_circle_scale_bg.setAlpha(80);

            normal_heart_rate_circle_scale_2_bg = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: D_W/2,
              center_y: D_W/2,
              start_angle: 197,
              end_angle: 254,
              radius: 217*kf,
              line_width: 15*kf,
              corner_flag: 0,
              //type: hmUI.data_type.HEART,
              color: 0xFF96FD7F,
              level: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_heart_rate_circle_scale_2_bg.setAlpha(80);

            normal_weather_circle_scale_bg = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: D_W/2,
              center_y: D_W/2,
              start_angle: 74,
              end_angle: 17,
              radius: 217*kf,
              line_width: 15*kf,
              corner_flag: 0,
              color: 0xFF96FD7F,
              level: 100,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_weather_circle_scale_bg.setAlpha(80);

	            normal_WEATHER_progress = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
                center_x: 233*kf,
                center_y: 233*kf,
                start_angle: 74,
                end_angle: 17,
                radius: 217*kf,
                line_width: 15*kf,
                corner_flag: 0,
              color: 0xFF96FD7F,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // end user_script.js

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 100,
              // end_angle: 157,
              // radius: 231,
              // line_width: 15,
              // line_cap: Rounded,
              // color: 0xFF96FD7F,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 100,
              end_angle: 157,
              radius: 224,
              line_width: 15,
              corner_flag: 0,
              color: 0xFF96FD7F,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 2,
              y: 2,
              w: 476,
              h: 476,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 160,
              end_angle: 270,
              mode: 1,
              // radius: 238,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 280,
              // end_angle: 337,
              // radius: 231,
              // line_width: 15,
              // line_cap: Rounded,
              // color: 0xFF96FD7F,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 280,
              end_angle: 337,
              radius: 224,
              line_width: 15,
              corner_flag: 0,
              color: 0xFF96FD7F,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -1,
              y: -1,
              w: 482,
              h: 482,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 340,
              end_angle: 360,
              mode: 0,
              // radius: 241,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 197,
              end_angle: 254,
              radius: 224,
              line_width: 15,
              corner_flag: 0,
              type: hmUI.data_type.HEART,
              color: 0xFF96FD7F,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 2,
              y: 2,
              w: 476,
              h: 476,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 257,
              end_angle: 300,
              mode: 1,
              // radius: 238,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 162,
              y: 81,
              w: 155,
              h: 52,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Roboto_A2-Black.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_month_name_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 224,
              y: 52,
              w: 155,
              h: 52,
              text_size: 31,
              char_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_string: Янв, Фев, Мар, Апр, Май, Июн, Июл, Авг, Сен, Окт, Ноя, Дек,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 106,
              y: 52,
              w: 155,
              h: 52,
              text_size: 31,
              char_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              // unit_string: Пнд, Втр, Срд, Чтв, Птн, Сбт, Вск,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_1 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 0,
              y: 12,
              w: 480,
              h: 480,
              text_size: 26,
              char_space: 0,
              font: 'fonts/HeadingSmallcaseProicv7-Bold.ttf',
              color: 0xFF96FD7F,
              // use_text_circle: true,
              start_angle: 262,
              end_angle: 290,
              mode: 0,
              // radius: 240,
              align_h: hmUI.align.CENTER_H,
              text: 'z',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_2 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -4,
              y: -4,
              w: 488,
              h: 488,
              text_size: 26,
              char_space: 0,
              font: 'fonts/HeadingSmallcaseProicv7-Bold.ttf',
              color: 0xFF96FD7F,
              // use_text_circle: true,
              start_angle: 80,
              end_angle: 110,
              mode: 1,
              // radius: 244,
              align_h: hmUI.align.CENTER_H,
              text: 'S',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_3 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: -4,
              y: -4,
              w: 488,
              h: 488,
              text_size: 26,
              char_space: 0,
              font: 'fonts/HeadingSmallcaseProicv7-Bold.ttf',
              color: 0xFF96FD7F,
              // use_text_circle: true,
              start_angle: 160,
              end_angle: 223,
              mode: 1,
              // radius: 244,
              align_h: hmUI.align.CENTER_H,
              text: 'P',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_4 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 343,
              y: 82,
              w: 52,
              h: 52,
              text_size: 42,
              char_space: 0,
              font: 'fonts/HeadingSmallcaseProicv7-Bold.ttf',
              color: 0xFFFF0000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: '~',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_5 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 44,
              y: 176,
              w: 52,
              h: 52,
              text_size: 37,
              char_space: 0,
              font: 'fonts/HeadingSmallcaseProicv7-Bold.ttf',
              color: 0xFF808080,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'd',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_6 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 44,
              y: 256,
              w: 52,
              h: 52,
              text_size: 37,
              char_space: 0,
              font: 'fonts/HeadingSmallcaseProicv7-Bold.ttf',
              color: 0xFF808080,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'T',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_7 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 384,
              y: 172,
              w: 52,
              h: 52,
              text_size: 37,
              char_space: 0,
              font: 'fonts/HeadingSmallcaseProicv7-Bold.ttf',
              color: 0xFF808080,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'y',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_8 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 384,
              y: 253,
              w: 52,
              h: 52,
              text_size: 37,
              char_space: 0,
              font: 'fonts/HeadingSmallcaseProicv7-Bold.ttf',
              color: 0xFF808080,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: 'j',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_widget_text_9 = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 308,
              y: 379,
              w: 52,
              h: 52,
              text_size: 37,
              char_space: 0,
              font: 'fonts/HeadingSmallcaseProicv7-Bold.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              text: '{}',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 162,
              y: 52,
              w: 155,
              h: 52,
              text_size: 31,
              char_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFF96FD7F,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 180,
              y: 374,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -1,
              y: -1,
              w: 482,
              h: 482,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 77,
              end_angle: 120,
              mode: 0,
              // radius: 241,
              align_h: hmUI.align.LEFT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: -1,
              y: -1,
              w: 482,
              h: 482,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -20,
              end_angle: 17,
              mode: 0,
              // radius: 241,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 178,
              y: 368,
              w: 155,
              h: 52,
              text_size: 31,
              char_space: 0,
              font: 'fonts/Roboto-Black.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 220,
              y: 36,
              src: 'stat_bg.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF96FD7F',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'a_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 101,
              y: 240,
              src: 'M_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 101,
              y: 122,
              src: 'H_4.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 29,
              y: 152,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'AlarmInfoScreen', native: true });
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 29,
              y: 236,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'CountdownAppScreen', native: true });
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 370,
              y: 150,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FindPhoneScreen', native: true });
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 202,
              y: 38,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                launchAppOrAppId('ScheduleCalScreen', 1057409);
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 202,
              y: 356,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                launchAppOrAppId('WeatherScreen', 1051195);
vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 294,
              y: 356,
              w: 82,
              h: 82,
              text: '',
              color: 0xFFFF8C00,
              text_size: 26,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                clik_block();
 vibro();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('Watch_Face.SwitchBG_Color');
            // Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.SwitchBG_Color, {
              // x: 359,
              // y: 226,
              // w: 80,
              // h: 80,
              // text: '',
              // color: 0xFFFF8C00,
              // text_size: 25,
              // press_src: '0.png',
              // normal_src: '0.png',
              // color_list: 0xFF96FD7F|0xFF00FFFF|0xFFFF0000|0xFFFFFF00|0xFFFF8000|0xFF0080FF,
              // toast_list: Цвет %s|Цвет %s|Цвет %s|Цвет %s|Цвет %s|Цвет %s,
              // use_crown: True,
              // use_in_AOD: True,
              // vibro: True,
            // });

            Button_Switch_BG_Color = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 359,
              y: 226,
              w: 80,
              h: 80,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0.png',
              normal_src: '0.png',
              click_func: (button_widget) => {
                switchBG_Color();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region vibrate function
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;

            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            //#endregion

            console.log('user_script_end.js');
            // start user_script_end.js


    normal_block_FILL_RECT = hmUI.createWidget(hmUI.widget.FILL_RECT, {
     x: 0,
     y: 0,
     w: D_W,
     h: D_W,
     color: 0x000000,
     alpha: 0,
     show_level: hmUI.show_level.ONLY_NORMAL,
    });
    normal_block_FILL_RECT.setProperty(hmUI.prop.VISIBLE, block == 1);

    btn_block = hmUI.createWidget(hmUI.widget.BUTTON, {
     x: 285 * kf,
     y: 346 * kf,
     text: '',
     w: 80 * kf,
     h: 80 * kf,
     normal_src: '0_Empty.png',
     press_src: '0_Empty.png',
	click_func: (button_widget) => {
		//vibro();
        hmUI.showToast({text: "Для разблокировки нужно долгое нажатие",});
		 },				  
     longpress_func: () => {
      // vibro();
	//MenuCirkl_Timer_on(3) 
		vibro();
      clik_block();
     },
     show_level: hmUI.show_level.ONLY_NORMAL,
    });
    btn_block.setProperty(hmUI.prop.VISIBLE, block == 1);
normal_widget_text_9.setProperty(hmUI.prop.TEXT, block == 0 ? '{' : '}');


            // end user_script_end.js

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('month font');
              if (updateHour) {
                let normal_Month_Str = normal_Month_Array[timeSensor.month-1];
                normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str );
              };

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 100,
                      end_angle: 157,
                      radius: 224,
                      line_width: 15,
                      corner_flag: 0,
                      color: 0xFF96FD7F,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 280,
                      end_angle: 337,
                      radius: 224,
                      line_width: 15,
                      corner_flag: 0,
                      color: 0xFF96FD7F,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);

                //SwitchBgColor
                if (hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`) === undefined) {
                  bgColorIndex = 0;
                  hmFS.SysProSetInt(`bgColorIndex_${watchfaceId}`, bgColorIndex);
                } else {
                  bgColorIndex = hmFS.SysProGetInt(`bgColorIndex_${watchfaceId}`);
                };
                if (screenType == hmSetting.screen_type.WATCHFACE && normal_background_bg) normal_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
          start_wg();
				  if (screenType == hmSetting.screen_type.AOD && idle_background_bg) idle_background_bg.setProperty(hmUI.prop.COLOR, bgColorList[bgColorIndex]);
                onDigitalCrown();
                console.log('resume_call.js');
                // start resume_call.js

 loadSettings();
 time_update2(true, true);
 //  if (screenType2 == hmSetting.screen_type.WATCHFACE) {
 if (!normal_timerTimeUpdate2) {
  normal_timerTimeUpdate2 = timer.createTimer(0, 1000, (function (option) {
   let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
   let updateMinute = timeSensor.second < 2;
   time_update2(updateHour, updateMinute);
  })); // end timer 
 }; // end timer check
 // };  // end screenType             

 update_weather();

                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');

                hmApp.unregisterSpinEvent();
                console.log('pause_call.js');
                // start pause_call.js

if (normal_timerTimeUpdate2) {
 timer.stopTimer(normal_timerTimeUpdate2);
 normal_timerTimeUpdate2 = undefined;
}

                // end pause_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}