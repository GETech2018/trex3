﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_alarm_clock_current_text_font = ''
        let normal_altimeter_current_text_font = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_digital_clock_img_time = ''
        let normal_image_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_icon_img = ''
        let normal_battery_current_text_font = ''
        let idle_background_bg = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_image_img = ''
        let idle_battery_current_text_font = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_readiness_jumpable_img_click = ''

        // Pressure file unified path
        const PRESSURE_FILE_PATH = "../../../baro_altim/pressure.dat";
        let lastPressureFileTime = 0;
        let lastPressureText = null;
        let lastPressureUpdateMs = 0; 
        const PRESSURE_THROTTLE_MS = 10 * 60 * 1000; // 10 minutes
        let text_pressure = null;        
            // --------------------
            // Pressure read/update 
            // --------------------
            function read_pressure() {
                try {
                    const [fs_stat, err] = hmFS.stat(PRESSURE_FILE_PATH);
                    if (err !== 0) return null;
                    const len = fs_stat.size / 4;
                    const fh = hmFS.open(PRESSURE_FILE_PATH, hmFS.O_RDONLY);
                    const array_buffer = new Float32Array(len);
                    hmFS.read(fh, array_buffer.buffer, 0, fs_stat.size);
                    hmFS.close(fh);
                    return array_buffer;
                } catch (e) { return null; }
            }
            function getPressureValue(pressure_array) {
                if (!pressure_array || pressure_array.length === 0) return 0;
                let start_index = pressure_array.length - 1;
                let end_index = start_index - 30*3;
                if (end_index < 0) end_index = 0;
                for (let index = start_index; index >= end_index; index--) {
                    if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
                }
                return 0;
            }
            function hPa_To_mmHg(hPa_value = 0) {
                return Math.round(hPa_value * 0.750064);
            }
            function updatePressure(force = false) {
                try {
                    const now = Date.now();
                    if (!force && (now - lastPressureUpdateMs) < PRESSURE_THROTTLE_MS) return;
                    const [stat, err] = hmFS.stat(PRESSURE_FILE_PATH);
                    if (err !== 0 || !stat) {
                        if (lastPressureText !== "--") {
                            try { text_pressure.setProperty(hmUI.prop.TEXT, "--"); } catch(e){}
                            lastPressureText = "--";
                        }
                        lastPressureUpdateMs = now;
                        return;
                    }
                    if (stat.mtime === lastPressureFileTime && !force) {
                        lastPressureUpdateMs = now;
                        return;
                    }
                    const arr = read_pressure();
                    if (!arr || arr.length === 0) {
                        if (lastPressureText !== "--") {
                            try { text_pressure.setProperty(hmUI.prop.TEXT, "--"); } catch(e){}
                            lastPressureText = "--";
                        }
                        lastPressureFileTime = stat.mtime;
                        lastPressureUpdateMs = now;
                        return;
                    }
                    const hPa = getPressureValue(arr);
                    const mmHg = hPa === 0 ? "--" : (hPa_To_mmHg(hPa) + "  ");
                    if (mmHg !== lastPressureText) {
                        try { text_pressure.setProperty(hmUI.prop.TEXT, mmHg); } catch(e){}
                        lastPressureText = mmHg;
                    }
                    lastPressureFileTime = stat.mtime;
                    lastPressureUpdateMs = now;
                } catch (e) {
                    if (lastPressureText !== "--") {
                        try { text_pressure.setProperty(hmUI.prop.TEXT, "--"); } catch(e){}
                        lastPressureText = "--";
                    }
                    lastPressureUpdateMs = Date.now();
                }
            }
        //dynamic modify end

        // Добавляем переменные для новых виджетов и таймера
        let ms_dot_img = null;
        let ms_tens_img = null;
        let ms_units_img = null;
        let ms_timer = null;
        const second_array = ["S_0.png","S_1.png","S_2.png","S_3.png","S_4.png","S_5.png","S_6.png","S_7.png","S_8.png","S_9.png"];
        let lastTens = -1;
        let lastUnits = -1;

        function updateCentiseconds() {
            const now = Date.now();
            const ms = now % 1000;
            const cs = Math.floor(ms / 10);
            const tens = Math.floor(cs / 10);
            const units = cs % 10;            
            if (tens !== lastTens) {
                if (ms_tens_img) {
                    ms_tens_img.setProperty(hmUI.prop.SRC, second_array[tens]);
                }
                lastTens = tens;
            }            
            if (units !== lastUnits) {
                if (ms_units_img) {
                    ms_units_img.setProperty(hmUI.prop.SRC, second_array[units]);
                }
                lastUnits = units;
            }
        }        

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: handelsonsix_cyr_six.ttf; FontSize: 42
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 488,
              h: 52,
              text_size: 42,
              char_space: 0,
              line_space: 0,
              font: 'fonts/handelsonsix_cyr_six.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: handelsonsix_cyr_six.ttf; FontSize: 45
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 530,
              h: 56,
              text_size: 45,
              char_space: 0,
              line_space: 0,
              font: 'fonts/handelsonsix_cyr_six.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: handelsonsix_cyr_six.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 362,
              h: 38,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/handelsonsix_cyr_six.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 347,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 101,
              y: 347,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 200,
              y: 96,
              week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 90,
              day_startY: 101,
              day_sc_array: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png"],
              day_tc_array: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png"],
              day_en_array: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 183,
              y: 390,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 141,
              y: 394,
              w: 200,
              h: 80,
              text_size: 42,
              char_space: 0,
              font: 'fonts/handelsonsix_cyr_six.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              padding: true,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            text_pressure = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 282,
              y: 55,
              w: 150,
              h: 50,
              text_size: 45,
              char_space: 0,
              font: 'fonts/handelsonsix_cyr_six.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              text: "--",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            updatePressure();

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 195,
              y: 10,
              src: 'pogoda.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 219,
              y: 46,
              image_array: ["A_0055.png","A_0056.png","A_0057.png","A_0058.png","A_0059.png","A_0060.png","A_0061.png","A_0062.png","A_0063.png","A_0064.png","A_0065.png","A_0066.png","A_0067.png","A_0068.png","A_0069.png","A_0070.png","A_0071.png","A_0072.png","A_0073.png","A_0074.png","A_0075.png","A_0076.png","A_0077.png","A_0078.png","A_0079.png","A_0080.png","A_0081.png","A_0082.png","A_0083.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 102,
              y: 55,
              w: 100,
              h: 50,
              text_size: 45,
              char_space: 0,
              font: 'fonts/handelsonsix_cyr_six.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 43,
              hour_startY: 186,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 296,
              minute_startY: 189,
              minute_array: ["M_0.png","M_1.png","M_2.png","M_3.png","M_4.png","M_5.png","M_6.png","M_7.png","M_8.png","M_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 265,
              second_startY: 288,
              second_array: ["S_0.png","S_1.png","S_2.png","S_3.png","S_4.png","S_5.png","S_6.png","S_7.png","S_8.png","S_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            ms_dot_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 265 + 76,  
              y: 288, 
              src: 'S_tchk.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            ms_tens_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: ms_dot_img.x + 15,  
              y: 288,
              src: 'S_0.png',  
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            
            ms_units_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: ms_tens_img.x + 40, 
              y: 288,
              src: 'S_0.png', 
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -172,
              // end_angle: 174,
              // radius: 225,
              // line_width: 9,
              // line_cap: Flat,
              // color: 0xFF909090,
              // mirror: False,
              // inversion: False,
              // alpha: 210,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -172,
              end_angle: 174,
              radius: 221,
              line_width: 9,
              corner_flag: 3,
              color: 0xFF909090,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale.setAlpha(210);
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zar.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 192,
              y: 444,
              w: 100,
              h: 50,
              text_size: 30,
              char_space: 0,
              font: 'fonts/handelsonsix_cyr_six.ttf',
              color: 0xFF000000,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 200,
              y: 96,
              week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 90,
              day_startY: 101,
              day_sc_array: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png"],
              day_tc_array: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png"],
              day_en_array: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png","D_7.png","D_8.png","D_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 43,
              hour_startY: 186,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 296,
              minute_startY: 189,
              minute_array: ["M_0.png","M_1.png","M_2.png","M_3.png","M_4.png","M_5.png","M_6.png","M_7.png","M_8.png","M_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 242,
              y: 187,
              src: 'M_dv.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 191,
              y: 444,
              w: 100,
              h: 50,
              text_size: 34,
              char_space: 0,
              font: 'fonts/handelsonsix_cyr_six.ttf',
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 123,
              y: 347,
              w: 100,
              h: 41,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 281,
              y: 347,
              w: 72,
              h: 41,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 206,
              y: 443,
              w: 65,
              h: 36,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 134,
              y: 48,
              w: 64,
              h: 53,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 322,
              y: 204,
              w: 74,
              h: 68,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 269,
              y: 289,
              w: 68,
              h: 49,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 395,
              w: 100,
              h: 45,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 80,
              y: 228,
              w: 63,
              h: 72,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 174,
              y: 228,
              w: 62,
              h: 71,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -172,
                      end_angle: 174,
                      radius: 221,
                      line_width: 9,
                      corner_flag: 3,
                      color: 0xFF909090,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            if (hmSetting.getScreenType() === hmSetting.screen_type.WATCHFACE) {
              ms_timer = timer.createTimer(0, 10, updateCentiseconds);
              updateCentiseconds(); 
            }            

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                updatePressure();
                console.log('resume_call()');
                scale_call();
                if (!ms_timer && hmSetting.getScreenType() === hmSetting.screen_type.WATCHFACE) {
                  ms_timer = timer.createTimer(0, 10, updateCentiseconds);
                  updateCentiseconds();
                }                
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (ms_timer) {
                  timer.stopTimer(ms_timer);
                  ms_timer = null;
                }
              }),              
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
              try {                    
                  lastPressureFileTime = 0;
                  lastPressureText = null;
                  if (ms_timer) {
                    timer.stopTimer(ms_timer);
                    ms_timer = null;
                  }
              } catch (e) {}               
              logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}