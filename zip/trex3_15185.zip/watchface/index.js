/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let chronoInterval;
		let chronoIsRunning = false;
		let chronoStart = 0;
		let chronoStoppedAt = 0;
		let normal_chrono_hours_rotary = '';
		let normal_chrono_hours_rotary_start_angle = 0;
		let normal_chrono_hours_rotary_end_angle = 360;
		let normal_chrono_minutes_rotary = '';
		let normal_chrono_minutes_rotary_start_angle = 0;
		let normal_chrono_minutes_rotary_end_angle = 360;
		let normal_chrono_seconds_rotary = '';
		let normal_chrono_seconds_rotary_start_angle = 0;
		let normal_chrono_seconds_rotary_end_angle = 360;
		let normal_hour_rotary3 = '';
		let timeInterval;
		let normal_minute_rotary4 = '';
		let normal_second_rotary5 = '';
		let idle_img8 = '';
		let idle_chrono_hours_rotary = '';
		let idle_chrono_hours_rotary_start_angle = 0;
		let idle_chrono_hours_rotary_end_angle = 360;
		let idle_chrono_minutes_rotary = '';
		let idle_chrono_minutes_rotary_start_angle = 0;
		let idle_chrono_minutes_rotary_end_angle = 360;
		let idle_chrono_seconds_rotary = '';
		let idle_chrono_seconds_rotary_start_angle = 0;
		let idle_chrono_seconds_rotary_end_angle = 360;
		let idle_hour_rotary11 = '';
		let idle_minute_rotary12 = '';
		let idle_second_rotary13 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				const vibrateSensor = hmSensor.createSensor(hmSensor.id.VIBRATE);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_chrono_hours_rotary = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 123,
					center_y: 227,
					pos_x: 107,
					pos_y: 164,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_chrono_minutes_rotary = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 357,
					center_y: 226,
					pos_x: 341,
					pos_y: 164,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_chrono_seconds_rotary = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 361,
					pos_x: 224,
					pos_y: 298,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_rotary3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 221,
					pos_y: 106,
					src: '0004.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_rotary4 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 241,
					pos_x: 225,
					pos_y: 43,
					src: '0005.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_rotary5 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 228,
					pos_y: 39,
					src: '0006.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0007.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_chrono_hours_rotary = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 123,
					center_y: 227,
					pos_x: 107,
					pos_y: 164,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_chrono_minutes_rotary = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 357,
					center_y: 226,
					pos_x: 341,
					pos_y: 164,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_chrono_seconds_rotary = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 361,
					pos_x: 224,
					pos_y: 298,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_rotary11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 221,
					pos_y: 106,
					src: '0004.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_rotary12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 241,
					pos_x: 225,
					pos_y: 43,
					src: '0005.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_second_rotary13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					center_x: 240,
					center_y: 240,
					pos_x: 228,
					pos_y: 39,
					src: '0006.png',
					enable: false,
					angle: 0,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateChrono() {
					let curTime = timeSensor.utc;
					let curDiff = curTime-chronoStart;
					let curMilli = curDiff.toString().substr(curDiff.toString().length - 3).padStart(3, '0');
					let curSeconds = (new Date(curDiff)).getSeconds().toString().padStart(2, '0');
					let curMinutes = (new Date(curDiff)).getMinutes().toString().padStart(2, '0');
					let curHours = (new Date(curDiff)).getUTCHours().toString().padStart(2, '0');
					if (typeof normal_chrono_hours != 'undefined' && normal_chrono_hours.length > 0) {
						for (let i=0; i < normal_chrono_hours.length; i++) {
							normal_chrono_hours[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_hours_array[curHours.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_minutes != 'undefined' && normal_chrono_minutes.length > 0) {
						for (let i=0; i < normal_chrono_minutes.length; i++) {
							normal_chrono_minutes[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_minutes_array[curMinutes.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_seconds != 'undefined' && normal_chrono_seconds.length > 0) {
						for (let i=0; i < normal_chrono_seconds.length; i++) {
							normal_chrono_seconds[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_seconds_array[curSeconds.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_milliseconds != 'undefined' && normal_chrono_milliseconds.length > 0) {
						for (let i=0; i < normal_chrono_milliseconds.length; i++) {
							normal_chrono_milliseconds[i].setProperty(hmUI.prop.MORE, {
								src: normal_chrono_milliseconds_array[curMilli.charAt(i)]
							})
						}
					}

					if (typeof normal_chrono_hours_rotary != 'undefined') {
						let hsa = normal_chrono_hours_rotary_start_angle;
						let hea = normal_chrono_hours_rotary_end_angle;
						let hcw = hea > hsa;
						let hd = hcw ? hea - hsa : hsa - hea;
						let hfac = hd / 360;
						normal_chrono_hours_rotary.setProperty(hmUI.prop.MORE, {
							angle: (hcw ? (hsa + (parseInt(curHours) * (6 * hfac))) : (hsa - (parseInt(curHours) * (6 * hfac))))
						})
					}

					if (typeof normal_chrono_minutes_rotary != 'undefined') {
						let msa = normal_chrono_minutes_rotary_start_angle;
						let mea = normal_chrono_minutes_rotary_end_angle;
						let mcw = mea > msa;
						let md = mcw ? mea - msa : msa - mea;
						let mfac = md / 360;
						normal_chrono_minutes_rotary.setProperty(hmUI.prop.MORE, {
							angle: (mcw ? (msa + (parseInt(curMinutes) * (6 * mfac))) : (msa - (parseInt(curMinutes) * (6 * mfac))))
						})
					}

					if (typeof normal_chrono_seconds_rotary != 'undefined') {
						let ssa = normal_chrono_seconds_rotary_start_angle;
						let sea = normal_chrono_seconds_rotary_end_angle;
						let scw = sea > ssa;
						let sd = scw ? sea - ssa : ssa - sea;
						let sfac = sd / 360;
						normal_chrono_seconds_rotary.setProperty(hmUI.prop.MORE, {
							angle: (scw ? (ssa + ((parseInt(curSeconds) + (parseInt(curMilli) / 1000)) * (6 * sfac))) : (ssa - ((parseInt(curSeconds) + (parseInt(curMilli) / 1000)) * (6 * sfac))))
						})
					}

				}

				function updateTime() {
					if (normal_hour_rotary3) {
						normal_hour_rotary3.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (normal_minute_rotary4) {
						normal_minute_rotary4.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
					if (normal_second_rotary5) {
						normal_second_rotary5.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.second * (6 * 1))));
					}
					if (idle_hour_rotary11) {
						idle_hour_rotary11.setProperty(hmUI.prop.ANGLE, (0 + parseInt((timeSensor.hour % 12) || 12) * (30 * 1) + (timeSensor.minute / 60) * (30 * 1)));
					}
					if (idle_minute_rotary12) {
						idle_minute_rotary12.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.minute * (6 * 1))));
					}
					if (idle_second_rotary13) {
						idle_second_rotary13.setProperty(hmUI.prop.ANGLE, (0 + (timeSensor.second * (6 * 1))));
					}
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						if (chronoIsRunning) {
							chronoInterval = setInterval(updateChrono, 50);
						}
						updateTime();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						clearInterval(timeInterval);
						clearInterval(chronoInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}