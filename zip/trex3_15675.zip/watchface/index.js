﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
     (() => {
      const __$$app$$__ = __$$hmAppManager$$__.currentApp;
      function getApp() {
          return __$$app$$__.app;
      }
      function getCurrentPage() {
          return __$$app$$__.current && __$$app$$__.current.module;
      }
      const __$$module$$__ = __$$app$$__.current;
      const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
      const {px} = __$$app$$__.__globals__;
            
    
      const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT} = hmSetting.getDeviceInfo();
    const radius = DEVICE_WIDTH / 2, centerX = DEVICE_WIDTH / 2, centerY = DEVICE_HEIGHT / 2
    
    const curTime = hmSensor.createSensor(hmSensor.id.TIME);
    const weather = hmSensor.createSensor(hmSensor.id.WEATHER);
    
    let weatherImg, tempText, cityNameText, tempMinText, tempMaxText, tempFeelsText, descriptionText
    let weatherProvider
  
        //------------- вибро ------------------
        const vibrator = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let stopVibro_Timer = null;
  
      function vibro(mode = 25, stopDelay = 30) {
          vibrator.stop();
          vibrator.scene = mode;
          vibrator.start();
          stopVibro_Timer = setTimeout(() => {
            stopVibro();
          }, stopDelay);
      }	
      function stopVibro(){
        vibrator.stop();
        if (stopVibro_Timer) clearTimeout(stopVibro_Timer);
      }
      /********  класс Провайдер погоды  ********/
      /******				v1.4			*******/
      /******		2025 © leXxiR [4pda]	*******/
      class WeatherProvider {
        constructor(props = {}) {
          this.props = {
            night_icons: [],											
            index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,		
            show_toast: true,											
            temp_widget: null,											
            temp_max_widget: null,										
            temp_min_widget: null,										
            temp_feels_widget: null,									
            description_widget: null,									
            cityName_widget: null,										
            icon_widget: null,											
            time_sensor: null,											
            weather_sensor: null,										
            file_name: 'weather.json',									
            auto_update: true,											
            lang: hmSetting.getLanguage() == 4 ? 0 : 1,					
            ...props,
          };

          this.providers = [
                  {name: ['Zepp', 'Zepp'], appId: null},							
                  {name: ['Погодный сервис', 'Weather service'], appId: 1065824},	
                  //{name: ['RuWeather', 'RWeather'], appId: 1066654},				
                ]

          this.description = [
              ['Облачно', 'Временами дождь', 'Временами снег', 'Ясно', 'Пасмурно', 'Слабый дождь', 'Слабый снег', 'Умеренный дождь', 'Умеренный снег', 'Сильный снегопад', 'Сильный дождь', 'Песчаная буря', 'Мокрый снег', 'Туман', 'Дымка', 'Дождь с грозой', 'Метель', 'Пыльно', 'Ливень', 'Дождь с градом', 'Сильный дождь с градом', 'Сильный дождь', 'Пыльная буря', 'Сильная песчаная буря', 'Сильный дождь', 'Обновите погоду', 'Облачно ночью', 'Дождливо ночью', 'Ясно ночью'],
              ['Cloudy', 'Showers', 'Snow Showers', 'Sunny', 'Overcast', 'Light Rain', 'Light Snow', 'Moderate Rain', 'Moderate Snow', 'Heavy Snow', 'Heavy Rain', 'Sandstorm', 'Rain and Snow', 'Fog', 'Hazy', 'T-Storms', 'Snowstorm', 'Floating dust', 'Very Heavy Rainstorm', 'Rain and Hail', 'T-Storms and Hail', 'Heavy Rainstorm', 'Dust', 'Heavy sand storm', 'Rainstorm', 'Unknown', 'Cloudy Nighttime', 'Showers Nighttime', 'Sunny Nighttime'],
            ]

          this.last = {
            weatherIcon: 25,
            weatherDescription:  'Нет данных',
            temperature: '--',
            temperatureFeels: '--',
            temperatureMax: '--',
            temperatureMin: '--',
            cityName: '--',
            modTime: null,
          }

          if (!this.props.time_sensor) this.props.time_sensor = hmSensor.createSensor(hmSensor.id.TIME);
          if (!this.props.weather_sensor) this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
          if (isFinite(props.index)) hmFS.SysProSetInt('WeatherProviderIndex', props.index);
          if (this.props.auto_update) this.createHandlers();
        }      
        // создание обработчиков автоматического обновления погоды
        createHandlers() {
          this.props.time_sensor.addEventListener(this.props.time_sensor.event.MINUTEEND, () => this.update());

          this.widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
            resume_call: ( () => this.update() )
          })
        }
        // служебные функции
        arrayBufferToCyrillic(buffer) {
          let result = '';
          const bytes = new Uint8Array(buffer);

          let i = 0;
          while (i < bytes.length) {
              let byte1 = bytes[i++];
          
              if (byte1 < 0x80) {								// Обработка 1-байтовых символов (ASCII)
                result += String.fromCharCode(byte1);
              } else if (byte1 >= 0xC0 && byte1 < 0xE0) {		// Обработка 2-байтовых символов (UTF-8 кодировка для кириллицы)
                let byte2 = bytes[i++];
                let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
                result += String.fromCharCode(charCode);
              } else if (byte1 >= 0xE0 && byte1 < 0xF0) {		// Обработка 3-байтовых символов (например, для UTF-8)
                let byte2 = bytes[i++];
                let byte3 = bytes[i++];
                let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
                result += String.fromCharCode(charCode);
              }
          }

          return result
        }  
        // чтение погодных данных из файла
        readFile(app_id) {
          if (!app_id) return null				
          let str_result = "";
          try {
              const [fs_stat, err] = hmFS.stat(this.props.file_name, {
                  appid: app_id,
              });
              if (err == 0) {
                  const fh = hmFS.open(this.props.file_name, hmFS.O_RDONLY, {
                  appid: app_id,
                  });

                  const len = fs_stat.size;
                  let array_buffer = new ArrayBuffer(len);
                  hmFS.read(fh, array_buffer, 0, len);
                  hmFS.close(fh);
                  str_result = this.arrayBufferToCyrillic(array_buffer);

                  return str_result;
              } else {
                  console.log("err:", err);
              }
          } catch (error) {
          console.log("error:", error);
          console.log("FAIL: No access to hmFS.");
          }
          return null;
        } 
        // получить время последнего изменеия файла
        getFileModTime(app_id) {
          if (!app_id) return null
          try {
              const [fs_stat, err] = hmFS.stat(this.props.file_name, {
                  appid: app_id,
              });
          
              if (err == 0) {
                  return fs_stat.mtime
              } else {
                  console.log("ModTime err:", err);
              }
          } catch (error) {
            console.log("ModTime error:", error);
            console.log("FAIL: No access to hmFS.");
          }
            return null
        }  
        // проверка времени суток: возвращает true, если сейчас день
        isDayNow() {
          const sunData = this.props.weather_sensor.getForecastWeather().tideData;
          let sunriseMins = 8 * 60;			// время восхода
          let sunsetMins = 20 * 60;			// и заката по умолчанию

          if (sunData.count > 0){
              const today = sunData.data[0];
              sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
              sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
          }

          const curMins = curTime.hour * 60 + curTime.minute;
          const nowIsDay = (curMins >= sunriseMins) && (curMins < sunsetMins);

          return nowIsDay
        } 
        // сопоставление индекса иконки погоды из приложений WeatherService и RuWeather с иконками погоды от Zepp 
        getZeppIconIndex(index, app_id = null) {
                          
          if (!app_id)  return index;			//	если нет app_id, то не меняем индекс иконки

          let newIndex = 25;
          
          if (app_id == 1065824) {					// WeatherService
              switch(index) {
              case 1:
                      newIndex = 3;
                  break;
              case 2:
                      newIndex = 0;
                  break;
              case 3:
              case 4:
                      newIndex = 4;
                  break;
              case 5:
                      newIndex = 1;
                  break;
              case 6:
                      newIndex = 5;
                  break;
              case 7:
                      newIndex = 10;
                  break;
              case 8:
                      newIndex = 15;
                  break;
              case 9:
                      newIndex = 6;
                  break;
              case 10:
                      newIndex = 8;
                  break;
              case 11:
                      newIndex = 9;
                  break;
              case 12:
                      newIndex = 12;
                  break;
              case 13:
                      newIndex = 13;
                  break;
              case 14:
                      newIndex = 17;
                  break;
              default:
                      newIndex = 25;
                  break;
              }
          } else if (app_id == 1066654) {					// 
              newIndex = index - 1;
          }

          return newIndex
        }  
        // температура со знаком
        tempWithSign(val){
          val = parseFloat(val);
          if (!isFinite(val)) return '--'		// если на входе не число - возвращаем прочерки
          val = Math.round(val);
          if (val > 0) val = '+' + val;
          val += '°';
          
          return val
        }    
        //получение погодных данных из Zepp
        getZeppWeatherData() {
          const iconIndex = this.props.weather_sensor.curAirIconIndex ?? 25;
          const data = {
              weatherIcon: iconIndex,
              weatherDescription:  this.description[this.props.lang][iconIndex],
              temperature: this.props.weather_sensor.current ?? '--',
              temperatureFeels: '--',
              temperatureMax: this.props.weather_sensor.high ?? '--',
              temperatureMin: this.props.weather_sensor.low ?? '--',
              cityName: this.props.weather_sensor.getForecastWeather().cityName ?? '--',
          }

          return data
        }  
        //получение погодных данных из файла приложения
        getAppWeatherData(app_id) {
          const data = {
              weatherIcon: 25,
              weatherDescription:  'Нет данных',
              temperature: '--',
              temperatureFeels: '--',
              temperatureMax: '--',
              temperatureMin: '--',
              cityName: '--',
          }  
          // читаем данные из файла данных приложения
          let weather_str = this.readFile(app_id);
          let weatherJson = JSON.parse(weather_str);          
          if (weatherJson) {
            if (isFinite(weatherJson.weatherIcon)) {		// считываем индекс иконки погоды и сразу переводим в нумерацию Zepp
                data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon), app_id);
            }

            if (weatherJson?.weatherDescriptionExtended?.length) {
                data.weatherDescription = weatherJson.weatherDescriptionExtended;
                data.weatherDescription = data.weatherDescription.replace(data.weatherDescription[0], data.weatherDescription[0].toUpperCase());
            } else data.weatherDescription = this.description[data.weatherIcon];

            if (isFinite(weatherJson.temperature)) {
                data.temperature = parseFloat(weatherJson.temperature);
                data.temperature = Math.round(data.temperature);
            }
            
            if (isFinite(weatherJson.temperatureFeels)){
                data.temperatureFeels = parseFloat(weatherJson.temperatureFeels);
                data.temperatureFeels = Math.round(data.temperatureFeels);
            }
                
            if (isFinite(weatherJson.temperatureMax)){
                data.temperatureMax = parseFloat(weatherJson.temperatureMax);
                data.temperatureMax = Math.round(data.temperatureMax);
            }
                
            if (isFinite(weatherJson.temperatureMin)){
                data.temperatureMin = parseFloat(weatherJson.temperatureMin);
                data.temperatureMin = Math.round(data.temperatureMin);
            }
            
            if (weatherJson.city) {
                data.cityName = weatherJson.city;
            }
          }
        
         return data
        }     
        //получение погодных данных из файла приложения или Zepp
        getWeatherData(app_id = null) {
          if (!app_id) return this.getZeppWeatherData()		// если нет app_id, то получаем данные от Zepp
          else return this.getAppWeatherData(app_id);			// иначе читаем данные из файла данных приложения
        } 
        // обновить виджеты, используя данные текущего провайдера
        update() {
          let curIcon = parseInt(this.last.weatherIcon);				// текущий индекс значка погоды без учета времени суток (т.е. число без "n")

          const modTime = this.getFileModTime(this.providers[this.props.index].appId);		// время изменеия файла с данными
          
          if (!modTime || this.last.modTime != modTime){										// если не получено время изменеия или оно отличается от последнего времени изменеия
              const newData = this.getWeatherData(this.providers[this.props.index].appId);	// тогда читаем новые данные из файла
              this.last.modTime = modTime;

              let val = this.tempWithSign(newData.temperature);
              if (val != this.last.temperature){
                  this.last.temperature = val;
                  if (this.props.temp_widget) this.props.temp_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = this.tempWithSign(newData.temperatureMax);
              if (val != this.last.temperatureMax){
                  this.last.temperatureMax = val;
                  if (this.props.temp_max_widget) this.props.temp_max_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = this.tempWithSign(newData.temperatureMin);
              if (val != this.last.temperatureMin){
                  this.last.temperatureMin = val;
                  if (this.props.temp_min_widget) this.props.temp_min_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = this.tempWithSign(newData.temperatureFeels);
              if (val != this.last.temperatureFeels){
                  this.last.temperatureFeels = val;
                  if (this.props.temp_feels_widget) this.props.temp_feels_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = newData.cityName;
              if (val != this.last.cityName){
                  this.last.cityName = val;
                  if (this.props.cityName_widget) this.props.cityName_widget.setProperty(hmUI.prop.TEXT, val);
              }

              val = newData.weatherDescription;
              if (val != this.last.weatherDescription){
                  this.last.weatherDescription = val;
                  if (this.props.description_widget) this.props.description_widget.setProperty(hmUI.prop.TEXT, val);
              }

              
              curIcon = newData.weatherIcon;						// получаем текущий индекс значка погоды
          }

          if (this.props.night_icons.includes(curIcon) && !this.isDayNow()){		// если он в списке ночных иконок и сейчас "ночь", то добавляем суффикс 'n'
              curIcon += 'n';
          }

          if (curIcon != this.last.weatherIcon){
              this.last.weatherIcon = curIcon;
              if (this.props.icon_widget) this.props.icon_widget.setProperty(hmUI.prop.SRC, `w_${curIcon}.png`);
          }
        }  
        // переключить на следующего провайдера
        next(show_toast = this.props.show_toast) {
          const v = (this.props.index + 1) % this.providers.length;
          this.provider = v;
          if (show_toast) hmUI.showToast({text: this.name});
        }    
        // переключить на предыдующего провайдера
        prev(show_toast = this.props.show_toast) {
          const v = (this.props.index - 1 + this.providers.length) % this.providers.length;
          this.provider = v;
          if (show_toast) hmUI.showToast({text: this.name});
        }    
        // переключить назад или вперед
        toggle(dir, show_toast = this.props.show_toast) {
          if (dir > 0) this.next(show_toast)
          else this.prev(show_toast);
        }  
        // установить провайдера по индексу
        set provider(v) {
          this.props.index = v;
          hmFS.SysProSetInt('WeatherProviderIndex', v);
          this.update();
        }  
        // получить индекс текущего провайдера
        get index() {
          return this.props.index
        }  
        // получить название текущего провайдера
        get name() {
          return this.providers[this.props.index].name[this.props.lang]
        }   
        // получить название города
        get cityName() {
          return this.last.cityName
        }  
        // получить текущую температуру
        get temperature() {
          return this.last.temperature
        }    
        // получить максимальную температуру
        get temperatureMax() {
          return this.last.temperatureMax
        } 
        // получить минимальную температуру
        get temperatureMin() {
          return this.last.temperatureMin
        }   
        // получить описание погоды
        get weatherDescription() {
          return this.last.weatherDescription
        } 
       // удалить
       delete() {
        this.providers = null;
        this.props = null;
        this.last = null;
        this.description = null;
        if (this.widgetDelegate) {
            hmUI.deleteWidget(this.widgetDelegate);
            this.widgetDelegate = null;
        }
       }

      }     
      // start user_functions.js
const {
  width: D_W,
  height: D_H
} = hmSetting.getDeviceInfo();                                                                                                                                                                                                         

        //end of ignored block
        let element_index = 1;  // Selected element index
        let element_count = 2;  // Number of elements
        //dynamic modify start
        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 32;
        let normal_heart_rate_TextCircle_img_height = 32;
        let normal_heart_rate_TextCircle_error_img_width = 40;
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 32;
        let normal_step_TextCircle_img_height = 32;
        let normal_step_TextCircle_error_img_width = 40;
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_day_TextCircle = new Array(2);
        let normal_day_TextCircle_ASCIIARRAY = new Array(10);
        let normal_day_TextCircle_img_width = 32;
        let normal_day_TextCircle_img_height = 32;
        let normal_day_TextCircle_error_img_width = 40;
        let normal_timerTextUpdate = undefined;
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_current_text_font = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 32;
        let normal_battery_TextCircle_img_height = 32;
        let normal_battery_TextCircle_unit = null;
        let normal_battery_TextCircle_unit_width = 40;
        let normal_battery_TextCircle_error_img_width = 40;
        let normal_digital_clock_img_time = ''
        let normal_uvi_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_uvi_icon_img = ''
        let idle_temperature_current_text_font = ''
        let idle_digital_clock_img_time = ''
        let idle_battery_current_text_font = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''        
        let timeSensor = ''

        //let curTime = hmSensor.createSensor(hmSensor.id.TIME);
        let second_circle, scale_timer   
        
        function startSecPointerAnim() {
          if (scale_timer) timer.stopTimer(scale_timer);
          scale_timer = timer.createTimer(0, 250, (function (option) {
            updateSeconds();
          }));
            }
    
            function stopSecPointerAnim() {
          if (scale_timer) {
                  timer.stopTimer(scale_timer);
                  scale_timer = undefined;
                }
          }
          
          function updateSeconds() {
            
            let level = Math.round(curTime.second / 60 * 100);
                        
            if (second_circle) 
            second_circle.setProperty(hmUI.prop.MORE, {                      
              center_x: 240,
              center_y: 240,
              start_angle: 0,
              end_angle: 361,
              radius: 110,
              line_width: 33,
              corner_flag: 3,
              color: 0x444444,
              level: level,
            });
          }               


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: GoogleSans-Regular.ttf; FontSize: 20
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 273,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: GoogleSans-Regular.ttf; FontSize: 24
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 333,
              h: 37,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFB99A3E,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Bowler.ttf; FontSize: 20
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 348,
              h: 24,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bowler.ttf',
              color: 0xFFB99A3E,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });    
            
            // FontName: Bowler.ttf; FontSize: 17; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 24,
              h: 21,
              text_size: 17,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bowler.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });                

            // FontName: Bowler.ttf; FontSize: 20; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 24,
              h: 24,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Bowler.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            console.log('user_script_start.js');
            // start user_script_start.js

            let sleep_time_txt = ''
            let sleep_start_time_txt = ''
            let sleep_end_time_txt = ''
            let sleep_score_txt = ''
            let wake_time_txt = ''

            const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
            let sleepInfo = sleep.getBasicInfo();
            
            let sleepTotalTime = sleep.getTotalTime();		
            let sleepStartTime = sleepInfo.startTime;
            let sleepEndTime = sleepInfo.endTime + 1;
            let sleepScore = sleepInfo.score;

        //время пробуждений	
            let sleepStageArray = sleep.getSleepStageData();
            const modelData = sleep.getSleepStageModel();
        //		

            function updateSleepInfo() {
                sleepTotalTime = sleep.getTotalTime();
                sleepInfo = sleep.getBasicInfo();
                sleepStartTime = sleepInfo.startTime;
                if (sleepStartTime >= 24*60) {
                    sleepStartTime -= 24*60
                }
                
                sleepEndTime = sleepInfo.endTime + 1;
                if (sleepEndTime >= 24*60) {
                    sleepEndTime -= 24*60
                }

            // время пробуждений
                let wakeTime = 0;
                sleepStageArray = sleep.getSleepStageData();
                
                for (let i = 0; i < sleepStageArray.length; i++) {
                let data = sleepStageArray[i];
                if (data.model == modelData.WAKE_STAGE){
                        wakeTime += data.stop + 1 - data.start;
                }

                }
                
                sleepTotalTime -= wakeTime;
           //
                
                sleep_time_txt.setProperty(hmUI.prop.TEXT, ' ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
                sleep_start_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepStartTime / 60).toString().padStart(2, "0") + ':' + (sleepStartTime % 60).toString().padStart(2, "0"));
                sleep_end_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepEndTime / 60).toString().padStart(2, "0") + ':' + (sleepEndTime % 60).toString().padStart(2, "0"));
                wake_time_txt.setProperty(hmUI.prop.TEXT, 'Не спали: ' + String(wakeTime) + ' мин.');
                sleep_score_txt.setProperty(hmUI.prop.TEXT, ' ' + String(sleepScore));
            }
            // end user_script_start.js

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //
            second_circle = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240, 
              center_y: 240,
              start_angle: 0,
              end_angle: 361,
              radius: 110,
              line_width: 33, 
              corner_flag: 3,
              color: 0x444444,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });    
            if (hmSetting.getScreenType() == hmSetting.screen_type.WATCHFACE) {
              updateSeconds();
            } else {
              second_circle.setProperty(hmUI.prop.MORE, {color: 0x000000});
            }  
            //
            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
            sleep_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 163,
              y: 309,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: "fonts/GoogleSans-Regular.ttf",
              text: '',
              color: 0xFFB99A3E,
              align_h: hmUI.align.CENTER_H,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //

  

            // end user_script.js

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              // radius: 218,
              // angle: 141,
              // char_space_angle: 0,
              // error_image: 'data_vp.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'data_0.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'data_1.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'data_2.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'data_3.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'data_4.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'data_5.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'data_6.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'data_7.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'data_8.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'data_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 + 186,
                src: 'data_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              // radius: 218,
              // angle: 180,
              // char_space_angle: 0,
              // error_image: 'data_vp.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 'data_0.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 'data_1.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 'data_2.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 'data_3.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 'data_4.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 'data_5.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 'data_6.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 'data_7.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 'data_8.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 'data_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_step_TextCircle_img_width / 2,
                pos_y: 240 + 186,
                src: 'data_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 0,
              month_startY: 0,
              month_sc_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_tc_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_en_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_day_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              // radius: 220,
              // angle: 0,
              // char_space_angle: 0,
              // error_image: 'data_vp.png',
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: TOP,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.DAY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_day_TextCircle_ASCIIARRAY[0] = 'data_0.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[1] = 'data_1.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[2] = 'data_2.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[3] = 'data_3.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[4] = 'data_4.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[5] = 'data_5.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[6] = 'data_6.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[7] = 'data_7.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[8] = 'data_8.png';  // set of images with numbers
            normal_day_TextCircle_ASCIIARRAY[9] = 'data_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_day_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_day_TextCircle_img_width / 2,
                pos_y: 240 - 220,
                src: 'data_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            let screenType = hmSetting.getScreenType();
            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 375,
              y: 262,
              image_array: ["wind_0.png","wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 383,
              y: 279,
              w: 50,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 38,
              y: 132,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const weatherInfo = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
            });

            weatherImg = weatherInfo.createWidget(hmUI.widget.IMG, {
                x: 372,
                y: 134,
                w: 80,
                h: 80,
                src: 'w_25.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
            });        

            tempText = weatherInfo.createWidget(hmUI.widget.TEXT, {
                x: -5,
                y: 280,
                w: 150,
                h: 30,
                text_size: 24,
                char_space: 0,
                line_space: 0,
                font: 'fonts/GoogleSans-Regular.ttf',
                text: '--',
                color: 0xFFFFFFFF,
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.TOP,
                unit_type: 1,
                text_style: hmUI.text_style.ELLIPSIS,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });     

            descriptionText = hmUI.createWidget(hmUI.widget.TEXT);
            descriptionText.setProperty(hmUI.prop.MORE, {
                x: 55,
                y: 55,
                w: 370,
                h: 370,
                text_size: 17,
                char_space: 0,
                font: 'fonts/Bowler.ttf',
                text: '--',
                color: 0xFF000000,
                align_h: hmUI.align.CENTER_H,
                align_v: hmUI.align.CENTER_V,
                text_style: hmUI.text_style.ELLIPSIS,            
                start_angle: -55,
                end_angle: 55,
                show_level: hmUI.show_level.ONLY_NORMAL,
            });            
              
            // экземпляр класса
            weatherProvider = new WeatherProvider({
                night_icons: [0, 1, 2, 3, 14],
                show_toast: false,
                temp_widget: tempText,
                temp_max_widget: tempMaxText,
                temp_min_widget: tempMinText,
                temp_feels_widget: tempFeelsText,
                description_widget: descriptionText,
                cityName_widget: cityNameText,
                icon_widget: weatherImg,
                time_sensor: curTime,
                weather_sensor: weather,
            });              

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              // radius: 218,
              // angle: 222,
              // char_space_angle: 0,
              // unit: 'data_pr.png',
              // error_image: 'data_vp.png',
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'data_0.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'data_1.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'data_2.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'data_3.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'data_4.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'data_5.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'data_6.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'data_7.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'data_8.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'data_9.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_battery_TextCircle_img_width / 2,
                pos_y: 240 + 186,
                src: 'data_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_battery_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_battery_TextCircle_unit_width / 2,
              pos_y: 240 + 186,
              src: 'data_pr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 160,
              hour_startY: 175,
              hour_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 160,
              minute_startY: 245,
              minute_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display 

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 125,
              y: 123,
              src: 'btoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 327,
              y: 123,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 21,
              hour_posY: 231,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 21,
              minute_posY: 231,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'clean.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 3,
              second_posY: 3,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 144,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFFB99A3E,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 160,
              hour_startY: 175,
              hour_array: ["h_0.png","h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png","h_7.png","h_8.png","h_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 160,
              minute_startY: 245,
              minute_array: ["m_0.png","m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 165,
              y: 308,
              w: 150,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/GoogleSans-Regular.ttf',
              color: 0xFF35C67D,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              unit_type: 1,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 21,
              hour_posY: 231,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 21,
              minute_posY: 231,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 406,
              w: 100,
              h: 69,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 336,
              y: 368,
              w: 74,
              h: 64,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 62,
              y: 350,
              w: 80,
              h: 69,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 268,
              w: 58,
              h: 56,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 191,
              y: 180,
              w: 100,
              h: 50,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 192,
              y: 253,
              w: 100,
              h: 50,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 324,
              y: 119,
              w: 35,
              h: 35,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 364,
              y: 220,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 191,
              y: 16,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 15,
              y: 221,
              w: 100,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 382,
              y: 142,
              w: 40,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button    
            
            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 220,
              y: 80,
              w: 40,
              h: 40,
              text: '',
              text_size: 25,
              color: 0xFFFF8C00,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: () => {                
                weatherProvider.prev(true);                
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });              

            //start of ignored block
            function text_update() {
              console.log('text_update()');

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 321;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 218));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  normal_heart_rate_TextCircle_angleOffset = -normal_heart_rate_TextCircle_angleOffset;
                  char_Angle -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_heart_rate_TextCircle_error_img_width / 2);
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.SRC, 'data_vp.png');
                  normal_heart_rate_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 360;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 218));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  normal_step_TextCircle_angleOffset = -normal_step_TextCircle_angleOffset;
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_step_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_step_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_step_TextCircle_error_img_width / 2);
                  normal_step_TextCircle[0].setProperty(hmUI.prop.SRC, 'data_vp.png');
                  normal_step_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle day_TIME');
              let valueDay = timeSensor.day;
              let normal_day_circle_string = parseInt(valueDay).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_day_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 0;
                if (valueDay != null && valueDay != undefined && isFinite(valueDay) && normal_day_circle_string.length > 0 && normal_day_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_day_TextCircle_img_angle = 0;
                  let normal_day_TextCircle_dot_img_angle = 0;
                  normal_day_TextCircle_img_angle = toDegree(Math.atan2(normal_day_TextCircle_img_width/2, 220));
                  // alignment = CENTER_H
                  let normal_day_TextCircle_angleOffset = normal_day_TextCircle_img_angle * (normal_day_circle_string.length - 1);
                  char_Angle -= normal_day_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_day_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_day_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_day_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_day_TextCircle_img_width / 2);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.SRC, normal_day_TextCircle_ASCIIARRAY[charCode]);
                      normal_day_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_day_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_day_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_day_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_day_TextCircle_error_img_width / 2);
                  normal_day_TextCircle[0].setProperty(hmUI.prop.SRC, 'data_vp.png');
                  normal_day_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 402;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  let normal_battery_TextCircle_unit_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 218));
                  normal_battery_TextCircle_unit_angle = toDegree(Math.atan2(normal_battery_TextCircle_unit_width/2, 218));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_angleOffset + (normal_battery_TextCircle_img_angle + normal_battery_TextCircle_unit_angle + 0) / 2;
                  normal_battery_TextCircle_angleOffset = -normal_battery_TextCircle_angleOffset;
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_battery_TextCircle_unit_angle;
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.POS_X, 240 - normal_battery_TextCircle_error_img_width / 2);
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.SRC, 'data_vp.png');
                  normal_battery_TextCircle[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };
            //click zona     

            function click_btn() {  // Function to enable and disable the visibility of elements
              element_index++;
              if(element_index > element_count) element_index = 1;
              normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
                                         
                                                                                                                 
              if (element_index == 1) {
                hmUI.showToast({text: 'Вид 1'});
              };
              if (element_index == 2) {
                hmUI.showToast({text: 'Вид 2'});
              };
            };
            // Button to switch elements. This block should be after all blocks with display elements.
            hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 46,  // x coordinate of the button
                y: 137,  // y coordinate of the button
                text: '',
                w: 50,  // button width
                h: 50,  // button height
                normal_src: 'clean.png',  // transparent image
                press_src: 'clean.png',  // transparent image
                show_level: hmUI.show_level.ONLY_NORMAL,
                click_func: () => {
                  click_btn();
                }
            });
            // end button 
            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType
                if (hmSetting.getScreenType() == hmSetting.screen_type.WATCHFACE) {
                  startSecPointerAnim();
                }


                console.log('resume_call.js');
                // start resume_call.js


//
              updateSleepInfo();
            //
                // end resume_call.js

              }),
              pause_call: (function () {
                console.log('pause_call()');
                stopSecPointerAnim();
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}