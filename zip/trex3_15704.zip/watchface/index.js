﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_system_lock_img = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_battery_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_lock_img = ''
        let idle_distance_text_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_battery_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim",
              anim_fps: 11,
              anim_size: 14,
              repeat_count: 1,
              anim_repeat: false,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 197,
              y: 56,
              src: '0027.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 114,
              font_array: ["C00.png","C01.png","C02.png","C03.png","C04.png","C05.png","C06.png","C07.png","C08.png","C09.png"],
              padding: false,
              h_space: 3,
              dot_image: 'JUM.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 258,
              day_startY: 66,
              day_sc_array: ["0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png"],
              day_tc_array: ["0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png"],
              day_en_array: ["0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png"],
              day_zero: 1,
              day_space: 9,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 295,
              y: 125,
              week_en: ["YO00.png","YO01.png","YO02.png","YO03.png","YO04.png","YO05.png","YO06.png"],
              week_tc: ["YO00.png","YO01.png","YO02.png","YO03.png","YO04.png","YO05.png","YO06.png"],
              week_sc: ["YO00.png","YO01.png","YO02.png","YO03.png","YO04.png","YO05.png","YO06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 251,
              month_startY: 128,
              month_sc_array: ["lm0.png","lm1.png","lm2.png","lm3.png","lm4.png","lm5.png","lm6.png","lm7.png","lm8.png","lm9.png"],
              month_tc_array: ["lm0.png","lm1.png","lm2.png","lm3.png","lm4.png","lm5.png","lm6.png","lm7.png","lm8.png","lm9.png"],
              month_en_array: ["lm0.png","lm1.png","lm2.png","lm3.png","lm4.png","lm5.png","lm6.png","lm7.png","lm8.png","lm9.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 311,
              y: 326,
              font_array: ["d00.png","d01.png","d02.png","d03.png","d04.png","d05.png","d06.png","d07.png","d08.png","d09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 168,
              y: 369,
              font_array: ["s00.png","s01.png","s02.png","s03.png","s04.png","s05.png","s06.png","s07.png","s08.png","s09.png"],
              padding: true,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["a00.png","a01.png","a02.png","a03.png","a04.png","a05.png","a06.png"],
              image_length: 7,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 326,
              font_array: ["d00.png","d01.png","d02.png","d03.png","d04.png","d05.png","d06.png","d07.png","d08.png","d09.png"],
              padding: true,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 60,
              hour_startY: 199,
              hour_array: ["mo0.png","mo1.png","mo2.png","mo3.png","mo4.png","mo5.png","mo6.png","mo7.png","mo8.png","mo9.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 184,
              minute_startY: 200,
              minute_array: ["mo0.png","mo1.png","mo2.png","mo3.png","mo4.png","mo5.png","mo6.png","mo7.png","mo8.png","mo9.png"],
              minute_zero: 1,
              minute_space: 20,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 321,
              second_startY: 200,
              second_array: ["cc0.png","cc1.png","cc2.png","cc3.png","cc4.png","cc5.png","cc6.png","cc7.png","cc8.png","cc9.png"],
              second_zero: 1,
              second_space: 8,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 197,
              y: 56,
              src: '0027.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 114,
              font_array: ["C00.png","C01.png","C02.png","C03.png","C04.png","C05.png","C06.png","C07.png","C08.png","C09.png"],
              padding: false,
              h_space: 3,
              dot_image: 'JUM.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 258,
              day_startY: 66,
              day_sc_array: ["0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png"],
              day_tc_array: ["0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png"],
              day_en_array: ["0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png"],
              day_zero: 1,
              day_space: 9,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 295,
              y: 125,
              week_en: ["YO00.png","YO01.png","YO02.png","YO03.png","YO04.png","YO05.png","YO06.png"],
              week_tc: ["YO00.png","YO01.png","YO02.png","YO03.png","YO04.png","YO05.png","YO06.png"],
              week_sc: ["YO00.png","YO01.png","YO02.png","YO03.png","YO04.png","YO05.png","YO06.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 251,
              month_startY: 128,
              month_sc_array: ["lm0.png","lm1.png","lm2.png","lm3.png","lm4.png","lm5.png","lm6.png","lm7.png","lm8.png","lm9.png"],
              month_tc_array: ["lm0.png","lm1.png","lm2.png","lm3.png","lm4.png","lm5.png","lm6.png","lm7.png","lm8.png","lm9.png"],
              month_en_array: ["lm0.png","lm1.png","lm2.png","lm3.png","lm4.png","lm5.png","lm6.png","lm7.png","lm8.png","lm9.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 311,
              y: 326,
              font_array: ["d00.png","d01.png","d02.png","d03.png","d04.png","d05.png","d06.png","d07.png","d08.png","d09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 168,
              y: 369,
              font_array: ["s00.png","s01.png","s02.png","s03.png","s04.png","s05.png","s06.png","s07.png","s08.png","s09.png"],
              padding: true,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["a00.png","a01.png","a02.png","a03.png","a04.png","a05.png","a06.png"],
              image_length: 7,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 326,
              font_array: ["d00.png","d01.png","d02.png","d03.png","d04.png","d05.png","d06.png","d07.png","d08.png","d09.png"],
              padding: true,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 60,
              hour_startY: 199,
              hour_array: ["mo0.png","mo1.png","mo2.png","mo3.png","mo4.png","mo5.png","mo6.png","mo7.png","mo8.png","mo9.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 184,
              minute_startY: 200,
              minute_array: ["mo0.png","mo1.png","mo2.png","mo3.png","mo4.png","mo5.png","mo6.png","mo7.png","mo8.png","mo9.png"],
              minute_zero: 1,
              minute_space: 20,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 321,
              second_startY: 200,
              second_array: ["cc0.png","cc1.png","cc2.png","cc3.png","cc4.png","cc5.png","cc6.png","cc7.png","cc8.png","cc9.png"],
              second_zero: 1,
              second_space: 8,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                console.log('pause_call()');
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}