﻿/*
** Watch_Face_Editor tool v 18.0
** watchface js version v2.1.1
** Copyright © SashaCX75. All Rights Reserved
*/

try {
(() => {
    //start of ignored block
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
        return __$$app$$__.app;
    }
    function getCurrentPage() {
        return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const {px} = __$$app$$__.__globals__;
    //const logger = Logger.getLogger('watchface_SashaCX75');
    const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
    //end of ignored block

    //dynamic modify start
    let tempText, cityNameText, descriptionText;
    let weatherProvider = null; 

    let btn_bezel = ''
    let bezel_num = 1
    let bezel_all = 2        
    
    let normal_background_bg_img = ''
    let normal_bg_img = ''
    let normal_date_img_date_month_img = ''
    let normal_day_text_font = ''
    let normal_date_img_date_week_img = ''
    let normal_sleep_icon_img = ''
    let normal_sleep_time_font = ''
    let normal_alarm_clock_current_text_font = ''
    let normal_system_disconnect_img = ''
    let normal_system_clock_img = ''
    let normal_step_current_text_font = ''
    let normal_battery_circle_scale = ''
    let normal_battery_pointer_progress_img_pointer = ''
    let normal_battery_current_text_font = ''
    let normal_sun_icon_img = ''
    let normal_sun_high_text_font = ''
    let normal_sun_low_text_font = ''
    let normal_sun_pointer_progress_img_pointer = ''
    let normal_moon_pointer_progress_img_pointer = ''
    let normal_analog_clock_time_pointer_hour = ''
    let normal_analog_clock_time_pointer_minute = ''
    let normal_analog_clock_time_pointer_second = ''
    let idle_background_bg_img = ''
    let idle_date_img_date_month_img = ''
    let idle_day_text_font = ''
    let idle_date_img_date_week_img = ''
    let idle_system_disconnect_img = ''
    let idle_battery_circle_scale = ''
    let idle_battery_pointer_progress_img_pointer = ''
    let idle_battery_current_text_font = ''
    let idle_sun_pointer_progress_img_pointer = ''
    let idle_moon_pointer_progress_img_pointer = ''
    let idle_analog_clock_time_pointer_hour = ''
    let idle_analog_clock_time_pointer_minute = ''
    let normal_step_jumpable_img_click = ''
    let normal_battery_jumpable_img_click = ''
    let normal_temperature_jumpable_img_click = ''
    let normal_countdown_jumpable_img_click = ''
    let normal_stopwatch_jumpable_img_click = ''
    let normal_alarm_jumpable_img_click = ''
    let normal_sleep_jumpable_img_click = ''
    let Button_1 = ''
    let Button_2 = ''
    let Button_3 = ''
    let timeSensor = '';
    let sleepSensor = '';

    // --------------------
    // WeatherProvider v5.1 —  T-Rex Ultra 2
    // --------------------
    class WeatherProvider {
            constructor(props = {}) {
                this.iconMapService = {
                    1: 3, 2: 0, 3: 4, 4: 4, 5: 1, 6: 5, 7: 10, 8: 15,
                    9: 6, 10: 8, 11: 9, 12: 12, 13: 13, 14: 17
                };

                this.description = [
                    ['Облачно','Временами дождь','Временами снег','Ясно','Пасмурно','Слабый дождь','Слабый снег','Умеренный дождь','Умеренный снег','Сильный снегопад','Сильный дождь','Песчаная буря','Мокрый снег','Туман','Дымка','Дождь с грозой','Метель','Пыльно','Ливень','Дождь с градом','Сильный дождь с градом','Сильный дождь','Пыльная буря','Сильная песчаная буря','Сильный дождь','Обновите погоду','Облачно ночью','Дождливо ночью','Ясно ночью'],
                    ['Cloudy','Showers','Snow Showers','Sunny','Overcast','Light Rain','Light Snow','Moderate Rain','Moderate Snow','Heavy Snow','Heavy Rain','Sandstorm','Rain and Snow','Fog','Hazy','T-Storms','Snowstorm','Floating dust','Very Heavy Rainstorm','Rain and Hail','T-Storms and Hail','Heavy Rainstorm','Dust','Heavy sand storm','Rainstorm','Unknown','Cloudy Nighttime','Showers Nighttime','Sunny Nighttime']
                ];

                this.props = {
                    night_icons: [0, 1, 2, 3, 14],
                    index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,
                    show_toast: true,
                    temp_widget: null,
                    temp_max_widget: null,
                    temp_min_widget: null,
                    temp_feels_widget: null,
                    description_widget: null,
                    cityName_widget: null,
                    icon_widget: null,
                    time_sensor: true,
                    weather_sensor: null,
                    lang: (hmSetting.getLanguage() === 4 ? 0 : 1),
                    ...props
                };

                this.providers = [
                    { name: ['Zepp','Zepp'], appId: null },
                    { name: ['Погодный сервис','Weather service'], appId: 1065824 }
                ];

                this.last = {
                    weatherIcon: 25,
                    displayedIcon: '25',
                    weatherDescription: 'Нет данных',
                    temperature: '--',
                    temperatureFeels: '--',
                    temperatureMax: '--',
                    temperatureMin: '--',
                    cityName: '--',
                    modTime: null,
                    sunriseMins: 360,
                    sunsetMins: 1200
                };

                this._THROTTLE_MS = 6 * 60 * 1000;
                this._lastUpdateMs = hmFS.SysProGetInt64("weatherLastUpdateMs") || 0;
                this._isUpdating = false;

                if (!this.props.time_sensor) this.props.time_sensor = curTime;

                if (!this.props.weather_sensor) {
                    try {
                        this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
                    } catch (e) {
                        console.log('WEATHER sensor creation failed:', e);
                        this.props.weather_sensor = null;
                    }
                }

                if (isFinite(this.props.index)) {
                    hmFS.SysProSetInt('WeatherProviderIndex', this.props.index);
                }
            }

            update(force = false) {
                if (this._isUpdating) return;

                const nowMs = Date.now();
                const isTimeout = (nowMs - this._lastUpdateMs >= this._THROTTLE_MS);

                if (!force && !isTimeout) return;

                this._isUpdating = true;

                const prov = this.providers[this.props.index];
                const isZepp = prov.appId === null;

                let shouldApply = force;

                if (isZepp) {
                    shouldApply = isTimeout || force;
                } else {                        
                    const modTime = this.getFileModTime(prov.appId);
                    if (force || !modTime || modTime !== this.last.modTime) {
                        this.last.modTime = modTime;
                        shouldApply = true;
                    } else if (isTimeout) {
                        shouldApply = true;
                    }
                }

                if (shouldApply) {
                    const newData = this.getWeatherData(prov.appId);
                    this._applyWeatherData(newData);
                }

                this._lastUpdateMs = nowMs;
                hmFS.SysProSetInt64("weatherLastUpdateMs", nowMs);

                this._isUpdating = false;
            }

            _applyWeatherData(newData) {
                
                const tVal = this.tempWithSign(newData.temperature);
                if (tVal !== this.last.temperature) {
                    this.last.temperature = tVal;
                    this.props.temp_widget?.setProperty(hmUI.prop.TEXT, tVal);
                }

                const tMax = this.tempWithSign(newData.temperatureMax);
                if (tMax !== this.last.temperatureMax) {
                    this.last.temperatureMax = tMax;
                    this.props.temp_max_widget?.setProperty(hmUI.prop.TEXT, tMax);
                }

                const tMin = this.tempWithSign(newData.temperatureMin);
                if (tMin !== this.last.temperatureMin) {
                    this.last.temperatureMin = tMin;
                    this.props.temp_min_widget?.setProperty(hmUI.prop.TEXT, tMin);
                }

                const tFeels = this.tempWithSign(newData.temperatureFeels);
                if (tFeels !== this.last.temperatureFeels) {
                    this.last.temperatureFeels = tFeels;
                    this.props.temp_feels_widget?.setProperty(hmUI.prop.TEXT, tFeels);
                }

                if (newData.cityName !== this.last.cityName) {
                    this.last.cityName = newData.cityName;
                    this.props.cityName_widget?.setProperty(hmUI.prop.TEXT, newData.cityName);
                }

                if (newData.weatherDescription !== this.last.weatherDescription) {
                    this.last.weatherDescription = newData.weatherDescription;
                    this.props.description_widget?.setProperty(hmUI.prop.TEXT, newData.weatherDescription);
                }
                
                let curIcon = parseInt(newData.weatherIcon);
                let iconSuffix = (this.props.night_icons.includes(curIcon) && !this.isDayNow()) ? 'n' : '';
                const finalIconStr = `${curIcon}${iconSuffix}`;

                if (finalIconStr !== this.last.displayedIcon) {
                    this.last.displayedIcon = finalIconStr;
                    this.last.weatherIcon = curIcon;
                    this.props.icon_widget?.setProperty(hmUI.prop.SRC, `w_${finalIconStr}.png`);
                }
            }

            tempWithSign(val) {
                let fVal = parseFloat(val);
                if (isNaN(fVal) || !isFinite(fVal)) return '--';
                return (fVal > 0 ? '+' : '') + Math.round(fVal) + '°';
            }

            isDayNow() {
                const ts = this.props.time_sensor;
                let curMins;

                if (ts && typeof ts.hour === 'number' && typeof ts.minute === 'number') {
                    curMins = ts.hour * 60 + ts.minute;
                } else {
                    const now = new Date();
                    curMins = now.getHours() * 60 + now.getMinutes();
                }

                if (isNaN(this.last.sunriseMins) || isNaN(this.last.sunsetMins)) {
                    return true;
                }

                return curMins >= this.last.sunriseMins && curMins < this.last.sunsetMins;
            }

            getWeatherData(app_id = null) {
                return !app_id ? this.getZeppWeatherData() : this.getAppWeatherData(app_id);
            }

            getZeppWeatherData() {
                try {
                    const ws = this.props.weather_sensor;
                    if (!ws) throw new Error("No Sensor");

                    const fw = ws.getForecastWeather ? ws.getForecastWeather() : null;
                    const cityName = fw ? fw.cityName : '--';
                    const iconIndex = ws.curAirIconIndex ?? 25;

                    if (fw && fw.forecastData && fw.forecastData.count > 0) {
                        const today = fw.forecastData.data[0];
                        if (today.sunrise && today.sunset) {
                            const riseHour = parseInt(today.sunrise.hour);
                            const riseMin = parseInt(today.sunrise.minute);
                            const setHour = parseInt(today.sunset.hour);
                            const setMin = parseInt(today.sunset.minute);

                            if (!isNaN(riseHour) && !isNaN(riseMin) && !isNaN(setHour) && !isNaN(setMin)) {
                                this.last.sunriseMins = riseHour * 60 + riseMin;
                                this.last.sunsetMins = setHour * 60 + setMin;
                                this.last.sunData = this.props.time_sensor ? this.props.time_sensor.day : new Date().getDate();
                            }
                        }
                    }

                    return {
                        weatherIcon: iconIndex,
                        weatherDescription: this.description[this.props.lang][iconIndex] || 'Нет данных',
                        temperature: ws.current ?? '--',
                        temperatureFeels: ws.feelsLike ?? '--',
                        temperatureMax: ws.high ?? '--',
                        temperatureMin: ws.low ?? '--',
                        cityName: cityName
                    };
                } catch (e) {
                    console.log('getZeppWeatherData error:', e);
                    return { weatherIcon:25, weatherDescription:'Нет данных', temperature:'--', temperatureFeels:'--', temperatureMax:'--', temperatureMin:'--', cityName:'--' };
                }
            }

            getAppWeatherData(app_id) {
                const data = { weatherIcon: 25, weatherDescription: 'Нет данных', temperature: '--', temperatureFeels: '--', temperatureMax: '--', temperatureMin: '--', cityName: '--' };
                const weather_str = this.readFile(app_id);
                if (!weather_str) return data;

                try {
                    const weatherJson = JSON.parse(weather_str);
                    if (weatherJson) {
                        data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon || 25), app_id);

                        if (weatherJson.weatherDescriptionExtended) {
                            const desc = weatherJson.weatherDescriptionExtended;
                            data.weatherDescription = desc.charAt(0).toUpperCase() + desc.slice(1);
                        } else {
                            data.weatherDescription = this.description[this.props.lang][data.weatherIcon] || 'Нет данных';
                        }

                        data.temperature = weatherJson.temperature ?? '--';
                        data.temperatureFeels = weatherJson.temperatureFeels ?? '--';
                        data.temperatureMax = weatherJson.temperatureMax ?? '--';
                        data.temperatureMin = weatherJson.temperatureMin ?? '--';
                        data.cityName = weatherJson.city || '--';
                    }
                } catch (e) {
                    console.log('JSON Parse error in getAppWeatherData:', e);
                }
                return data;
            }

            getZeppIconIndex(index, app_id = null) {
                if (!app_id) return index;
                if (app_id === 1065824) return this.iconMapService[index] ?? 25;
                if (app_id === 1066654) return index - 1;
                return index;
            }

            readFile(app_id) {
                if (!app_id) return null;
                try {
                    const [fs_stat, err] = hmFS.stat('weather.json', { appid: app_id });
                    if (err === 0 && fs_stat.size > 0) {
                        const fh = hmFS.open('weather.json', hmFS.O_RDONLY, { appid: app_id });
                        const array_buffer = new ArrayBuffer(fs_stat.size);
                        hmFS.read(fh, array_buffer, 0, fs_stat.size);
                        hmFS.close(fh);
                        return this.arrayBufferToCyrillic(array_buffer);
                    }
                } catch (e) {
                    console.log('readFile error:', e);
                }
                return null;
            }

            getFileModTime(app_id) {
                if (!app_id) return null;
                try {
                    const [fs_stat, err] = hmFS.stat('weather.json', { appid: app_id });
                    if (err === 0) return fs_stat.mtime;
                } catch (e) {}
                return null;
            }

            arrayBufferToCyrillic(buffer) {
                let result = '';
                const bytes = new Uint8Array(buffer);
                for (let i = 0; i < bytes.length;) {
                    let byte1 = bytes[i++];
                    if (byte1 < 0x80) {
                        result += String.fromCharCode(byte1);
                    } else if (byte1 >= 0xC0 && byte1 < 0xE0) {
                        let byte2 = bytes[i++];
                        result += String.fromCharCode(((byte1 & 0x1F) << 6) | (byte2 & 0x3F));
                    } else if (byte1 >= 0xE0 && byte1 < 0xF0) {
                        let byte2 = bytes[i++];
                        let byte3 = bytes[i++];
                        result += String.fromCharCode(((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F));
                    }
                }
                return result;
            }

            next(show_toast = this.props.show_toast) {
                this.props.index = (this.props.index + 1) % this.providers.length;
                hmFS.SysProSetInt('WeatherProviderIndex', this.props.index);
                this.last.modTime = 0;                    
                if (show_toast) hmUI.showToast({ text: this.providers[this.props.index].name[this.props.lang] });
                this.update(true);
            }

            prev(show_toast = this.props.show_toast) {
                this.props.index = (this.props.index - 1 + this.providers.length) % this.providers.length;
                hmFS.SysProSetInt('WeatherProviderIndex', this.props.index);
                this.last.modTime = 0;                    
                if (show_toast) hmUI.showToast({ text: this.providers[this.props.index].name[this.props.lang] });
                this.update(true);
            }

            get cityName() { return this.last.cityName ?? '--'; }
            get temperature() { return this.last.temperature ?? '--'; }
            get temperatureFeels() { return this.last.temperatureFeels ?? '--'; }
            get temperatureMax() { return this.last.temperatureMax ?? '--'; }
            get temperatureMin() { return this.last.temperatureMin ?? '--'; }
            get weatherDescription() { return this.last.weatherDescription ?? 'Нет данных'; }
            get weatherIcon() { return this.last.weatherIcon ?? 25; }

            delete() {
                this._isUpdating = false;
                this.props = null;
                this.last = null;
                this.description = null;
                this.iconMapService = null;
                this.providers = null;
            }
    }

    function click_Bezel() {
          if(bezel_num>=bezel_all) {bezel_num=1;}
          else { bezel_num=bezel_num+1;}
          hmUI.showToast({text: "Вид " + parseInt(bezel_num) });
            normal_bg_img.setProperty(hmUI.prop.SRC, "osn_AOD_" + parseInt(bezel_num) + ".png");
    }        
    //dynamic modify end

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
        init_view() {
            //dynamic modify start
                
            
        // FontName: IntroFriday.ttf; FontSize: 34
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 478,
          y: 478,
          w: 459,
          h: 48,
          text_size: 34,
          char_space: 1,
          line_space: 0,
          font: 'fonts/IntroFriday.ttf',
          color: 0xFFFFFFFF,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "0123456789 _-.,:;`'%°\\/",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: IntroFriday.ttf; FontSize: 28
        hmUI.createWidget(hmUI.widget.TEXT, {
          x: 478,
          y: 478,
          w: 385,
          h: 40,
          text_size: 28,
          char_space: 1,
          line_space: 0,
          font: 'fonts/IntroFriday.ttf',
          color: 0xFFFFFFFF,
          align_h: hmUI.align.LEFT,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          text: "0123456789 _-.,:;`'%°\\/",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: IntroFriday.ttf; FontSize: 26; Cache: full
        hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 31,
              h: 31,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/IntroFriday.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: 'vos_1.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: 'osn_AOD_1.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 162,
          month_startY: 144,
          month_sc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
          month_tc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
          month_en_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
          month_is_character: true ,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
          time_update(true);
        });

        timeSensor.addEventListener(timeSensor.event.MINUTE_CHANGE, function() {
          updateSunBackground();
        });

        normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 165,
          y: 83,
          w: 150,
          h: 40,
          text_size: 34,
          char_space: 1,
          font: 'fonts/IntroFriday.ttf',
          color: 0xFFFFFFFF,
          line_space: 0,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 142,
          y: 116,
          week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
          week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
          week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_sleep_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 330,
          y: 352,
          src: 'sleep.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_sleep_time_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: -3,
          y: -3,
          w: 486,
          h: 486,
          text_size: 28,
          char_space: 1,
          font: 'fonts/IntroFriday.ttf',
          color: 0xFFFFFFFF,
          // use_text_circle: true,
          start_angle: 90,
          end_angle: 150,
          mode: 1,
          // radius: 243,
          align_h: hmUI.align.LEFT,
          // padding: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_alarm_clock_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: -3,
          y: -3,
          w: 486,
          h: 486,
          text_size: 28,
          char_space: 1,
          font: 'fonts/IntroFriday.ttf',
          color: 0xFFFFFFFF,
          // use_text_circle: true,
          start_angle: 180,
          end_angle: 228,
          mode: 1,
          // radius: 243,
          align_h: hmUI.align.LEFT,
          padding: true,
          type: hmUI.data_type.ALARM_CLOCK,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 163,
          y: 285,
          src: 'bt_off.png',
          type: hmUI.system_status.DISCONNECT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 121,
          y: 353,
          src: 'alarm.png',
          type: hmUI.system_status.CLOCK,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        const weatherInfo = hmUI.createWidget(hmUI.widget.GROUP, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
        });

        cityNameText = hmUI.createWidget(hmUI.widget.TEXT, {
          x: -1,
          y: -1,
          w: 482,
          h: 482,
          text_size: 26,
          char_space: 0,
          font: 'fonts/IntroFriday.ttf',
          color: 0xFFFFFFFF,
          // use_text_circle: true,
          start_angle: -98,
          end_angle: -18,
          mode: 0,
          // radius: 241,
          align_h: hmUI.align.RIGHT,
          ext: "--",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        descriptionText = hmUI.createWidget(hmUI.widget.TEXT, {
          x: -1,
          y: -1,
          w: 482,
          h: 482,
          text_size: 26,
          char_space: 0,
          font: 'fonts/IntroFriday.ttf',
          color: 0xFFFFFFFF,
          // use_text_circle: true,
          start_angle: 19,
          end_angle: 99,
          mode: 0,
          // radius: 241,
          align_h: hmUI.align.LEFT,
          text: '--',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });            

        tempText = weatherInfo.createWidget(hmUI.widget.TEXT, {
          x: -3,
          y: -3,
          w: 486,
          h: 486,
          text_size: 28,
          char_space: 1,
          font: 'fonts/IntroFriday.ttf',
          color: 0xFFFFFFFF,
          // use_text_circle: true,
          start_angle: -20,
          end_angle: 21,
          mode: 0,
          // radius: 243,
          align_h: hmUI.align.CENTER_H,
          unit_type: 1,
          text: '--',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        weatherProvider = new WeatherProvider({                
            temp_widget: tempText,
            cityName_widget: cityNameText,                
            description_widget: descriptionText,
            show_toast: true
        });
        weatherProvider.update(true);             

        normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: -3,
          y: -3,
          w: 486,
          h: 486,
          text_size: 28,
          char_space: 1,
          font: 'fonts/IntroFriday.ttf',
          color: 0xFFFFFFFF,
          // use_text_circle: true,
          start_angle: 90,
          end_angle: 270,
          mode: 1,
          // radius: 243,
          align_h: hmUI.align.CENTER_H,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
          // center_x: 240,
          // center_y: 354,
          // start_angle: -152,
          // end_angle: 155,
          // radius: 45,
          // line_width: 10,
          // line_cap: Flat,
          // color: 0xFF000000,
          // mirror: False,
          // inversion: True,
          // alpha: 190,
          // type: hmUI.data_type.BATTERY,
          // show_level: hmUI.show_level.ONLY_NORMAL,
        // });

        let screenType = hmSetting.getScreenType();
        normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
          center_x: 240,
          center_y: 354,
          start_angle: 155,
          end_angle: -152,
          radius: 40,
          line_width: 10,
          corner_flag: 3,
          color: 0xFF000000,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_battery_circle_scale.setAlpha(190);
        
        const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
        battery.addEventListener(hmSensor.event.CHANGE, function() {
          scale_call();
        });

        normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: 'batt.png',
          center_x: 240,
          center_y: 354,
          x: 18,
          y: 57,
          start_angle: -152,
          end_angle: 155,
          invalid_visible: false,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 167,
          y: 340,
          w: 150,
          h: 40,
          text_size: 28,
          char_space: 1,
          font: 'fonts/IntroFriday.ttf',
          color: 0xFFFFFFFF,
          line_space: 0,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          align_h: hmUI.align.CENTER_H,
          unit_type: 1,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 63,
          y: 278,
          src: 'sunset.png',
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_sun_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: -3,
          y: -3,
          w: 486,
          h: 486,
          text_size: 28,
          char_space: 1,
          font: 'fonts/IntroFriday.ttf',
          color: 0xFFFFFFFF,
          // use_text_circle: true,
          start_angle: 180,
          end_angle: 257,
          mode: 1,
          // radius: 243,
          align_h: hmUI.align.LEFT,
          type: hmUI.data_type.SUN_RISE,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_sun_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: -3,
          y: -3,
          w: 486,
          h: 486,
          text_size: 28,
          char_space: 1,
          font: 'fonts/IntroFriday.ttf',
          color: 0xFFFFFFFF,
          // use_text_circle: true,
          start_angle: 102,
          end_angle: 200,
          mode: 1,
          // radius: 243,
          align_h: hmUI.align.RIGHT,
          type: hmUI.data_type.SUN_SET,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: 'sun.png',
          center_x: 240,
          center_y: 310,
          x: 20,
          y: 151,
          start_angle: -78,
          end_angle: 78,
          invalid_visible: false,
          type: hmUI.data_type.SUN_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_moon_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: 'moon.png',
          center_x: 240,
          center_y: 310,
          x: 20,
          y: 151,
          start_angle: -78,
          end_angle: 78,
          invalid_visible: false,
          type: hmUI.data_type.MOON_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: 'hour1.png',
          hour_centerX: 240,
          hour_centerY: 240,
          hour_posX: 26,
          hour_posY: 229,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: 'minn1.png',
          minute_centerX: 240,
          minute_centerY: 240,
          minute_posX: 26,
          minute_posY: 229,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          second_path: 'sekk1.png',
          second_centerX: 240,
          second_centerY: 240,
          second_posX: 26,
          second_posY: 229,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });


        idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          src: 'osn_AOD_2.png',
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
          month_startX: 162,
          month_startY: 144,
          month_sc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
          month_tc_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
          month_en_array: ["month_0.png","month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png"],
          month_is_character: true ,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 165,
          y: 83,
          w: 150,
          h: 40,
          text_size: 34,
          char_space: 1,
          font: 'fonts/IntroFriday.ttf',
          color: 0xFFFFFFFF,
          line_space: 0,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          align_h: hmUI.align.CENTER_H,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
          x: 142,
          y: 116,
          week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
          week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
          week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
          x: 163,
          y: 285,
          src: 'bt_off.png',
          type: hmUI.system_status.DISCONNECT,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
          // center_x: 240,
          // center_y: 354,
          // start_angle: -152,
          // end_angle: 155,
          // radius: 45,
          // line_width: 10,
          // line_cap: Flat,
          // color: 0xFF000000,
          // mirror: False,
          // inversion: True,
          // alpha: 190,
          // type: hmUI.data_type.BATTERY,
          // show_level: hmUI.show_level.ONLY_AOD,
        // });

        idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
          center_x: 240,
          center_y: 354,
          start_angle: 155,
          end_angle: -152,
          radius: 40,
          line_width: 10,
          corner_flag: 3,
          color: 0xFF000000,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_battery_circle_scale.setAlpha(190);

        idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: 'batt.png',
          center_x: 240,
          center_y: 354,
          x: 18,
          y: 57,
          start_angle: -152,
          end_angle: 155,
          invalid_visible: false,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
          x: 167,
          y: 340,
          w: 150,
          h: 40,
          text_size: 28,
          char_space: 1,
          font: 'fonts/IntroFriday.ttf',
          color: 0xFFFFFFFF,
          line_space: 0,
          align_v: hmUI.align.TOP,
          text_style: hmUI.text_style.ELLIPSIS,
          align_h: hmUI.align.CENTER_H,
          unit_type: 1,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: 'sun.png',
          center_x: 240,
          center_y: 310,
          x: 20,
          y: 151,
          start_angle: -78,
          end_angle: 78,
          invalid_visible: false,
          type: hmUI.data_type.SUN_CURRENT,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_moon_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
          src: 'moon.png',
          center_x: 240,
          center_y: 310,
          x: 20,
          y: 151,
          start_angle: -78,
          end_angle: 78,
          invalid_visible: false,
          type: hmUI.data_type.MOON_CURRENT,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          hour_path: 'hour1.png',
          hour_centerX: 240,
          hour_centerY: 240,
          hour_posX: 26,
          hour_posY: 229,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
          minute_path: 'minn1.png',
          minute_centerX: 240,
          minute_centerY: 240,
          minute_posX: 26,
          minute_posY: 229,
          show_level: hmUI.show_level.ONLY_AOD,
        });
        console.log('Watch_Face.Shortcuts');

        normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 191,
          y: 421,
          w: 100,
          h: 57,
          type: hmUI.data_type.STEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 212,
          y: 325,
          w: 55,
          h: 55,
          type: hmUI.data_type.BATTERY,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 83,
          y: 29,
          w: 80,
          h: 63,
          type: hmUI.data_type.WEATHER_CURRENT,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 10,
          y: 280,
          w: 70,
          h: 80,
          type: hmUI.data_type.COUNT_DOWN,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 401,
          y: 280,
          w: 70,
          h: 80,
          type: hmUI.data_type.STOP_WATCH,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 71,
          y: 374,
          w: 80,
          h: 70,
          type: hmUI.data_type.ALARM_CLOCK,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
          x: 336,
          y: 377,
          w: 83,
          h: 69,
          type: hmUI.data_type.SLEEP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });


        Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 204,
          y: 100,
          w: 70,
          h: 57,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'clean.png',
          normal_src: 'clean.png',
          click_func: (button_widget) => {
            hmApp.startApp({url: 'ScheduleCalScreen', native: true });
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 313,
          y: 29,
          w: 80,
          h: 66,
          text: '',
          text_size: 25,
          color: 0xFFFF8C00,
          press_src: 'clean.png',
          normal_src: 'clean.png',
          click_func: () => {
            weatherProvider.prev(true);
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); 

        Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 314,
          y: 108,
          w: 70,
          h: 70,
          text: '',
          color: 0xFFFF8C00,
          text_size: 25,
          press_src: 'clean.png',
          normal_src: 'clean.png',
          click_func: (button_widget) => {
            hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
          }, // end func
          show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button  
        
        btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 207,
          y: 207,
          text: '',
          w: 70,
          h: 70,
          normal_src: 'clean.png',
          press_src: 'clean.png',
          click_func: () => {
           click_Bezel();

          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        btn_bezel.setProperty(hmUI.prop.VISIBLE, true);            

        //#region updateSunBackground
        function updateSunBackground() {
          if (!weatherProvider || !normal_background_bg_img) return;

          let curMins = timeSensor ? (timeSensor.hour * 60 + timeSensor.minute) : (new Date().getHours() * 60 + new Date().getMinutes());
          let sunrise = weatherProvider.last ? weatherProvider.last.sunriseMins : 360;
          let sunset = weatherProvider.last ? weatherProvider.last.sunsetMins : 1200;

          let bgImg = 'zak_2.png';

          if (curMins >= sunrise - 30 && curMins < sunrise) {
            bgImg = 'zak_3.png';
          } else if (curMins >= sunrise && curMins < sunrise + 30) {
            bgImg = 'vos_1.png';
          } else if (curMins >= sunrise + 30 && curMins < sunset - 30) {
            bgImg = 'vos_2.png';
          } else if (curMins >= sunset - 30 && curMins < sunset) {
            bgImg = 'vos_3.png';
          } else if (curMins >= sunset && curMins < sunset + 30) {
            bgImg = 'zak_1.png';
          } else {
            bgImg = 'zak_2.png';
          }

          normal_background_bg_img.setProperty(hmUI.prop.SRC, bgImg);
        }
        //#endregion

        //#region time_update
        function time_update(updateHour = false, updateMinute = false) {
          let hour = timeSensor.hour;
          let minute = timeSensor.minute;
          let second = timeSensor.second;
          let format_hour = timeSensor.format_hour;

          if (updateHour) {
            let normal_dayStr = timeSensor.day.toString();
            normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
          };

          if (updateHour) {
            let idle_dayStr = timeSensor.day.toString();
            idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
          };

        };

        //#endregion
        if (!sleepSensor) sleepSensor = hmSensor.createSensor(hmSensor.id.SLEEP);
        //#region sleep_update
        function sleep_update() {

          let sleepTime = sleepSensor.getTotalTime();
          const modelData = sleepSensor.getSleepStageModel();
          let sleepStageArray = sleepSensor.getSleepStageData();
          let wakeupTime = 0;
          let wakeupCount = 0;

          for (let i = 0; i < sleepStageArray.length; i++) {
            let data = sleepStageArray[i];
            if (data.model == modelData.WAKE_STAGE) {
              wakeupTime += data.stop + 1 - data.start;
              wakeupCount++;
            };
          };
          sleepTime -= wakeupTime;
          let sleepTimeHour = Math.floor(sleepTime / 60);
          let sleepTimeMin = sleepTime % 60;

          let normal_sleepTimeHourStr = sleepTimeHour.toString();
          normal_sleepTimeHourStr = normal_sleepTimeHourStr.padStart(2, '0');
          let normal_sleepTimeMinStr = sleepTimeMin.toString().padStart(2, '0');
          let normal_sleepTimeStr = normal_sleepTimeHourStr + ':' + normal_sleepTimeMinStr;
          if (normal_sleep_time_font) normal_sleep_time_font.setProperty(hmUI.prop.TEXT, normal_sleepTimeStr);

        };

        //#endregion
        function scale_call() {
            
            let valueBattery = battery.current;
            let targetBattery = 100;
            let progressBattery = valueBattery/targetBattery;
            if (progressBattery > 1) progressBattery = 1;
            let progress_cs_normal_battery = 1 - progressBattery;

            if (screenType != hmSetting.screen_type.AOD) {

              // normal_battery_circle_scale_circle_scale
              let level = Math.round(progress_cs_normal_battery * 100);
              if (normal_battery_circle_scale) {
                normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                  center_x: 240,
                  center_y: 354,
                  start_angle: 155,
                  end_angle: -152,
                  radius: 40,
                  line_width: 10,
                  corner_flag: 3,
                  color: 0xFF000000,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                  level: level,
                });
              };
            };

            let progress_cs_idle_battery = 1 - progressBattery;

            if (screenType == hmSetting.screen_type.AOD) {

              // idle_battery_circle_scale_circle_scale
              let level = Math.round(progress_cs_idle_battery * 100);
              if (idle_battery_circle_scale) {
                idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                  center_x: 240,
                  center_y: 354,
                  start_angle: 155,
                  end_angle: -152,
                  radius: 40,
                  line_width: 10,
                  corner_flag: 3,
                  color: 0xFF000000,
                  show_level: hmUI.show_level.ONLY_AOD,
                  level: level,
                });
              };
            };

        };

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {
            console.log('resume_call()');
            scale_call();
            time_update(true, true);
            sleep_update();
            if (weatherProvider) {
                weatherProvider.update(false);
            }
            updateSunBackground();
          }),
        });

            //dynamic modify end
        },
        onInit() {
            logger.log('index page.js on init invoke');
        },
        build() {
            this.init_view();
            logger.log('index page.js on ready invoke');
        },
        onDestroy() {
            if (weatherProvider) {
                weatherProvider.delete();
                weatherProvider = null;
            }              
            logger.log('index page.js on destroy invoke');
        }
    });
    ;
})();
} catch (e) {
console.log('Mini Program Error', e);
e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
;
}