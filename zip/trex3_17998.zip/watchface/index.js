﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_high_text_font = ''
        let normal_temperature_low_text_font = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_wind_text_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_year_text_font = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_altimeter_icon_img = ''
        let normal_altitude_target_text_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_humidity_text_text_img = ''
        let normal_humidity_text_separator_img = ''
        let normal_uvi_text_text_img = ''
        let normal_uvi_text_separator_img = ''
        let normal_aqi_text_text_img = ''
        let normal_aqi_text_separator_img = ''
        let normal_sun_icon_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_compass_direction_pointer_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_moon_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_altitude_jumpable_img_click = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Rajdhani-Bold.ttf; FontSize: 28
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 368,
              h: 50,
              text_size: 28,
              char_space: 1,
              line_space: 0,
              font: 'fonts/Rajdhani-Bold.ttf',
              color: 0xFFFF3131,
              align_h: hmUI.align.RIGHT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Rajdhani-Bold.ttf; FontSize: 20
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 244,
              h: 36,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Rajdhani-Bold.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["name_weather_00.png","name_weather_01.png","name_weather_02.png","name_weather_03.png","name_weather_04.png","name_weather_05.png","name_weather_06.png","name_weather_07.png","name_weather_08.png","name_weather_09.png","name_weather_10.png","name_weather_11.png","name_weather_12.png","name_weather_13.png","name_weather_14.png","name_weather_15.png","name_weather_16.png","name_weather_17.png","name_weather_18.png","name_weather_19.png","name_weather_20.png","name_weather_21.png","name_weather_22.png","name_weather_23.png","name_weather_24.png","name_weather_25.png","name_weather_26.png","name_weather_27.png","name_weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 112,
              y: 45,
              w: 85,
              h: 32,
              text_size: 22,
              char_space: 0,
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 340,
              y: 77,
              w: 60,
              h: 40,
              text_size: 28,
              char_space: 1,
              font: 'fonts/Rajdhani-Bold.ttf',
              color: 0xFFFF3131,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 282,
              y: 77,
              w: 60,
              h: 40,
              text_size: 28,
              char_space: 1,
              font: 'fonts/Rajdhani-Bold.ttf',
              color: 0xFF3E3EFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.RIGHT,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 242,
              y: 44,
              font_array: ["digits_small_00.png","digits_small_01.png","digits_small_02.png","digits_small_03.png","digits_small_04.png","digits_small_05.png","digits_small_06.png","digits_small_07.png","digits_small_08.png","digits_small_09.png"],
              padding: false,
              h_space: -8,
              imperial_unit_sc: 'digit_small_faringate.png',
              imperial_unit_tc: 'digit_small_faringate.png',
              imperial_unit_en: 'digit_small_faringate.png',
              negative_image: 'digit_small_minus.png',
              invalid_image: 'digit_small_error.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 308,
              y: 41,
              src: 'digit_small_celcium.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //#region temperatureUnit
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 242,
                y: 44,
                font_array: ["digits_small_00.png","digits_small_01.png","digits_small_02.png","digits_small_03.png","digits_small_04.png","digits_small_05.png","digits_small_06.png","digits_small_07.png","digits_small_08.png","digits_small_09.png"],
                padding: false,
                h_space: -8,
                unit_sc: 'digit_small_faringate.png',
                unit_tc: 'digit_small_faringate.png',
                unit_en: 'digit_small_faringate.png',
                negative_image: 'digit_small_minus.png',
                invalid_image: 'digit_small_error.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //#endregion

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 37,
              y: 167,
              src: 'WIND_digit_01.png',
              // alpha: 150,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img.setAlpha(150);

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 46,
              y: 190,
              image_array: ["wind_01.png","wind_02.png","wind_03.png","wind_04.png","wind_05.png","wind_06.png","wind_07.png","wind_08.png"],
              image_length: 8,
              // alpha: 150,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level.setAlpha(150);

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 10,
              y: 235,
              font_array: ["digits_small_00.png","digits_small_01.png","digits_small_02.png","digits_small_03.png","digits_small_04.png","digits_small_05.png","digits_small_06.png","digits_small_07.png","digits_small_08.png","digits_small_09.png"],
              padding: false,
              h_space: -10,
              // alpha: 200,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img.setAlpha(200);

            normal_wind_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 59,
              y: 246,
              src: 'wind_ms.png',
              // alpha: 150,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_separator_img.setAlpha(150);

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'seconds.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 228,
              y: 19,
              font_array: ["small_digit_00.png","small_digit_01.png","small_digit_02.png","small_digit_03.png","small_digit_04.png","small_digit_05.png","small_digit_06.png","small_digit_07.png","small_digit_08.png","small_digit_09.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 19,
              src: 'battery.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 86,
              y: 293,
              font_array: ["digits_small_00.png","digits_small_01.png","digits_small_02.png","digits_small_03.png","digits_small_04.png","digits_small_05.png","digits_small_06.png","digits_small_07.png","digits_small_08.png","digits_small_09.png"],
              padding: false,
              h_space: -10,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 300,
              src: 'icon_pai.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 293,
              font_array: ["digits_small_00.png","digits_small_01.png","digits_small_02.png","digits_small_03.png","digits_small_04.png","digits_small_05.png","digits_small_06.png","digits_small_07.png","digits_small_08.png","digits_small_09.png"],
              padding: false,
              h_space: -10,
              invalid_image: 'digit_small_error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 175,
              y: 300,
              src: 'icon__heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 293,
              font_array: ["digits_small_00.png","digits_small_01.png","digits_small_02.png","digits_small_03.png","digits_small_04.png","digits_small_05.png","digits_small_06.png","digits_small_07.png","digits_small_08.png","digits_small_09.png"],
              padding: false,
              h_space: -10,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 289,
              y: 300,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 351,
              day_startY: 362,
              day_sc_array: ["digits_small_00.png","digits_small_01.png","digits_small_02.png","digits_small_03.png","digits_small_04.png","digits_small_05.png","digits_small_06.png","digits_small_07.png","digits_small_08.png","digits_small_09.png"],
              day_tc_array: ["digits_small_00.png","digits_small_01.png","digits_small_02.png","digits_small_03.png","digits_small_04.png","digits_small_05.png","digits_small_06.png","digits_small_07.png","digits_small_08.png","digits_small_09.png"],
              day_en_array: ["digits_small_00.png","digits_small_01.png","digits_small_02.png","digits_small_03.png","digits_small_04.png","digits_small_05.png","digits_small_06.png","digits_small_07.png","digits_small_08.png","digits_small_09.png"],
              day_zero: 1,
              day_space: -10,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 292,
              y: 363,
              week_en: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_tc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              week_sc: ["day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 249,
              month_startY: 359,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_year_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 246,
              y: 340,
              w: 100,
              h: 30,
              text_size: 20,
              char_space: 0,
              font: 'fonts/Rajdhani-Bold.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.LEFT,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 141,
              y: 412,
              src: 'icon_stat_bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 295,
              y: 410,
              src: 'icon_stat_al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 215,
              y: 407,
              image_array: ["img_arr_0005_00.png","img_arr_0005_01.png","img_arr_0005_02.png","img_arr_0005_03.png","img_arr_0005_04.png","img_arr_0005_05.png","img_arr_0005_06.png","img_arr_0005_07.png","img_arr_0005_08.png","img_arr_0005_09.png","img_arr_0005_10.png","img_arr_0005_11.png","img_arr_0005_12.png","img_arr_0005_13.png","img_arr_0005_14.png","img_arr_0005_15.png","img_arr_0005_16.png","img_arr_0005_17.png","img_arr_0005_18.png","img_arr_0005_19.png","img_arr_0005_20.png","img_arr_0005_21.png","img_arr_0005_22.png","img_arr_0005_23.png","img_arr_0005_24.png","img_arr_0005_25.png","img_arr_0005_26.png","img_arr_0005_27.png","img_arr_0005_28.png","img_arr_0005_29.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 66,
              y: 346,
              src: 'att.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 340,
              font_array: ["digits_small_00.png","digits_small_01.png","digits_small_02.png","digits_small_03.png","digits_small_04.png","digits_small_05.png","digits_small_06.png","digits_small_07.png","digits_small_08.png","digits_small_09.png"],
              padding: false,
              h_space: -10,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 151,
              y: 378,
              font_array: ["small_digit_00.png","small_digit_01.png","small_digit_02.png","small_digit_03.png","small_digit_04.png","small_digit_05.png","small_digit_06.png","small_digit_07.png","small_digit_08.png","small_digit_09.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 198,
              y: 374,
              src: 'digit_small_hPa.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 110,
              font_array: ["digits_small_00.png","digits_small_01.png","digits_small_02.png","digits_small_03.png","digits_small_04.png","digits_small_05.png","digits_small_06.png","digits_small_07.png","digits_small_08.png","digits_small_09.png"],
              padding: false,
              h_space: -10,
              // alpha: 150,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_text_img.setAlpha(150);

            normal_humidity_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 85,
              src: 'weat_RH%.png',
              // alpha: 150,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_text_separator_img.setAlpha(150);

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 110,
              font_array: ["digits_small_00.png","digits_small_01.png","digits_small_02.png","digits_small_03.png","digits_small_04.png","digits_small_05.png","digits_small_06.png","digits_small_07.png","digits_small_08.png","digits_small_09.png"],
              padding: false,
              h_space: -10,
              invalid_image: 'digit_small_error.png',
              // alpha: 150,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img.setAlpha(150);

            normal_uvi_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 140,
              y: 85,
              src: 'weat_UVI.png',
              // alpha: 150,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_separator_img.setAlpha(150);

            normal_aqi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 56,
              y: 110,
              font_array: ["digits_small_00.png","digits_small_01.png","digits_small_02.png","digits_small_03.png","digits_small_04.png","digits_small_05.png","digits_small_06.png","digits_small_07.png","digits_small_08.png","digits_small_09.png"],
              padding: false,
              h_space: -10,
              invalid_image: 'digit_small_error.png',
              // alpha: 150,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.AQI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_aqi_text_text_img.setAlpha(150);

            normal_aqi_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 67,
              y: 85,
              src: 'weat_AQI.png',
              // alpha: 150,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_aqi_text_separator_img.setAlpha(150);

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 204,
              y: 45,
              src: 'icon_sunrise.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 385,
              am_y: 192,
              am_sc_path: 'icon_AM.png',
              am_en_path: 'icon_AM.png',
              pm_x: 385,
              pm_y: 192,
              pm_sc_path: 'icon_PM.png',
              pm_en_path: 'icon_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 115,
              hour_startY: 180,
              hour_array: ["digit_large_00.png","digit_large_01.png","digit_large_02.png","digit_large_03.png","digit_large_04.png","digit_large_05.png","digit_large_06.png","digit_large_07.png","digit_large_08.png","digit_large_09.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 260,
              minute_startY: 180,
              minute_array: ["digit_large_00.png","digit_large_01.png","digit_large_02.png","digit_large_03.png","digit_large_04.png","digit_large_05.png","digit_large_06.png","digit_large_07.png","digit_large_08.png","digit_large_09.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 385,
              second_startY: 230,
              second_array: ["digits_small_00.png","digits_small_01.png","digits_small_02.png","digits_small_03.png","digits_small_04.png","digits_small_05.png","digits_small_06.png","digits_small_07.png","digits_small_08.png","digits_small_09.png"],
              second_zero: 1,
              second_space: -10,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 175,
              src: 'digit_large_separation.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'compass.png',
              // center_x: 240,
              // center_y: 240,
              // x: 240,
              // y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //#region Compass_Pointer
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 240,
              center_x: 240,
              center_y: 240,
              src: 'compass.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //#endregion


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 115,
              hour_startY: 180,
              hour_array: ["digit_large_00.png","digit_large_01.png","digit_large_02.png","digit_large_03.png","digit_large_04.png","digit_large_05.png","digit_large_06.png","digit_large_07.png","digit_large_08.png","digit_large_09.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_angle: 0,
              alpha: 100,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 260,
              minute_startY: 180,
              minute_array: ["digit_large_00.png","digit_large_01.png","digit_large_02.png","digit_large_03.png","digit_large_04.png","digit_large_05.png","digit_large_06.png","digit_large_07.png","digit_large_08.png","digit_large_09.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_angle: 0,
              minute_follow: 0,
              // alpha: 100,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 175,
              src: 'digit_large_separation.png',
              // alpha: 100,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img.setAlpha(100);
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 284,
              y: 276,
              w: 160,
              h: 60,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 276,
              w: 114,
              h: 60,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 37,
              y: 276,
              w: 133,
              h: 60,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 172,
              y: 11,
              w: 135,
              h: 32,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 200,
              y: 43,
              w: 40,
              h: 37,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 204,
              y: 399,
              w: 72,
              h: 73,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 250,
              y: 43,
              w: 110,
              h: 37,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 69,
              y: 374,
              w: 170,
              h: 24,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 188,
              w: 270,
              h: 88,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 382,
              y: 188,
              w: 80,
              h: 88,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 278,
              y: 399,
              w: 100,
              h: 72,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altitude_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 53,
              y: 337,
              w: 186,
              h: 38,
              type: hmUI.data_type.ALTITUDE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('year font');
              if (updateHour) {
                let normal_yearStr = timeSensor.year.toString();
                normal_year_text_font.setProperty(hmUI.prop.TEXT, normal_yearStr );
              };

            };

            //#endregion
            //#region compass_update
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);

                }

              }); // Listener end

            };
            //#endregion

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}