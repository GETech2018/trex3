﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_uvi_image_progress_img_level = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_linear_scale = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_uvi_image_progress_img_level = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_heart_rate_circle_scale = ''
        let idle_heart_rate_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_calorie_linear_scale = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 70,
              y: 210,
              image_array: ["uv0.png","uv1.png","uv2.png","uv3.png","uv4.png"],
              image_length: 5,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 418,
              y: 278,
              src: 'lock.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 194,
              y: 269,
              src: 'bluetooth-of.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 224,
              y: 276,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 126,
              // center_y: 346,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 40,
              // line_width: 3,
              // line_cap: Rounded,
              // color: 0xFF16B61B,
              // mirror: False,
              // inversion: False,
              // alpha: 200,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 126,
              center_y: 346,
              start_angle: 0,
              end_angle: 360,
              radius: 39,
              line_width: 3,
              corner_flag: 0,
              color: 0xFF16B61B,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale.setAlpha(200);
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 342,
              font_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 274,
              font_array: ["mp0.png","mp1.png","mp2.png","mp3.png","mp4.png","mp5.png","mp6.png","mp7.png","mp8.png","mp9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'ml.png',
              imperial_unit_tc: 'ml.png',
              imperial_unit_en: 'ml.png',
              dot_image: 'dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 245,
              font_array: ["mp0.png","mp1.png","mp2.png","mp3.png","mp4.png","mp5.png","mp6.png","mp7.png","mp8.png","mp9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 352,
              y: 245,
              image_array: ["step001.png","step002.png","step003.png","step004.png","step005.png","step006.png","step009.png","step010.png","step07.png","step08.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 243,
              font_array: ["mp0.png","mp1.png","mp2.png","mp3.png","mp4.png","mp5.png","mp6.png","mp7.png","mp8.png","mp9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'minus.png',
              dot_image: 'colon.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 243,
              font_array: ["mp0.png","mp1.png","mp2.png","mp3.png","mp4.png","mp5.png","mp6.png","mp7.png","mp8.png","mp9.png"],
              padding: false,
              h_space: 2,
              dot_image: 'colon.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 355,
              y: 129,
              image_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 347,
              y: 184,
              font_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'celsius.png',
              unit_tc: 'celsius.png',
              unit_en: 'celsius.png',
              imperial_unit_sc: 'fareneith.png',
              imperial_unit_tc: 'fareneith.png',
              imperial_unit_en: 'fareneith.png',
              negative_image: 'minus.png',
              invalid_image: 'minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 347,
                y: 184,
                font_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'fareneith.png',
                unit_tc: 'fareneith.png',
                unit_en: 'fareneith.png',
                imperial_unit_sc: 'celsius.png',
                imperial_unit_tc: 'celsius.png',
                imperial_unit_en: 'celsius.png',
                negative_image: 'minus.png',
                invalid_image: 'minus.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 300,
              y: 165,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 64,
              y: 176,
              font_array: ["mini0.png","mini1.png","mini2.png","mini3.png","mini4.png","mini5.png","mini6.png","mini7.png","mini8.png","mini9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 113,
              y: 153,
              image_array: ["bat0.png","bat1.png","bat2.png","bat3.png","bat4.png","bat5.png","bat6.png","bat7.png","bat8.png","bat9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            normal_calorie_linear_scale.setAlpha(180);
            };

            // normal_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 105,
              // start_y: 135,
              // color: 0xFF12BA30,
              // lenght: 175,
              // line_width: 5,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 180,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 312,
              year_startY: 92,
              year_sc_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              year_tc_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              year_en_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 270,
              day_startY: 92,
              day_sc_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              day_tc_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              day_en_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 196,
              month_startY: 92,
              month_sc_array: ["mnt01.png","mnt02.png","mnt03.png","mnt04.png","mnt05.png","mnt06.png","mnt07.png","mnt08.png","mnt09.png","mnt10.png","mnt11.png","mnt12.png"],
              month_tc_array: ["mnt01.png","mnt02.png","mnt03.png","mnt04.png","mnt05.png","mnt06.png","mnt07.png","mnt08.png","mnt09.png","mnt10.png","mnt11.png","mnt12.png"],
              month_en_array: ["mnt01.png","mnt02.png","mnt03.png","mnt04.png","mnt05.png","mnt06.png","mnt07.png","mnt08.png","mnt09.png","mnt10.png","mnt11.png","mnt12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 116,
              y: 92,
              week_en: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_tc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_sc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 190,
              hour_startY: 298,
              hour_array: ["h0.png","h1.png","h2.png","h3.png","h4.png","h5.png","h6.png","h7.png","h8.png","h9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 290,
              minute_startY: 298,
              minute_array: ["h0.png","h1.png","h2.png","h3.png","h4.png","h5.png","h6.png","h7.png","h8.png","h9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 374,
              second_startY: 300,
              second_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 70,
              y: 210,
              image_array: ["uv0.png","uv1.png","uv2.png","uv3.png","uv4.png"],
              image_length: 5,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 418,
              y: 278,
              src: 'lock.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 194,
              y: 269,
              src: 'bluetooth-of.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 224,
              y: 276,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 126,
              // center_y: 346,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 40,
              // line_width: 3,
              // line_cap: Rounded,
              // color: 0xFF16B61B,
              // mirror: False,
              // inversion: False,
              // alpha: 200,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 126,
              center_y: 346,
              start_angle: 0,
              end_angle: 360,
              radius: 39,
              line_width: 3,
              corner_flag: 0,
              color: 0xFF16B61B,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_circle_scale.setAlpha(200);

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 342,
              font_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 74,
              y: 274,
              font_array: ["mp0.png","mp1.png","mp2.png","mp3.png","mp4.png","mp5.png","mp6.png","mp7.png","mp8.png","mp9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'ml.png',
              imperial_unit_tc: 'ml.png',
              imperial_unit_en: 'ml.png',
              dot_image: 'dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 245,
              font_array: ["mp0.png","mp1.png","mp2.png","mp3.png","mp4.png","mp5.png","mp6.png","mp7.png","mp8.png","mp9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 352,
              y: 245,
              image_array: ["step001.png","step002.png","step003.png","step004.png","step005.png","step006.png","step009.png","step010.png","step07.png","step08.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 96,
              y: 243,
              font_array: ["mp0.png","mp1.png","mp2.png","mp3.png","mp4.png","mp5.png","mp6.png","mp7.png","mp8.png","mp9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'minus.png',
              dot_image: 'colon.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 243,
              font_array: ["mp0.png","mp1.png","mp2.png","mp3.png","mp4.png","mp5.png","mp6.png","mp7.png","mp8.png","mp9.png"],
              padding: false,
              h_space: 2,
              dot_image: 'colon.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 355,
              y: 129,
              image_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 347,
              y: 184,
              font_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'celsius.png',
              unit_tc: 'celsius.png',
              unit_en: 'celsius.png',
              imperial_unit_sc: 'fareneith.png',
              imperial_unit_tc: 'fareneith.png',
              imperial_unit_en: 'fareneith.png',
              negative_image: 'minus.png',
              invalid_image: 'minus.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 347,
                y: 184,
                font_array: ["s0.png","s1.png","s2.png","s3.png","s4.png","s5.png","s6.png","s7.png","s8.png","s9.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'fareneith.png',
                unit_tc: 'fareneith.png',
                unit_en: 'fareneith.png',
                imperial_unit_sc: 'celsius.png',
                imperial_unit_tc: 'celsius.png',
                imperial_unit_en: 'celsius.png',
                negative_image: 'minus.png',
                invalid_image: 'minus.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //end of ignored block

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 300,
              y: 165,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 64,
              y: 176,
              font_array: ["mini0.png","mini1.png","mini2.png","mini3.png","mini4.png","mini5.png","mini6.png","mini7.png","mini8.png","mini9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 113,
              y: 153,
              image_array: ["bat0.png","bat1.png","bat2.png","bat3.png","bat4.png","bat5.png","bat6.png","bat7.png","bat8.png","bat9.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_calorie_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);

            idle_calorie_linear_scale.setAlpha(180);
            };

            // idle_calorie_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 105,
              // start_y: 135,
              // color: 0xFF12BA30,
              // lenght: 175,
              // line_width: 5,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // alpha: 180,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 312,
              year_startY: 92,
              year_sc_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              year_tc_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              year_en_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 270,
              day_startY: 92,
              day_sc_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              day_tc_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              day_en_array: ["date0.png","date1.png","date2.png","date3.png","date4.png","date5.png","date6.png","date7.png","date8.png","date9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 196,
              month_startY: 92,
              month_sc_array: ["mnt01.png","mnt02.png","mnt03.png","mnt04.png","mnt05.png","mnt06.png","mnt07.png","mnt08.png","mnt09.png","mnt10.png","mnt11.png","mnt12.png"],
              month_tc_array: ["mnt01.png","mnt02.png","mnt03.png","mnt04.png","mnt05.png","mnt06.png","mnt07.png","mnt08.png","mnt09.png","mnt10.png","mnt11.png","mnt12.png"],
              month_en_array: ["mnt01.png","mnt02.png","mnt03.png","mnt04.png","mnt05.png","mnt06.png","mnt07.png","mnt08.png","mnt09.png","mnt10.png","mnt11.png","mnt12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 116,
              y: 92,
              week_en: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_tc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_sc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 190,
              hour_startY: 298,
              hour_array: ["h0.png","h1.png","h2.png","h3.png","h4.png","h5.png","h6.png","h7.png","h8.png","h9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 290,
              minute_startY: 298,
              minute_array: ["h0.png","h1.png","h2.png","h3.png","h4.png","h5.png","h6.png","h7.png","h8.png","h9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 126,
                      center_y: 346,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 39,
                      line_width: 3,
                      corner_flag: 0,
                      color: 0xFF16B61B,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_ls_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_linear_scale
                  // initial parameters
                  let start_x_normal_calorie = 105;
                  let start_y_normal_calorie = 135;
                  let lenght_ls_normal_calorie = 175;
                  let line_width_ls_normal_calorie = 5;
                  let color_ls_normal_calorie = 0xFF12BA30;
                  
                  // calculated parameters
                  let start_x_normal_calorie_draw = start_x_normal_calorie;
                  let start_y_normal_calorie_draw = start_y_normal_calorie;
                  lenght_ls_normal_calorie = lenght_ls_normal_calorie * progress_ls_normal_calorie;
                  let lenght_ls_normal_calorie_draw = lenght_ls_normal_calorie;
                  let line_width_ls_normal_calorie_draw = line_width_ls_normal_calorie;
                  if (lenght_ls_normal_calorie < 0){
                    lenght_ls_normal_calorie_draw = -lenght_ls_normal_calorie;
                    start_x_normal_calorie_draw = start_x_normal_calorie - lenght_ls_normal_calorie_draw;
                  };
                  
                  normal_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_calorie_draw,
                    y: start_y_normal_calorie_draw,
                    w: lenght_ls_normal_calorie_draw,
                    h: line_width_ls_normal_calorie_draw,
                    color: color_ls_normal_calorie,
                  });
                };

                console.log('update scales HEART');
                let progress_cs_idle_heart_rate = progressHeartRate;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_heart_rate * 100);
                  if (idle_heart_rate_circle_scale) {
                    idle_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 126,
                      center_y: 346,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 39,
                      line_width: 3,
                      corner_flag: 0,
                      color: 0xFF16B61B,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                let progress_ls_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_linear_scale
                  // initial parameters
                  let start_x_idle_calorie = 105;
                  let start_y_idle_calorie = 135;
                  let lenght_ls_idle_calorie = 175;
                  let line_width_ls_idle_calorie = 5;
                  let color_ls_idle_calorie = 0xFF12BA30;
                  
                  // calculated parameters
                  let start_x_idle_calorie_draw = start_x_idle_calorie;
                  let start_y_idle_calorie_draw = start_y_idle_calorie;
                  lenght_ls_idle_calorie = lenght_ls_idle_calorie * progress_ls_idle_calorie;
                  let lenght_ls_idle_calorie_draw = lenght_ls_idle_calorie;
                  let line_width_ls_idle_calorie_draw = line_width_ls_idle_calorie;
                  if (lenght_ls_idle_calorie < 0){
                    lenght_ls_idle_calorie_draw = -lenght_ls_idle_calorie;
                    start_x_idle_calorie_draw = start_x_idle_calorie - lenght_ls_idle_calorie_draw;
                  };
                  
                  idle_calorie_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_calorie_draw,
                    y: start_y_idle_calorie_draw,
                    w: lenght_ls_idle_calorie_draw,
                    h: line_width_ls_idle_calorie_draw,
                    color: color_ls_idle_calorie,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}