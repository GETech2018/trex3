﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''

        let element_index = 1;  // Selected element index
        let element_count = 2;  // Number of elements

        let delay_Timer = null;
        let clicks = 0;
        let clicksDelay = 400;

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 37,
              y: 195,
              src: 'NON_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 38,
              y: 250,
              src: 'ALARM.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 152,
              y: 403,
              font_array: ["Mini001.png","Mini002.png","Mini003.png","Mini004.png","Mini005.png","Mini006.png","Mini007.png","Mini008.png","Mini009.png","Mini010.png"],
              padding: false,
              h_space: 3,
              dot_image: 'POINT.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 245,
              y: 416,
              src: 'Reddistance.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 163,
              y: 403,
              font_array: ["Mini001.png","Mini002.png","Mini003.png","Mini004.png","Mini005.png","Mini006.png","Mini007.png","Mini008.png","Mini009.png","Mini010.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
	    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 241,
              y: 416,
              src: 'Redsteps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
	    normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 177,
              y: 35,
              font_array: ["Mini001.png","Mini002.png","Mini003.png","Mini004.png","Mini005.png","Mini006.png","Mini007.png","Mini008.png","Mini009.png","Mini010.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 317,
              month_startY: 139,
              month_sc_array: ["Mini001.png","Mini002.png","Mini003.png","Mini004.png","Mini005.png","Mini006.png","Mini007.png","Mini008.png","Mini009.png","Mini010.png"],
              month_tc_array: ["Mini001.png","Mini002.png","Mini003.png","Mini004.png","Mini005.png","Mini006.png","Mini007.png","Mini008.png","Mini009.png","Mini010.png"],
              month_en_array: ["Mini001.png","Mini002.png","Mini003.png","Mini004.png","Mini005.png","Mini006.png","Mini007.png","Mini008.png","Mini009.png","Mini010.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 270,
              day_startY: 139,
              day_sc_array: ["Mini001.png","Mini002.png","Mini003.png","Mini004.png","Mini005.png","Mini006.png","Mini007.png","Mini008.png","Mini009.png","Mini010.png"],
              day_tc_array: ["Mini001.png","Mini002.png","Mini003.png","Mini004.png","Mini005.png","Mini006.png","Mini007.png","Mini008.png","Mini009.png","Mini010.png"],
              day_en_array: ["Mini001.png","Mini002.png","Mini003.png","Mini004.png","Mini005.png","Mini006.png","Mini007.png","Mini008.png","Mini009.png","Mini010.png"],
              day_zero: 0,
              day_space: 3,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 310,
              y: 139,
              src: 'POINT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 62,
              y: 139,
              week_en: ["Day001.png","Day002.png","Day003.png","Day004.png","Day005.png","Day006.png","Day007.png"],
              week_tc: ["Day001.png","Day002.png","Day003.png","Day004.png","Day005.png","Day006.png","Day007.png"],
              week_sc: ["Day001.png","Day002.png","Day003.png","Day004.png","Day005.png","Day006.png","Day007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 291,
              y: 312,
              font_array: ["Mini001.png","Mini002.png","Mini003.png","Mini004.png","Mini005.png","Mini006.png","Mini007.png","Mini008.png","Mini009.png","Mini010.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 351,
              y: 312,
              src: 'PROCENT.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 84,
              y: 312,
              image_array: ["BATT001.png","BATT002.png","BATT003.png","BATT004.png","BATT005.png","BATT006.png","BATT007.png","BATT008.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 406,
              am_y: 195,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 406,
              pm_y: 218,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 85,
              hour_startY: 188,
              hour_array: ["Big001.png","Big002.png","Big003.png","Big004.png","Big005.png","Big006.png","Big007.png","Big008.png","Big009.png","Big010.png"],
              hour_zero: 0,
              hour_space: 15,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 258,
              minute_startY: 188,
              minute_array: ["Big001.png","Big002.png","Big003.png","Big004.png","Big005.png","Big006.png","Big007.png","Big008.png","Big009.png","Big010.png"],
              minute_zero: 1,
              minute_space: 15,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 404,
              second_startY: 263,
              second_array: ["Mini001.png","Mini002.png","Mini003.png","Mini004.png","Mini005.png","Mini006.png","Mini007.png","Mini008.png","Mini009.png","Mini010.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 37,
              y: 195,
              src: 'NON_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 406,
              am_y: 195,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 406,
              pm_y: 218,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 85,
              hour_startY: 188,
              hour_array: ["Big001.png","Big002.png","Big003.png","Big004.png","Big005.png","Big006.png","Big007.png","Big008.png","Big009.png","Big010.png"],
              hour_zero: 0,
              hour_space: 15,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 258,
              minute_startY: 188,
              minute_array: ["Big001.png","Big002.png","Big003.png","Big004.png","Big005.png","Big006.png","Big007.png","Big008.png","Big009.png","Big010.png"],
              minute_zero: 1,
              minute_space: 15,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 253,
              y: 187,
              w: 144,
              h: 106,
              src: 'Null.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 91,
              y: 187,
              w: 132,
              h: 106,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 186,
              y: 0,
              w: 112,
              h: 90,
              src: 'Null.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

	      function click_btn() {  // Function to enable and disable the visibility of elements
              element_index++;
              if(element_index > element_count) element_index = 1;
              
              normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
              normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);

              normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
              normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);
              
            };


            // Button to switch elements. This block should be after all blocks with display elements.
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 161,  // x coordinate of the button
              y: 365,  // y coordinate of the button
              text: '',
              w: 160,  // button width
              h: 110,  // button height
              normal_src: '',  
              press_src: '',  
              show_level: hmUI.show_level.ONLY_NORMAL,
              click_func: () => {
                click_btn();
              }
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}