﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
try {
  (() => {
    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    function getApp() {
      return __$$app$$__.app;
    }
    function getCurrentPage() {
      return __$$app$$__.current && __$$app$$__.current.module;
    }
    const __$$module$$__ = __$$app$$__.current;
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
    const { px } = __$$app$$__.__globals__;
    const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75');

    const THEMES = {
      1: [0x00E5FF, 0xFF007F, 0x39FF14, 0xFF6600], // Яркая
      2: [0x8E8D8A, 0x4A6572, 0x6B8E23, 0x967BB6], // Спокойная  
      3: [0xFF6E6E6E, 0xFF000000]                     // Монохром
    };

    const THEME_NAMES = {
      1: 'Яркая',
      2: 'Спокойная',
      3: 'Монохром'
    };

    const IMG_SPECS = {
      'htw_': { w: 107, h: 382 },
      'htb_': { w: 107, h: 382 },
      'huw_': { w: 186, h: 182 },
      'hub_': { w: 186, h: 182 },
      'mw_':  { w: 94,  h: 206 },
      'mb_':  { w: 94,  h: 206 }
    };

    const LAYOUTS = [
      // Блок 1 (Минуты 0-4, 10-14, 20-24 ...)
      {
        white: {
          hTens:  { x: 96,  y: 47,  prefix: 'htw_' },
          hUnits: { x: 200, y: 46,  prefix: 'huw_' },
          mTens:  { x: 198, y: 224, prefix: 'mw_'  },
          mUnits: { x: 287, y: 224, prefix: 'mw_'  }
        },
        black: {
          hTens:  { x: 96,  y: 47,  prefix: 'htb_' },
          hUnits: { x: 200, y: 46,  prefix: 'hub_' },
          mTens:  { x: 198, y: 224, prefix: 'mb_'  },
          mUnits: { x: 287, y: 224, prefix: 'mb_'  }
        }
      },
      // Блок 2 (Минуты 5-9, 15-19, 25-29 ...)
      {
        white: {
          hTens:  { x: 93,  y: 44,  prefix: 'mw_'  },
          hUnits: { x: 183, y: 44,  prefix: 'mw_'  },
          mTens:  { x: 96,  y: 248, prefix: 'huw_' },
          mUnits: { x: 277, y: 47,  prefix: 'htw_' }
        },
        black: {
          hTens:  { x: 93,  y: 44,  prefix: 'mb_'  },
          hUnits: { x: 183, y: 44,  prefix: 'mb_'  },
          mTens:  { x: 96,  y: 248, prefix: 'hub_' },
          mUnits: { x: 277, y: 47,  prefix: 'htb_' }
        }
      }
    ];

    const DIGIT_KEYS = ['hTens', 'hUnits', 'mTens', 'mUnits'];

    let normal_background_bg = '';
    let normal_second_curtain = '';
    
    let base_img_widgets = {};
    let overlay_img_widgets = {};
    let normal_timerTimeUpdate = undefined;

    let idle_background_bg = '';
    let idle_img_widgets = {};
    let idle_timerTimeUpdate = undefined;
    
    let timeSensor = '';
    let lastMinute = -1;
    let currentTheme = 1;
    let currentColor = 0x000000;
    let prevColor = 0x000000;

    function getSavedTheme() {
      try {
        let val = hmFS.SysProGetInt('WatchTheme');
        if (val && val >= 1 && val <= 3) return val;
      } catch (e) {}
      return 1;
    }

    function saveTheme(theme) {
      try {
        hmFS.SysProSetInt('WatchTheme', theme);
      } catch (e) {}
    }

    __$$module$$__.module = DeviceRuntimeCore.WatchFace({
      init_view() {
        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

        currentTheme = getSavedTheme();

        normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          x: 0, y: 0, w: 480, h: 480, color: prevColor,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_second_curtain = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          x: 0, y: 0, w: 480, h: 0, color: currentColor,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        DIGIT_KEYS.forEach(key => {
          base_img_widgets[key] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0, y: 0,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
        });

        DIGIT_KEYS.forEach(key => {
          overlay_img_widgets[key] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0, y: 0, h: 0,
            show_level: hmUI.show_level.ONLY_NORMAL,
          });
        });

        hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 210, y: 210, w: 60, h: 60, text: '',
          normal_src: '', press_src: '',
          click_func: () => {
            currentTheme = (currentTheme % 3) + 1;
            saveTheme(currentTheme);
            lastMinute = -1;
            time_update(true, true);
            hmUI.showToast({ text: `Тема: ${THEME_NAMES[currentTheme]}` });
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });

        idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
          x: 0, y: 0, w: 480, h: 480, color: 0x000000,
          show_level: hmUI.show_level.ONLY_AOD,
        });

        DIGIT_KEYS.forEach(key => {
          idle_img_widgets[key] = hmUI.createWidget(hmUI.widget.IMG, {
            x: 0, y: 0,
            show_level: hmUI.show_level.ONLY_AOD,
          });
        });

        //#region time_update
        function time_update(updateHour = false, updateMinute = false) {
          let minute = timeSensor.minute;
          let second = timeSensor.second;

          let hourVal = (timeSensor.format_hour !== undefined) ? timeSensor.format_hour : timeSensor.hour;

          let hStr = String(hourVal).padStart(2, '0');
          let mStr = String(minute).padStart(2, '0');

          let timeVals = {
            hTens: hStr[0],
            hUnits: hStr[1],
            mTens: mStr[0],
            mUnits: mStr[1]
          };

          let layoutIndex = Math.floor(minute / 5) % 2;
          let currentLayout = LAYOUTS[layoutIndex];
          let palette = THEMES[currentTheme];

          if (lastMinute !== minute || updateMinute || updateHour) {
            if (lastMinute !== -1 && lastMinute !== minute) {
              prevColor = currentColor;
              currentColor = palette[minute % palette.length];
            } else {
              let prevMin = (minute - 1 + 60) % 60;
              prevColor = palette[prevMin % palette.length];
              currentColor = palette[minute % palette.length];
            }
            lastMinute = minute;

            normal_background_bg.setProperty(hmUI.prop.COLOR, prevColor);
            normal_second_curtain.setProperty(hmUI.prop.COLOR, currentColor);

            DIGIT_KEYS.forEach(key => {
              let val = timeVals[key];
              let whiteCfg = currentLayout.white[key];
              let spec = IMG_SPECS[whiteCfg.prefix];

              idle_img_widgets[key].setProperty(hmUI.prop.MORE, {
                x: whiteCfg.x,
                y: whiteCfg.y,
                w: spec.w,
                h: spec.h,
                src: `${whiteCfg.prefix}${val}.png`
              });
            });
          }

          let activeScreen = hmSetting.getScreenType();
          if (activeScreen === hmSetting.screen_type.WATCHFACE) {
            let max_h = 480;
            let step = max_h / 60;
            let currentHeight = (second + 1) * step;
            let isEven = (minute % 2 === 0);
            let curtainY, curtainH, splitY;

            if (isEven) {
              curtainY = 0;
              curtainH = currentHeight;
              splitY = curtainH;
            } else {
              curtainY = max_h - currentHeight;
              curtainH = currentHeight;
              splitY = curtainY;
            }

            normal_second_curtain.setProperty(hmUI.prop.MORE, {
              x: 0, y: curtainY, w: 480, h: curtainH
            });

            DIGIT_KEYS.forEach(key => {
              let val = timeVals[key];
              let whiteCfg = currentLayout.white[key];
              let blackCfg = currentLayout.black[key];

              let whiteSpec = IMG_SPECS[whiteCfg.prefix];
              let blackSpec = IMG_SPECS[blackCfg.prefix];

              base_img_widgets[key].setProperty(hmUI.prop.MORE, {
                x: whiteCfg.x,
                y: whiteCfg.y,
                w: whiteSpec.w,
                h: whiteSpec.h,
                src: `${whiteCfg.prefix}${val}.png`
              });

              let overlayH = Math.max(0, Math.min(blackSpec.h, splitY - blackCfg.y));

              if (overlayH > 0) {
                overlay_img_widgets[key].setProperty(hmUI.prop.MORE, {
                  x: blackCfg.x,
                  y: blackCfg.y,
                  w: blackSpec.w,
                  h: overlayH,
                  src: `${blackCfg.prefix}${val}.png`
                });
              } else {
                overlay_img_widgets[key].setProperty(hmUI.prop.MORE, {
                  x: blackCfg.x,
                  y: blackCfg.y,
                  w: blackSpec.w,
                  h: 0,
                  src: ''
                });
              }
            });
          }
        }
        //#endregion

        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {            
            if (normal_timerTimeUpdate) {
                timer.stopTimer(normal_timerTimeUpdate);
                normal_timerTimeUpdate = undefined;
            }
            if (idle_timerTimeUpdate) {
                timer.stopTimer(idle_timerTimeUpdate);
                idle_timerTimeUpdate = undefined;
            }

            let activeScreen = hmSetting.getScreenType();
            lastMinute = -1;
            time_update(true, true);

            if (activeScreen === hmSetting.screen_type.WATCHFACE) {
                normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                time_update(false, false);
                }));
            } else if (activeScreen === hmSetting.screen_type.AOD) {
                let secondsLeft = 60 - timeSensor.second;
                let initialDelay = (secondsLeft > 0 ? secondsLeft : 60) * 1000;

                idle_timerTimeUpdate = timer.createTimer(initialDelay, 60000, (function (option) {
                time_update(true, true);
                }));
            }
          }),
          pause_call: (function () {
            if (normal_timerTimeUpdate) {
              timer.stopTimer(normal_timerTimeUpdate);
              normal_timerTimeUpdate = undefined;
            }
            if (idle_timerTimeUpdate) {
              timer.stopTimer(idle_timerTimeUpdate);
              idle_timerTimeUpdate = undefined;
            }
          }),
        });
      },
      onInit() {
        logger.log('index page.js on init invoke');
      },
      build() {
        this.init_view();
        logger.log('index page.js on ready invoke');
      },
      onDestroy() {
        logger.log('index page.js on destroy invoke');
      }
    });
  })();
} catch (e) {
  console.log('Mini Program Error', e);
  e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}