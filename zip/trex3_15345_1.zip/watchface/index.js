﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_calorie_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 19,
              font_array: ["Nr. Attività_01.png","Nr. Attività_02.png","Nr. Attività_03.png","Nr. Attività_04.png","Nr. Attività_05.png","Nr. Attività_06.png","Nr. Attività_07.png","Nr. Attività_08.png","Nr. Attività_09.png","Nr. Attività_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 163,
              y: 72,
              font_array: ["Nr. Attività_01.png","Nr. Attività_02.png","Nr. Attività_03.png","Nr. Attività_04.png","Nr. Attività_05.png","Nr. Attività_06.png","Nr. Attività_07.png","Nr. Attività_08.png","Nr. Attività_09.png","Nr. Attività_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Nr. Attività_14.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 128,
              font_array: ["Nr. Attività_01.png","Nr. Attività_02.png","Nr. Attività_03.png","Nr. Attività_04.png","Nr. Attività_05.png","Nr. Attività_06.png","Nr. Attività_07.png","Nr. Attività_08.png","Nr. Attività_09.png","Nr. Attività_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 359,
              y: 315,
              font_array: ["Nr. Sistema_01.png","Nr. Sistema_02.png","Nr. Sistema_03.png","Nr. Sistema_04.png","Nr. Sistema_05.png","Nr. Sistema_06.png","Nr. Sistema_07.png","Nr. Sistema_08.png","Nr. Sistema_09.png","Nr. Sistema_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Nr. Sistema_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 29,
              y: 315,
              font_array: ["Nr. Sistema_01.png","Nr. Sistema_02.png","Nr. Sistema_03.png","Nr. Sistema_04.png","Nr. Sistema_05.png","Nr. Sistema_06.png","Nr. Sistema_07.png","Nr. Sistema_08.png","Nr. Sistema_09.png","Nr. Sistema_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 132,
              y: 315,
              week_en: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_tc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_sc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 383,
              month_startY: 185,
              month_sc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_tc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_en_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 376,
              day_startY: 247,
              day_sc_array: ["Nr. Giorni_01.png","Nr. Giorni_02.png","Nr. Giorni_03.png","Nr. Giorni_04.png","Nr. Giorni_05.png","Nr. Giorni_06.png","Nr. Giorni_07.png","Nr. Giorni_08.png","Nr. Giorni_09.png","Nr. Giorni_10.png"],
              day_tc_array: ["Nr. Giorni_01.png","Nr. Giorni_02.png","Nr. Giorni_03.png","Nr. Giorni_04.png","Nr. Giorni_05.png","Nr. Giorni_06.png","Nr. Giorni_07.png","Nr. Giorni_08.png","Nr. Giorni_09.png","Nr. Giorni_10.png"],
              day_en_array: ["Nr. Giorni_01.png","Nr. Giorni_02.png","Nr. Giorni_03.png","Nr. Giorni_04.png","Nr. Giorni_05.png","Nr. Giorni_06.png","Nr. Giorni_07.png","Nr. Giorni_08.png","Nr. Giorni_09.png","Nr. Giorni_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 144,
              y: 373,
              image_array: ["0200.png","0201.png","0202.png","0203.png","0204.png","0205.png","0206.png","0207.png","0208.png","0209.png","0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png","0218.png","0219.png","0220.png","0221.png","0222.png","0223.png","0224.png","0225.png","0226.png","0227.png","0228.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 387,
              font_array: ["Nr. Sistema_01.png","Nr. Sistema_02.png","Nr. Sistema_03.png","Nr. Sistema_04.png","Nr. Sistema_05.png","Nr. Sistema_06.png","Nr. Sistema_07.png","Nr. Sistema_08.png","Nr. Sistema_09.png","Nr. Sistema_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Nr. Sistema_13.png',
              unit_tc: 'Nr. Sistema_13.png',
              unit_en: 'Nr. Sistema_13.png',
              imperial_unit_sc: 'Nr. Sistema_13.png',
              imperial_unit_tc: 'Nr. Sistema_13.png',
              imperial_unit_en: 'Nr. Sistema_13.png',
              negative_image: 'Nr. Sistema_11.png',
              invalid_image: 'Nr. Sistema_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 209,
                y: 387,
                font_array: ["Nr. Sistema_01.png","Nr. Sistema_02.png","Nr. Sistema_03.png","Nr. Sistema_04.png","Nr. Sistema_05.png","Nr. Sistema_06.png","Nr. Sistema_07.png","Nr. Sistema_08.png","Nr. Sistema_09.png","Nr. Sistema_10.png"],
                padding: false,
                h_space: 2,
                unit_sc: 'Nr. Sistema_13.png',
                unit_tc: 'Nr. Sistema_13.png',
                unit_en: 'Nr. Sistema_13.png',
                imperial_unit_sc: 'Nr. Sistema_13.png',
                imperial_unit_tc: 'Nr. Sistema_13.png',
                imperial_unit_en: 'Nr. Sistema_13.png',
                negative_image: 'Nr. Sistema_11.png',
                invalid_image: 'Nr. Sistema_12.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 13,
              hour_startY: 187,
              hour_array: ["Nr. Ore_01.png","Nr. Ore_02.png","Nr. Ore_03.png","Nr. Ore_04.png","Nr. Ore_05.png","Nr. Ore_06.png","Nr. Ore_07.png","Nr. Ore_08.png","Nr. Ore_09.png","Nr. Ore_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 202,
              minute_startY: 187,
              minute_array: ["Nr. Ore_01.png","Nr. Ore_02.png","Nr. Ore_03.png","Nr. Ore_04.png","Nr. Ore_05.png","Nr. Ore_06.png","Nr. Ore_07.png","Nr. Ore_08.png","Nr. Ore_09.png","Nr. Ore_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 19,
              font_array: ["Nr. Attività_01.png","Nr. Attività_02.png","Nr. Attività_03.png","Nr. Attività_04.png","Nr. Attività_05.png","Nr. Attività_06.png","Nr. Attività_07.png","Nr. Attività_08.png","Nr. Attività_09.png","Nr. Attività_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 163,
              y: 72,
              font_array: ["Nr. Attività_01.png","Nr. Attività_02.png","Nr. Attività_03.png","Nr. Attività_04.png","Nr. Attività_05.png","Nr. Attività_06.png","Nr. Attività_07.png","Nr. Attività_08.png","Nr. Attività_09.png","Nr. Attività_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Nr. Attività_14.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 128,
              font_array: ["Nr. Attività_01.png","Nr. Attività_02.png","Nr. Attività_03.png","Nr. Attività_04.png","Nr. Attività_05.png","Nr. Attività_06.png","Nr. Attività_07.png","Nr. Attività_08.png","Nr. Attività_09.png","Nr. Attività_10.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 359,
              y: 315,
              font_array: ["Nr. Sistema_01.png","Nr. Sistema_02.png","Nr. Sistema_03.png","Nr. Sistema_04.png","Nr. Sistema_05.png","Nr. Sistema_06.png","Nr. Sistema_07.png","Nr. Sistema_08.png","Nr. Sistema_09.png","Nr. Sistema_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Nr. Sistema_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 29,
              y: 315,
              font_array: ["Nr. Sistema_01.png","Nr. Sistema_02.png","Nr. Sistema_03.png","Nr. Sistema_04.png","Nr. Sistema_05.png","Nr. Sistema_06.png","Nr. Sistema_07.png","Nr. Sistema_08.png","Nr. Sistema_09.png","Nr. Sistema_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 132,
              y: 315,
              week_en: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_tc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_sc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 383,
              month_startY: 185,
              month_sc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_tc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_en_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 376,
              day_startY: 247,
              day_sc_array: ["Nr. Giorni_01.png","Nr. Giorni_02.png","Nr. Giorni_03.png","Nr. Giorni_04.png","Nr. Giorni_05.png","Nr. Giorni_06.png","Nr. Giorni_07.png","Nr. Giorni_08.png","Nr. Giorni_09.png","Nr. Giorni_10.png"],
              day_tc_array: ["Nr. Giorni_01.png","Nr. Giorni_02.png","Nr. Giorni_03.png","Nr. Giorni_04.png","Nr. Giorni_05.png","Nr. Giorni_06.png","Nr. Giorni_07.png","Nr. Giorni_08.png","Nr. Giorni_09.png","Nr. Giorni_10.png"],
              day_en_array: ["Nr. Giorni_01.png","Nr. Giorni_02.png","Nr. Giorni_03.png","Nr. Giorni_04.png","Nr. Giorni_05.png","Nr. Giorni_06.png","Nr. Giorni_07.png","Nr. Giorni_08.png","Nr. Giorni_09.png","Nr. Giorni_10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 144,
              y: 373,
              image_array: ["0200.png","0201.png","0202.png","0203.png","0204.png","0205.png","0206.png","0207.png","0208.png","0209.png","0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png","0218.png","0219.png","0220.png","0221.png","0222.png","0223.png","0224.png","0225.png","0226.png","0227.png","0228.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 387,
              font_array: ["Nr. Sistema_01.png","Nr. Sistema_02.png","Nr. Sistema_03.png","Nr. Sistema_04.png","Nr. Sistema_05.png","Nr. Sistema_06.png","Nr. Sistema_07.png","Nr. Sistema_08.png","Nr. Sistema_09.png","Nr. Sistema_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Nr. Sistema_13.png',
              unit_tc: 'Nr. Sistema_13.png',
              unit_en: 'Nr. Sistema_13.png',
              imperial_unit_sc: 'Nr. Sistema_13.png',
              imperial_unit_tc: 'Nr. Sistema_13.png',
              imperial_unit_en: 'Nr. Sistema_13.png',
              negative_image: 'Nr. Sistema_11.png',
              invalid_image: 'Nr. Sistema_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 209,
                y: 387,
                font_array: ["Nr. Sistema_01.png","Nr. Sistema_02.png","Nr. Sistema_03.png","Nr. Sistema_04.png","Nr. Sistema_05.png","Nr. Sistema_06.png","Nr. Sistema_07.png","Nr. Sistema_08.png","Nr. Sistema_09.png","Nr. Sistema_10.png"],
                padding: false,
                h_space: 2,
                unit_sc: 'Nr. Sistema_13.png',
                unit_tc: 'Nr. Sistema_13.png',
                unit_en: 'Nr. Sistema_13.png',
                imperial_unit_sc: 'Nr. Sistema_13.png',
                imperial_unit_tc: 'Nr. Sistema_13.png',
                imperial_unit_en: 'Nr. Sistema_13.png',
                negative_image: 'Nr. Sistema_11.png',
                invalid_image: 'Nr. Sistema_12.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //end of ignored block

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 13,
              hour_startY: 187,
              hour_array: ["Nr. Ore_01.png","Nr. Ore_02.png","Nr. Ore_03.png","Nr. Ore_04.png","Nr. Ore_05.png","Nr. Ore_06.png","Nr. Ore_07.png","Nr. Ore_08.png","Nr. Ore_09.png","Nr. Ore_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 202,
              minute_startY: 187,
              minute_array: ["Nr. Ore_01.png","Nr. Ore_02.png","Nr. Ore_03.png","Nr. Ore_04.png","Nr. Ore_05.png","Nr. Ore_06.png","Nr. Ore_07.png","Nr. Ore_08.png","Nr. Ore_09.png","Nr. Ore_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}