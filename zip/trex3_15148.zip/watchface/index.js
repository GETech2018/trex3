/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_battery_imageset2 = '';
		let normal_battery_imagecombo3 = '';
		let normal_date_imagecombo5 = '';
		let normal_month_imageset6 = '';
		let normal_hour_imagecombo8 = '';
		let normal_minute_imagecombo9 = '';
		let normal_img10 = '';
		let normal_second_imagecombo11 = '';
		let normal_img13 = '';
		let normal_sunrise_text14 = '';
		let normal_img15 = '';
		let normal_sunset_text16 = '';
		let normal_weather_imageset18 = '';
		let normal_temperature_current_imagecombo19 = '';
		let normal_img21 = '';
		let normal_moonset_text22 = '';
		let normal_moonrise_text23 = '';
		let normal_img24 = '';
		let normal_steps_imagecombo26 = '';
		let normal_img27 = '';
		let normal_heart_current_imagecombo29 = '';
		let normal_img30 = '';
		let normal_heartrate_linegraph31 = '';
		let normal_img33 = '';
		let normal_img34 = '';
		let idle_hour_imagecombo36 = '';
		let idle_minute_imagecombo37 = '';
		let idle_img39 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imageset2 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 351,
					y: 104,
					image_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png"],
					image_length: 11,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo3 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 378,
					y: 203,
					font_array: ["0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png"],
					padding: false,
					h_space: 0,
					unit_sc: '0024.png',
					unit_tc: '0024.png',
					unit_en: '0024.png',
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo5 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 270,
					day_startY: 65,
					day_sc_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
					day_tc_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
					day_en_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.LEFT,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset6 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 319,
					month_startY: 65,
					month_sc_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png"],
					month_tc_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png"],
					month_en_array: ["0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo8 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 46,
					hour_startY: 136,
					hour_array: ["0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo9 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 181,
					minute_startY: 139,
					minute_array: ["0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 161,
					y: 141,
					w: 13,
					h: 78,
					src: '0067.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo11 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 290,
					second_startY: 160,
					second_array: ["0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 43,
					y: 106,
					w: 32,
					h: 24,
					src: '0078.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sunrise_text14 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 81,
					y: 110,
					w: 100,
					h: 20,
					color: 0x000000,
					text_size: 20,
					align_h: hmUI.align.LEFT,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Roboto-Medium.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img15 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 144,
					y: 107,
					w: 32,
					h: 24,
					src: '0079.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_sunset_text16 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 178,
					y: 110,
					w: 100,
					h: 20,
					color: 0x000000,
					text_size: 20,
					align_h: hmUI.align.LEFT,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Roboto-Medium.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset18 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 133,
					y: 25,
					image_array: ["0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0082.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0086.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png","0106.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo19 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 193,
					y: 36,
					font_array: ["0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0118.png"],
					unit_tc: ["0118.png"],
					unit_en: ["0118.png"],
					negative_image: ["0117.png"],
					invalid_image: ["0119.png"],
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img21 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 10,
					y: 244,
					w: 32,
					h: 24,
					src: '0120.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_moonset_text22 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 156,
					y: 249,
					w: 100,
					h: 20,
					color: 0x000000,
					text_size: 20,
					align_h: hmUI.align.LEFT,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Roboto-Medium.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_moonrise_text23 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 44,
					y: 250,
					w: 100,
					h: 20,
					color: 0x000000,
					text_size: 20,
					align_h: hmUI.align.LEFT,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/Roboto-Medium.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img24 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 120,
					y: 246,
					w: 32,
					h: 24,
					src: '0121.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo26 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 133,
					y: 397,
					font_array: ["0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png"],
					padding: true,
					h_space: 0,
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img27 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 244,
					y: 406,
					w: 85,
					h: 26,
					src: '0132.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo29 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 257,
					y: 302,
					font_array: ["0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png"],
					padding: false,
					h_space: 0,
					invalid_image: '0143.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img30 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 282,
					y: 250,
					w: 43,
					h: 40,
					src: '0144.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heartrate_linegraph31 = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, {
					x: 22,
					y: 280,
					w: 224,
					h: 49,
					line_color: 0xFF0000,
					line_width: 1,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img33 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 65,
					y: 342,
					w: 146,
					h: 27,
					src: '0145.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img34 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 379,
					y: 196,
					w: 101,
					h: 117,
					src: '0146.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_hour_imagecombo36 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 110,
					hour_startY: 186,
					hour_array: ["0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo37 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 259,
					minute_startY: 186,
					minute_array: ["0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img39 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 230,
					y: 172,
					w: 20,
					h: 120,
					src: '0157.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateWeather() {
					let tideData = weatherSensor.getForecastWeather().tideData;
					normal_sunrise_text14.setProperty(hmUI.prop.TEXT, tideData.data[0].sunrise.hour.toString().padStart(2, '0') + ':' + tideData.data[0].sunrise.minute.toString().padStart(2, '0'));
					normal_sunset_text16.setProperty(hmUI.prop.TEXT, tideData.data[0].sunset.hour.toString().padStart(2, '0') + ':' + tideData.data[0].sunset.minute.toString().padStart(2, '0'));
					normal_moonset_text22.setProperty(hmUI.prop.TEXT, tideData.data[0].moonset.hour.toString().padStart(2, '0') + ':' + tideData.data[0].moonset.minute.toString().padStart(2, '0'));
					normal_moonrise_text23.setProperty(hmUI.prop.TEXT, tideData.data[0].moonrise.hour.toString().padStart(2, '0') + ':' + tideData.data[0].moonrise.minute.toString().padStart(2, '0'));
				}

				weatherSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateWeather();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						updateWeather();
					}),
					pause_call: (function () {
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
		},
	});	})()
} catch (e) {
	console.log(e)
}