/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_week_imageset2 = '';
		let normal_img3 = '';
		let normal_date_imagecombo4 = '';
		let normal_month_imageset5 = '';
		let normal_battery_imagecombo7 = '';
		let normal_battery_imageset8 = '';
		let normal_steps_imagecombo10 = '';
		let normal_steps_imageset11 = '';
		let normal_distance_imagecombo13 = '';
		let normal_heart_rate_imageset15 = '';
		let normal_heart_current_imagecombo16 = '';
		let normal_hour_imagecombo18 = '';
		let normal_minute_imagecombo19 = '';
		let normal_second_imagecombo20 = '';
		let normal_ampm_imageset21 = '';
		let normal_pai_imagecombo23 = '';
		let normal_user_nickname_text25 = '';
		let normal_weather_shortcut28 = '';
		let normal_steps_shortcut29 = '';
		let normal_alarm_shortcut30 = '';
		let normal_heart_shortcut31 = '';
		let normal_flashlight32 = '';
		let screen_brightness = 0;
		let normal_sleep_shortcut33 = '';
		let normal_altimeter_shortcut34 = '';
		let normal_stress_shortcut35 = '';
		let idle_img37 = '';
		let idle_hour_imagecombo39 = '';
		let idle_minute_imagecombo40 = '';
		let idle_ampm_imageset41 = '';
		let idle_battery_imagecombo43 = '';
		let normal_flashlight_foreground = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const vibrateSensor = hmSensor.createSensor(hmSensor.id.VIBRATE);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_week_imageset2 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
					x: 68,
					y: 71,
					week_en: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png"],
					week_tc: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png"],
					week_sc: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png"],
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 70,
					y: 97,
					w: 339,
					h: 30,
					src: '0010.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_date_imagecombo4 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 176,
					day_startY: 44,
					day_sc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					day_tc_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					day_en_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
					day_zero: true,
					day_space: 0,
					day_align: hmUI.align.RIGHT,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset5 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 230,
					month_startY: 44,
					month_sc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					month_tc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					month_en_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo7 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 381,
					y: 155,
					font_array: ["0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png"],
					padding: true,
					h_space: 0,
					unit_sc: '0043.png',
					unit_tc: '0043.png',
					unit_en: '0043.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imageset8 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 303,
					y: 128,
					image_array: ["0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png"],
					image_length: 11,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo10 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 100,
					y: 278,
					font_array: ["0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png"],
					padding: true,
					h_space: 0,
					align_h: hmUI.align.RIGHT,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imageset11 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 42,
					y: 250,
					image_array: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png"],
					image_length: 11,
					type: hmUI.data_type.STEP,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo13 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 84,
					y: 342,
					font_array: ["0076.png","0077.png","0078.png","0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png"],
					padding: false,
					h_space: 0,
					dot_image: '0086.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_rate_imageset15 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 288,
					y: 300,
					image_array: ["0087.png","0088.png","0089.png","0090.png","0091.png","0092.png"],
					image_length: 6,
					type: hmUI.data_type.HEART,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo16 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 303,
					y: 342,
					font_array: ["0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png"],
					padding: false,
					h_space: 0,
					invalid_image: '0103.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo18 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 31,
					hour_startY: 145,
					hour_array: ["0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.RIGHT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo19 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 159,
					minute_startY: 145,
					minute_array: ["0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo20 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 278,
					second_startY: 149,
					second_array: ["0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_ampm_imageset21 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					am_x: 240,
					am_y: 232,
					am_sc_path: '0124.png',
					am_en_path: '0124.png',
					pm_x: 240,
					pm_y: 232,
					pm_sc_path: '0125.png',
					pm_en_path: '0125.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_pai_imagecombo23 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 206,
					y: 342,
					font_array: ["0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.PAI_DAILY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_user_nickname_text25 = hmUI.createWidget(hmUI.widget.TEXT, {
					x: 199,
					y: 426,
					w: 116,
					h: 19,
					color: 0xA1A1A1,
					text_size: 19,
					align_h: hmUI.align.LEFT,
					align_v: hmUI.align.CENTER_V,
					text_style: hmUI.text_style.NONE,
					font: 'fonts/MicroFLF.ttf',
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_shortcut28 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 0,
					y: 241,
					w: 62,
					h: 103,
					src: '',
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_shortcut29 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 68,
					y: 239,
					w: 160,
					h: 103,
					src: '',
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_alarm_shortcut30 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 31,
					y: 350,
					w: 103,
					h: 103,
					src: '',
					type: hmUI.data_type.ALARM_CLOCK,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_shortcut31 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 273,
					y: 268,
					w: 126,
					h: 83,
					src: '',
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_flashlight32 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 353,
					y: 358,
					w: 103,
					h: 103,
					src: '',
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				normal_flashlight32.addEventListener(hmUI.event.CLICK_UP, (info) => {
					screen_brightness = hmSetting.getBrightness();
					hmSetting.setBrightness(100);
					normal_flashlight_foreground.setProperty(hmUI.prop.VISIBLE, true);
					hmUI.showToast({
						text: 'Flashlight On'
					});
					vibrateSensor.stop();
					vibrateSensor.scene = 25;
					vibrateSensor.start();
				});

				normal_sleep_shortcut33 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 407,
					y: 241,
					w: 74,
					h: 103,
					src: '',
					type: hmUI.data_type.SLEEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_altimeter_shortcut34 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 132,
					y: 408,
					w: 103,
					h: 72,
					src: '',
					type: hmUI.data_type.ALTIMETER,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_stress_shortcut35 = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
					x: 246,
					y: 408,
					w: 103,
					h: 72,
					src: '',
					type: hmUI.data_type.STRESS,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_img37 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0136.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_hour_imagecombo39 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 31,
					hour_startY: 145,
					hour_array: ["0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.RIGHT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo40 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 159,
					minute_startY: 145,
					minute_array: ["0137.png","0138.png","0139.png","0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_ampm_imageset41 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					am_x: 240,
					am_y: 232,
					am_sc_path: '0147.png',
					am_en_path: '0147.png',
					pm_x: 240,
					pm_y: 232,
					pm_sc_path: '0148.png',
					pm_en_path: '0148.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_battery_imagecombo43 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 381,
					y: 155,
					font_array: ["0149.png","0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png"],
					padding: true,
					h_space: 0,
					unit_sc: '0159.png',
					unit_tc: '0159.png',
					unit_en: '0159.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				normal_flashlight_foreground = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0160.png',
					show_level: hmUI.show_level.ONLY_NORMAL
				});

				normal_flashlight_foreground.setProperty(hmUI.prop.VISIBLE, false);

				normal_flashlight_foreground.addEventListener(hmUI.event.CLICK_DOWN, (info) => {
					hmSetting.setBrightness(screen_brightness);
					normal_flashlight_foreground.setProperty(hmUI.prop.VISIBLE, false);
					hmUI.showToast({
						text: 'Flashlight Off'
					});
					vibrateSensor.stop();
					vibrateSensor.scene = 25;
					vibrateSensor.start();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						normal_user_nickname_text25.setProperty(hmUI.prop.TEXT, hmSetting.getUserData().nickName.toString());
					}),
					pause_call: (function () {
						hmSetting.setBrightScreenCancel();
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
						hmSetting.setBrightScreenCancel();
		},
	});	})()
} catch (e) {
	console.log(e)
}