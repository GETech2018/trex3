
try {
  (() => {
  
const { beforeModuleCreate = () => {}, afterModuleCreate = () => {} } = DeviceRuntimeCore.LifeCycle;
beforeModuleCreate();

const { beforePageCreate = () => {}, afterPageCreate = () => {} } = DeviceRuntimeCore.LifeCycle;
beforePageCreate();
const __$$G$$__ = __$$hmAppManager$$__.currentApp.current.__globals__.__$$G$$__;

!function (context) {
  with (context) {
    const __$$RQR$$__ = __$$R$$__;
    
__$$app$$__.app = App({
    globalData: {},
    onCreate(options) {
    },
    onDestroy(options) {
    }
});
const logger = Logger.getLogger('trex3_v4');
const IMG = name => 'images/' + name;
const COLORS = {
    white: 16777215,
    dim: 10528948,
    green: 3988580,
    lime: 9895740,
    yellow: 16762920,
    orange: 16747520,
    red: 16729680,
    cyan: 3328255,
    blue: 4621055,
    purple: 11822335,
    grey: 3948616,
    dark: 1184792,
    card: 1842722
};
const DATA_CELLS = [
    {
        key: 'bodybat',
        label: '身体电量',
        icon: 'icon_bodybat.png',
        color: COLORS.green
    },
    {
        key: 'hrv',
        label: 'HRV',
        icon: 'icon_hrv.png',
        color: COLORS.purple
    },
    {
        key: 'stress',
        label: '压力',
        icon: 'icon_stress.png',
        color: COLORS.orange
    },
    {
        key: 'kcal_active',
        label: '动态卡',
        icon: 'icon_kcal_active.png',
        color: COLORS.yellow
    },
    {
        key: 'kcal_rest',
        label: '静态卡',
        icon: 'icon_kcal_rest.png',
        color: 7896712
    },
    {
        key: 'pai',
        label: 'PAI',
        icon: 'icon_pai.png',
        color: COLORS.cyan
    },
    {
        key: 'sleep',
        label: '睡眠',
        icon: 'icon_sleep.png',
        color: COLORS.blue
    },
    {
        key: 'tload',
        label: '负荷',
        icon: 'icon_tload.png',
        color: COLORS.red
    },
    {
        key: 'steps',
        label: '步数',
        icon: 'icon_steps.png',
        color: COLORS.lime
    }
];
const HR_BARS = 24;
const HR_BAR_W = 14;
const HR_BAR_GAP = 3;
const HR_CHART_X = 44;
const HR_CHART_Y = 236;
const HR_CHART_H = 58;
__$$module$$__.module = WatchFace({
    init_view() {
        const isAOD = hmSetting.getScreenType() === hmSetting.screen_type.AOD;
        if (isAOD) {
            this._buildAOD();
            return;
        }
        this._buildNormal();
        this._startTimers();
    },
    _buildNormal() {
        hmUI.createWidget(hmUI.widget.IMG, {
            x: 0,
            y: 0,
            w: 480,
            h: 480,
            src: IMG('background.png'),
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        this.arcImg = hmUI.createWidget(hmUI.widget.IMG, {
            x: 20,
            y: -6,
            w: 440,
            h: 240,
            src: IMG('arc_70.png'),
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        this.batText = hmUI.createWidget(hmUI.widget.TEXT, {
            x: 220,
            y: 16,
            w: 40,
            h: 26,
            text: '--',
            color: COLORS.green,
            text_size: 20,
            align_h: hmUI.align.CENTER_H,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG, {
            x: 46,
            y: 54,
            w: 20,
            h: 20,
            src: IMG('icon_sunrise.png'),
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        this.sunriseText = hmUI.createWidget(hmUI.widget.TEXT, {
            x: 70,
            y: 54,
            w: 70,
            h: 22,
            text: '06:11',
            color: COLORS.dim,
            text_size: 17,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG, {
            x: 376,
            y: 54,
            w: 20,
            h: 20,
            src: IMG('icon_sunset.png'),
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        this.sunsetText = hmUI.createWidget(hmUI.widget.TEXT, {
            x: 400,
            y: 54,
            w: 70,
            h: 22,
            text: '17:47',
            color: COLORS.dim,
            text_size: 17,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG, {
            x: 229,
            y: 52,
            w: 22,
            h: 22,
            src: IMG('icon_weather.png'),
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        this.weatherText = hmUI.createWidget(hmUI.widget.TEXT, {
            x: 210,
            y: 78,
            w: 60,
            h: 24,
            text: '--\xB0',
            color: COLORS.yellow,
            text_size: 20,
            align_h: hmUI.align.CENTER_H,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        this.timeImgs = [];
        const timeSeq = [
            0,
            0,
            10,
            0,
            0
        ];
        const timeXs = [
            88,
            142,
            190,
            238,
            292
        ];
        for (let i = 0; i < 5; i++) {
            this.timeImgs.push(hmUI.createWidget(hmUI.widget.IMG, {
                x: timeXs[i],
                y: 96,
                w: timeSeq[i] === 10 ? 18 : 54,
                h: 90,
                src: IMG(timeSeq[i] === 10 ? 'digit_colon.png' : 'digit_0.png'),
                show_level: hmUI.show_level.ONLY_NORMAL
            }));
        }
        this.secText = hmUI.createWidget(hmUI.widget.TEXT, {
            x: 330,
            y: 108,
            w: 50,
            h: 26,
            text: '00',
            color: COLORS.cyan,
            text_size: 22,
            align_h: hmUI.align.CENTER_H,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        this.dateText = hmUI.createWidget(hmUI.widget.TEXT, {
            x: 0,
            y: 196,
            w: 480,
            h: 22,
            text: '',
            color: COLORS.dim,
            text_size: 19,
            align_h: hmUI.align.CENTER_H,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG, {
            x: 34,
            y: 212,
            w: 412,
            h: 96,
            src: IMG('hr_chart_bg.png'),
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.IMG, {
            x: 46,
            y: 222,
            w: 18,
            h: 18,
            src: IMG('icon_heart.png'),
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        hmUI.createWidget(hmUI.widget.TEXT, {
            x: 70,
            y: 223,
            w: 100,
            h: 18,
            text: '今日心率',
            color: COLORS.dim,
            text_size: 15,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        this.hrNowText = hmUI.createWidget(hmUI.widget.TEXT, {
            x: 360,
            y: 221,
            w: 70,
            h: 20,
            text: '-- bpm',
            color: COLORS.red,
            text_size: 17,
            align_h: hmUI.align.RIGHT,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
        this.hrBars = [];
        for (let i = 0; i < HR_BARS; i++) {
            this.hrBars.push(hmUI.createWidget(hmUI.widget.FILL_RECT, {
                x: HR_CHART_X + i * (HR_BAR_W + HR_BAR_GAP),
                y: HR_CHART_Y + HR_CHART_H,
                w: HR_BAR_W,
                h: 0,
                color: COLORS.green,
                show_level: hmUI.show_level.ONLY_NORMAL
            }));
        }
        this.cellTexts = [];
        const cellW = 128, cellH = 48;
        const x0 = 42, y0 = 310;
        DATA_CELLS.forEach((item, i) => {
            const row = Math.floor(i / 3);
            const col = i % 3;
            const x = x0 + col * (cellW + 6);
            const y = y0 + row * (cellH + 5);
            hmUI.createWidget(hmUI.widget.IMG, {
                x,
                y,
                w: cellW,
                h: cellH,
                src: IMG('hr_chart_bg.png'),
                show_level: hmUI.show_level.ONLY_NORMAL
            });
            hmUI.createWidget(hmUI.widget.IMG, {
                x: x + 8,
                y: y + 7,
                w: 16,
                h: 16,
                src: IMG(item.icon),
                show_level: hmUI.show_level.ONLY_NORMAL
            });
            hmUI.createWidget(hmUI.widget.TEXT, {
                x: x + 28,
                y: y + 7,
                w: 80,
                h: 16,
                text: item.label,
                color: COLORS.dim,
                text_size: 12,
                show_level: hmUI.show_level.ONLY_NORMAL
            });
            const valText = hmUI.createWidget(hmUI.widget.TEXT, {
                x: x + 8,
                y: y + 23,
                w: 110,
                h: 22,
                text: '--',
                color: item.color,
                text_size: 19,
                show_level: hmUI.show_level.ONLY_NORMAL
            });
            this.cellTexts.push(valText);
        });
        this.runText = hmUI.createWidget(hmUI.widget.TEXT, {
            x: 0,
            y: 476,
            w: 480,
            h: 16,
            text: '月跑量 -- km \xB7 今日 -- km',
            color: COLORS.dim,
            text_size: 13,
            align_h: hmUI.align.CENTER_H,
            show_level: hmUI.show_level.ONLY_NORMAL
        });
    },
    _buildAOD() {
        hmUI.createWidget(hmUI.widget.FILL_RECT, {
            x: 0,
            y: 0,
            w: 480,
            h: 480,
            color: 0,
            show_level: hmUI.show_level.ONAL_AOD
        });
        const xs = [
            160,
            196,
            226,
            256,
            286
        ];
        for (let i = 0; i < 5; i++) {
            hmUI.createWidget(hmUI.widget.IMG, {
                x: xs[i],
                y: 214,
                w: i === 2 ? 14 : 28,
                h: 52,
                src: IMG(i === 2 ? 'aod_colon.png' : 'aod_digit_0.png'),
                show_level: hmUI.show_level.ONAL_AOD
            });
        }
        hmUI.createWidget(hmUI.widget.FILL_RECT, {
            x: 236,
            y: 286,
            w: 8,
            h: 8,
            color: 5001820,
            show_level: hmUI.show_level.ONAL_AOD
        });
    },
    _startTimers() {
        this._refreshTime();
        this._refreshData();
        this._refreshHRChart();
        timer.createTimer(1000, 1000, () => {
            this._refreshTime();
        }, {});
        timer.createTimer(60000, 60000, () => {
            this._sampleHR();
            this._refreshHRChart();
            this._refreshData();
        }, {});
        this._sampleHR();
    },
    _refreshTime() {
        const now = new Date();
        const h = now.getHours();
        const m = now.getMinutes();
        const s = now.getSeconds();
        const seq = [
            Math.floor(h / 10),
            h % 10,
            10,
            Math.floor(m / 10),
            m % 10
        ];
        for (let i = 0; i < 5; i++) {
            this.timeImgs[i].setProperty(hmUI.prop.SRC, IMG(seq[i] === 10 ? 'digit_colon.png' : `digit_${ seq[i] }.png`));
        }
        this.secText.setProperty(hmUI.prop.TEXT, s.toString().padStart(2, '0'));
        const weekDays = [
            '周日',
            '周一',
            '周二',
            '周三',
            '周四',
            '周五',
            '周六'
        ];
        this.dateText.setProperty(hmUI.prop.TEXT, `${ now.getMonth() + 1 }\u6708${ now.getDate() }\u65E5 ${ weekDays[now.getDay()] }`);
    },
    _readSensor(id, field) {
        try {
            const s = hmSensor.getSensor(id);
            if (!s)
                return null;
            return field ? s[field] : s.current;
        } catch (e) {
            return null;
        }
    },
    _refreshData() {
        const bat = hmSetting.getBattery();
        this.batText.setProperty(hmUI.prop.TEXT, bat + '%');
        const arcPct = Math.round(bat / 5) * 5;
        this.arcImg.setProperty(hmUI.prop.SRC, IMG(`arc_${ arcPct }.png`));
        const hr = this._readSensor(hmSensor.id.HEART) || 0;
        this.hrNowText.setProperty(hmUI.prop.TEXT, hr ? `${ hr } bpm` : '-- bpm');
        const vals = [
            this._readSensor(hmSensor.id.BODY_BATTERY),
            this._readSensor(hmSensor.id.HRV),
            this._readSensor(hmSensor.id.STRESS),
            this._readSensor(hmSensor.id.CALORIE, 'sport'),
            this._readSensor(hmSensor.id.CALORIE, 'rest'),
            this._readSensor(hmSensor.id.PAI),
            this._readSensor(hmSensor.id.SLEEP, 'totalTime'),
            this._readSensor(hmSensor.id.SPORT, 'trainingLoad'),
            this._readSensor(hmSensor.id.STEP)
        ];
        this.cellTexts.forEach((w2, i) => {
            w2.setProperty(hmUI.prop.TEXT, this._fmtVal(vals[i], DATA_CELLS[i].key));
        });
        const sport = hmSensor.getSensor(hmSensor.id.SPORT);
        const dist = sport && sport.distance ? (sport.distance / 1000).toFixed(2) : '0.00';
        this.runText.setProperty(hmUI.prop.TEXT, `\u6708\u8DD1\u91CF -- km \xB7 \u4ECA\u65E5 ${ dist } km`);
        const w = this._readSensor(hmSensor.id.WEATHER, 'currentTemperature');
        if (w !== null && w !== '--') {
            this.weatherText.setProperty(hmUI.prop.TEXT, `${ w }\xB0`);
        }
    },
    _fmtVal(v, key) {
        if (v === null || v === void 0 || v === '--')
            return '--';
        const n = Number(v);
        if (key === 'hrv')
            return `${ Math.round(n) }ms`;
        if (key === 'sleep')
            return this._fmtSleep(n);
        if (key === 'kcal_active' || key === 'kcal_rest')
            return `${ Math.round(n) }`;
        if (n >= 1000)
            return Math.round(n).toLocaleString();
        return String(Math.round(n));
    },
    _fmtSleep(minutes) {
        if (!minutes || minutes === '--')
            return '--';
        const h = Math.floor(minutes / 60);
        const m = minutes % 60;
        return `${ h }.${ Math.round(m * 10 / 60) }h`;
    },
    _sampleHR() {
        const now = new Date();
        const hour = now.getHours();
        const hr = this._readSensor(hmSensor.id.HEART) || 0;
        if (!hr)
            return;
        let sum = hmFS.SysProGetInt(`hrs${ hour }`) || 0;
        let cnt = hmFS.SysProGetInt(`hrc${ hour }`) || 0;
        sum += hr;
        cnt += 1;
        hmFS.SysProSetInt(`hrs${ hour }`, sum);
        hmFS.SysProSetInt(`hrc${ hour }`, cnt);
        hmFS.SysProSetInt(`hr${ hour }`, Math.round(sum / cnt));
    },
    _refreshHRChart() {
        const maxHR = 200;
        for (let i = 0; i < HR_BARS; i++) {
            const avg = hmFS.SysProGetInt(`hr${ i }`) || 0;
            let h = 0;
            if (avg > 0) {
                h = Math.max(4, Math.round(avg / maxHR * HR_CHART_H));
            }
            const y = HR_CHART_Y + HR_CHART_H - h;
            let col = COLORS.green;
            if (avg > 100)
                col = COLORS.yellow;
            if (avg > 140)
                col = COLORS.red;
            this.hrBars[i].setProperty(hmUI.prop.MORE, {
                x: HR_CHART_X + i * (HR_BAR_W + HR_BAR_GAP),
                y,
                w: HR_BAR_W,
                h,
                color: col
            });
        }
    },
    onInit() {
        logger.log('T-Rex3 v4 init');
    },
    build() {
        this.init_view();
    },
    onDestroy() {
        logger.log('destroy');
    }
});
;
  }
}.bind(__$$G$$__)(__$$G$$__);
afterPageCreate();
afterModuleCreate();
;
  })();
} catch(e) {
  
console.log('Mini Program Error', e);
e && e.stack && e.stack.split(/\n/).forEach(i => console.log("error stack", i));
;
/* todo */
}