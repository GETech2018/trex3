﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_city_name_text = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_battery_circle_scale = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_heart_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 390,
              y: 125,
              src: 'ikony_03.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 68,
              y: 125,
              src: 'ikony_02.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: '0001alarm.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 228,
              y: 38,
              src: 'ikony_01.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 163,
              y: 270,
              w: 159,
              h: 32,
              text_size: 23,
              char_space: 0,
              color: 0xFFC0C0C0,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 343,
              y: 188,
              image_array: ["pogoda_01.png","pogoda_02.png","pogoda_03.png","pogoda_04.png","pogoda_05.png","pogoda_06.png","pogoda_07.png","pogoda_08.png","pogoda_09.png","pogoda_10.png","pogoda_11.png","pogoda_12.png","pogoda_13.png","pogoda_14.png","pogoda_15.png","pogoda_16.png","pogoda_17.png","pogoda_18.png","pogoda_19.png","pogoda_20.png","pogoda_21.png","pogoda_22.png","pogoda_23.png","pogoda_24.png","pogoda_25.png","pogoda_26.png","pogoda_27.png","pogoda_28.png","pogoda_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 341,
              y: 245,
              font_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              padding: false,
              h_space: 0,
              negative_image: 'cyfr_sr_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 311,
              // center_y: 112,
              // start_angle: 0,
              // end_angle: 359,
              // radius: 60,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFFAE0000,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 311,
              center_y: 112,
              start_angle: 0,
              end_angle: 359,
              radius: 58,
              line_width: 5,
              corner_flag: 0,
              color: 0xFFAE0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 105,
              font_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 117,
              y: 105,
              font_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'cyfr_sr_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 100,
              // center_y: 235,
              // start_angle: 0,
              // end_angle: 359,
              // radius: 64,
              // line_width: 5,
              // line_cap: Rounded,
              // color: 0xFF717171,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 100,
              center_y: 235,
              start_angle: 0,
              end_angle: 359,
              radius: 62,
              line_width: 5,
              corner_flag: 0,
              color: 0xFF717171,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 37,
              y: 226,
              font_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 348,
              year_startY: 324,
              year_sc_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              year_tc_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              year_en_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 272,
              month_startY: 324,
              month_sc_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              month_tc_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              month_en_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 320,
              y: 325,
              src: 'cyfr_mini_13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 191,
              day_startY: 324,
              day_sc_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              day_tc_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              day_en_array: ["cyfr_mini_00.png","cyfr_mini_01.png","cyfr_mini_02.png","cyfr_mini_03.png","cyfr_mini_04.png","cyfr_mini_05.png","cyfr_mini_06.png","cyfr_mini_07.png","cyfr_mini_08.png","cyfr_mini_09.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 243,
              y: 325,
              src: 'cyfr_mini_13.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 47,
              y: 322,
              week_en: ["DnTyg_1.png","DnTyg_2.png","DnTyg_3.png","DnTyg_4.png","DnTyg_5.png","DnTyg_6.png","DnTyg_7.png"],
              week_tc: ["DnTyg_1.png","DnTyg_2.png","DnTyg_3.png","DnTyg_4.png","DnTyg_5.png","DnTyg_6.png","DnTyg_7.png"],
              week_sc: ["DnTyg_1.png","DnTyg_2.png","DnTyg_3.png","DnTyg_4.png","DnTyg_5.png","DnTyg_6.png","DnTyg_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 164,
              hour_startY: 389,
              hour_array: ["cyfr_sr_01.png","cyfr_sr_02.png","cyfr_sr_03.png","cyfr_sr_04.png","cyfr_sr_05.png","cyfr_sr_06.png","cyfr_sr_07.png","cyfr_sr_08.png","cyfr_sr_09.png","cyfr_sr_10.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 250,
              minute_startY: 389,
              minute_array: ["cyfr_sr_01.png","cyfr_sr_02.png","cyfr_sr_03.png","cyfr_sr_04.png","cyfr_sr_05.png","cyfr_sr_06.png","cyfr_sr_07.png","cyfr_sr_08.png","cyfr_sr_09.png","cyfr_sr_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 230,
              y: 384,
              src: 'cyfr_sr_12.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'wskaz_n_1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 26,
              hour_posY: 241,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'wskaz_n_2.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 26,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'wskaz_n_3.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 26,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 239,
              // line_width: 7,
              // line_cap: Rounded,
              // color: 0xFF008800,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 0,
              end_angle: 360,
              radius: 236,
              line_width: 7,
              corner_flag: 0,
              color: 0xFF008800,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod_tarcza.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aod_wskaz_01.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 16,
              hour_posY: 239,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aod_wskaz_02.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 16,
              minute_posY: 239,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 256,
              y: 61,
              w: 111,
              h: 103,
              src: 'puste.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 117,
              y: 58,
              w: 106,
              h: 106,
              src: 'puste.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 243,
              y: 381,
              w: 130,
              h: 89,
              src: 'puste.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 104,
              y: 381,
              w: 130,
              h: 89,
              src: 'puste.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 313,
              y: 164,
              w: 132,
              h: 70,
              src: 'puste.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 313,
              y: 238,
              w: 132,
              h: 60,
              src: 'puste.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 49,
              y: 181,
              w: 106,
              h: 106,
              src: 'puste.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {
              console.log('scale_call()');

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              let normal_cityNameStr = weatherData.cityName;
              normal_city_name_text.setProperty(hmUI.prop.TEXT, normal_cityNameStr);

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 311,
                      center_y: 112,
                      start_angle: 0,
                      end_angle: 359,
                      radius: 58,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFFAE0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 100,
                      center_y: 235,
                      start_angle: 0,
                      end_angle: 359,
                      radius: 62,
                      line_width: 5,
                      corner_flag: 0,
                      color: 0xFF717171,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 236,
                      line_width: 7,
                      corner_flag: 0,
                      color: 0xFF008800,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}