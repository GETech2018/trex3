﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_high_TextRotate = new Array(4);
        let normal_temperature_high_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_high_TextRotate_img_width = 14;
        let normal_temperature_high_TextRotate_unit = null;
        let normal_temperature_high_TextRotate_unit_width = 14;
        let normal_temperature_high_TextRotate_dot_width = 8;
        let normal_temperature_high_TextRotate_error_img_width = 25;
        let normal_temperature_low_TextRotate = new Array(4);
        let normal_temperature_low_TextRotate_ASCIIARRAY = new Array(10);
        let normal_temperature_low_TextRotate_img_width = 14;
        let normal_temperature_low_TextRotate_unit = null;
        let normal_temperature_low_TextRotate_unit_width = 14;
        let normal_temperature_low_TextRotate_dot_width = 8;
        let normal_temperature_low_TextRotate_error_img_width = 25;
        let normal_temperature_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_calorie_TextRotate = new Array(4);
        let normal_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let normal_calorie_TextRotate_img_width = 14;
        let normal_calorie_TextRotate_unit = null;
        let normal_calorie_TextRotate_unit_width = 39;
        let normal_calorie_TextRotate_error_img_width = 25;
        let normal_distance_TextRotate = new Array(5);
        let normal_distance_TextRotate_ASCIIARRAY = new Array(10);
        let normal_distance_TextRotate_img_width = 14;
        let normal_distance_TextRotate_unit = null;
        let normal_distance_TextRotate_unit_width = 39;
        let normal_distance_TextRotate_dot_width = 5;
        let normal_distance_TextRotate_error_img_width = 25;
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_high_TextRotate = new Array(4);
        let idle_temperature_high_TextRotate_ASCIIARRAY = new Array(10);
        let idle_temperature_high_TextRotate_img_width = 14;
        let idle_temperature_high_TextRotate_unit = null;
        let idle_temperature_high_TextRotate_unit_width = 14;
        let idle_temperature_high_TextRotate_dot_width = 8;
        let idle_temperature_high_TextRotate_error_img_width = 25;
        let idle_temperature_low_TextRotate = new Array(4);
        let idle_temperature_low_TextRotate_ASCIIARRAY = new Array(10);
        let idle_temperature_low_TextRotate_img_width = 14;
        let idle_temperature_low_TextRotate_unit = null;
        let idle_temperature_low_TextRotate_unit_width = 14;
        let idle_temperature_low_TextRotate_dot_width = 8;
        let idle_temperature_low_TextRotate_error_img_width = 25;
        let idle_temperature_current_text_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_calorie_TextRotate = new Array(4);
        let idle_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let idle_calorie_TextRotate_img_width = 14;
        let idle_calorie_TextRotate_unit = null;
        let idle_calorie_TextRotate_unit_width = 39;
        let idle_calorie_TextRotate_error_img_width = 25;
        let idle_distance_TextRotate = new Array(5);
        let idle_distance_TextRotate_ASCIIARRAY = new Array(10);
        let idle_distance_TextRotate_img_width = 14;
        let idle_distance_TextRotate_unit = null;
        let idle_distance_TextRotate_unit_width = 39;
        let idle_distance_TextRotate_dot_width = 5;
        let idle_distance_TextRotate_error_img_width = 25;
        let idle_step_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 431,
              y: 264,
              src: 'Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 384,
              y: 264,
              src: 'Sveglia.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 146,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'Sistema_13.png',
              dot_image: 'Sistema_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 337,
              y: 146,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'Sistema_13.png',
              dot_image: 'Sistema_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 146,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Sistema_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 300,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_temperature_high_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 339,
              // y: 428,
              // font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: -28,
              // unit_en: 'Sistema_17.png',
              // imperial_unit_en: 'Sistema_17.png',
              // negative_image: 'Sistema_18.png',
              // invalid_image: 'Sistema_13.png',
              // dot_image: 'Sistema_18.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_high_TextRotate_ASCIIARRAY[0] = 'Sistema_01.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[1] = 'Sistema_02.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[2] = 'Sistema_03.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[3] = 'Sistema_04.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[4] = 'Sistema_05.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[5] = 'Sistema_06.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[6] = 'Sistema_07.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[7] = 'Sistema_08.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[8] = 'Sistema_09.png';  // set of images with numbers
            normal_temperature_high_TextRotate_ASCIIARRAY[9] = 'Sistema_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_temperature_high_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 339,
                center_y: 428,
                pos_x: 339,
                pos_y: 428,
                angle: -28,
                src: 'Sistema_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_high_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 339,
              center_y: 428,
              pos_x: 339,
              pos_y: 428,
              angle: -28,
              src: 'Sistema_17.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            const temperatureUnit = hmSetting.getTemperatureUnit();
            if (temperatureUnit == 1) {
              normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Sistema_17.png');
            };
            //end of ignored block
            const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            // normal_temperature_low_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 130,
              // y: 425,
              // font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 28,
              // unit_en: 'Sistema_16.png',
              // imperial_unit_en: 'Sistema_16.png',
              // negative_image: 'Sistema_18.png',
              // invalid_image: 'Sistema_13.png',
              // dot_image: 'Sistema_18.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_temperature_low_TextRotate_ASCIIARRAY[0] = 'Sistema_01.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[1] = 'Sistema_02.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[2] = 'Sistema_03.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[3] = 'Sistema_04.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[4] = 'Sistema_05.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[5] = 'Sistema_06.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[6] = 'Sistema_07.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[7] = 'Sistema_08.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[8] = 'Sistema_09.png';  // set of images with numbers
            normal_temperature_low_TextRotate_ASCIIARRAY[9] = 'Sistema_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_temperature_low_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 130,
                center_y: 425,
                pos_x: 130,
                pos_y: 425,
                angle: 28,
                src: 'Sistema_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_temperature_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_temperature_low_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 130,
              center_y: 425,
              pos_x: 130,
              pos_y: 425,
              angle: 28,
              src: 'Sistema_16.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (temperatureUnit == 1) {
              normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Sistema_16.png');
            };
            //end of ignored block

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 443,
              font_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png","Passi_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Passi_12.png',
              unit_tc: 'Passi_12.png',
              unit_en: 'Passi_12.png',
              imperial_unit_sc: 'Passi_13.png',
              imperial_unit_tc: 'Passi_13.png',
              imperial_unit_en: 'Passi_13.png',
              negative_image: 'Passi_14.png',
              invalid_image: 'Passi_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 187,
                y: 443,
                font_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png","Passi_10.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Passi_13.png',
                unit_tc: 'Passi_13.png',
                unit_en: 'Passi_13.png',
                imperial_unit_sc: 'Passi_12.png',
                imperial_unit_tc: 'Passi_12.png',
                imperial_unit_en: 'Passi_12.png',
                negative_image: 'Passi_14.png',
                invalid_image: 'Passi_11.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 380,
              font_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png","Passi_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 291,
              y: 384,
              image_array: ["Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png","Batt_06.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 347,
              // y: 33,
              // font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 32,
              // unit_en: 'Sistema_15.png',
              // invalid_image: 'Sistema_13.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextRotate_ASCIIARRAY[0] = 'Sistema_01.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = 'Sistema_02.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = 'Sistema_03.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = 'Sistema_04.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = 'Sistema_05.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = 'Sistema_06.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = 'Sistema_07.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = 'Sistema_08.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = 'Sistema_09.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = 'Sistema_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 347,
                center_y: 33,
                pos_x: 347,
                pos_y: 33,
                angle: 32,
                src: 'Sistema_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_calorie_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 347,
              center_y: 33,
              pos_x: 347,
              pos_y: 33,
              angle: 32,
              src: 'Sistema_15.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_calorie_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 92,
              // y: 58,
              // font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: -35,
              // unit_en: 'Sistema_14.png',
              // negative_image: 'Sistema_11.png',
              // invalid_image: 'Sistema_13.png',
              // dot_image: 'Sistema_11.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextRotate_ASCIIARRAY[0] = 'Sistema_01.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = 'Sistema_02.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = 'Sistema_03.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = 'Sistema_04.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = 'Sistema_05.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = 'Sistema_06.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = 'Sistema_07.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = 'Sistema_08.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = 'Sistema_09.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = 'Sistema_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 92,
                center_y: 58,
                pos_x: 92,
                pos_y: 58,
                angle: -35,
                src: 'Sistema_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 92,
              center_y: 58,
              pos_x: 92,
              pos_y: 58,
              angle: -35,
              src: 'Sistema_14.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 68,
              font_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png","Passi_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 321,
              day_startY: 332,
              day_sc_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png","Passi_10.png"],
              day_tc_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png","Passi_10.png"],
              day_en_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png","Passi_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 93,
              y: 330,
              week_en: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_tc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_sc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 10,
              hour_startY: 185,
              hour_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              hour_zero: 1,
              hour_space: 13,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 208,
              minute_startY: 185,
              minute_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              minute_zero: 1,
              minute_space: 13,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 382,
              second_startY: 185,
              second_array: ["Secondi_01.png","Secondi_02.png","Secondi_03.png","Secondi_04.png","Secondi_05.png","Secondi_06.png","Secondi_07.png","Secondi_08.png","Secondi_09.png","Secondi_10.png"],
              second_zero: 1,
              second_space: 8,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 180,
              y: 185,
              src: 'Ore_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 431,
              y: 264,
              src: 'Off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 384,
              y: 264,
              src: 'Sveglia.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 75,
              y: 146,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'Sistema_13.png',
              dot_image: 'Sistema_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 337,
              y: 146,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'Sistema_13.png',
              dot_image: 'Sistema_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 146,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Sistema_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 300,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_temperature_high_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 339,
              // y: 428,
              // font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: -28,
              // unit_en: 'Sistema_17.png',
              // imperial_unit_en: 'Sistema_17.png',
              // negative_image: 'Sistema_18.png',
              // invalid_image: 'Sistema_13.png',
              // dot_image: 'Sistema_18.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_HIGH,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_temperature_high_TextRotate_ASCIIARRAY[0] = 'Sistema_01.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[1] = 'Sistema_02.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[2] = 'Sistema_03.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[3] = 'Sistema_04.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[4] = 'Sistema_05.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[5] = 'Sistema_06.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[6] = 'Sistema_07.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[7] = 'Sistema_08.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[8] = 'Sistema_09.png';  // set of images with numbers
            idle_temperature_high_TextRotate_ASCIIARRAY[9] = 'Sistema_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_temperature_high_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 339,
                center_y: 428,
                pos_x: 339,
                pos_y: 428,
                angle: -28,
                src: 'Sistema_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_temperature_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_temperature_high_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 339,
              center_y: 428,
              pos_x: 339,
              pos_y: 428,
              angle: -28,
              src: 'Sistema_17.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (temperatureUnit == 1) {
              idle_temperature_high_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Sistema_17.png');
            };
            //end of ignored block

            // idle_temperature_low_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 130,
              // y: 425,
              // font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: 28,
              // unit_en: 'Sistema_16.png',
              // imperial_unit_en: 'Sistema_16.png',
              // negative_image: 'Sistema_18.png',
              // invalid_image: 'Sistema_13.png',
              // dot_image: 'Sistema_18.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.WEATHER_LOW,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_temperature_low_TextRotate_ASCIIARRAY[0] = 'Sistema_01.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[1] = 'Sistema_02.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[2] = 'Sistema_03.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[3] = 'Sistema_04.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[4] = 'Sistema_05.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[5] = 'Sistema_06.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[6] = 'Sistema_07.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[7] = 'Sistema_08.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[8] = 'Sistema_09.png';  // set of images with numbers
            idle_temperature_low_TextRotate_ASCIIARRAY[9] = 'Sistema_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_temperature_low_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 130,
                center_y: 425,
                pos_x: 130,
                pos_y: 425,
                angle: 28,
                src: 'Sistema_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_temperature_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_temperature_low_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 130,
              center_y: 425,
              pos_x: 130,
              pos_y: 425,
              angle: 28,
              src: 'Sistema_16.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (temperatureUnit == 1) {
              idle_temperature_low_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Sistema_16.png');
            };
            //end of ignored block

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 443,
              font_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png","Passi_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Passi_12.png',
              unit_tc: 'Passi_12.png',
              unit_en: 'Passi_12.png',
              imperial_unit_sc: 'Passi_13.png',
              imperial_unit_tc: 'Passi_13.png',
              imperial_unit_en: 'Passi_13.png',
              negative_image: 'Passi_14.png',
              invalid_image: 'Passi_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 187,
                y: 443,
                font_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png","Passi_10.png"],
                padding: false,
                h_space: 0,
                unit_sc: 'Passi_13.png',
                unit_tc: 'Passi_13.png',
                unit_en: 'Passi_13.png',
                imperial_unit_sc: 'Passi_12.png',
                imperial_unit_tc: 'Passi_12.png',
                imperial_unit_en: 'Passi_12.png',
                negative_image: 'Passi_14.png',
                invalid_image: 'Passi_11.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //end of ignored block

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 380,
              font_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png","Passi_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 291,
              y: 384,
              image_array: ["Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png","Batt_06.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 347,
              // y: 33,
              // font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 0,
              // angle: 32,
              // unit_en: 'Sistema_15.png',
              // invalid_image: 'Sistema_13.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_TextRotate_ASCIIARRAY[0] = 'Sistema_01.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[1] = 'Sistema_02.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[2] = 'Sistema_03.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[3] = 'Sistema_04.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[4] = 'Sistema_05.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[5] = 'Sistema_06.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[6] = 'Sistema_07.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[7] = 'Sistema_08.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[8] = 'Sistema_09.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[9] = 'Sistema_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 347,
                center_y: 33,
                pos_x: 347,
                pos_y: 33,
                angle: 32,
                src: 'Sistema_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_calorie_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 347,
              center_y: 33,
              pos_x: 347,
              pos_y: 33,
              angle: 32,
              src: 'Sistema_15.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_calorie_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            // idle_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 92,
              // y: 58,
              // font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 1,
              // angle: -35,
              // unit_en: 'Sistema_14.png',
              // negative_image: 'Sistema_11.png',
              // invalid_image: 'Sistema_13.png',
              // dot_image: 'Sistema_11.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_distance_TextRotate_ASCIIARRAY[0] = 'Sistema_01.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[1] = 'Sistema_02.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[2] = 'Sistema_03.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[3] = 'Sistema_04.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[4] = 'Sistema_05.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[5] = 'Sistema_06.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[6] = 'Sistema_07.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[7] = 'Sistema_08.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[8] = 'Sistema_09.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[9] = 'Sistema_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 92,
                center_y: 58,
                pos_x: 92,
                pos_y: 58,
                angle: -35,
                src: 'Sistema_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 92,
              center_y: 58,
              pos_x: 92,
              pos_y: 58,
              angle: -35,
              src: 'Sistema_14.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
            //end of ignored block

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 68,
              font_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png","Passi_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 321,
              day_startY: 332,
              day_sc_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png","Passi_10.png"],
              day_tc_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png","Passi_10.png"],
              day_en_array: ["Passi_01.png","Passi_02.png","Passi_03.png","Passi_04.png","Passi_05.png","Passi_06.png","Passi_07.png","Passi_08.png","Passi_09.png","Passi_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 93,
              y: 330,
              week_en: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_tc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              week_sc: ["Giorno_01.png","Giorno_02.png","Giorno_03.png","Giorno_04.png","Giorno_05.png","Giorno_06.png","Giorno_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 10,
              hour_startY: 185,
              hour_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              hour_zero: 1,
              hour_space: 13,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 208,
              minute_startY: 185,
              minute_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              minute_zero: 1,
              minute_space: 13,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 180,
              y: 185,
              src: 'Ore_11.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();
            //start of ignored block
            function text_update() {
              console.log('text_update()');
              let weatherData = weatherSensor.getForecastWeather();
              let forecastData = weatherData.forecastData;
              let temperature_high_temp = -100;
              if (forecastData.count > 0) {
                temperature_high_temp = forecastData.data[0].high;
              }; // end forecastData;

              console.log('update text rotate temperature_high_forecastData');
              let temperatureHigh = undefined;
              let normal_temperature_high_rotate_string = undefined;
              if (temperature_high_temp > -100) {
                temperatureHigh = 0;
                normal_temperature_high_rotate_string = String(temperature_high_temp)
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && normal_temperature_high_rotate_string.length > 0 && normal_temperature_high_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_temperature_high_TextRotate_posOffset = normal_temperature_high_TextRotate_img_width * normal_temperature_high_rotate_string.length;
                  normal_temperature_high_TextRotate_posOffset = normal_temperature_high_TextRotate_posOffset + 2 * (normal_temperature_high_rotate_string.length - 1);
                  img_offset -= normal_temperature_high_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_high_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 339 + img_offset);
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_high_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_high_TextRotate_img_width + 2;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 339 + img_offset);
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.SRC, 'Sistema_18.png');
                      normal_temperature_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_high_TextRotate_dot_width + 2;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.POS_X, 339 + img_offset);
                  normal_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_temperature_high_TextRotate[0].setProperty(hmUI.prop.POS_X, 339 - normal_temperature_high_TextRotate_error_img_width / 2);
                  normal_temperature_high_TextRotate[0].setProperty(hmUI.prop.SRC, 'Sistema_13.png');
                  normal_temperature_high_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };
              let temperature_low_temp = -100;
              if (forecastData.count > 0) {
                temperature_low_temp = forecastData.data[0].low;
              }; // end forecastData;

              console.log('update text rotate temperature_low_forecastData');
              let temperatureLow = undefined;
              let normal_temperature_low_rotate_string = undefined;
              if (temperature_low_temp > -100) {
                temperatureLow = 0;
                normal_temperature_low_rotate_string = String(Math.abs(temperature_low_temp)).padStart(3, '0')
                if (Math.sign (temperature_low_temp) < 0)normal_temperature_low_rotate_string = '-' + normal_temperature_low_rotate_string;
              };

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_temperature_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && normal_temperature_low_rotate_string.length > 0 && normal_temperature_low_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_temperature_low_TextRotate_posOffset = normal_temperature_low_TextRotate_img_width * normal_temperature_low_rotate_string.length;
                  normal_temperature_low_TextRotate_posOffset = normal_temperature_low_TextRotate_posOffset + 2 * (normal_temperature_low_rotate_string.length - 1);
                  img_offset -= normal_temperature_low_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_temperature_low_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 130 + img_offset);
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.SRC, normal_temperature_low_TextRotate_ASCIIARRAY[charCode]);
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_low_TextRotate_img_width + 2;
                      index++;
                    }  // end if digit
                    else { 
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 130 + img_offset);
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.SRC, 'Sistema_18.png');
                      normal_temperature_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_temperature_low_TextRotate_dot_width + 2;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.POS_X, 130 + img_offset);
                  normal_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_temperature_low_TextRotate[0].setProperty(hmUI.prop.POS_X, 130 - normal_temperature_low_TextRotate_error_img_width / 2);
                  normal_temperature_low_TextRotate[0].setProperty(hmUI.prop.SRC, 'Sistema_13.png');
                  normal_temperature_low_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_rotate_string = parseInt(valueCalories).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_calorie_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_rotate_string.length > 0 && normal_calorie_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_calorie_TextRotate_posOffset = normal_calorie_TextRotate_img_width * normal_calorie_rotate_string.length;
                  img_offset -= normal_calorie_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 347 + img_offset);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, normal_calorie_TextRotate_ASCIIARRAY[charCode]);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_calorie_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  normal_calorie_TextRotate_unit.setProperty(hmUI.prop.POS_X, 347 + img_offset);
                  normal_calorie_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_calorie_TextRotate[0].setProperty(hmUI.prop.POS_X, 347 - normal_calorie_TextRotate_error_img_width / 2);
                  normal_calorie_TextRotate[0].setProperty(hmUI.prop.SRC, 'Sistema_13.png');
                  normal_calorie_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_rotate_string.length > 0 && normal_distance_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_distance_TextRotate_posOffset = normal_distance_TextRotate_img_width * normal_distance_rotate_string.length;
                  normal_distance_TextRotate_posOffset = normal_distance_TextRotate_posOffset - normal_distance_TextRotate_img_width + normal_distance_TextRotate_dot_width;
                  normal_distance_TextRotate_posOffset = normal_distance_TextRotate_posOffset + 1 * (normal_distance_rotate_string.length - 1);
                  img_offset -= normal_distance_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 92 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, normal_distance_TextRotate_ASCIIARRAY[charCode]);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_img_width + 1;
                      index++;
                    }  // end if digit
                    else { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 92 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'Sistema_11.png');
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_dot_width + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 92 + img_offset);
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 92 - normal_distance_TextRotate_error_img_width / 2);
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.SRC, 'Sistema_13.png');
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate temperature_high_forecastData');
              let idle_temperature_high_rotate_string = undefined;
              if (temperature_high_temp > -100) {
                temperatureHigh = 0;
                idle_temperature_high_rotate_string = String(temperature_high_temp)
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_temperature_high_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureHigh != null && temperatureHigh != undefined && isFinite(temperatureHigh) && idle_temperature_high_rotate_string.length > 0 && idle_temperature_high_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_temperature_high_TextRotate_posOffset = idle_temperature_high_TextRotate_img_width * idle_temperature_high_rotate_string.length;
                  idle_temperature_high_TextRotate_posOffset = idle_temperature_high_TextRotate_posOffset + 2 * (idle_temperature_high_rotate_string.length - 1);
                  img_offset -= idle_temperature_high_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_temperature_high_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_temperature_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 339 + img_offset);
                      idle_temperature_high_TextRotate[index].setProperty(hmUI.prop.SRC, idle_temperature_high_TextRotate_ASCIIARRAY[charCode]);
                      idle_temperature_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_high_TextRotate_img_width + 2;
                      index++;
                    }  // end if digit
                    else { 
                      idle_temperature_high_TextRotate[index].setProperty(hmUI.prop.POS_X, 339 + img_offset);
                      idle_temperature_high_TextRotate[index].setProperty(hmUI.prop.SRC, 'Sistema_18.png');
                      idle_temperature_high_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_high_TextRotate_dot_width + 2;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_temperature_high_TextRotate_unit.setProperty(hmUI.prop.POS_X, 339 + img_offset);
                  idle_temperature_high_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_temperature_high_TextRotate[0].setProperty(hmUI.prop.POS_X, 339 - idle_temperature_high_TextRotate_error_img_width / 2);
                  idle_temperature_high_TextRotate[0].setProperty(hmUI.prop.SRC, 'Sistema_13.png');
                  idle_temperature_high_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate temperature_low_forecastData');
              let idle_temperature_low_rotate_string = undefined;
              if (temperature_low_temp > -100) {
                temperatureLow = 0;
                idle_temperature_low_rotate_string = String(Math.abs(temperature_low_temp)).padStart(3, '0')
                if (Math.sign (temperature_low_temp) < 0)idle_temperature_low_rotate_string = '-' + idle_temperature_low_rotate_string;
              };

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_temperature_low_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (temperatureLow != null && temperatureLow != undefined && isFinite(temperatureLow) && idle_temperature_low_rotate_string.length > 0 && idle_temperature_low_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_temperature_low_TextRotate_posOffset = idle_temperature_low_TextRotate_img_width * idle_temperature_low_rotate_string.length;
                  idle_temperature_low_TextRotate_posOffset = idle_temperature_low_TextRotate_posOffset + 2 * (idle_temperature_low_rotate_string.length - 1);
                  img_offset -= idle_temperature_low_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_temperature_low_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_temperature_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 130 + img_offset);
                      idle_temperature_low_TextRotate[index].setProperty(hmUI.prop.SRC, idle_temperature_low_TextRotate_ASCIIARRAY[charCode]);
                      idle_temperature_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_low_TextRotate_img_width + 2;
                      index++;
                    }  // end if digit
                    else { 
                      idle_temperature_low_TextRotate[index].setProperty(hmUI.prop.POS_X, 130 + img_offset);
                      idle_temperature_low_TextRotate[index].setProperty(hmUI.prop.SRC, 'Sistema_18.png');
                      idle_temperature_low_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_temperature_low_TextRotate_dot_width + 2;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_temperature_low_TextRotate_unit.setProperty(hmUI.prop.POS_X, 130 + img_offset);
                  idle_temperature_low_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_temperature_low_TextRotate[0].setProperty(hmUI.prop.POS_X, 130 - idle_temperature_low_TextRotate_error_img_width / 2);
                  idle_temperature_low_TextRotate[0].setProperty(hmUI.prop.SRC, 'Sistema_13.png');
                  idle_temperature_low_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate calorie_CALORIE');
              let idle_calorie_rotate_string = parseInt(valueCalories).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_calorie_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && idle_calorie_rotate_string.length > 0 && idle_calorie_rotate_string.length <= 4) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_calorie_TextRotate_posOffset = idle_calorie_TextRotate_img_width * idle_calorie_rotate_string.length;
                  img_offset -= idle_calorie_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 347 + img_offset);
                      idle_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, idle_calorie_TextRotate_ASCIIARRAY[charCode]);
                      idle_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_calorie_TextRotate_img_width;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  idle_calorie_TextRotate_unit.setProperty(hmUI.prop.POS_X, 347 + img_offset);
                  idle_calorie_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_calorie_TextRotate[0].setProperty(hmUI.prop.POS_X, 347 - idle_calorie_TextRotate_error_img_width / 2);
                  idle_calorie_TextRotate[0].setProperty(hmUI.prop.SRC, 'Sistema_13.png');
                  idle_calorie_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate DISTANCE');
              let idle_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && idle_distance_rotate_string.length > 0 && idle_distance_rotate_string.length <= 5) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_distance_TextRotate_posOffset = idle_distance_TextRotate_img_width * idle_distance_rotate_string.length;
                  idle_distance_TextRotate_posOffset = idle_distance_TextRotate_posOffset - idle_distance_TextRotate_img_width + idle_distance_TextRotate_dot_width;
                  idle_distance_TextRotate_posOffset = idle_distance_TextRotate_posOffset + 1 * (idle_distance_rotate_string.length - 1);
                  img_offset -= idle_distance_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 92 + img_offset);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.SRC, idle_distance_TextRotate_ASCIIARRAY[charCode]);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_distance_TextRotate_img_width + 1;
                      index++;
                    }  // end if digit
                    else { 
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 92 + img_offset);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'Sistema_11.png');
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_distance_TextRotate_dot_width + 1;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 92 + img_offset);
                  idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 92 - idle_distance_TextRotate_error_img_width / 2);
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.SRC, 'Sistema_13.png');
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

            };

            //end of ignored block
            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                text_update();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}