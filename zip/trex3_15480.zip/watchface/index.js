    /*
     ** Watch_Face_Editor tool
     ** watchface js version v2.1.1
     ** Copyright © SashaCX75. All Rights Reserved
     */

    try {
     (() => {
      //start of ignored block
      const __$$app$$__ = __$$hmAppManager$$__.currentApp;

      function getApp() {
       return __$$app$$__.app;
      }

      function getCurrentPage() {
       return __$$app$$__.current && __$$app$$__.current.module;
      }
      const __$$module$$__ = __$$app$$__.current;
      const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
      const {
       px
      } = __$$app$$__.__globals__;
      const logger = Logger.getLogger('watchface_SashaCX75');
      //end of ignored block

      //dynamic modify start


      console.log('user_functions.js');
      // start user_functions.js

      const {
       width: D_W,
       height: D_H
      } = hmSetting.getDeviceInfo();
      let groupVremya = ''
      let groupPogoda = ''
      let groupTap = ''
      let groupActiv = ''
      let canvas0 = ''
      let canvas = ''

      let groupSleep = ''


      let i_tap_bg_img = ''
      let bg_edit_img = ''

      let fix_color_CIRCLE_1 = ''
      let fix_color_CIRCLE_2 = ''
      let normal_date_img_date_week_img = ''
      let normal_month_name_font = ''
      let app_text = ''
      let normal_current_text_sensor = ''
      let select_CIRCLE = ''
      let ic_select_img = ''


      let tap_5_edit = ''

      let Button_1 = ''
      let Button_2 = ''
      let Button_3 = ''
      let Button_4 = ''
      let Button_5 = ''
      let Button_6 = ''
      let Button_7 = ''
      let Button_8 = ''
      let Button_9 = ''
      let Button_10 = ''
      let Button_11 = ''
      let Button_12 = ''


      const battery = hmSensor.createSensor(hmSensor.id.BATTERY)
      const step = hmSensor.createSensor(hmSensor.id.STEP);
      const heart_rate = hmSensor.createSensor(hmSensor.id.HEART); //heart_rate.last
      const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
      const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
      const stand = hmSensor.createSensor(hmSensor.id.STAND)
      const pai = hmSensor.createSensor(hmSensor.id.PAI);
      const fatburn = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
      const spo2 = hmSensor.createSensor(hmSensor.id.SPO2);
      const stress = hmSensor.createSensor(hmSensor.id.STRESS);


      let sleep_time_txt = ''
      let sleep_start_time_txt = ''
      let sleep_end_time_txt = ''
      let sleep_score_txt = ''
      let wake_time_txt

      const sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
      let sleepInfo = sleep.getBasicInfo();

      let sleepTotalTime = sleep.getTotalTime();
      let sleepStartTime = sleepInfo.startTime;
      let sleepEndTime = sleepInfo.endTime + 1;
      let sleepScore = sleepInfo.score;

      //-----------  время пробуждений ------------------		
      let sleepStageArray = sleep.getSleepStageData();
      const modelData = sleep.getSleepStageModel();
      //-------------------------------------------------		

      //sleep_time_txt.setProperty(hmUI.prop.TEXT, 'Время сна: ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));


      function click_sleep() {
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       groupSleep.setProperty(hmUI.prop.VISIBLE, true);
      }


      function click_exit_sleep() {
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       groupSleep.setProperty(hmUI.prop.VISIBLE, false);
      }


      function read_pressure() {
       console.log("read_pressure()");
       const file_name_alt = "../../../baro_altim/pressure.dat";
       const [fs_stat, err] = hmFS.stat(file_name_alt);
       if (err == 0) {
        let file_size = fs_stat.size;
        const len = file_size / 4;
        console.log(`size_alt: ${file_size}, lenght: ${len}`)
        const fh = hmFS.open(file_name_alt, hmFS.O_RDONLY)

        let array_buffer = new Float32Array(len);
        hmFS.read(fh, array_buffer.buffer, 0, file_size);
        hmFS.close(fh);
        console.log(`value ${array_buffer[array_buffer.length -1]}`);
        return array_buffer;
       } else {
        console.log('err:', err)
       }
       return null;
      }

      function getPressureValue(pressure_array) {
       console.log("getPressureValue()");
       if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
       let start_index = pressure_array.length - 1;
       let end_index = start_index - 30 * 3; // 3 часа
       if (end_index < 0) end_index = 0;
       for (let index = start_index; index >= end_index; index--) {
        if (pressure_array[index] != 0) return parseInt(pressure_array[index] / 100);
       }
       return 0;
      }

      function changesPressure(pressure_array) {
       console.log("changesPressure()");
       if (pressure_array == null || pressure_array == undefined || pressure_array.length == 0) return 0;
       let start_index = pressure_array.length - 1;
       let end_index = start_index - 30 * 3; // 3 часа
       let value = pressure_array[start_index];
       let result = 0;
       if (end_index < 0) end_index = 0;
       for (let index = start_index; index >= end_index; index--) {
        let element = pressure_array[index];
        if (element != 0) {
         if (Math.abs(value - element) > 10) { // учитываем только если разниза больше 0,1 hPa
          value = value - element;
          console.log(`element = ${element}`);
          console.log(`pressere_changes = ${value}`);
          return value;
         }
        }
       }
       return result;
      }

      function hPa_To_mmHg(hPa_value = 0) {
       let mmHg = Math.round(hPa_value * 0.750064);
       return mmHg;
      }
      //#endregion

      let text_pressere; // отображаем давление
      let text_pressere_changes; // отображаем изменение давления


      // const battery = hmSensor.createSensor(hmSensor.id.BATTERY)
      const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

      let normal_background_bg = ''

      let Activ_color_alpha = ''

      let color_bg_Activ = [0xff0000, 0xff0000, 0xFCB61C, 0x068FF9, 0xFFB900, 0xffffff, 0xf8e36c, 0xb84cf6, 0xa3fd1f, 0xfd912f, 0x8cffff, 0xff00a2, 0x8a8a8a];

      let menu = 0
      let color_ic = 0
      let Activ_color = 0

      function click_Activ_color() {
       Activ_color = (Activ_color + 1) % 2
       ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, Activ_color == 0);
       hmFS.SysProSetInt('OMG_218_480_Activ_color', Activ_color);
      }


      function loadSettings() {

       if (hmFS.SysProGetInt('OMG_218_480_color') === undefined) {
        color = 0;
        hmFS.SysProSetInt('OMG_218_480_color', color);
       } else {
        color = hmFS.SysProGetInt('OMG_218_480_color');
       }

       if (hmFS.SysProGetInt('OMG_218_480_color_ic') === undefined) {
        color_ic = 0;
        hmFS.SysProSetInt('OMG_218_480_color_ic', color_ic);
       } else {
        color_ic = hmFS.SysProGetInt('OMG_218_480_color_ic');
       }

       if (hmFS.SysProGetInt('OMG_218_480_Activ_color') === undefined) {
        Activ_color = 0;
        hmFS.SysProSetInt('OMG_218_480_Activ_color', Activ_color);
       } else {
        Activ_color = hmFS.SysProGetInt('OMG_218_480_Activ_color');
       }

       if (hmFS.SysProGetInt('OMG_218_480_select') === undefined) {
        select = 0;
        hmFS.SysProSetInt('OMG_218_480_select', select);
       } else {
        select = hmFS.SysProGetInt('OMG_218_480_select');
       }

       if (hmFS.SysProGetInt('OMG_218_480_app_text_num') === undefined) {
        app_text_num = 0;
        hmFS.SysProSetInt('OMG_218_480_app_text_num', app_text_num);
       } else {
        app_text_num = hmFS.SysProGetInt('OMG_218_480_app_text_num');
       }

       if (hmFS.SysProGetInt('OMG_218_480_tip_grafik') === undefined) {
        tip_grafik = 0;
        hmFS.SysProSetInt('OMG_218_480_tip_grafik', tip_grafik);
       } else {
        tip_grafik = hmFS.SysProGetInt('OMG_218_480_tip_grafik');
       }
		  
       if (hmFS.SysProGetInt('OMG_218_480_fix_gsm') === undefined) {
        fix_gsm = 0;
        hmFS.SysProSetInt('OMG_218_480_fix_gsm', fix_gsm);
       } else {
        fix_gsm = hmFS.SysProGetInt('OMG_218_480_fix_gsm');
       }
		  
      }


      let app_text_num = 0;
      let app_text_arr = [
       ['ШАГИ', hmUI.data_type.STEP, false, 0, 1], //0
       ['ПУЛЬС', hmUI.data_type.HEART, false, 0, 1], //1
       ['КАЛОРИИ', hmUI.data_type.CAL, false, 0, 1], //2
       ['ЗАРЯД', hmUI.data_type.BATTERY, false, 1, 1], //3
       ['КМ', hmUI.data_type.DISTANCE, false, 0, 1], //4
       ['ММ.РТ.СТ', hmUI.data_type.ALTIMETER, false, 0, 1], //5
       ['ВЫСОТА', hmUI.data_type.ALTITUDE, false, 0, 0], //6
       ['ВЛАЖНОСТЬ', hmUI.data_type.HUMIDITY, false, 1, 0], //7
       ['ПОГОДА', hmUI.data_type.WEATHER_HIGH_LOW, false, 0, 1], //8
       ['ВОС/ЗАК', hmUI.data_type.SUN_RISE, false, 0, 1], //9
       ['ГОРОД', hmUI.data_type.SUN_SET, false, 0, 1], //10
       ['СТРЕСС', hmUI.data_type.STRESS, false, 0, 0], //11
       ['КИСЛОРОД', hmUI.data_type.SPO2, false, 0, 1], //12
       ['PAI', hmUI.data_type.PAI_DAILY, false, 0, 1], //13
       ['ЖИР', hmUI.data_type.FAT_BURNING, false, 0, 1], //14
       ['УФ', hmUI.data_type.UVI, false, 0, 0], //15
       ['РАЗМИНКА', hmUI.data_type.STAND, false, 0, 1], //16
       ['БУДИЛЬНИК', hmUI.data_type.ALARM_CLOCK, true, 0, 0], //17
       ['ТАЙМЕР', hmUI.data_type.COUNT_DOWN, true, 0, 0], //18
       ['ЭТАЖ', hmUI.data_type.FLOOR, false, 0, 0] //19
      ];

      function app_update() {
       let distanceCurrent = distance.current;

       app_text_arr[0][1] = String(step.current);
       app_text_arr[1][1] = String(heart_rate.last);
       app_text_arr[3][1] = battery.current + "%";
       app_text_arr[2][1] = String(calorie.current);
       app_text_arr[4][1] = (distanceCurrent / 1000).toFixed(2);
       app_text_arr[14][1] = String(fatburn.current);
       app_text_arr[13][1] = String(pai.totalpai);
       app_text_arr[12][1] = String(spo2.current);
       app_text_arr[16][1] = String(stand.current);


       normal_current_text_sensor.setProperty(hmUI.prop.TEXT, app_text_arr[app_text_num][1]);

       app_text.setProperty(hmUI.prop.TEXT, app_text_arr[app_text_num][0]);


      }


      let len_month = [93, 115, 80, 94, 51, 70, 70, 106, 120, 106, 92, 111];
      let len_week = [177, 108, 78, 101, 112, 107, 165];
      let len_data = 76;


      let select = 0;

      function click_select() {
       select = (select + 1) % 3
       select_CIRCLE.setProperty(hmUI.prop.MORE, {
        center_x: 240-10*D_W/466 + select * 10*D_W/466,
        center_y: 71,
        color: color_bg[color],
        radius: 5,
        show_level: hmUI.show_level.ONLY_NORMAL,
       });
       ic_select_img.setProperty(hmUI.prop.SRC, 'ic_select_' + select + '.png');
       hmFS.SysProSetInt('OMG_218_480_select', select);

      }


      function makeAOD() {
       // color = hmFS.SysProGetInt('NUMNUM_color');
       const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: (function () {
         stopVibro();
        }),
        pause_call: (function () {
         hmApp.unregisterSpinEvent();
         stopVibro();
        }),
       });
      }


      let color_bg = [0xff0000, 0xFCB61C, 0x068FF9, 0xFFB900, 0xffffff, 0xf8e36c, 0xb84cf6, 0xa3fd1f, 0xfd912f, 0x8cffff, 0xff00a2];

      let crownSensitivity = 70; // уровень чувствительности колесика
      let color = 0;
      let degreeSum = 0;
      let normal_up_current_text_font = []
      //         let MenuCirklDelay = 1000;
      let MenuCirkl_Timer = null;

      let app_ACR_text = []

      function onDigitalCrown() {
       hmApp.registerSpinEvent(function (key, degree) {
        if (key === hmApp.key.HOME) {
         degreeSum += degree;
         if (Math.abs(degreeSum) > crownSensitivity) {


          if (Activ_color == 1 && menu == 1) {
           let step = degreeSum < 0 ? -1 : 1;
           color_ic += step;
           color_ic = color_ic < 0 ? color_bg_Activ.length + color_ic : color_ic % color_bg_Activ.length;
           degreeSum = 0;


           Activ_color_alpha.setProperty(hmUI.prop.MORE, {
            center_x: 240,
            center_y: 240,
            radius: 240,
            color: color_bg_Activ[color_ic],
            alpha: color_ic == 0 ? 0 : 255,
            show_level: hmUI.show_level.ONLY_NORMAL,
           })
           hmFS.SysProSetInt('OMG_218_480_color_ic', color_ic);
           vibro();
          }


          if (select == 0 && menu == 0) {
           let step = degreeSum < 0 ? -1 : 1;
           color += step;
           color = color < 0 ? color_bg.length + color : color % color_bg.length;
           degreeSum = 0;


           g_ACR_color.setProperty(hmUI.prop.VISIBLE, true);
           if (MenuCirkl_Timer) {
            timer.stopTimer(MenuCirkl_Timer)
           }
           MenuCirkl_Timer = timer.createTimer(1000, 1, (function (option) {
            g_ACR_color.setProperty(hmUI.prop.VISIBLE, false);
           }));

           menu_ARC_PROGRES.setProperty(hmUI.prop.MORE, {
            center_x: 240,
            center_y: 240,
            start_angle: 45 + 90 / color_bg.length * color,
            end_angle: 135 + 90 / color_bg.length * color,
            radius: 226,
            line_width: 16,
            corner_flag: 0,
            color: 0xFF0000,
            level: 100 / color_bg.length,
            show_level: hmUI.show_level.ONLY_NORMAL,
           });


           normal_background_bg.setProperty(hmUI.prop.COLOR, color_bg[color]);
           fix_color_CIRCLE_1.setProperty(hmUI.prop.COLOR, color_bg[color]);
           fix_color_CIRCLE_2.setProperty(hmUI.prop.COLOR, color_bg[color]);
           // normal_time_minute_text_font.setProperty(hmUI.prop.COLOR, color_bg[color]);

           normal_time_minute_text_font.setProperty(hmUI.prop.MORE, {
            x: 235,
            y: 170,
            w: 155,
            h: 155,
            text_size: 142,
            char_space: 0,
            line_space: 0,
            font: 'fonts/Bebas11.ttf',
            color: color_bg[color],
            align_h: hmUI.align.CENTER_H,
            align_v: hmUI.align.CENTER_V,
            text_style: hmUI.text_style.ELLIPSIS,
            type: hmUI.data_type.MINUTE,
            padding: true,
            show_level: hmUI.show_level.ONLY_NORMAL,
           });


           normal_dow_text_font.setProperty(hmUI.prop.COLOR, color_bg[color]);
           //        select_CIRCLE_0.setProperty(hmUI.prop.COLOR, color_bg[color]);
           //        select_CIRCLE_1.setProperty(hmUI.prop.COLOR, color_bg[color]);
           //        select_CIRCLE_2.setProperty(hmUI.prop.COLOR, color_bg[color]);
           select_CIRCLE.setProperty(hmUI.prop.COLOR, color_bg[color]);

           hmFS.SysProSetInt('OMG_218_480_color', color);

           normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
            center_x: 240,
            center_y: 240,
            start_angle: 0,
            end_angle: 360,
            radius: 194,
            line_width: 24,
            corner_flag: 3,
            color: color_bg[color],
            show_level: hmUI.show_level.ONLY_NORMAL,
            // level: level,
           });

           normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
            center_x: 240,
            center_y: 240,
            start_angle: -118,
            end_angle: -62,
            radius: 226,
            line_width: 21,
            corner_flag: 0,
            color: color_bg[color],
            show_level: hmUI.show_level.ONLY_NORMAL,
            type: hmUI.data_type.BATTERY,
           });

           normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
            center_x: 240,
            center_y: 240,
            start_angle: 118,
            end_angle: 62,
            radius: 226,
            line_width: 21,
            corner_flag: 0,
            color: color_bg[color],
            show_level: hmUI.show_level.ONLY_NORMAL,
            type: hmUI.data_type.STEP,
           });


           vibro();
          }

          if (select == 2 && menu == 0) {
           let step = degreeSum < 0 ? -1 : 1;
           app_text_num += step;
           app_text_num = app_text_num < 0 ? app_text_arr.length + app_text_num : app_text_num % app_text_arr.length;
           degreeSum = 0;

           app_text.setProperty(hmUI.prop.TEXT, app_text_arr[app_text_num][0]);
           // normal_up_current_text_font[app_text_num].setProperty(hmUI.prop.VISIBLE, true); 
           for (var i = 0; i < app_text_arr.length; i++) {
            if (app_text_arr[i][4] == 0) {
             normal_up_current_text_font[i].setProperty(hmUI.prop.VISIBLE, i == app_text_num);
            }
           }

            // normal_current_text_sensor.setProperty(hmUI.prop.TEXT, app_text_arr[app_text_num][1]);

            normal_current_text_sensor.setProperty(hmUI.prop.MORE, {
             x: 108,
             y: 288,
             w: 264,
             h: 103,
             text: app_text_arr[app_text_num][1],
             text_size: app_text_num == 8 ? 39 : app_text_num == 10 ? 39 : 70, //70
             char_space: 0,
             line_space: -21,
             font: 'fonts/Bebas11.ttf',
             color: 0xFFFFFFFF,
             align_h: hmUI.align.CENTER_H,
             align_v: hmUI.align.CENTER_V,
             text_style: app_text_num == 10 ? hmUI.text_style.NONE : hmUI.text_style.WRAP,
             // text_style: hmUI.text_style.WRAP,//переносить текст
             // text_style: hmUI.text_style.NONE,//бегущая строка
             // padding: app_text_arr[i][2],
             // type: app_text_arr[i][1],
             // unit_type: app_text_arr[i][3],
             show_level: hmUI.show_level.ONLY_NORMAL,
            });


            normal_current_text_sensor.setProperty(hmUI.prop.VISIBLE, app_text_arr[app_text_num][4] == 1);


            ACR_text_bg.setProperty(hmUI.prop.VISIBLE, true);
            for (let i = 0; i < app_text_arr.length; i++) {
             app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, true);
            }

            if (MenuCirkl_Timer) {
             timer.stopTimer(MenuCirkl_Timer)
            }
            MenuCirkl_Timer = timer.createTimer(1000, 1, (function (option) {
             ACR_text_bg.setProperty(hmUI.prop.VISIBLE, false);
             for (let i = 0; i < app_text_arr.length; i++) {
              app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false);
             }
            }));


            for (let i = 0; i < app_text_arr.length; i++) {
             app_ACR_text[i].setProperty(hmUI.prop.COLOR, app_text_num == i ? 0xff0000 : 0xffffff);

            };


           hmFS.SysProSetInt('OMG_218_480_app_text_num', app_text_num);
           vibro();
          }


         }
        }
       }) // crown
      }


      const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE)
      let stopVibro_Timer = null;

      function vibro(scene = 25) {
       let stopDelay = 50;
       vibrate.stop();
       vibrate.scene = scene;
       if (scene < 23 || scene > 25) stopDelay = 1220;
       vibrate.start();
       stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
      }

      function stopVibro() {
       vibrate.stop();
       timer.stopTimer(stopVibro_Timer);
      }

      function click_Pogoda_on() {
       normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
       menu = 2
       groupVremya.setProperty(hmUI.prop.VISIBLE, false);
       groupPogoda.setProperty(hmUI.prop.VISIBLE, true);
      }

      function click_Pogoda_off() {
       normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);
       menu = 0
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
      }

      function click_Activ_on() {
       menu = 1
       groupVremya.setProperty(hmUI.prop.VISIBLE, false);
       groupActiv.setProperty(hmUI.prop.VISIBLE, true);
      }

      function click_Activ_off() {
       menu = 0
       Activ_color = 0
       ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, Activ_color == 0);
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       groupActiv.setProperty(hmUI.prop.VISIBLE, false);
      }


      let apps = [
       ['Нет действия', '-', `tap/i_tap_pusto.png`, 0, 'page/index'],
       ['Таймер', 'CountdownAppScreen', `tap/i_tap_obrat_otchet.png`, 0, 'page/index'],
       ['Секундомер', 'StopWatchScreen', `tap/i_tap_secundomer.png`, 0, 'page/index'],
       ['Мировые часы', 'WorldClockScreen', `tap/i_tap_mirivie_chasi.png`, 0, 'page/index'],
       ['Восход/закат', 'TideScreen', `tap/i_tap_voshod_zakat.png`, 0, 'page/index'],
       ['Сон', 'Sleep_HomeScreen', `tap/i_tap_son.png`, 0, 'page/index'],
       ['Стресс', 'StressHomeScreen', `tap/i_tap_stress.png`, 0, 'page/index'],
       ['SP02 (Кислород)', 'spo_HomeScreen', `tap/i_tap_kislorod.png`, 0, 'page/index'],
       ['Дыхание', 'RespirationsettingScreen', `tap/i_tap_dihanie.png`, 0, 'page/index'],
       ['Измерение одним касанием', 'oneKeyAppScreen', `tap/i_tap_1_kosanie.png`, 0, 'page/index'],
       ['Женский календарь', 'menstrualAppScreen', `tap/i_tap_gensk_calendar.png`, 0, 'page/index'],
       ['Найти телефон', 'FindPhoneScreen', `tap/i_tap_naiti_telo.png`, 0, 'page/index'],
       ['Музыка', 'LocalMusicScreen', `tap/i_tap_musik.png`, 0, 'page/index'], //'PhoneMusicCtrlScreen'
       ['Компас', 'CompassScreen', `tap/i_tap_kompas.png`, 0, 'page/index'],
       ['Набрать номер', 'DialCallScreen', `tap/i_tap_nabor.png`, 0, 'page/index'],
       ['Телефон', 'PhoneHomeScreen', `tap/i_tap_telefon.png`, 0, 'page/index'],
       ['Диктофон', 'VoiceMemoScreen', `tap/i_tap_dictofon.png`, 0, 'page/index'],
       ['Расписание', 'ScheduleListScreen', `tap/i_tap_raspisanie.png`, 0, 'page/index'],
       ['Список дел', 'todoListScreen', `tap/i_tap_spisok_del.png`, 0, 'page/index'],
       ['Календарь', 'ScheduleCalScreen', `tap/i_tap_calendar.png`, 0, 'page/index'],
       ['Погода', 'WeatherScreen', `tap/i_tap_pogoda.png`, 0, 'page/index'],
       ['Настройка', 'Settings_homeScreen', `tap/i_tap_sitting.png`, 0, 'page/index'],
       ['Камера', 'HidcameraScreen', `tap/i_tap_camera.png`, 0, 'page/index'],
       ['Пульс', 'heart_app_Screen', `tap/i_tap_puls.png`, 0, 'page/index'],
       ['Будильник', 'AlarmInfoScreen', `tap/i_tap_budilnik.png`, 0, 'page/index'],
       ['PAI', 'PAI_app_Screen', `tap/i_tap_pai.png`, 0, 'page/index'],
       ['Тренировка', 'SportListScreen', `tap/i_tap_trenerovka.png`, 0, 'page/index'],
       ['AOD', 'Settings_standbyModelScreen', `tap/i_tap_aod.png`, 0, 'page/index'],
       ['Экономия заряда', 'LowBatteryScreen', `tap/i_tap_LowBattery.png`, 0, 'page/index'],
       ['Давление/Высота', 'BaroAltimeterScreen', `tap/i_tap_barometr.png`, 0, 'page/index'],
       ['Погода LeXxiR', '1051195', `tap/i_tap_LeXxiR.png`, 1, 'page/index'],
       ['Календарь Sasha', '1057409', `tap/i_tap_calen_Sasha.png`, 1, 'page/index'],
       ['Flow', '1038314', `tap/i_tap_flow.png`, 1, 'page/gtr/home/index.page'],
       ['Ночной режим', 'Settings_nsModeHomeScreen', `tap/i_tap_night_Mode_Screen.png`, 0, 'page/index'],
       ['Говорящие часы', '1066653', `tap/i_tap_talking_watch.png`, 1, 'page/index.page'],
       ['Перезагрузка', 'HmReStartScreen', `tap/i_tap_restart.png`, 0, 'page/index'],
      ];


      const tap_1_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
       edit_id: 101,
       x: 176,
       y: 21,
       w: 128,
       h: 128,
       select_image: 'tap/edit_red_1.png',
       un_select_image: 'tap/edit_griin_1.png',
       default_type: 19,
       optional_types: [{
        type: 0,
        preview: apps[0][2],
        title_en: apps[0][0]
       }, {
        type: 1,
        preview: apps[1][2],
        title_en: apps[1][0]
       }, {
        type: 2,
        preview: apps[2][2],
        title_en: apps[2][0]
       }, {
        type: 3,
        preview: apps[3][2],
        title_en: apps[3][0]
       }, {
        type: 4,
        preview: apps[4][2],
        title_en: apps[4][0]
       }, {
        type: 5,
        preview: apps[5][2],
        title_en: apps[5][0]
       }, {
        type: 6,
        preview: apps[6][2],
        title_en: apps[6][0]
       }, {
        type: 7,
        preview: apps[7][2],
        title_en: apps[7][0]
       }, {
        type: 8,
        preview: apps[8][2],
        title_en: apps[8][0]
       }, {
        type: 9,
        preview: apps[9][2],
        title_en: apps[9][0]
       }, {
        type: 10,
        preview: apps[10][2],
        title_en: apps[10][0]
       }, {
        type: 11,
        preview: apps[11][2],
        title_en: apps[11][0]
       }, {
        type: 12,
        preview: apps[12][2],
        title_en: apps[12][0]
       }, {
        type: 13,
        preview: apps[13][2],
        title_en: apps[13][0]
       }, {
        type: 14,
        preview: apps[14][2],
        title_en: apps[14][0]
       }, {
        type: 15,
        preview: apps[15][2],
        title_en: apps[15][0]
       }, {
        type: 16,
        preview: apps[16][2],
        title_en: apps[16][0]
       }, {
        type: 17,
        preview: apps[17][2],
        title_en: apps[17][0]
       }, {
        type: 18,
        preview: apps[18][2],
        title_en: apps[18][0]
       }, {
        type: 19,
        preview: apps[19][2],
        title_en: apps[19][0]
       }, {
        type: 20,
        preview: apps[20][2],
        title_en: apps[20][0]
       }, {
        type: 21,
        preview: apps[21][2],
        title_en: apps[21][0]
       }, {
        type: 22,
        preview: apps[22][2],
        title_en: apps[22][0]
       }, {
        type: 23,
        preview: apps[23][2],
        title_en: apps[23][0]
       }, {
        type: 24,
        preview: apps[24][2],
        title_en: apps[24][0]
       }, {
        type: 25,
        preview: apps[25][2],
        title_en: apps[25][0]
       }, {
        type: 26,
        preview: apps[26][2],
        title_en: apps[26][0]
       }, {
        type: 27,
        preview: apps[27][2],
        title_en: apps[27][0]
       }, {
        type: 28,
        preview: apps[28][2],
        title_en: apps[28][0]
       }, {
        type: 29,
        preview: apps[29][2],
        title_en: apps[29][0]
       }, {
        type: 30,
        preview: apps[30][2],
        title_en: apps[30][0]
       }, {
        type: 31,
        preview: apps[31][2],
        title_en: apps[31][0]
       }, {
        type: 32,
        preview: apps[32][2],
        title_en: apps[32][0]
       }, {
        type: 33,
        preview: apps[33][2],
        title_en: apps[33][0]
       }, {
        type: 34,
        preview: apps[34][2],
        title_en: apps[34][0]
       }, {
        type: 35,
        preview: apps[35][2],
        title_en: apps[35][0]
       }, ],

       count: 36,
       tips_x: -37,
       tips_y: 134,
       tips_width: 201,
       tips_margin: 10,
       tips_BG: 'tap/tips_bg.png'
      })

      let tap_1_select = tap_1_edit.getProperty(hmUI.prop.CURRENT_TYPE)

      const tap_2_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
       edit_id: 102,
       x: 310,
       y: 98,
       w: 128,
       h: 128,
       select_image: 'tap/edit_red_1.png',
       un_select_image: 'tap/edit_griin_1.png',
       default_type: 20,
       optional_types: [{
        type: 0,
        preview: apps[0][2],
        title_en: apps[0][0]
       }, {
        type: 1,
        preview: apps[1][2],
        title_en: apps[1][0]
       }, {
        type: 2,
        preview: apps[2][2],
        title_en: apps[2][0]
       }, {
        type: 3,
        preview: apps[3][2],
        title_en: apps[3][0]
       }, {
        type: 4,
        preview: apps[4][2],
        title_en: apps[4][0]
       }, {
        type: 5,
        preview: apps[5][2],
        title_en: apps[5][0]
       }, {
        type: 6,
        preview: apps[6][2],
        title_en: apps[6][0]
       }, {
        type: 7,
        preview: apps[7][2],
        title_en: apps[7][0]
       }, {
        type: 8,
        preview: apps[8][2],
        title_en: apps[8][0]
       }, {
        type: 9,
        preview: apps[9][2],
        title_en: apps[9][0]
       }, {
        type: 10,
        preview: apps[10][2],
        title_en: apps[10][0]
       }, {
        type: 11,
        preview: apps[11][2],
        title_en: apps[11][0]
       }, {
        type: 12,
        preview: apps[12][2],
        title_en: apps[12][0]
       }, {
        type: 13,
        preview: apps[13][2],
        title_en: apps[13][0]
       }, {
        type: 14,
        preview: apps[14][2],
        title_en: apps[14][0]
       }, {
        type: 15,
        preview: apps[15][2],
        title_en: apps[15][0]
       }, {
        type: 16,
        preview: apps[16][2],
        title_en: apps[16][0]
       }, {
        type: 17,
        preview: apps[17][2],
        title_en: apps[17][0]
       }, {
        type: 18,
        preview: apps[18][2],
        title_en: apps[18][0]
       }, {
        type: 19,
        preview: apps[19][2],
        title_en: apps[19][0]
       }, {
        type: 20,
        preview: apps[20][2],
        title_en: apps[20][0]
       }, {
        type: 21,
        preview: apps[21][2],
        title_en: apps[21][0]
       }, {
        type: 22,
        preview: apps[22][2],
        title_en: apps[22][0]
       }, {
        type: 23,
        preview: apps[23][2],
        title_en: apps[23][0]
       }, {
        type: 24,
        preview: apps[24][2],
        title_en: apps[24][0]
       }, {
        type: 25,
        preview: apps[25][2],
        title_en: apps[25][0]
       }, {
        type: 26,
        preview: apps[26][2],
        title_en: apps[26][0]
       }, {
        type: 27,
        preview: apps[27][2],
        title_en: apps[27][0]
       }, {
        type: 28,
        preview: apps[28][2],
        title_en: apps[28][0]
       }, {
        type: 29,
        preview: apps[29][2],
        title_en: apps[29][0]
       }, {
        type: 30,
        preview: apps[30][2],
        title_en: apps[30][0]
       }, {
        type: 31,
        preview: apps[31][2],
        title_en: apps[31][0]
       }, {
        type: 32,
        preview: apps[32][2],
        title_en: apps[32][0]
       }, {
        type: 33,
        preview: apps[33][2],
        title_en: apps[33][0]
       }, {
        type: 34,
        preview: apps[34][2],
        title_en: apps[34][0]
       }, {
        type: 35,
        preview: apps[35][2],
        title_en: apps[35][0]
       }, ],

       count: 36,

       tips_x: -36,
       tips_y: 134,
       tips_width: 201,
       tips_margin: 10,
       tips_BG: 'tap/tips_bg.png'
      })

      let tap_2_select = tap_2_edit.getProperty(hmUI.prop.CURRENT_TYPE)

      const tap_3_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
       edit_id: 103,
       x: 310,
       y: 253,
       w: 128,
       h: 128,
       select_image: 'tap/edit_red_1.png',
       un_select_image: 'tap/edit_griin_1.png',
       default_type: 24,
       optional_types: [{
        type: 0,
        preview: apps[0][2],
        title_en: apps[0][0]
       }, {
        type: 1,
        preview: apps[1][2],
        title_en: apps[1][0]
       }, {
        type: 2,
        preview: apps[2][2],
        title_en: apps[2][0]
       }, {
        type: 3,
        preview: apps[3][2],
        title_en: apps[3][0]
       }, {
        type: 4,
        preview: apps[4][2],
        title_en: apps[4][0]
       }, {
        type: 5,
        preview: apps[5][2],
        title_en: apps[5][0]
       }, {
        type: 6,
        preview: apps[6][2],
        title_en: apps[6][0]
       }, {
        type: 7,
        preview: apps[7][2],
        title_en: apps[7][0]
       }, {
        type: 8,
        preview: apps[8][2],
        title_en: apps[8][0]
       }, {
        type: 9,
        preview: apps[9][2],
        title_en: apps[9][0]
       }, {
        type: 10,
        preview: apps[10][2],
        title_en: apps[10][0]
       }, {
        type: 11,
        preview: apps[11][2],
        title_en: apps[11][0]
       }, {
        type: 12,
        preview: apps[12][2],
        title_en: apps[12][0]
       }, {
        type: 13,
        preview: apps[13][2],
        title_en: apps[13][0]
       }, {
        type: 14,
        preview: apps[14][2],
        title_en: apps[14][0]
       }, {
        type: 15,
        preview: apps[15][2],
        title_en: apps[15][0]
       }, {
        type: 16,
        preview: apps[16][2],
        title_en: apps[16][0]
       }, {
        type: 17,
        preview: apps[17][2],
        title_en: apps[17][0]
       }, {
        type: 18,
        preview: apps[18][2],
        title_en: apps[18][0]
       }, {
        type: 19,
        preview: apps[19][2],
        title_en: apps[19][0]
       }, {
        type: 20,
        preview: apps[20][2],
        title_en: apps[20][0]
       }, {
        type: 21,
        preview: apps[21][2],
        title_en: apps[21][0]
       }, {
        type: 22,
        preview: apps[22][2],
        title_en: apps[22][0]
       }, {
        type: 23,
        preview: apps[23][2],
        title_en: apps[23][0]
       }, {
        type: 24,
        preview: apps[24][2],
        title_en: apps[24][0]
       }, {
        type: 25,
        preview: apps[25][2],
        title_en: apps[25][0]
       }, {
        type: 26,
        preview: apps[26][2],
        title_en: apps[26][0]
       }, {
        type: 27,
        preview: apps[27][2],
        title_en: apps[27][0]
       }, {
        type: 28,
        preview: apps[28][2],
        title_en: apps[28][0]
       }, {
        type: 29,
        preview: apps[29][2],
        title_en: apps[29][0]
       }, {
        type: 30,
        preview: apps[30][2],
        title_en: apps[30][0]
       }, {
        type: 31,
        preview: apps[31][2],
        title_en: apps[31][0]
       }, {
        type: 32,
        preview: apps[32][2],
        title_en: apps[32][0]
       }, {
        type: 33,
        preview: apps[33][2],
        title_en: apps[33][0]
       }, {
        type: 34,
        preview: apps[34][2],
        title_en: apps[34][0]
       }, {
        type: 35,
        preview: apps[35][2],
        title_en: apps[35][0]
       }, ],

       count: 36,
       tips_x: -36,
       tips_y: -64,
       tips_width: 201,
       tips_margin: 10,
       tips_BG: 'tap/tips_bg.png'
      })

      let tap_3_select = tap_3_edit.getProperty(hmUI.prop.CURRENT_TYPE)

      const tap_4_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
       edit_id: 104,
       x: 176,
       y: 331,
       w: 128,
       h: 128,
       select_image: 'tap/edit_red_1.png',
       un_select_image: 'tap/edit_griin_1.png',
       default_type: 11,
       optional_types: [{
        type: 0,
        preview: apps[0][2],
        title_en: apps[0][0]
       }, {
        type: 1,
        preview: apps[1][2],
        title_en: apps[1][0]
       }, {
        type: 2,
        preview: apps[2][2],
        title_en: apps[2][0]
       }, {
        type: 3,
        preview: apps[3][2],
        title_en: apps[3][0]
       }, {
        type: 4,
        preview: apps[4][2],
        title_en: apps[4][0]
       }, {
        type: 5,
        preview: apps[5][2],
        title_en: apps[5][0]
       }, {
        type: 6,
        preview: apps[6][2],
        title_en: apps[6][0]
       }, {
        type: 7,
        preview: apps[7][2],
        title_en: apps[7][0]
       }, {
        type: 8,
        preview: apps[8][2],
        title_en: apps[8][0]
       }, {
        type: 9,
        preview: apps[9][2],
        title_en: apps[9][0]
       }, {
        type: 10,
        preview: apps[10][2],
        title_en: apps[10][0]
       }, {
        type: 11,
        preview: apps[11][2],
        title_en: apps[11][0]
       }, {
        type: 12,
        preview: apps[12][2],
        title_en: apps[12][0]
       }, {
        type: 13,
        preview: apps[13][2],
        title_en: apps[13][0]
       }, {
        type: 14,
        preview: apps[14][2],
        title_en: apps[14][0]
       }, {
        type: 15,
        preview: apps[15][2],
        title_en: apps[15][0]
       }, {
        type: 16,
        preview: apps[16][2],
        title_en: apps[16][0]
       }, {
        type: 17,
        preview: apps[17][2],
        title_en: apps[17][0]
       }, {
        type: 18,
        preview: apps[18][2],
        title_en: apps[18][0]
       }, {
        type: 19,
        preview: apps[19][2],
        title_en: apps[19][0]
       }, {
        type: 20,
        preview: apps[20][2],
        title_en: apps[20][0]
       }, {
        type: 21,
        preview: apps[21][2],
        title_en: apps[21][0]
       }, {
        type: 22,
        preview: apps[22][2],
        title_en: apps[22][0]
       }, {
        type: 23,
        preview: apps[23][2],
        title_en: apps[23][0]
       }, {
        type: 24,
        preview: apps[24][2],
        title_en: apps[24][0]
       }, {
        type: 25,
        preview: apps[25][2],
        title_en: apps[25][0]
       }, {
        type: 26,
        preview: apps[26][2],
        title_en: apps[26][0]
       }, {
        type: 27,
        preview: apps[27][2],
        title_en: apps[27][0]
       }, {
        type: 28,
        preview: apps[28][2],
        title_en: apps[28][0]
       }, {
        type: 29,
        preview: apps[29][2],
        title_en: apps[29][0]
       }, {
        type: 30,
        preview: apps[30][2],
        title_en: apps[30][0]
       }, {
        type: 31,
        preview: apps[31][2],
        title_en: apps[31][0]
       }, {
        type: 32,
        preview: apps[32][2],
        title_en: apps[32][0]
       }, {
        type: 33,
        preview: apps[33][2],
        title_en: apps[33][0]
       }, {
        type: 34,
        preview: apps[34][2],
        title_en: apps[34][0]
       }, {
        type: 35,
        preview: apps[35][2],
        title_en: apps[35][0]
       }, ],

       count: 36,
       tips_x: -37,
       tips_y: -66,
       tips_width: 201,
       tips_margin: 10,
       tips_BG: 'tap/tips_bg.png'
      })

      let tap_4_select = tap_4_edit.getProperty(hmUI.prop.CURRENT_TYPE)


      const tap_6_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
       edit_id: 106,
       x: 41,
       y: 98,
       w: 128,
       h: 128,
       select_image: 'tap/edit_red_1.png',
       un_select_image: 'tap/edit_griin_1.png',
       default_type: 35,
       optional_types: [{
        type: 0,
        preview: apps[0][2],
        title_en: apps[0][0]
       }, {
        type: 1,
        preview: apps[1][2],
        title_en: apps[1][0]
       }, {
        type: 2,
        preview: apps[2][2],
        title_en: apps[2][0]
       }, {
        type: 3,
        preview: apps[3][2],
        title_en: apps[3][0]
       }, {
        type: 4,
        preview: apps[4][2],
        title_en: apps[4][0]
       }, {
        type: 5,
        preview: apps[5][2],
        title_en: apps[5][0]
       }, {
        type: 6,
        preview: apps[6][2],
        title_en: apps[6][0]
       }, {
        type: 7,
        preview: apps[7][2],
        title_en: apps[7][0]
       }, {
        type: 8,
        preview: apps[8][2],
        title_en: apps[8][0]
       }, {
        type: 9,
        preview: apps[9][2],
        title_en: apps[9][0]
       }, {
        type: 10,
        preview: apps[10][2],
        title_en: apps[10][0]
       }, {
        type: 11,
        preview: apps[11][2],
        title_en: apps[11][0]
       }, {
        type: 12,
        preview: apps[12][2],
        title_en: apps[12][0]
       }, {
        type: 13,
        preview: apps[13][2],
        title_en: apps[13][0]
       }, {
        type: 14,
        preview: apps[14][2],
        title_en: apps[14][0]
       }, {
        type: 15,
        preview: apps[15][2],
        title_en: apps[15][0]
       }, {
        type: 16,
        preview: apps[16][2],
        title_en: apps[16][0]
       }, {
        type: 17,
        preview: apps[17][2],
        title_en: apps[17][0]
       }, {
        type: 18,
        preview: apps[18][2],
        title_en: apps[18][0]
       }, {
        type: 19,
        preview: apps[19][2],
        title_en: apps[19][0]
       }, {
        type: 20,
        preview: apps[20][2],
        title_en: apps[20][0]
       }, {
        type: 21,
        preview: apps[21][2],
        title_en: apps[21][0]
       }, {
        type: 22,
        preview: apps[22][2],
        title_en: apps[22][0]
       }, {
        type: 23,
        preview: apps[23][2],
        title_en: apps[23][0]
       }, {
        type: 24,
        preview: apps[24][2],
        title_en: apps[24][0]
       }, {
        type: 25,
        preview: apps[25][2],
        title_en: apps[25][0]
       }, {
        type: 26,
        preview: apps[26][2],
        title_en: apps[26][0]
       }, {
        type: 27,
        preview: apps[27][2],
        title_en: apps[27][0]
       }, {
        type: 28,
        preview: apps[28][2],
        title_en: apps[28][0]
       }, {
        type: 29,
        preview: apps[29][2],
        title_en: apps[29][0]
       }, {
        type: 30,
        preview: apps[30][2],
        title_en: apps[30][0]
       }, {
        type: 31,
        preview: apps[31][2],
        title_en: apps[31][0]
       }, {
        type: 32,
        preview: apps[32][2],
        title_en: apps[32][0]
       }, {
        type: 33,
        preview: apps[33][2],
        title_en: apps[33][0]
       }, {
        type: 34,
        preview: apps[34][2],
        title_en: apps[34][0]
       }, {
        type: 35,
        preview: apps[35][2],
        title_en: apps[35][0]
       }, ],

       count: 36,
       tips_x: -36,
       tips_y: 134,

       tips_width: 201,
       tips_margin: 10,
       tips_BG: 'tap/tips_bg.png'
      })

      let tap_6_select = tap_6_edit.getProperty(hmUI.prop.CURRENT_TYPE)

      let btn_tap = ''
      let btn_click_tap_exit = ''

      let btn_Tap_zona_0 = ''
      let btn_Tap_zona_1 = ''
      let btn_Tap_zona_2 = ''
      let btn_Tap_zona_3 = ''
      let btn_Tap_zona_4 = ''
      let btn_Tap_zona_5 = ''

      function tap_zona_exit() {
       groupVremya.setProperty(hmUI.prop.VISIBLE, true);
       groupTap.setProperty(hmUI.prop.VISIBLE, false);
      }

      let tap_x_y = [
       [178, 26, 1],
       [308, 102, 1],
       [308, 253, 1],
       [178, 328, 0],
       [47, 253, 0],
       [47, 102, 0]
      ];

      function tap_run() {
       groupVremya.setProperty(hmUI.prop.VISIBLE, false);
       groupTap.setProperty(hmUI.prop.VISIBLE, true);
      }


      //-------------------------------- 
      //переменные для ргафика
      let weather_ic_array = []
      let weather_ic = []
      let DigDay = []
      let DigNight = []
      let yArrH = [];
      let arr_xH = [];
      let arr_yH = [];
      let arr_x = [];
      let arr_y = [];
      let arr_xL = [];
      let arr_yL = [];
      let yArrAll = [];
      let yArrL = [];
      let y_pogodaH = [];
      let y_pogodaL = [];
      let week_array = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"];
      let week_text = []
      let data_text = []
      const ROOTPATH = "images/"
      var shag = 46;
      var x0 = 119 - 23 - 23;
      let dney = 8;
      let isDayIcons = false

      let shotWeaterhNames = ["ОБЛАЧНО", "МЕСТАМИ ДОЖДЬ", "МЕСТАМИ СНЕГ", "СОЛНЕЧНО", "ПАСМУРНО", "СЛАБЫЙ ДОЖДЬ", "СЛАБЫЙ СНЕГ", "УМЕРЕННЫЙ ДОЖДЬ", "УМЕРЕННЫЙ СНЕГ", "СИЛЬНЫЙ СНЕГОПАД", "СИЛЬНЫЙ ДОЖДЬ", "ПЕСЧАНАЯ БУРЯ", "МОКРЫЙ СНЕГ", "ТУМАН", "ДЫМКА", "ДОЖДЬ С ГРОЗОЙ", "МЕТЕЛЬ", "ПЫЛЬНО", "ЛИВЕНЬ", "ДОЖДЬ С ГРАДОМ", "СИЛЬНЫЙ ДОЖДЬ С ГРАДОМ", "СИЛЬНЫЙ ДОЖДЬ", "ПЕСЧАНАЯ БУРЯ", "СИЛЬНАЯ ПЕСЧАНАЯ БУРЯ", "СИЛЬНЫЙ ДОЖДЬ", "НЕИЗВЕСТНАЯ ПОГОДА", "ОБЛАЧНО НОЧЬЮ", "ДОЖДЛИВО НОЧЬЮ", "ЯСНО НОЧЬЮ"];

      //            let app_activ_left = []
      //            let app_activ_right = []
      //            let app_activ_txt_left = []
      //            let app_activ_txt_right = []
      //            let activ_arr_left = [
      //                ['PAI', hmUI.data_type.PAI_WEEKLY, false],
      //                ['КАЛОРИЙ', hmUI.data_type.CAL, false],
      //                ['ШАГОВ', hmUI.data_type.STEP, false],
      //                ['РАЗМИНКА', hmUI.data_type.STAND, false],
      //                ['БУДИЛЬНИК', hmUI.data_type.ALARM_CLOCK, true],
      //                ['ЭТАЖ', hmUI.data_type.FLOOR, false]
      //            ];
      //            let activ_arr_right = [
      //                ['ЖИР', hmUI.data_type.FAT_BURNING, false],
      //                ['ПУЛЬС', hmUI.data_type.HEART, false],
      //                ['КМ', hmUI.data_type.DISTANCE, false],
      //                ['КИСЛОРОД', hmUI.data_type.SPO2, false],
      //                ['ТАЙМЕР', hmUI.data_type.COUNT_DOWN, true],
      //                ['СТРЕСС', hmUI.data_type.STRESS, false]
      //            ];

      let tip_grafik = 0

      function click_tip_grafik() {
       tip_grafik = (tip_grafik + 1) % 2
       hmFS.SysProSetInt('OMG_218_480_tip_grafik', tip_grafik);
       ic_graf_img.setProperty(hmUI.prop.SRC, "images/Grafik/ic_graf_" + tip_grafik + ".png");
       click_Pogoda_off();
       normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
       setTimeout(() => {
        click_Pogoda_on()
        tip()
       }, 350);
      }

      let fix_gsm = 0;

      function click_fix_gms() {
       fix_gsm = (fix_gsm + 1) % 2
       hmFS.SysProSetInt('OMG_218_480_fix_gsm', fix_gsm);
       fix_gsm_text_font.setProperty(hmUI.prop.TEXT, fix_gsm == 0 ? '+0' : '+1');
       click_Pogoda_off();
       normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, true);
       setTimeout(() => {
        click_Pogoda_on()
        updateGrafik()
        app_update();
       }, 350);
      }

      // let timeSensor = ''

      let normal_city_name_text_0 = ''


      //-------------------------------- 

      //массив иконок для графика       
      for (var i = 0; i <= 28; i++) {
       weather_ic_array.push(ROOTPATH + "Grafik/weather/" + i + ".png"); //0-28
      }


      //обновление для   графика           
      function updateGrafik() {
       if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
       let day_num = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
       let year = timeSensor.year;
       if (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)) { // Високосный год
        day_num[2] = 29
       } else {
        day_num[2] = 28
       }

       let current = weatherSensor.current;
       let curAirIconIndex = weatherSensor.curAirIconIndex;

       let temperature_current_temp = -100;
       if (weatherSensor.current != undefined && weatherSensor.current != 'undefined') {
        temperature_current_temp = weatherSensor.current;
       }; // end currentWeather; 

       let weatherData = weatherSensor.getForecastWeather();
       let forecastData = weatherData.forecastData;


       let tideData = weatherData.tideData;
       let sunset_hour = -1;
       let sunset_minute = -1;
       if (tideData.count > 0) {
        sunset_hour = tideData.data[0].sunset.hour + fix_gsm;;
        sunset_minute = tideData.data[0].sunset.minute;
       }; // end tideData;

       let sunsetTime = undefined;
       let normal_sunset_circle_string = undefined;
       if (sunset_hour >= 0 && sunset_minute >= 0) {
        sunsetTime = 0;
        normal_sunset_circle_string = String(sunset_hour).padStart(2, '0') + ':' + String(sunset_minute).padStart(2, '0');
       };


       let sunrise_hour = -1;
       let sunrise_minute = -1;
       if (tideData.count > 0) {
        sunrise_hour = tideData.data[0].sunrise.hour + fix_gsm;;
        sunrise_minute = tideData.data[0].sunrise.minute;
       }; // end tideData;

       let sunriseTime = undefined;
       let normal_sunrise_circle_string = undefined;
       if (sunrise_hour >= 0 && sunrise_minute >= 0) {
        sunriseTime = 0;
        normal_sunrise_circle_string = String(sunrise_hour).padStart(2, '0') + ':' + String(sunrise_minute).padStart(2, '0');
       };


       normal_temp_text_font.setProperty(hmUI.prop.TEXT, temperature_current_temp + "°С");
       normal_weather_text_font.setProperty(hmUI.prop.TEXT, shotWeaterhNames[curAirIconIndex]);
       normal_city_name_text_0.setProperty(hmUI.prop.TEXT, normal_sunrise_circle_string + "   " + weatherData.cityName + "   " + normal_sunset_circle_string);


       app_text_arr[8][1] = shotWeaterhNames[curAirIconIndex];
       app_text_arr[8][0] = temperature_current_temp + "°С " + forecastData.data[0].high + "/" + forecastData.data[0].low;
       app_text_arr[10][1] = weatherData.cityName;
       app_text_arr[10][0] = temperature_current_temp + "°С " + forecastData.data[0].high + "/" + forecastData.data[0].low;


       if (forecastData.count == 0) {
        for (let i = 0; i < dney; i++) {
         var invalidPath = "--";
         weather_ic[i].setProperty(hmUI.prop.SRC, ROOTPATH + "Grafik/weather/25.png");
        }
       } else {
        let weekDay = timeSensor.week - 1;
        let data_gr = timeSensor.day;
        let month_gr = timeSensor.month;

        for (let i = 0; i < dney; i++) {

         // let arr_y  = [252, 238, 252, 266, 238, 224, 308, 322];    

         yArrH[i] = forecastData.data[i].high;

         let element = forecastData.data[i];
         let iconIndex = element.index;
         weather_ic[i].setProperty(hmUI.prop.SRC, weather_ic_array[iconIndex]);
         let week2 = week_array[weekDay];
         week_text[i].setProperty(hmUI.prop.MORE, {
          color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
          text: week2,
         });
         data_text[i].setProperty(hmUI.prop.MORE, {
          color: weekDay < 5 ? "0xFFFFFFFF" : "0xFFFF0000",
          text: data_gr,
         });
         weekDay = (weekDay + 1) % 7;
         data_gr = (data_gr + 1)
         if (data_gr > day_num[month_gr]) data_gr = 1
         if (i < dney - 1) yArrL[i] = forecastData.data[i].low;

        }
       }


       sunData = weatherData.tideData;
       if (sunData.count > 0) {
        today = sunData.data[0];
        sunriseMins = (today.sunrise.hour + fix_gsm) * 60 + today.sunrise.minute;
        sunsetMins = (today.sunset.hour + fix_gsm) * 60 + today.sunset.minute;
       } else {
        sunriseMins = sunriseMins_def;
        sunsetMins = sunsetMins_def;
       }
       curMins = timeSensor.hour * 60 + timeSensor.minute;
       let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

       if (isDayNow) {
        if (!isDayIcons) {
         isDayIcons = true;
        }
       } else {
        if (isDayIcons) {
         isDayIcons = false;
        }
       }


       normal_vos_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons == false);
       normal_vos_icon_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == false);
       normal_zak_text_font.setProperty(hmUI.prop.VISIBLE, isDayIcons == true);
       normal_zak_icon_img.setProperty(hmUI.prop.VISIBLE, isDayIcons == true);


       app_text_arr[9][1] = isDayIcons == false ? normal_sunrise_circle_string : normal_sunset_circle_string;
       app_text_arr[9][0] = isDayIcons == false ? "ВОСХОД" : "ЗАКАТ";


       shotWeaterhNames = isDayIcons == false ? ["Облачно ночью", "Местами дождь", "Местами снег", "Ясно ночью", "Пасмурно ночью", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь ", "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"] : ["Облачно", "Местами дождь", "Местами снег", "Cолнечно", "Пасмурно", "Слабый дождь", "Слабый снег", "Умеренный дождь", "Умеренный снег", "Сильный снегопад", "Сильный дождь", "Песчаная буря", "Мокрый снег", "Туман", "Дымка", "Дождь с грозой", "Метель", "Пыльно", "Ливень", "Дождь с градом", "Сильный дождь с градом", "Сильный дождь", "Песчаная буря", "Сильная песчаная буря", "Сильный дождь", "Неизвестная погода", "Облачно ночью", "Дождливо ночью", "Ясно ночью"]; //  array_ic_weater = isDayIcons == false ?  ["Ъ", "Ы", "Э", "Ь", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"] : ["А", "Б", "В", "Г", "Д", "Е", "Ж", "З", "И", "Й", "К", "Л", "М", "Н", "О", "П", "Р", "С", "У", "Ф", "Х", "Ц", "Ч", "Ш", "?", "Ъ", "Ы", "Ь"];  

       tip()

      }

      function tip() {

       canvas.clear({
        x: 0,
        y: 0,
        w: 480,
        h: D_W
       })


       for (let i = 0; i < dney - 1; i++) {
        canvas.drawRect({
         x1: 94 + shag * [i],
         y1: 93,
         x2: 94 + shag * [i] + 1,
         y2: 351,
         color: 0xc0c0c0
        })
       }


       let maxH = Math.max(...yArrH)
       let maxL = Math.min(...yArrL)
       let delta = 120 / (maxL - maxH)

       let RedArray = [];
       let BlueArray = [];

       if (tip_grafik == 0) {
        for (let i = 0; i < dney; i++) {
         arr_x[i] = x0 + shag * [i];
         arr_y[i] = yArrH[i] * delta + 162 - maxH * delta;
        }
        // let n = arr_x.length;
        splain(dney)

        for (let i = 0; i < dney - 1; i++) {
         arr_x[i] = x0 + 23 + shag * [i];
         arr_y[i] = yArrL[i] * delta + 162 - maxH * delta;
        }
        // n = dney - 1;
        splain(dney - 1)
       }
       if (tip_grafik == 1) {
        let k = 0
        for (let i = 0; i < dney; i++) {

         yArrAll[k] = yArrH[i]
         k = k + 1
         yArrAll[k] = yArrL[i]
         k = k + 1
        }


        for (let i = 0; i < yArrAll.length; i++) {
         arr_x[i] = x0 + shag / 2 * [i];
         arr_y[i] = yArrAll[i] * delta + 162 - maxH * delta;
        }
        //n = yArrAll.length - 1;
        splain(yArrAll.length - 1)
       }


       for (let i = 0; i < dney; i++) {
        if (tip_grafik == 0) {
         canvas.drawCircle({
          center_x: x0 + shag * [i],
          center_y: yArrH[i] * delta + 162 - maxH * delta,
          radius: 5,
          color: 0xFF0000
         })
        }
        y_pogodaH[i] = (yArrH[i] * delta + 145 - maxH * delta) - 5;
        DigDay[i].setProperty(hmUI.prop.more, {
         x: x0 - 23 - 5 + i * 45 * 1.02,
         y: y_pogodaH[i] - 18, //120-7//120-7/- 38
         w: 52,
         h: 41,
         color: "0xFFffffff",
         text_size: 28,
         text: yArrH[i],
         text_style: hmUI.text_style.NONE,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         show_level: hmUI.show_level.ONLY_NORMAL
        });

        if (i < dney - 1) {
         if (tip_grafik == 0) {
          canvas.drawCircle({
           center_x: x0 + 23 + shag * [i],
           center_y: yArrL[i] * delta + 162 - maxH * delta,
           radius: 5,
           color: 0x00eaff
          })
         }
         y_pogodaL[i] = (yArrL[i] * delta + 145 - maxH * delta) - 5;;
         DigNight[i].setProperty(hmUI.prop.more, {
          x: x0 - 23 - 5 + 23 + i * 45 * 1.02,
          y: y_pogodaL[i] + 19, //120-7 / - 1  
          w: 52,
          h: 41,
          color: "0xFFffffff",
          text_size: 28,
          text: yArrL[i],
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });
        } //dney - 1
       }; //dney   
      }


      function splain(n) {
       let arr_a = new Array(n).fill().map(() => new Array(1));
       let arr_b = new Array(n - 1).fill().map(() => new Array(1));
       let arr_c = new Array(n).fill().map(() => new Array(1));
       let arr_d = new Array(n - 1).fill().map(() => new Array(1));

       let arr_h = new Array(n - 1).fill().map(() => new Array(1));
       let arr_alpha = new Array(n).fill().map(() => new Array(1));
       let arr_l = new Array(n).fill().map(() => new Array(1));
       let arr_mu = new Array(n).fill().map(() => new Array(1));
       let arr_z = new Array(n).fill().map(() => new Array(1));

       for (var i = 0; i < n - 1; i++) {
        arr_h[i] = arr_x[i + 1] - arr_x[i];
       }

       for (var i = 1; i < n - 1; i++) {
        arr_alpha[i] = 3 * ((arr_y[i + 1] - arr_y[i]) / arr_h[i] - (arr_y[i] - arr_y[i - 1]) / arr_h[i - 1]);
       }

       arr_l[0] = 1;
       arr_mu[0] = 0;
       arr_z[0] = 0;

       for (var i = 1; i < n - 1; i++) {
        arr_l[i] = 2 * (arr_x[i + 1] - arr_x[i - 1]) - arr_h[i - 1] * arr_mu[i - 1];
        arr_mu[i] = arr_h[i] / arr_l[i];
        arr_z[i] = (arr_alpha[i] - arr_h[i - 1] * arr_z[i - 1]) / arr_l[i];
       }

       arr_l[n - 1] = 1;
       arr_z[n - 1] = 0;
       arr_c[n - 1] = 0;

       for (var j = n - 2; j >= 0; j--) {
        arr_c[j] = arr_z[j] - arr_mu[j] * arr_c[j + 1];
        arr_b[j] = (arr_y[j + 1] - arr_y[j]) / arr_h[j] - arr_h[j] * (arr_c[j + 1] + 2 * arr_c[j]) / 3;
        arr_d[j] = (arr_c[j + 1] - arr_c[j]) / (3 * arr_h[j]);
        arr_a[j] = arr_y[j];
       }

       for (var i = 0; i < n - 1; i++) {
        for (xi = arr_x[i]; xi < arr_x[i + 1] - 1; xi += 5) {
         yi = arr_a[i] + arr_b[i] * (xi - arr_x[i]) + arr_c[i] * Math.pow((xi - arr_x[i]), 2) + arr_d[i] * Math.pow((xi - arr_x[i]), 3);

         if (tip_grafik == 0) {
          canvas.drawImage({
           x: xi,
           y: yi,
           w: 5,
           h: 310 - yi,
           alpha: 127,
           image: n == dney ? 'images/Grafik/line_day.png' : 'images/Grafik/line_night.png'
          })
         }

         canvas.drawLine({
          x1: xi,
          y1: yi,
          x2: xi + 5,
          y2: arr_a[i] + arr_b[i] * (xi + 5 - arr_x[i]) + arr_c[i] * Math.pow((xi + 5 - arr_x[i]), 2) + arr_d[i] * Math.pow((xi + 5 - arr_x[i]), 3),
          // color: n == dney ? 0xff0000 : 0x00eaff//0x009cff  yArrAll.length - 1
          color: n == dney ? 0xff0000 : n == dney - 1 ? 0x00eaff : 0x12a2fd //0x009cff
         })


        }
       }

      }
      // end user_functions.js

      let normal_image_img = ''
      let normal_calorie_circle_scale = ''
      let normal_stand_icon_img = ''
      let normal_dow_text_font = ''
      let normal_DOW_Array = ['ПОНЕДЕЛЬНИК', 'ВОРНИК', 'СРЕДА', 'ЧЕТВЕРГ', 'ПЯТНИЦА', 'СУББОТА', 'ВОСКРЕСЕНЬЕ', ];
      let normal_Month_Array = ['ЯНВАРЯ', 'ФЕВРАЛЯ', 'МАРТА', 'АПРЕЛЯ', 'МАЯ', 'ИЮНЯ', 'ИЮЛЯ', 'АВГУСТА', 'СЕНТЯБРЯ', 'ОКТЯБРЯ', 'НОЯБРЯ', 'ДЕКАБРЯ', ];
      let normal_day_text_font = ''
      let normal_time_hour_text_font = ''
      let normal_timerTimeUpdate = undefined;
      let normal_time_minute_text_font = ''
      let normal_temperature_current_text_font = ''
      let normal_battery_circle_scale = ''
      let normal_step_circle_scale = ''
      let normal_system_disconnect_img = ''
      let normal_system_clock_img = ''
      let timeSensor = ''


      //dynamic modify end

      __$$module$$__.module = DeviceRuntimeCore.WatchFace({
       init_view() {
        //dynamic modify start
        loadSettings();

        // FontName: Bebas11.ttf; FontSize: 35; Cache: full
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 478,
         y: 478,
         w: 43,
         h: 43,
         text_size: 36,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFF00,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 478,
         y: 478,
         w: 43,
         h: 43,
         text_size: 28,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFF00,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 478,
         y: 478,
         w: 43,
         h: 43,
         text_size: 40,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFF00,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 478,
         y: 478,
         w: 43,
         h: 43,
         text_size: 38,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFF00,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Bebas11.ttf; FontSize: 39

        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 478,
         y: 478,
         w: 404,
         h: 59,
         text_size: 89,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        // FontName: Bebas11.ttf; FontSize: 138
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 478,
         y: 478,
         w: 1440,
         h: 206,
         text_size: 142,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        // FontName: Bebas11.ttf; FontSize: 50


        // FontName: Bebas11.ttf; FontSize: 70
        hmUI.createWidget(hmUI.widget.TEXT, {
         x: 478,
         y: 478,
         w: 731,
         h: 103,
         text_size: 72,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        i_tap_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         w: 480,
         h: 480,
         src: 'tap/i_tap_bg.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        const tap_5_edit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
         edit_id: 10021,
         x: 41,
         y: 253,
         w: 128,
         h: 128,
         select_image: 'tap/edit_red_1.png',
         un_select_image: 'tap/edit_griin_1.png',
         default_type: hmUI.edit_type.APPLIST,
         optional_types: [{
           type: hmUI.edit_type.APPLIST,
           preview: 'transparent_img.png'
          },
          {
           type: hmUI.edit_type.SPORTSLIST,
           preview: 'transparent_img.png'
          }
         ],
         count: 2,
         select_list: {
          title_font_size: 34,
          title_align_h: hmUI.align.CENTER_H,
          list_item_vspace: 8,
          list_tips_text_font_size: 32,
          list_tips_text_align_h: hmUI.align.LEFT
         },
         tips_BG: 'tap/tips_bg.png',
         tips_x: -36,
         tips_y: -64,
         tips_width: 201,
         tips_margin: 10,
        });

        bg_edit_img = hmUI.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: 'tap/bg_edit.png',
         show_level: hmUI.show_level.ONLY_EDIT,
        });

        groupVremya = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: 480,
         h: 480,
        }); // 


        console.log('user_script_start.js');
        // start user_script_start.js

        normal_background_bg = groupVremya.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: 480,
         h: 480,
         color: color_bg[color],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        // end user_script_start.js

        console.log('Watch_Face.ScreenNormal');

        normal_image_img = groupVremya.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: 'bg_0.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        let screenType = hmSetting.getScreenType();
        normal_battery_circle_scale = groupVremya.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 240,
         center_y: 240,
         start_angle: -118,
         end_angle: -62,
         radius: 225,
         line_width: 21,
         corner_flag: 0,
         color: color_bg[color],
         type: hmUI.data_type.BATTERY,

         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_step_circle_scale = groupVremya.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 240,
         center_y: 240,
         start_angle: 118,
         end_angle: 62,
         radius: 225,
         line_width: 21,
         corner_flag: 0,
         color: color_bg[color],
         type: hmUI.data_type.STEP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        groupVremya.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: 'bg.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_calorie_circle_scale = groupVremya.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 240,
         center_y: 240,
         start_angle: 0,
         end_angle: 360,
         radius: 194,
         line_width: 24,
         corner_flag: 3,
         color: color_bg[color],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        fix_color_CIRCLE_1 = groupVremya.createWidget(hmUI.widget.CIRCLE, {
         center_x: 46,
         center_y: 240,
         color: color_bg[color],
         radius: 18,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        fix_color_CIRCLE_2 = groupVremya.createWidget(hmUI.widget.CIRCLE, {
         center_x: 433,
         center_y: 240,
         color: color_bg[color],
         radius: 18,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_stand_icon_img = groupVremya.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         src: 'cap.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
        timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
         time_update(true);
        });

        normal_dow_text_font = groupVremya.createWidget(hmUI.widget.TEXT, {
         x: 188,
         y: 113,
         w: 253,
         h: 103,
         text_size: 40,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: color_bg[color],
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // padding: true,
         // unit_string: ПОНЕДЕЛЬНИК, ВОРНИК, СРЕДА, ЧЕТВЕРГ, ПЯТНИЦА, СУББОТА, ВОСКРЕСЕНЬЕ,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_date_img_date_week_img = groupVremya.createWidget(hmUI.widget.IMG_WEEK, {
         x: 150,
         y: 91,
         week_en: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
         week_tc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
         week_sc: ["week_0.png", "week_1.png", "week_2.png", "week_3.png", "week_4.png", "week_5.png", "week_6.png"],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_month_name_font = groupVremya.createWidget(hmUI.widget.TEXT, {
         x: 188,
         y: 78,
         w: 253,
         h: 103,
         text_size: 40,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.LEFT,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         // unit_string: ЯНВАРЯ, ФЕВРАЛЯ, МАРТА, АПРЕЛЯ, МАЯ, ИЮНЯ, ИЮЛЯ, АВГУСТА, СЕНТЯБРЯ, ОКТЯБРЯ, НОЯБРЯ, ДЕКАБРЯ,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_day_text_font = groupVremya.createWidget(hmUI.widget.TEXT, {
         x: 95,
         y: 98,
         w: 89,
         h: 103,
         text_size: 89,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.system_status.DISCONNECT,
         // padding: true,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        //        normal_time_hour_text_font = groupVremya.createWidget(hmUI.widget.TEXT, {
        //         x: 91,
        //         y: 170,
        //         w: 155,
        //         h: 155,
        //         text_size: 142,
        //         char_space: 0,
        //         line_space: 0,
        //         font: 'fonts/Bebas11.ttf',
        //         color: 0xFFFFFFFF,
        //         align_h: hmUI.align.CENTER_H,
        //         align_v: hmUI.align.CENTER_V,
        //         text_style: hmUI.text_style.ELLIPSIS,
        //         // padding: true,
        //         show_level: hmUI.show_level.ONLY_NORMAL,
        //        });

        normal_time_hour_text_font = groupVremya.createWidget(hmUI.widget.TEXT_FONT, {
         x: 91,
         y: 170,
         w: 155,
         h: 155,
         text_size: 142,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         type: hmUI.data_type.HOUR,
         text_style: hmUI.text_style.ELLIPSIS,
         padding: true,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_time_minute_text_font = groupVremya.createWidget(hmUI.widget.TEXT_FONT, {
         x: 235,
         y: 170,
         w: 155,
         h: 155,
         text_size: 142,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: color_bg[color],
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.MINUTE,
         padding: true,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        app_text = groupVremya.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 371,
         w: 480,
         h: 43,
         text: app_text_arr[app_text_num][0],
         text_size: 38,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xffffff,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        for (var i = 0; i < app_text_arr.length; i++) {
         if (app_text_arr[i][4] == 0) {
          normal_up_current_text_font[i] = groupVremya.createWidget(hmUI.widget.TEXT_FONT, {
           x: 0,
           y: 288,
           w: 480,
           h: 103,
           text_size: 72,
           char_space: 0,
           line_space: 0,
           font: 'fonts/Bebas11.ttf',
           color: 0xFFFFFFFF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.ELLIPSIS,
           padding: app_text_arr[i][2],
           type: app_text_arr[i][1],
           unit_type: app_text_arr[i][3],
           show_level: hmUI.show_level.ONLY_NORMAL,
          });
          normal_up_current_text_font[i].setProperty(hmUI.prop.VISIBLE, i == app_text_num);
         }

        }

        normal_current_text_sensor = groupVremya.createWidget(hmUI.widget.TEXT, {
         x: 108,
         y: 288,
         w: 264,
         h: 103,
         text: "--",
         text_size: app_text_num == 8 ? 39 : app_text_num == 10 ? 39 : 70, //70         char_space: 0,
         line_space: -21,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: app_text_num == 10 ? hmUI.text_style.NONE : hmUI.text_style.WRAP,
         // text_style: hmUI.text_style.NONE,//бегущая строка
         // padding: app_text_arr[i][2],
         // type: app_text_arr[i][1],
         // unit_type: app_text_arr[i][3],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        // normal_current_text_sensor.setProperty(hmUI.prop.VISIBLE, 5 == app_text_num);
        normal_current_text_sensor.setProperty(hmUI.prop.VISIBLE, app_text_arr[app_text_num][4] == 1);

        // normal_up_current_text_font[i].setProperty(hmUI.prop.VISIBLE, false); 


        normal_system_disconnect_img = groupVremya.createWidget(hmUI.widget.IMG_STATUS, {
         x: 75,
         y: 184,
         src: 'stat_B_off.png',
         type: hmUI.system_status.DISCONNECT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_system_clock_img = groupVremya.createWidget(hmUI.widget.IMG_STATUS, {
         x: 376,
         y: 184,
         src: 'stat_H_on.png',
         type: hmUI.system_status.CLOCK,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        select_CIRCLE = groupVremya.createWidget(hmUI.widget.CIRCLE, {
         center_x: 240-10*D_W/466 + select * 10*D_W/466,
         center_y: 71,
         color: color_bg[color],
         radius: 5,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        ic_select_img = groupVremya.createWidget(hmUI.widget.IMG, {
         x: 380,
         y: 375,
         src: 'ic_select_' + select + '.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        console.log('user_script_beforeShortcuts.js');
        // start user_script_beforeShortcuts.js


        groupTap = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: 480,
         h: 480,
        });


        Tap_zona_0 = groupTap.createWidget(hmUI.widget.IMG, {
         x: tap_x_y[0][0],
         y: tap_x_y[0][1],
         src: apps[tap_1_select][2], //'tap/i_tap_calendar.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Tap_zona_1 = groupTap.createWidget(hmUI.widget.IMG, {
         x: tap_x_y[1][0],
         y: tap_x_y[1][1],
         src: apps[tap_2_select][2],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Tap_zona_2 = groupTap.createWidget(hmUI.widget.IMG, {
         x: tap_x_y[2][0],
         y: tap_x_y[2][1],
         src: apps[tap_3_select][2],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Tap_zona_3 = groupTap.createWidget(hmUI.widget.IMG, {
         x: tap_x_y[3][0],
         y: tap_x_y[3][1],
         src: apps[tap_4_select][2],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        //        Tap_zona_4 = groupTap.createWidget(hmUI.widget.IMG, {
        //         x: tap_x_y[4][0],
        //         y: tap_x_y[4][1],
        //         src: apps[tap_5_select][2],
        //         show_level: hmUI.show_level.ONLY_NORMAL,
        //        });

        Tap_zona_5 = groupTap.createWidget(hmUI.widget.IMG, {
         x: tap_x_y[5][0],
         y: tap_x_y[5][1],
         src: apps[tap_6_select][2],
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        btn_Tap_zona_0 = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: tap_x_y[0][0],
         y: tap_x_y[0][1],
         text: '',
         w: 116,
         h: 116,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          hmApp.startApp({
           url: apps[tap_1_select][1],
           native: true
          });
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Tap_zona_1 = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: tap_x_y[1][0],
         y: tap_x_y[1][1],
         text: '',
         w: 116,
         h: 116,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          hmApp.startApp({
           url: apps[tap_2_select][1],
           native: true
          });
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Tap_zona_2 = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: tap_x_y[2][0],
         y: tap_x_y[2][1],
         text: '',
         w: 116,
         h: 116,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          hmApp.startApp({
           url: apps[tap_3_select][1],
           native: true
          });
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Tap_zona_3 = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: tap_x_y[3][0],
         y: tap_x_y[3][1],
         text: '',
         w: 116,
         h: 116,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          hmApp.startApp({
           url: apps[tap_4_select][1],
           native: true
          });
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        //        btn_Tap_zona_4 = groupTap.createWidget(hmUI.widget.BUTTON, {
        //         x: tap_x_y[4][0],
        //         y: tap_x_y[4][1],
        //         text: '',
        //         w: 116,
        //         h: 116,
        //         normal_src: '0_Empty.png',
        //         press_src: '0_Empty.png',
        //         click_func: () => {
        //          vibro();
        //          hmApp.startApp({
        //           url: apps[tap_5_select][1],
        //           native: true
        //          });
        //         },
        //         show_level: hmUI.show_level.ONLY_NORMAL,
        //        });

        btn_Tap_zona_5 = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: tap_x_y[5][0],
         y: tap_x_y[5][1],
         text: '',
         w: 116,
         h: 116,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          hmApp.startApp({
           url: apps[tap_6_select][1],
           native: true
          });
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        btn_tap = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 32,
         y: 34,
         text: '',
         w: 103,
         h: 103,
         normal_src: '0_Empty.png',
         press_src: 'images/Grafik/press_100.png',
         click_func: () => {
          vibro();
          tap_run();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_str = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 347, //x кнопки
         y: 34, //y кнопки
         text: '',
         w: 103, //ширина кнопки
         h: 103, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'images/Grafik/press_100.png',
         click_func: () => {
          vibro();
          click_Pogoda_on();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Activ = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 31, //x кнопки
         y: 343, //y кнопки
         text: '',
         w: 103, //ширина кнопки
         h: 103, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'images/Grafik/press_100.png',
         click_func: () => {
          vibro();
          click_Activ_on();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_select = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 347, //x кнопки
         y: 343, //y кнопки
         text: '',
         w: 103, //ширина кнопки
         h: 103, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'images/Grafik/press_100.png',
         click_func: () => {
          vibro();
          click_select();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_sleep = groupVremya.createWidget(hmUI.widget.BUTTON, {
         x: 377, //x кнопки
         y: 188, //y кнопки
         text: '',
         w: 103, //ширина кнопки
         h: 103, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'images/Grafik/press_100.png',
         click_func: () => {
          vibro();
          click_sleep();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        btn_click_tap_exit = groupTap.createWidget(hmUI.widget.BUTTON, {
         x: 188,
         y: 188,
         text: '',
         w: 103,
         h: 103,
         normal_src: '0_Empty.png',
         press_src: '0_Empty.png',
         click_func: () => {
          vibro();
          tap_zona_exit();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        groupSleep = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: 480,
         h: 480,
        }); // ы


        normal_Sleep_bg = groupSleep.createWidget(hmUI.widget.FILL_RECT, {
         x: 74,
         y: 102,
         w: 332,
         h: 206,
         color: 0x000000,
         radius: 21,
         alpha: 178,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        sleep_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 0, // координата X
         y: 111, // координата Y
         w: 480, // ширина 	
         h: 41, // высота	
         text_size: 34, // размер текста
         text: '',
         font: 'fonts/Bebas11.ttf',
         color: 0xffffff, // цвет текста
         align_h: hmUI.align.CENTER_H,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 106, // координата X
         y: 148, // координата Y
         w: 480, // ширина 	
         h: 41, // высота	
         text_size: 34, // размер текста
         text: 'ЗАСНУЛИ',
         font: 'fonts/Bebas11.ttf',
         color: 0x00ff00, // цвет текста
         align_h: hmUI.align.LEFT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupSleep.createWidget(hmUI.widget.TEXT, {
         x: -108, // координата X
         y: 148, // координата Y
         w: 480, // ширина 	
         h: 41, // высота	
         text_size: 34, // размер текста
         text: 'ПРОСНУЛИСЬ',
         font: 'fonts/Bebas11.ttf',
         color: 0xe779ff, // цвет текста
         align_h: hmUI.align.RIGHT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        sleep_start_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 106,
         y: 186,
         w: 480, // ширина 	
         h: 41,
         text_size: 34,
         text: '',
         font: 'fonts/Bebas11.ttf',
         color: 0x00ff00,
         align_h: hmUI.align.LEFT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        sleep_end_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: -108, // координата X
         y: 186,
         w: 480, // ширина 	
         h: 41,
         text_size: 34,
         text: '',
         font: 'fonts/Bebas11.ttf',
         color: 0xe779ff,
         align_h: hmUI.align.RIGHT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        wake_time_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 224,
         w: 480,
         h: 41,
         text_size: 34,
         font: 'fonts/Bebas11.ttf',
         text: '',
         color: 0xff4949,
         align_h: hmUI.align.CENTER_H,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        sleep_score_txt = groupSleep.createWidget(hmUI.widget.TEXT, {
         x: 0,
         y: 264,
         w: 480,
         h: 41,
         text_size: 34,
         font: 'fonts/Bebas11.ttf',
         text: '',
         color: 0xffffff,
         align_h: hmUI.align.CENTER_H,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        btn_exit_sleep = groupSleep.createWidget(hmUI.widget.BUTTON, {
         x: 0, //x кнопки
         y: 0, //y кнопки
         text: '',
         w: 480, //ширина кнопки
         h: 480, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'images/Grafik/press_100.png',
         click_func: () => {
          vibro();
          click_exit_sleep();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_on();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        normal_background_Pogoda = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 0,
         y: 0,
         w: 480,
         h: 480,
         color: 0x000000,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);


        //---------------------------    погода
        groupPogoda = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: 480,
         h: 480,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        canvas = groupPogoda.createWidget(hmUI.widget.CANVAS, {
         x: 0,
         y: 0,
         w: 480,
         h: 480,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        canvas.setPaint({
         color: 0x00ff00,
         line_width: 4
        })


        normal_temp_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 118,
         y: 2,
         w: 243,
         h: 33,
         text_size: 28,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        })

        normal_weather_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 118,
         y: 32,
         w: 243,
         h: 33,
         text_size: 28,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        })

        normal_city_name_text_0 = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 76,
         y: 62,
         w: 328,
         h: 33,
         text_size: 28,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        ic_graf_img = groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 426,
         y: 218,
         src: 'images/Grafik/ic_graf_0.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        /*        ic_lexxir_img = groupPogoda.createWidget(hmUI.widget.IMG, {
                 x: 10,
                 y: 218,
                 src: 'images/Grafik/ic_lexxir.png',
                 show_level: hmUI.show_level.ONLY_NORMAL,
                });*/

        groupPogoda.createWidget(hmUI.widget.CIRCLE, {
         center_x: 32,
         center_y: 240,
         radius: 22,
         color: 0xbdbabd,
         // alpha: color_ic == 0 ? 0 : 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        fix_gsm_text_font = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 10,
         y: 220,
         w: 43,
         h: 43,
         text: fix_gsm == 0 ? '+0' : '+1',
         text_size: 28,
         char_space: 0,
         line_space: 0,
         font: 'fonts/Bebas11.ttf',
         color: 0x000000,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        })


        groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 182,
         y: 362,
         src: ROOTPATH + 'Grafik/ic_activ/bg_wind.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.IMG_LEVEL, {
         x: 180,
         y: 362,
         image_array: [ROOTPATH + "Grafik/ic_activ/wind_0.png", ROOTPATH + "Grafik/ic_activ/wind_1.png", ROOTPATH + "Grafik/ic_activ/wind_2.png", ROOTPATH + "Grafik/ic_activ/wind_3.png", ROOTPATH + "Grafik/ic_activ/wind_4.png", ROOTPATH + "Grafik/ic_activ/wind_5.png", ROOTPATH + "Grafik/ic_activ/wind_6.png", ROOTPATH + "Grafik/ic_activ/wind_7.png"],
         image_length: 8,
         type: hmUI.data_type.WIND_DIRECTION,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: 0,
         y: 381,
         w: 480,
         h: 41,
         text_size: 36,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.WIND,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 328,
         y: 381,
         src: ROOTPATH + 'Grafik/ic_activ/ic_davl_txt.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 16,
         y: 176,
         src: ROOTPATH + 'Grafik/ic_activ/ic_uv.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: -44,
         y: 278,
         w: 155,
         h: 31,
         text_size: 28,
         font: 'fonts/Bebas11.ttf',
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.UVI,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 433,
         y: 176,
         src: ROOTPATH + 'Grafik/ic_activ/ic_visota.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: 370,
         y: 278,
         w: 155,
         h: 31,
         text_size: 28,
         font: 'fonts/Bebas11.ttf',
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.ALTITUDE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        text_pressere = groupPogoda.createWidget(hmUI.widget.TEXT, {
         x: 265,
         y: 369,
         w: 155,
         h: 41,
         color: 0xffffff,
         font: 'fonts/Bebas11.ttf',
         text_size: 36,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.NONE,
         text: "--",
        });

        groupPogoda.createWidget(hmUI.widget.IMG, {
         x: 63,
         y: 380,
         src: ROOTPATH + 'Grafik/ic_activ/ic_vlag_txt.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.TEXT_FONT, {
         x: 65,
         y: 369,
         w: 155,
         h: 41,
         text_size: 36,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         font: 'fonts/Bebas11.ttf',
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         unit_type: 1,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.HUMIDITY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        for (var i = 0; i < dney; i++) {
         week_text[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
          x: x0 - 3 - 23 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
          y: 305, //- 21
          w: 52,
          h: 52,
          char_space: 0, //-1
          line_space: 0,
          color: "0xFFffffff",
          text: week_array[i],
          text_size: 23,
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });
         // hmUI.deleteWidget(data_text[i]);
         data_text[i] = groupPogoda.createWidget(hmUI.widget.TEXT, {
          x: x0 - 3 - 23 + i * 46 * 1.0, //,107 + i * 45 * 1.02,
          y: 325, //- 21
          w: 52,
          h: 52,

          char_space: 0, //-1
          line_space: 0,
          color: "0xFFffffff",
          text: 31,
          text_size: 23,
          text_style: hmUI.text_style.NONE,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          show_level: hmUI.show_level.ONLY_NORMAL
         });

         weather_ic[i] = groupPogoda.createWidget(hmUI.widget.IMG, {
          x: x0 - 23 + i * shag,
          y: 91, //- 10
          w: 41,
          h: 41,
          // src: weatherArray[i],
          shortcut: true,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });

         DigDay[i] = groupPogoda.createWidget(hmUI.widget.TEXT);
         if (i < dney - 1) DigNight[i] = groupPogoda.createWidget(hmUI.widget.TEXT);

        }


        btn_Pogoda_off = groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 188, //x кнопки
         y: 188, //y кнопки
         text: '',
         w: 103, //ширина кнопки
         h: 103, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'images/Grafik/press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_Pogoda_off();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_off();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_tip_grafik = groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 377, //x кнопки
         y: 188, //y кнопки
         text: '',
         w: 103, //ширина кнопки
         h: 103, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'images/Grafik/press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_tip_grafik();
         },
         //           longpress_func: () => {
         //            vibro();
         //			   blok_btn_off();
         //           },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupPogoda.createWidget(hmUI.widget.BUTTON, {
         x: 0,
         y: 188,
         w: 103,
         h: 103,
         text: '',
         normal_src: 'blank.png',
         press_src: 'images/Grafik/press_100.png',
         click_func: () => {

          vibro(); //имя вызываемой функции
          click_fix_gms();

          //          hmApp.startApp({
          //           appid: 1051195,
          //           url: 'page/index',
          //           params: {
          //            from_wf: true,
          //           }
          //          });

         },
        });

        groupActiv = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: 480,
         h: 480,
        });

        groupActiv.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         w: 480,
         h: 480,
         src: 'images/Grafik/bg_activ.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        Activ_color_alpha = groupActiv.createWidget(hmUI.widget.CIRCLE, {
         center_x: 240,
         center_y: 240,
         radius: 240,
         color: color_bg_Activ[color_ic],
         alpha: color_ic == 0 ? 0 : 255,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.IMG, {
         x: 0,
         y: 0,
         w: 480,
         h: 480,
         src: 'images/Grafik/bg_activ_mask.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 222,
         y: 198,
         w: 155,
         h: 41,
         text_size: 38,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.WEATHER_HIGH_LOW,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 162,
         y: 370,
         w: 155,
         h: 41,
         text_size: 38,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.DISTANCE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 268,
         y: 72,
         w: 155,
         h: 41,
         text_size: 38,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.PAI_WEEKLY,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_vos_icon_img = groupActiv.createWidget(hmUI.widget.IMG, {
         x: 284,
         y: 262,
         src: 'images/Grafik/ic_activ/ic_vos.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_zak_icon_img = groupActiv.createWidget(hmUI.widget.IMG, {
         x: 284,
         y: 262,
         src: 'images/Grafik/ic_activ/ic_zak.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_zak_text_font = groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 230,
         y: 317,
         w: 155,
         h: 41,
         text_size: 38,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.SUN_SET,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        normal_vos_text_font = groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 230,
         y: 317,
         w: 155,
         h: 41,
         text_size: 38,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.SUN_RISE,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });


        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 162,
         y: 72,
         w: 155,
         h: 41,
         text_size: 38,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         padding: true,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.ALARM_CLOCK,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 53,
         y: 397,
         w: 155,
         h: 41,
         text_size: 38,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.SPO2,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 343,
         y: 317,
         w: 155,
         h: 41,
         text_size: 38,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.STRESS,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 419,
         center_y: 171,
         start_angle: -135,
         end_angle: 135,
         radius: 40,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.STAND,

         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 343,
         y: 198,
         w: 155,
         h: 41,
         text_size: 38,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.STAND,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 185,
         center_y: 288,
         start_angle: -135,
         end_angle: 135,
         radius: 40,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.STEP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 268,
         y: 397,
         w: 155,
         h: 41,
         text_size: 38,
         char_space: 0,
         line_space: 0,
         //padding: true,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.FLOOR,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 102,
         y: 317,
         w: 155,
         h: 41,
         text_size: 38,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.STEP,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 300,
         center_y: 171,
         start_angle: -135,
         end_angle: 135,
         radius: 40,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.WEATHER_CURRENT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 419,
         center_y: 290,
         start_angle: -135,
         end_angle: 135,
         radius: 40,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.STRESS,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 307,
         center_y: 290,
         start_angle: -135,
         end_angle: 135,
         radius: 40,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.SUN_CURRENT,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 180,
         center_y: 171,
         start_angle: -135,
         end_angle: 135,
         radius: 40,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.HEART,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 102,
         y: 198,
         w: 155,
         h: 41,
         text_size: 38,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.HEART,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 61,
         center_y: 290,
         start_angle: -135,
         end_angle: 135,
         radius: 40,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.FAT_BURNING,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: -18,
         y: 317,
         w: 155,
         h: 41,
         text_size: 38,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.FAT_BURNING,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 61,
         center_y: 171,
         start_angle: -135,
         end_angle: 135,
         radius: 40,
         line_width: 10,
         corner_flag: 3,
         color: 0xFFFFFFFF,
         type: hmUI.data_type.CAL,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: 53,
         y: 72,
         w: 155,
         h: 41,
         text_size: 38,
         char_space: 0,
         line_space: 0,
         padding: true,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.COUNT_DOWN,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        groupActiv.createWidget(hmUI.widget.TEXT_FONT, {
         x: -18,
         y: 198,
         w: 155,
         h: 41,
         text_size: 38,
         char_space: 0,
         line_space: 0,
         color: 0xFFFFFFFF,
         align_h: hmUI.align.CENTER_H,
         align_v: hmUI.align.CENTER_V,
         text_style: hmUI.text_style.ELLIPSIS,
         type: hmUI.data_type.CAL,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        ic_activ_color_off_img = groupActiv.createWidget(hmUI.widget.IMG, {
         x: 374,
         y: 356,
         src: 'images/Grafik/ic_activ_color_off.png',
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        ic_activ_color_off_img.setProperty(hmUI.prop.VISIBLE, Activ_color == 0);


        Button_1 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 188,
         y: 19,
         w: 103,
         h: 103,
         text: '',
         color: 0xFFFF8C00,
         text_size: 26,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'AlarmInfoScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_2 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 81,
         y: 19,
         w: 103,
         h: 103,
         text: '',
         color: 0xFFFF8C00,
         text_size: 26,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'CountdownAppScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_3 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 296,
         y: 19,
         w: 103,
         h: 103,
         text: '',
         color: 0xFFFF8C00,
         text_size: 26,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'PAI_app_Screen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_4 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 8,
         y: 126,
         w: 103,
         h: 103,
         text: '',
         color: 0xFFFF8C00,
         text_size: 26,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'activityWeekShowScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_5 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 128,
         y: 126,
         w: 103,
         h: 103,
         text: '',
         color: 0xFFFF8C00,
         text_size: 26,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'heart_app_Screen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_6 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 248,
         y: 126,
         w: 103,
         h: 103,
         text: '',
         color: 0xFFFF8C00,
         text_size: 26,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'WeatherScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_7 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 368,
         y: 126,
         w: 103,
         h: 103,
         text: '',
         color: 0xFFFF8C00,
         text_size: 26,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'SportListScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_8 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 9,
         y: 244,
         w: 103,
         h: 103,
         text: '',
         color: 0xFFFF8C00,
         text_size: 26,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'readinessAppScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_9 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 134,
         y: 244,
         w: 103,
         h: 103,
         text: '',
         color: 0xFFFF8C00,
         text_size: 26,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'activityAppScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_10 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 258,
         y: 244,
         w: 103,
         h: 103,
         text: '',
         color: 0xFFFF8C00,
         text_size: 26,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'TideScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_11 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 368,
         y: 244,
         w: 103,
         h: 103,
         text: '',
         color: 0xFFFF8C00,
         text_size: 26,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'SportRecordListScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button

        Button_12 = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 78,
         y: 352,
         w: 103,
         h: 103,
         text: '',
         color: 0xFFFF8C00,
         text_size: 26,
         press_src: 'images/Grafik/press_100.png',
         normal_src: 'pusto.png',
         click_func: (button_widget) => {
          hmApp.startApp({
           url: 'RespirationwidgetScreen',
           native: true
          });
          vibro();
         }, // end func
         show_level: hmUI.show_level.ONLY_NORMAL,
        }); // end button		   


        btn_Activ_off = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 188,
         y: 377,
         text: '',
         w: 103, //ширина кнопки
         h: 103, //высота кнопки
         text: "ОК",
         char_space: 0,
         line_space: -57,
         color: 0xFFFFFFFF,
         text_size: 25,
         normal_src: '0_Empty.png',
         press_src: 'images/Grafik/press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_Activ_off();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        btn_Activ_color = groupActiv.createWidget(hmUI.widget.BUTTON, {
         x: 309,
         y: 355,
         text: '',
         w: 103, //ширина кнопки
         h: 103, //высота кнопки
         normal_src: '0_Empty.png',
         press_src: 'press_100.png',
         click_func: () => {
          vibro(); //имя вызываемой функции
          click_Activ_color();
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        g_ACR_color = hmUI.createWidget(hmUI.widget.GROUP, {
         x: 0,
         y: 0,
         w: 480,
         h: 480,
        })

        //цвет	
        menu_ARC_PROGRES_bg = g_ACR_color.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 240,
         center_y: 240,
         start_angle: 60 - 15,
         end_angle: 120 + 15,
         radius: 226,
         line_width: 16,
         corner_flag: 0,
         color: 0xFF5b5b5b,
         level: 100,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        menu_ARC_PROGRES = g_ACR_color.createWidget(hmUI.widget.ARC_PROGRESS, {
         center_x: 240,
         center_y: 240,
         start_angle: 45 + 90 / color_bg.length * (-color * 95), // start_angle: 45 + 90 / array * gde,
         end_angle: 135 + 90 / color_bg.length * (-color * 95), //end_angle: 135 + 90 / array * gde,
         radius: 226,
         line_width: 16,
         corner_flag: 0,
         color: 0xFF0000, //0xFF007eff
         level: 100 / color_bg.length, //level: pointer,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });

        for (let i = 0; i < color_bg.length; i++) {
         menu_ARC_color = g_ACR_color.createWidget(hmUI.widget.ARC_PROGRESS, {
          center_x: 240,
          center_y: 240,
          start_angle: 45 + 90 / color_bg.length * i,
          end_angle: 135 + 90 / color_bg.length * i,
          radius: 209,
          line_width: 16,
          corner_flag: 0,
          color: color_bg[i],
          level: 100 / color_bg.length,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });
        };
        g_ACR_color.setProperty(hmUI.prop.VISIBLE, false);


        ACR_text_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
         x: 70,
         y: 72,
         w: 341,
         h: 228,
         color: 0x000000,
         alpha: 158,
         show_level: hmUI.show_level.ONLY_NORMAL,
        });
        ACR_text_bg.setProperty(hmUI.prop.VISIBLE, false);

        for (let i = 0; i < app_text_arr.length; i++) {
         app_ACR_text[i] = hmUI.createWidget(hmUI.widget.TEXT, {
          x: i < 10 ? 68 : 233,
          y: i < 10 ? 70 + i * 21 : 70 + (i - 10) * 21,
          w: 171,
          h: 31,
          text: app_text_arr[i][0],
          text_size: 22,
          char_space: 0,
          line_space: 0,
          //font: 'fonts/Bebas11.ttf',
          color: app_text_num == i ? 0xff0000 : 0xffffff,
          align_h: hmUI.align.CENTER_H,
          align_v: hmUI.align.CENTER_V,
          text_style: hmUI.text_style.NONE,
          show_level: hmUI.show_level.ONLY_NORMAL,
         });
         app_ACR_text[i].setProperty(hmUI.prop.VISIBLE, false);
        };


        //text: app_text_arr[app_text_num][0],


        groupVremya.setProperty(hmUI.prop.VISIBLE, true);
        groupTap.setProperty(hmUI.prop.VISIBLE, false);
        groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
        groupActiv.setProperty(hmUI.prop.VISIBLE, false);
        groupSleep.setProperty(hmUI.prop.VISIBLE, false);
        // end user_script_beforeShortcuts.js

        //start of ignored block
        function time_update(updateHour = false, updateMinute = false) {
         console.log('time_update()');
         let hour = timeSensor.hour;
         let minute = timeSensor.minute;
         let second = timeSensor.second;
         let format_hour = timeSensor.format_hour;


         let valueCalories = second;
         let targetCalories = 60;
         let progressCalories = valueCalories / targetCalories;
         if (progressCalories > 1) progressCalories = 1;
         let progress_cs_normal_calorie = progressCalories;

         if (screenType != hmSetting.screen_type.AOD) {

          // normal_calorie_circle_scale_circle_scale
          let level = Math.round(progress_cs_normal_calorie * 100);
          if (normal_calorie_circle_scale) {
           normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
            center_x: 240,
            center_y: 240,
            start_angle: 0,
            end_angle: 360,
            radius: 194,
            line_width: 24,
            corner_flag: 3,
            color: color_bg[color],
            show_level: hmUI.show_level.ONLY_NORMAL,
            level: level,
           });
          };
         };

         let Sensor_week = timeSensor.week;
         let Sensor_month = timeSensor.month;
         // тест
//                         let Sensor_month = 9;
//                         let Sensor_week = 1;

         console.log('day of week font');
         if (updateHour) {
          let normal_DOW_Str = normal_DOW_Array[Sensor_week - 1];
          normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str);
         };

         console.log('hour font');
         if (updateHour) {
          //          let normal_hourStr = format_hour.toString();
          //          normal_hourStr = normal_hourStr.padStart(2, '0');
          //          normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr);

          let normal_Month_Str = normal_Month_Array[Sensor_month - 1];
          normal_month_name_font.setProperty(hmUI.prop.TEXT, normal_Month_Str);

          let normal_DOW_Str = normal_DOW_Array[Sensor_week - 1];
          normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str);

          let normal_dayStr = timeSensor.day.toString();
          normal_dayStr = normal_dayStr.padStart(2, '0');
          // normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );

          let max_x = (len_week[Sensor_week - 1] - len_month[Sensor_month - 1])*D_W/466;


          let normal_max_x = max_x < 0 ? len_month[Sensor_month - 1]*D_W/466 : len_week[Sensor_week - 1]*D_W/466

          let normal_day_x = (D_W - 86*D_W/466 - normal_max_x) / 2;

          // normal_day_text_font.setProperty(hmUI.prop.x, normal_day_x);
          normal_month_name_font.setProperty(hmUI.prop.X, normal_day_x + 86*D_W/466);
          normal_dow_text_font.setProperty(hmUI.prop.X, normal_day_x + 86*D_W/466);

          normal_day_text_font.setProperty(hmUI.prop.MORE, {
           x: normal_day_x,
           y: 98,
           w: 89,
           h: 103,
           text: normal_dayStr,
           text_size: 89,
           char_space: 0,
           line_space: 0,
           font: 'fonts/Bebas11.ttf',
           color: 0xFFFFFFFF,
           align_h: hmUI.align.CENTER_H,
           align_v: hmUI.align.CENTER_V,
           text_style: hmUI.text_style.ELLIPSIS,
           // padding: true,
           show_level: hmUI.show_level.ONLY_NORMAL,
          });


          //            let len_month = [93, 115, 80, 94, 51, 70, 70, 106, 120, 106, 92, 111];
          //            let len_week = [177, 108, 78, 101, 112, 107, 165];
          //            let len_data = 76;


         };

         console.log('minute font');
         /*         if (updateMinute) {
                   let normal_minuteStr = minute.toString();
                   normal_minuteStr = normal_minuteStr.padStart(2, '0');
                   normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr);
                  };*/

        };

        //end of ignored block


        const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
         resume_call: (function () {

          app_update();
          loadSettings();

          //-----------  сон------------------
          sleepTotalTime = sleep.getTotalTime();
          sleepInfo = sleep.getBasicInfo();
          sleepStartTime = sleepInfo.startTime;
          if (sleepStartTime >= 24 * 60) {
           sleepStartTime -= 24 * 60
          }

          sleepEndTime = sleepInfo.endTime + 1;
          if (sleepEndTime >= 24 * 60) {
           sleepEndTime -= 24 * 60
          }

          //-----------  время пробуждений ------------------
          let wakeTime = 0;
          sleepStageArray = sleep.getSleepStageData();

          for (let i = 0; i < sleepStageArray.length; i++) {
           let data = sleepStageArray[i];
           if (data.model == modelData.WAKE_STAGE) {
            wakeTime += data.stop + 1 - data.start;
           }

          }

          sleepTotalTime -= wakeTime;
          //-------------------------------------------------

          sleep_time_txt.setProperty(hmUI.prop.TEXT, 'СПАЛИ ' + Math.floor(sleepTotalTime / 60).toString().padStart(2, "0") + ':' + (sleepTotalTime % 60).toString().padStart(2, "0"));
          sleep_start_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepStartTime / 60).toString().padStart(2, "0") + ':' + (sleepStartTime % 60).toString().padStart(2, "0"));
          sleep_end_time_txt.setProperty(hmUI.prop.TEXT, Math.floor(sleepEndTime / 60).toString().padStart(2, "0") + ':' + (sleepEndTime % 60).toString().padStart(2, "0"));
          wake_time_txt.setProperty(hmUI.prop.TEXT, 'ПРОСЫПАЛИСЬ ' + String(wakeTime) + ' мин.');
          sleep_score_txt.setProperty(hmUI.prop.TEXT, 'КАЧЕСТВО ' + String(sleepScore) + ' %');
          //-------------------------------------------------


          let pressure_array = read_pressure();
          let value = getPressureValue(pressure_array);
          value = hPa_To_mmHg(value); // если нужно перевести в мм.рт.ст.

          let pressere_changes_str = "=";
          let color_pressere = 0x00ff00;
          let pressere_changes = changesPressure(pressure_array);
          if (pressere_changes < 0) {
           pressere_changes_str = "↓";
           color_pressere = 0xffff00;
          }
          if (pressere_changes > 0) {
           pressere_changes_str = "↑";
           color_pressere = 0xff0000;
          }
          //text_pressere_changes.setProperty(hmUI.prop.TEXT, pressere_changes_str);

          let value_str = value == 0 ? "--" : value + pressere_changes_str;
          text_pressere.setProperty(hmUI.prop.TEXT, value_str);
          text_pressere.setProperty(hmUI.prop.COLOR, color_pressere);

          // normal_current_text_sensor.setProperty(hmUI.prop.TEXT, value_str);

          app_text_arr[5][1] = value_str;


          //  scale_call();
          time_update(true, true);
          if (screenType == hmSetting.screen_type.WATCHFACE) {
           if (!normal_timerTimeUpdate) {
            normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {


             let updateHour = timeSensor.minute == 0;
             let updateMinute = timeSensor.second < 2;
             time_update(updateHour, updateMinute);
            })); // end timer 
           }; // end timer check
          }; // end screenType


          console.log('resume_call.js');
          // start resume_call.js

          stopVibro();
          updateGrafik();

          setTimeout(() => {
           onDigitalCrown();
          }, 350);

         }),
         pause_call: (function () {
          hmApp.unregisterSpinEvent();
          console.log('pause_call()');
          if (normal_timerTimeUpdate) {
           timer.stopTimer(normal_timerTimeUpdate);
           normal_timerTimeUpdate = undefined;
          }

          console.log('pause_call.js');
          // start pause_call.js

          stopVibro();

          groupVremya.setProperty(hmUI.prop.VISIBLE, true);
          groupPogoda.setProperty(hmUI.prop.VISIBLE, false);
          groupTap.setProperty(hmUI.prop.VISIBLE, false);
          groupActiv.setProperty(hmUI.prop.VISIBLE, false);
          groupSleep.setProperty(hmUI.prop.VISIBLE, false);
          normal_background_Pogoda.setProperty(hmUI.prop.VISIBLE, false);
          // end pause_call.js

         }),
        });


        //dynamic modify end
       },
       onInit() {
        if (hmSetting.getScreenType() == hmSetting.screen_type.AOD) {
         stopVibro();
         loadSettings();
        }
       },
       build() {
        this.init_view();
        logger.log('index page.js on ready invoke');
       },
       onDestroy() {
        logger.log('index page.js on destroy invoke');
       }
      });;
     })();
    } catch (e) {
     console.log('Mini Program Error', e);
     e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));;
    }
