﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_sun_high_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_sun_high_text_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 290,
              y: 143,
              src: 'Sveglia.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 255,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 16,
              y: 254,
              image_array: ["Batteria_01.png","Batteria_02.png","Batteria_03.png","Batteria_04.png","Batteria_05.png","Batteria_06.png","Batteria_07.png","Batteria_08.png","Batteria_09.png"],
              image_length: 9,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 18,
              font_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'Attività_15.png',
              dot_image: 'Attività_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 265,
              year_startY: 68,
              year_sc_array: ["Anno_01.png","Anno_02.png","Anno_03.png","Anno_04.png","Anno_05.png","Anno_06.png","Anno_07.png","Anno_08.png","Anno_09.png","Anno_10.png"],
              year_tc_array: ["Anno_01.png","Anno_02.png","Anno_03.png","Anno_04.png","Anno_05.png","Anno_06.png","Anno_07.png","Anno_08.png","Anno_09.png","Anno_10.png"],
              year_en_array: ["Anno_01.png","Anno_02.png","Anno_03.png","Anno_04.png","Anno_05.png","Anno_06.png","Anno_07.png","Anno_08.png","Anno_09.png","Anno_10.png"],
              year_zero: 1,
              year_space: 1,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 151,
              month_startY: 68,
              month_sc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_tc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_en_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 69,
              y: 117,
              week_en: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_tc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_sc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 74,
              day_startY: 68,
              day_sc_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
              day_tc_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
              day_en_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 144,
              y: 396,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 406,
              font_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Attività_13.png',
              unit_tc: 'Attività_13.png',
              unit_en: 'Attività_13.png',
              imperial_unit_sc: 'Attività_13.png',
              imperial_unit_tc: 'Attività_13.png',
              imperial_unit_en: 'Attività_13.png',
              negative_image: 'Attività_14.png',
              invalid_image: 'Attività_15.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 218,
                y: 406,
                font_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
                padding: false,
                h_space: 3,
                unit_sc: 'Attività_13.png',
                unit_tc: 'Attività_13.png',
                unit_en: 'Attività_13.png',
                imperial_unit_sc: 'Attività_13.png',
                imperial_unit_tc: 'Attività_13.png',
                imperial_unit_en: 'Attività_13.png',
                negative_image: 'Attività_14.png',
                invalid_image: 'Attività_15.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 263,
              y: 344,
              font_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 206,
              y: 315,
              image_array: ["Barra_01.png","Barra_02.png","Barra_03.png","Barra_04.png","Barra_05.png","Barra_06.png","Barra_07.png","Barra_08.png","Barra_09.png"],
              image_length: 9,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 258,
              font_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
              padding: false,
              h_space: 3,
              dot_image: 'Attività_16.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 206,
              font_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 362,
              y: 135,
              font_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Attività_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 17,
              hour_startY: 155,
              hour_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 163,
              minute_startY: 155,
              minute_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 55,
              second_startY: 325,
              second_array: ["Secondi_01.png","Secondi_02.png","Secondi_03.png","Secondi_04.png","Secondi_05.png","Secondi_06.png","Secondi_07.png","Secondi_08.png","Secondi_09.png","Secondi_10.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 135,
              y: 155,
              src: 'Ore_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Back_01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 290,
              y: 143,
              src: 'Sveglia.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 165,
              y: 255,
              font_array: ["Sistema_01.png","Sistema_02.png","Sistema_03.png","Sistema_04.png","Sistema_05.png","Sistema_06.png","Sistema_07.png","Sistema_08.png","Sistema_09.png","Sistema_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 16,
              y: 254,
              image_array: ["Batteria_01.png","Batteria_02.png","Batteria_03.png","Batteria_04.png","Batteria_05.png","Batteria_06.png","Batteria_07.png","Batteria_08.png","Batteria_09.png"],
              image_length: 9,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 191,
              y: 18,
              font_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'Attività_15.png',
              dot_image: 'Attività_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 265,
              year_startY: 68,
              year_sc_array: ["Anno_01.png","Anno_02.png","Anno_03.png","Anno_04.png","Anno_05.png","Anno_06.png","Anno_07.png","Anno_08.png","Anno_09.png","Anno_10.png"],
              year_tc_array: ["Anno_01.png","Anno_02.png","Anno_03.png","Anno_04.png","Anno_05.png","Anno_06.png","Anno_07.png","Anno_08.png","Anno_09.png","Anno_10.png"],
              year_en_array: ["Anno_01.png","Anno_02.png","Anno_03.png","Anno_04.png","Anno_05.png","Anno_06.png","Anno_07.png","Anno_08.png","Anno_09.png","Anno_10.png"],
              year_zero: 1,
              year_space: 1,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 149,
              month_startY: 68,
              month_sc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_tc_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_en_array: ["Mese_01.png","Mese_02.png","Mese_03.png","Mese_04.png","Mese_05.png","Mese_06.png","Mese_07.png","Mese_08.png","Mese_09.png","Mese_10.png","Mese_11.png","Mese_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 69,
              y: 117,
              week_en: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_tc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              week_sc: ["Giorni_01.png","Giorni_02.png","Giorni_03.png","Giorni_04.png","Giorni_05.png","Giorni_06.png","Giorni_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 74,
              day_startY: 68,
              day_sc_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
              day_tc_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
              day_en_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 144,
              y: 396,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 406,
              font_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Attività_13.png',
              unit_tc: 'Attività_13.png',
              unit_en: 'Attività_13.png',
              imperial_unit_sc: 'Attività_13.png',
              imperial_unit_tc: 'Attività_13.png',
              imperial_unit_en: 'Attività_13.png',
              negative_image: 'Attività_14.png',
              invalid_image: 'Attività_15.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //start of ignored block
            if (temperatureUnit == 1) {
              idle_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 218,
                y: 406,
                font_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
                padding: false,
                h_space: 3,
                unit_sc: 'Attività_13.png',
                unit_tc: 'Attività_13.png',
                unit_en: 'Attività_13.png',
                imperial_unit_sc: 'Attività_13.png',
                imperial_unit_tc: 'Attività_13.png',
                imperial_unit_en: 'Attività_13.png',
                negative_image: 'Attività_14.png',
                invalid_image: 'Attività_15.png',
                align_h: hmUI.align.RIGHT,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_AOD,
              });
            };
            //end of ignored block

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 263,
              y: 344,
              font_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 206,
              y: 315,
              image_array: ["Barra_01.png","Barra_02.png","Barra_03.png","Barra_04.png","Barra_05.png","Barra_06.png","Barra_07.png","Barra_08.png","Barra_09.png"],
              image_length: 9,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 258,
              font_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
              padding: false,
              h_space: 3,
              dot_image: 'Attività_16.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 338,
              y: 206,
              font_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 362,
              y: 135,
              font_array: ["Attività_01.png","Attività_02.png","Attività_03.png","Attività_04.png","Attività_05.png","Attività_06.png","Attività_07.png","Attività_08.png","Attività_09.png","Attività_11.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'Attività_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 17,
              hour_startY: 155,
              hour_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 163,
              minute_startY: 155,
              minute_array: ["Ore_01.png","Ore_02.png","Ore_03.png","Ore_04.png","Ore_05.png","Ore_06.png","Ore_07.png","Ore_08.png","Ore_09.png","Ore_10.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 135,
              y: 155,
              src: 'Ore_11.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}