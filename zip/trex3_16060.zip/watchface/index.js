﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_day = ''
        let normal_compass_icon_img = ''
        let normal_compass_direction_pointer_img = ''
        let normal_compass_text_img = ''
        let normal_compass_direction_img_level = ''
        let normal_compass_direction_arr = ["d_1.png", "d_2.png", "d_3.png", "d_4.png", "d_5.png", "d_6.png", "d_7.png", "d_8.png"];
        let normal_alarm_clock_icon_img = ''
        let normal_alarm_clock_text_text_img = ''
        let normal_wind_icon_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_text_text_img = ''
        let normal_moon_icon_img = ''
        let normal_moon_current_text_img = ''
        let normal_moon_pointer_progress_img_pointer = ''
        let normal_sun_icon_img = ''
        let normal_sun_current_text_img = ''
        let normal_sun_pointer_progress_img_pointer = ''
        let normal_uvi_icon_img = ''
        let normal_uvi_pointer_progress_img_pointer = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_pai_icon_img = ''
        let normal_pai_pointer_progress_img_pointer = ''
        let normal_pai_weekly_text_img = ''
        let normal_training_load_icon_img = ''
        let normal_training_load_pointer_progress_img_pointer = ''
        let normal_training_load_text_text_img = ''
        let normal_readiness_icon_img = ''
        let normal_readiness_pointer_progress_img_pointer = ''
        let normal_readiness_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_stand_target_TextCircle = new Array(2);
        let normal_stand_target_TextCircle_ASCIIARRAY = new Array(10);
        let normal_stand_target_TextCircle_img_width = 20;
        let normal_stand_target_TextCircle_img_height = 37;
        let normal_stand_TextCircle = new Array(2);
        let normal_stand_TextCircle_ASCIIARRAY = new Array(10);
        let normal_stand_TextCircle_img_width = 20;
        let normal_stand_TextCircle_img_height = 37;
        let normal_stand_TextCircle_unit = null;
        let normal_stand_TextCircle_unit_width = 16;
        let normal_stand_image_progress_img_level = ''
        let normal_step_TextCircle = new Array(5);
        let normal_step_TextCircle_ASCIIARRAY = new Array(10);
        let normal_step_TextCircle_img_width = 20;
        let normal_step_TextCircle_img_height = 37;
        let normal_step_image_progress_img_level = ''
        let normal_heart_rate_TextCircle = new Array(3);
        let normal_heart_rate_TextCircle_ASCIIARRAY = new Array(10);
        let normal_heart_rate_TextCircle_img_width = 20;
        let normal_heart_rate_TextCircle_img_height = 37;
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_TextCircle = new Array(3);
        let normal_battery_TextCircle_ASCIIARRAY = new Array(10);
        let normal_battery_TextCircle_img_width = 20;
        let normal_battery_TextCircle_img_height = 37;
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let mask = ''
        let fg_mask = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_stand_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
		
		const curTime = hmSensor.createSensor(hmSensor.id.TIME);
		const weather = hmSensor.createSensor(hmSensor.id.WEATHER);
		let weatherData = weather.getForecastWeather();
		let forecastData = weatherData.forecastData;
		let sunData = weatherData.tideData;
		let today = '';
		let sunriseMins = '';
		let sunsetMins = '';
		let sunriseMins_def = 8 * 60;			
		let sunsetMins_def = 20 * 60;

		let curMins = '';
		
		let isDayBg = true;
		
		function autoToggleBg() {

			weatherData = weather.getForecastWeather();
			sunData = weatherData.tideData;
			if (sunData.count > 0){
				today = sunData.data[0];
				sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
				sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
			} else {
				sunriseMins = sunriseMins_def;
				sunsetMins = sunsetMins_def;
			}

			curMins = curTime.hour * 60 + curTime.minute;
			let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
			
			if(isDayNow){
				if(!isDayBg){
					normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "day.png");
					isDayBg = true;
				}
			} else {
				if(isDayBg){
					normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "night.png");
					isDayBg = false;
				}
			}
		}
		
		let btn_zona1 = ''
        let zona1_num = 0
        let zona1_all = 9
		
		function click_zona1() {
		  zona1_num = (zona1_num + 1) % (zona1_all + 1);
          if (zona1_num == 0) {		
		    normal_readiness_icon_img.setProperty(hmUI.prop.VISIBLE, true);
            normal_readiness_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_readiness_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_training_load_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		 if (zona1_num == 1) {
			normal_readiness_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_readiness_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_readiness_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_training_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_training_load_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 2) {
			normal_readiness_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_readiness_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_readiness_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 3) {
			normal_readiness_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_readiness_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_readiness_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 4) {
			normal_readiness_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_readiness_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_readiness_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 5) {
			normal_readiness_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_readiness_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_readiness_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 6) {
			normal_readiness_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_readiness_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_readiness_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_moon_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_moon_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 7) {
			normal_readiness_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_readiness_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_readiness_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_alarm_clock_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 8) {
			normal_readiness_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_readiness_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_readiness_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_alarm_clock_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
		    hmUI.showToast({
            });
          };
		  
		  if (zona1_num == 9) {
			normal_readiness_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_readiness_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_readiness_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, true);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, true);
		    hmUI.showToast({
            });
          };
        }
		
		let longPress_Timer = null;
	    let longPressDelay = 900; 
		
		function getLongPress1() {
		    if(longPress_Timer) timer.stopTimer(longPress_Timer);
			
			let url;

			switch(zona1_num) {
			   case 0:
					url = 'readinessAppScreen';
				break;
			   case 1:
					url = 'SportStatusScreen';
				break;
			   case 2:
					url = 'PAI_app_Screen';
				break;
			   case 3:
					url = 'WeatherScreen';
				break;
				case 4:
					url = 'WeatherScreen';
				break;
				case 5:
					url = 'TideScreen';
				break;
				case 6:
					url = 'TideScreen';
				break;
				case 7:
					url = 'WeatherScreen';
				break;
				case 8:
					url = 'AlarmInfoScreen';
				break;
				case 9:
					url = 'CompassScreen';
				break;
			   default:
				break;
			}
			hmApp.startApp({ url: url, native: true });
			
	    }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 286,
              y: 372,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 229,
              y: 371,
              src: 'bt.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 177,
              y: 371,
              src: 'clock.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 213,
              day_startY: 98,
              day_sc_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              day_tc_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              day_en_array: ["n_0.png","n_1.png","n_2.png","n_3.png","n_4.png","n_5.png","n_6.png","n_7.png","n_8.png","n_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 146,
              src: 'compass.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            
            // normal_compass_custom_pointer_img = hmUI.createWidget(hmUI.widget.CUSTOM_POINTER, {
              // src: 'Pointer12.png',
              // center_x: 239,
              // center_y: 220,
              // x: 10,
              // y: 68,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.COMPASS,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            //#region Compass_Pointer
            normal_compass_direction_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 239 - 10,
              pos_y: 220 - 68,
              center_x: 239,
              center_y: 220,
              src: 'Pointer12.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //#endregion

            normal_compass_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 192,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'du.png',
              unit_tc: 'du.png',
              unit_en: 'du.png',
              negative_image: 'negative1.png',
              align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.COMPASS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_compass_direction_img_level = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 227,
              src: 'd_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
              // img_error: 'direction-NULL.png',
              // type: hmUI.data_type.COMPASS,
            });

            normal_alarm_clock_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 146,
              src: 'timerbg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 188,
              y: 220,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'negative1.png',
              dot_image: 'colonsun.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 146,
              src: 'wind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 179,
              y: 159,
              image_array: ["wind_1.png","wind_2.png","wind_3.png","wind_4.png","wind_5.png","wind_6.png","wind_7.png","wind_8.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 202,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 146,
              src: 'moonset.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 220,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'colonsun.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'moon.png',
              center_x: 240,
              center_y: 231,
              x: 21,
              y: 64,
              start_angle: -51,
              end_angle: 51,
              invalid_visible: false,
              type: hmUI.data_type.MOON_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 146,
              src: 'sunset.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 220,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: 0,
              dot_image: 'colonsun.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'sun.png',
              center_x: 240,
              center_y: 231,
              x: 21,
              y: 64,
              start_angle: -51,
              end_angle: 51,
              invalid_visible: false,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 146,
              src: 'temperature.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer01.png',
              center_x: 240,
              center_y: 220,
              x: 15,
              y: 70,
              start_angle: -136,
              end_angle: 138,
              invalid_visible: false,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 146,
              src: 'day.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			autoToggleBg();

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 200,
              y: 179,
              image_array: ["w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_26.png","w_27.png","w_28.png","w_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 250,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'du.png',
              unit_tc: 'du.png',
              unit_en: 'du.png',
              negative_image: 'negative2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 146,
              src: 'PAI.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer.png',
              center_x: 241,
              center_y: 220,
              x: 12,
              y: 72,
              start_angle: -134,
              end_angle: 135,
              invalid_visible: false,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 202,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_training_load_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 146,
              src: 'training_load.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_training_load_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer.png',
              center_x: 240,
              center_y: 221,
              x: 12,
              y: 71,
              start_angle: -129,
              end_angle: 133,
              invalid_visible: false,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_training_load_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 202,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.TRAINING_LOAD,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 166,
              y: 146,
              src: 'readiness.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer.png',
              center_x: 241,
              center_y: 220,
              x: 12,
              y: 71,
              start_angle: -133,
              end_angle: 137,
              invalid_visible: false,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 212,
              y: 200,
              font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.READINESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 8,
              y: 16,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_target_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              // radius: 242,
              // angle: -139,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STAND_TARGET,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_target_TextCircle_ASCIIARRAY[0] = 'num_0.png';  // set of images with numbers
            normal_stand_target_TextCircle_ASCIIARRAY[1] = 'num_1.png';  // set of images with numbers
            normal_stand_target_TextCircle_ASCIIARRAY[2] = 'num_2.png';  // set of images with numbers
            normal_stand_target_TextCircle_ASCIIARRAY[3] = 'num_3.png';  // set of images with numbers
            normal_stand_target_TextCircle_ASCIIARRAY[4] = 'num_4.png';  // set of images with numbers
            normal_stand_target_TextCircle_ASCIIARRAY[5] = 'num_5.png';  // set of images with numbers
            normal_stand_target_TextCircle_ASCIIARRAY[6] = 'num_6.png';  // set of images with numbers
            normal_stand_target_TextCircle_ASCIIARRAY[7] = 'num_7.png';  // set of images with numbers
            normal_stand_target_TextCircle_ASCIIARRAY[8] = 'num_8.png';  // set of images with numbers
            normal_stand_target_TextCircle_ASCIIARRAY[9] = 'num_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 2; i++) {
              normal_stand_target_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_stand_target_TextCircle_img_width / 2,
                pos_y: 240 + 205,
                src: 'num_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_stand_target_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            // normal_stand_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              // radius: 242,
              // angle: -133,
              // char_space_angle: 0,
              // unit: 'percent.png',
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: RIGHT,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_TextCircle_ASCIIARRAY[0] = 'num_0.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[1] = 'num_1.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[2] = 'num_2.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[3] = 'num_3.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[4] = 'num_4.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[5] = 'num_5.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[6] = 'num_6.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[7] = 'num_7.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[8] = 'num_8.png';  // set of images with numbers
            normal_stand_TextCircle_ASCIIARRAY[9] = 'num_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 2; i++) {
              normal_stand_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_stand_TextCircle_img_width / 2,
                pos_y: 240 + 205,
                src: 'num_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_stand_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_stand_TextCircle_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              center_x: 240,
              center_y: 240,
              pos_x: 240 - normal_stand_TextCircle_unit_width / 2,
              pos_y: 240 + 205,
              src: 'percent.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_stand_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
            //#endregion

            normal_stand_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 33,
              y: 240,
              image_array: ["stnd_1.png","stnd_2.png","stnd_3.png","stnd_4.png","stnd_5.png","stnd_6.png","stnd_7.png","stnd_8.png","stnd_9.png","stnd_10.png","stnd_11.png","stnd_12.png"],
              image_length: 12,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              // radius: 241,
              // angle: 135,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextCircle_ASCIIARRAY[0] = 'num_0.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[1] = 'num_1.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[2] = 'num_2.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[3] = 'num_3.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[4] = 'num_4.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[5] = 'num_5.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[6] = 'num_6.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[7] = 'num_7.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[8] = 'num_8.png';  // set of images with numbers
            normal_step_TextCircle_ASCIIARRAY[9] = 'num_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 5; i++) {
              normal_step_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_step_TextCircle_img_width / 2,
                pos_y: 240 + 204,
                src: 'num_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 240,
              y: 240,
              image_array: ["step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png","step_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_rate_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              // radius: 204,
              // angle: 46,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_TextCircle_ASCIIARRAY[0] = 'num_0.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[1] = 'num_1.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[2] = 'num_2.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[3] = 'num_3.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[4] = 'num_4.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[5] = 'num_5.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[6] = 'num_6.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[7] = 'num_7.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[8] = 'num_8.png';  // set of images with numbers
            normal_heart_rate_TextCircle_ASCIIARRAY[9] = 'num_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              normal_heart_rate_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_heart_rate_TextCircle_img_width / 2,
                pos_y: 240 - 241,
                src: 'num_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 240,
              y: 33,
              image_array: ["h_1.png","h_2.png","h_3.png","h_4.png","h_5.png","h_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 240,
              // circle_center_Y: 240,
              // font_array: ["num_0.png","num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png"],
              // radius: 204,
              // angle: -46,
              // char_space_angle: 0,
              // zero: false,
              // reverse_direction: false,
              // unit_in_alignment: true,
              // vertical_alignment: BOTTOM,
              // horizontal_alignment: CENTER_H,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_battery_TextCircle_ASCIIARRAY[0] = 'num_0.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[1] = 'num_1.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[2] = 'num_2.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[3] = 'num_3.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[4] = 'num_4.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[5] = 'num_5.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[6] = 'num_6.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[7] = 'num_7.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[8] = 'num_8.png';  // set of images with numbers
            normal_battery_TextCircle_ASCIIARRAY[9] = 'num_9.png';  // set of images with numbers

            //#region TextCircle
            for (let i = 0; i < 3; i++) {
              normal_battery_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 240,
                center_y: 240,
                pos_x: 240 - normal_battery_TextCircle_img_width / 2,
                pos_y: 240 - 241,
                src: 'num_0.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //#endregion
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 33,
              y: 33,
              image_array: ["batt_1.png","batt_2.png","batt_3.png","batt_4.png","batt_5.png","batt_6.png","batt_7.png","batt_8.png","batt_9.png","batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 104,
              hour_startY: 285,
              hour_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'colon.png',
              hour_unit_tc: 'colon.png',
              hour_unit_en: 'colon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 201,
              minute_startY: 285,
              minute_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'colon.png',
              minute_unit_tc: 'colon.png',
              minute_unit_en: 'colon.png',
              minute_align: hmUI.align.LEFT,

              second_startX: 296,
              second_startY: 285,
              second_array: ["time_0.png","time_1.png","time_2.png","time_3.png","time_4.png","time_5.png","time_6.png","time_7.png","time_8.png","time_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 45,
              hour_startY: 158,
              hour_array: ["info_bricks_digital_time_num_0.png","info_bricks_digital_time_num_1.png","info_bricks_digital_time_num_2.png","info_bricks_digital_time_num_3.png","info_bricks_digital_time_num_4.png","info_bricks_digital_time_num_5.png","info_bricks_digital_time_num_6.png","info_bricks_digital_time_num_7.png","info_bricks_digital_time_num_8.png","info_bricks_digital_time_num_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'aodcolon.png',
              hour_unit_tc: 'aodcolon.png',
              hour_unit_en: 'aodcolon.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 260,
              minute_startY: 158,
              minute_array: ["info_bricks_digital_time_num_0.png","info_bricks_digital_time_num_1.png","info_bricks_digital_time_num_2.png","info_bricks_digital_time_num_3.png","info_bricks_digital_time_num_4.png","info_bricks_digital_time_num_5.png","info_bricks_digital_time_num_6.png","info_bricks_digital_time_num_7.png","info_bricks_digital_time_num_8.png","info_bricks_digital_time_num_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Editable_Elements');

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 66,
              y: 187,
              w: 100,
              h: 100,
              select_image: 'select.png',
              un_select_image: 'unselect.png',
              default_type: hmUI.edit_type.APPLIST,
              optional_types: [
                { type: hmUI.edit_type.APPLIST, preview: 'ez(1)_APPLIST.png' },
              ],
              count: 1,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '.png',
              tips_x: -66,
              tips_y: -187,
              tips_width: 0,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 315,
              y: 187,
              w: 100,
              h: 100,
              select_image: 'select.png',
              un_select_image: 'unselect.png',
              default_type: hmUI.edit_type.SPORTSLIST,
              optional_types: [
                { type: hmUI.edit_type.SPORTSLIST, preview: 'ez(2)_SPORTSLIST.png' },
              ],
              count: 1,
              select_list: {
                title_font_size: 34,
                title_align_h: hmUI.align.CENTER_H,
                list_item_vspace: 8,
                list_tips_text_font_size: 32,
                list_tips_text_align_h: hmUI.align.LEFT
              },
              tips_BG: '.png',
              tips_x: -315,
              tips_y: -187,
              tips_width: 0,
              tips_margin: 0,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'mask.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'mask1.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });
            console.log('Watch_Face.Shortcuts');
			
			const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if (scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro() {
              vibrate.stop();
              if (timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 340,
              y: 363,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 340,
              y: 35,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_zona1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 170,
              text: '',
              w: 100,
              h: 100,
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
				vibro();
				click_zona1();
                click_Vibrate();
             },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_zona1.setProperty(hmUI.prop.VISIBLE, true);
			normal_training_load_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_training_load_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_uvi_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_sun_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_moon_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_direction_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
			normal_wind_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_alarm_clock_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_icon_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_text_img.setProperty(hmUI.prop.VISIBLE, false);
			normal_compass_direction_img_level.setProperty(hmUI.prop.VISIBLE, false);
			
			btn_zona1.addEventListener(hmUI.event.CLICK_DOWN, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
					longPress_Timer = timer.createTimer(longPressDelay, 0, getLongPress1, {});
			});
			btn_zona1.addEventListener(hmUI.event.CLICK_UP, function () {
					if(longPress_Timer) timer.stopTimer(longPress_Timer);
			});

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 35,
              w: 100,
              h: 100,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 40,
              y: 363,
              w: 100,
              h: 100,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 195,
              y: 293,
              w: 80,
              h: 65,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 100,
              y: 293,
              w: 80,
              h: 65,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 80,
              w: 100,
              h: 65,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'Empty.png',
              normal_src: 'Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              longpress_func: (button_widget) => {
                hmApp.startApp({url: 'todoListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            let screenType = hmSetting.getScreenType();
            //#region text_update
            function text_update() {
              console.log('text_update()');

              console.log('update text circle stand_target_STAND');
              let targetStand = stand.target;
              let normal_stand_target_circle_string = parseInt(targetStand).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_stand_target_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 41;
                if (targetStand != null && targetStand != undefined && isFinite(targetStand) && normal_stand_target_circle_string.length > 0 && normal_stand_target_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_stand_target_TextCircle_img_angle = 0;
                  let normal_stand_target_TextCircle_dot_img_angle = 0;
                  normal_stand_target_TextCircle_img_angle = toDegree(Math.atan2(normal_stand_target_TextCircle_img_width/2, 242));
                  // alignment = CENTER_H
                  let normal_stand_target_TextCircle_angleOffset = normal_stand_target_TextCircle_img_angle * (normal_stand_target_circle_string.length - 1);
                  normal_stand_target_TextCircle_angleOffset = -normal_stand_target_TextCircle_angleOffset;
                  char_Angle -= normal_stand_target_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_stand_target_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_stand_target_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_stand_target_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_stand_target_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_stand_target_TextCircle_img_width / 2);
                      normal_stand_target_TextCircle[index].setProperty(hmUI.prop.SRC, normal_stand_target_TextCircle_ASCIIARRAY[charCode]);
                      normal_stand_target_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_stand_target_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle stand_STAND');
              let valueStand = stand.current;
              let normal_stand_circle_string = parseInt(valueStand).toString();
              normal_stand_circle_string = normal_stand_circle_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_stand_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_stand_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, false);
                let char_Angle = 47;
                if (valueStand != null && valueStand != undefined && isFinite(valueStand) && normal_stand_circle_string.length > 0 && normal_stand_circle_string.length <= 2) {  // display data if it was possible to get it
                  let normal_stand_TextCircle_img_angle = 0;
                  let normal_stand_TextCircle_dot_img_angle = 0;
                  let normal_stand_TextCircle_unit_angle = 0;
                  normal_stand_TextCircle_img_angle = toDegree(Math.atan2(normal_stand_TextCircle_img_width/2, 242));
                  normal_stand_TextCircle_unit_angle = toDegree(Math.atan2(normal_stand_TextCircle_unit_width/2, 242));
                  // alignment = RIGHT
                  let normal_stand_TextCircle_angleOffset = normal_stand_TextCircle_img_angle * (normal_stand_circle_string.length - 1);
                  normal_stand_TextCircle_angleOffset = normal_stand_TextCircle_angleOffset + (normal_stand_TextCircle_img_angle + normal_stand_TextCircle_unit_angle + 0) / 2;
                  normal_stand_TextCircle_angleOffset = -normal_stand_TextCircle_angleOffset;
                  char_Angle -= 2 * normal_stand_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_stand_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_stand_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_stand_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_stand_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_stand_TextCircle_img_width / 2);
                      normal_stand_TextCircle[index].setProperty(hmUI.prop.SRC, normal_stand_TextCircle_ASCIIARRAY[charCode]);
                      normal_stand_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_stand_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                  char_Angle -= normal_stand_TextCircle_unit_angle;
                  normal_stand_TextCircle_unit.setProperty(hmUI.prop.ANGLE, char_Angle);
                  normal_stand_TextCircle_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite

              };

              console.log('update text circle step_STEP');
              let valueStep = step.current;
              let normal_step_circle_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 315;
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_circle_string.length > 0 && normal_step_circle_string.length <= 5) {  // display data if it was possible to get it
                  let normal_step_TextCircle_img_angle = 0;
                  let normal_step_TextCircle_dot_img_angle = 0;
                  normal_step_TextCircle_img_angle = toDegree(Math.atan2(normal_step_TextCircle_img_width/2, 241));
                  // alignment = CENTER_H
                  let normal_step_TextCircle_angleOffset = normal_step_TextCircle_img_angle * (normal_step_circle_string.length - 1);
                  normal_step_TextCircle_angleOffset = -normal_step_TextCircle_angleOffset;
                  char_Angle -= normal_step_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_step_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_step_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_step_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_step_TextCircle_img_width / 2);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.SRC, normal_step_TextCircle_ASCIIARRAY[charCode]);
                      normal_step_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_step_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle heart_rate_HEART');
              let valueHeartRate = heart_rate.last;
              let normal_heart_rate_circle_string = parseInt(valueHeartRate).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_heart_rate_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 46;
                if (valueHeartRate != null && valueHeartRate != undefined && isFinite(valueHeartRate) && normal_heart_rate_circle_string.length > 0 && normal_heart_rate_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_heart_rate_TextCircle_img_angle = 0;
                  let normal_heart_rate_TextCircle_dot_img_angle = 0;
                  normal_heart_rate_TextCircle_img_angle = toDegree(Math.atan2(normal_heart_rate_TextCircle_img_width/2, 204));
                  // alignment = CENTER_H
                  let normal_heart_rate_TextCircle_angleOffset = normal_heart_rate_TextCircle_img_angle * (normal_heart_rate_circle_string.length - 1);
                  char_Angle -= normal_heart_rate_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_heart_rate_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_heart_rate_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_heart_rate_TextCircle_img_width / 2);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.SRC, normal_heart_rate_TextCircle_ASCIIARRAY[charCode]);
                      normal_heart_rate_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_heart_rate_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle battery_BATTERY');
              let valueBattery = battery.current;
              let normal_battery_circle_string = parseInt(valueBattery).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 3; i++) {  // hide all symbols
                  normal_battery_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = -46;
                if (valueBattery != null && valueBattery != undefined && isFinite(valueBattery) && normal_battery_circle_string.length > 0 && normal_battery_circle_string.length <= 3) {  // display data if it was possible to get it
                  let normal_battery_TextCircle_img_angle = 0;
                  let normal_battery_TextCircle_dot_img_angle = 0;
                  normal_battery_TextCircle_img_angle = toDegree(Math.atan2(normal_battery_TextCircle_img_width/2, 204));
                  // alignment = CENTER_H
                  let normal_battery_TextCircle_angleOffset = normal_battery_TextCircle_img_angle * (normal_battery_circle_string.length - 1);
                  char_Angle -= normal_battery_TextCircle_angleOffset;
                  // alignment end
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_battery_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 3) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle += normal_battery_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.POS_X, 240 - normal_battery_TextCircle_img_width / 2);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.SRC, normal_battery_TextCircle_ASCIIARRAY[charCode]);
                      normal_battery_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle += normal_battery_TextCircle_img_angle;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            //#endregion
            //#region compass_update
            console.log('compass_update()');
            if (screenType == hmSetting.screen_type.WATCHFACE){
              compass = hmSensor.createSensor(hmSensor.id.COMPASS);
              compass.start();

              if (compass.direction_angle && compass.direction  && compass.direction_angle != 'INVALID') { // initial data
                // Compass Pointer
                let compass_direction_angle = parseInt(compass.direction_angle);
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                // Compass Number
                let normal_compass_direction_angle_text = compass_direction_angle.toString();
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);
                // Compass Images
                let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                let compass_direction_index = parseInt(compass_direction_angle_img/45);
                if (compass_direction_index > 7) compass_direction_index = 0;
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

              } else { // error data
                normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');
                normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, 'direction-NULL.png');

              }

              compass.addEventListener(hmSensor.event.CHANGE, function (compass_res) { // change values when changing direction

                if (compass_res.calibration_status) {
                  // Compass Pointer
                  let compass_direction_angle = parseInt(compass_res.direction_angle);
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, -compass_direction_angle);
                  // Compass Number
                  let normal_compass_direction_angle_text = compass_direction_angle.toString();
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, normal_compass_direction_angle_text);
                  // Compass Images
                  let compass_direction_angle_img = compass_direction_angle + 45 / 2;
                  let compass_direction_index = parseInt(compass_direction_angle_img/45);
                  if (compass_direction_index > 7) compass_direction_index = 0;
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, normal_compass_direction_arr[compass_direction_index]);

                } else { // error data
                  normal_compass_direction_pointer_img.setProperty(hmUI.prop.ANGLE, 0);
                  normal_compass_text_img.setProperty(hmUI.prop.TEXT, '-');
                  normal_compass_direction_img_level.setProperty(hmUI.prop.SRC, 'direction-NULL.png');

                }

              }); // Listener end

            };
            //#endregion
			
			let gr_panels = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
            });
            gr_panels.setProperty(hmUI.prop.VISIBLE, false);

            let gr_panels_fill = gr_panels.createWidget(hmUI.widget.FILL_RECT, {
              x: 70,
              y: 70,
              w: 480 - 140,
              h: 480 - 140,
              color: '0xAA211d1e',
              radius: 20,
              alpha: 220,
              show_level:

                hmUI.show_level.ONLY_NORMAL,
            });	

			
		let secondImg = gr_panels.createWidget(hmUI.widget.IMG, {
          x: 180,
          y: 180,
          src: "applist_icon_stopwatch.png",
          show_level: hmUI.show_level.ONLY_NORMAL
        });

        let milli_value = 0
        let second_value = 0
        let min_value = 0
        let flag = true

        let constSecond = 0
        let constMin = 0

        let minPoint = null
        let hourPoint = null

        let createCount = 0;
        let bigNumObject = new Array(8)
        let smallNumObject = new Array(8)

        let bigNumArr = [
          "time_0.png",
          "time_1.png",
          "time_2.png",
          "time_3.png",
          "time_4.png",
          "time_5.png",
          "time_6.png",
          "time_7.png",
          "time_8.png",
          "time_9.png",
        ]
        let smallNumArr = [
          "smallNum_0.png",
          "smallNum_1.png",
          "smallNum_2.png",
          "smallNum_3.png",
          "smallNum_4.png",
          "smallNum_5.png",
          "smallNum_6.png",
          "smallNum_7.png",
          "smallNum_8.png",
          "smallNum_9.png",
        ]
        for (let i = 0; i < bigNumObject.length; i++) {
          //console.log(i+'uuuuu')
          if (i == 2 || i == 5) {
            bigNumObject[i] = gr_panels.createWidget(hmUI.widget.IMG, {
              x: 115 + i * 32,
              y: 197,
              src: "colon_time.png",
              show_level: hmUI.show_level.ONLY_NORMAL
            });
          } else {
            bigNumObject[i] = gr_panels.createWidget(hmUI.widget.IMG, {
              x: 110 + i * 32,
              y: 208,
              src: "time_0.png",
              show_level: hmUI.show_level.ONLY_NORMAL
            });
          }
          bigNumObject[i].setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示
        }
        for (let j = 0; j < smallNumObject.length; j++) {
          if (j == 2 || j == 5) {
            smallNumObject[j] = gr_panels.createWidget(hmUI.widget.IMG, {
              x: 187 + j * 14,
              y: 140,
              src: "smallNum_n.png",
              show_level: hmUI.show_level.ONLY_NORMAL
            });
          } else {
            smallNumObject[j] = gr_panels.createWidget(hmUI.widget.IMG, {
              x: 183 + j * 14,
              y: 140,
              src: "smallNum_0.png",
              show_level: hmUI.show_level.ONLY_NORMAL
            });
          }
          smallNumObject[j].setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示
        }
        let backBtn = gr_panels.createWidget(hmUI.widget.IMG, {
          x: 314,
          y: 318,
          src: "back.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        backBtn.setProperty(hmUI.prop.VISIBLE, false);
        let green_red_btn = gr_panels.createWidget(hmUI.widget.IMG, {
          x: 125,
          y: 318,
          src: "lv.png",
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        green_red_btn.setProperty(hmUI.prop.VISIBLE, false);
        secondImg.addEventListener(hmUI.event.CLICK_UP, (function (info) {

          

          secondImg.setProperty(hmUI.prop.VISIBLE, false);
          for (let n = 0; n < 8; n++) {
            bigNumObject[n].setProperty(hmUI.prop.VISIBLE, true); //false隐藏 true显示
            smallNumObject[n].setProperty(hmUI.prop.VISIBLE, true); //false隐藏 true显示  
            if (n == 0 || n == 1 || n == 3 || n == 4 || n == 6 || n == 7) {
              bigNumObject[n].setProperty(hmUI.prop.SRC, "time_0.png")
              smallNumObject[n].setProperty(hmUI.prop.SRC, "smallNum_0.png")
            }
          }
          milli_value = 0
          second_value = 0
          min_value = 0

          constSecond = 0
          constMin = 0
          backBtn.setProperty(hmUI.prop.VISIBLE, true);
          green_red_btn.setProperty(hmUI.prop.VISIBLE, true);
          flag = true
        }));
        backBtn.addEventListener(hmUI.event.CLICK_UP, (function (info) {
          timer.stopTimer(hsTimer)
          timer.stopTimer(sTimer)
          green_red_btn.setProperty(hmUI.prop.SRC, "lv.png"); //false隐藏 true显示 
          for (let n = 0; n < 8; n++) {
            bigNumObject[n].setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示
            smallNumObject[n].setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示
          }
          backBtn.setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示
          green_red_btn.setProperty(hmUI.prop.VISIBLE, false); //false隐藏 true显示

          

          secondImg.setProperty(hmUI.prop.VISIBLE, true);

        }));
        green_red_btn.addEventListener(hmUI.event.CLICK_UP, (function (info) {
          flag = !flag
          // minPoint.setProperty(hmUI.prop.ANGLE, 0)
          // hourPoint.setProperty(hmUI.prop.ANGLE, 0)
          if (flag) {
            green_red_btn.setProperty(hmUI.prop.SRC, "lv.png"); //false隐藏 true显示 
            timer.stopTimer(hsTimer)
            timer.stopTimer(sTimer)
            bigNumObject[0].setProperty(hmUI.prop.SRC, "time_0.png")
            bigNumObject[1].setProperty(hmUI.prop.SRC, "time_0.png")
            bigNumObject[3].setProperty(hmUI.prop.SRC, "time_0.png")
            bigNumObject[4].setProperty(hmUI.prop.SRC, "time_0.png")
            bigNumObject[6].setProperty(hmUI.prop.SRC, "time_0.png")
            bigNumObject[7].setProperty(hmUI.prop.SRC, "time_0.png")

            smallNumObject[0].setProperty(hmUI.prop.SRC, "smallNum_" + hmFS.SysProGetInt("t0") + ".png")
            smallNumObject[1].setProperty(hmUI.prop.SRC, "smallNum_" + hmFS.SysProGetInt("t1") + ".png")
            smallNumObject[3].setProperty(hmUI.prop.SRC, "smallNum_" + hmFS.SysProGetInt("t3") + ".png")
            smallNumObject[4].setProperty(hmUI.prop.SRC, "smallNum_" + hmFS.SysProGetInt("t4") + ".png")
            smallNumObject[6].setProperty(hmUI.prop.SRC, "smallNum_" + hmFS.SysProGetInt("t6") + ".png")
            smallNumObject[7].setProperty(hmUI.prop.SRC, "smallNum_" + hmFS.SysProGetInt("t7") + ".png")
          } else {
            green_red_btn.setProperty(hmUI.prop.SRC, "red.png"); //false隐藏 true显示 
            hmFS.SysProSetInt("t0", 0);
            hmFS.SysProSetInt("t1", 0);
            hmFS.SysProSetInt("t3", 0);
            hmFS.SysProSetInt("t4", 0);
            hmFS.SysProSetInt("t6", 0);
            hmFS.SysProSetInt("t7", 0);
            milli_value = 0
            second_value = 0
            min_value = 0

            constSecond = 0
            constMin = 0
            timerSample()

          }
        }));
        let hsTimer = null
        let sTimer = null
        function setHaomiao(t) {
          if (milli_value >= 99) {
            milli_value = -1
          }
          milli_value++
          bigNumObject[6].setProperty(hmUI.prop.SRC, "time_" + parseInt(milli_value / 10) + ".png")
          bigNumObject[7].setProperty(hmUI.prop.SRC, "time_" + parseInt(milli_value % 10) + ".png")

          hmFS.SysProSetInt("t6", parseInt(milli_value / 10));
          hmFS.SysProSetInt("t7", parseInt(milli_value % 10));

        }
        function setmiao(t) {
          if (second_value >= 59) {
            second_value = -1
          }
          second_value++
          constSecond++
          //setAngle(constSecond)
          if (second_value == 0) {
            min_value++
            setfen()
          }
          bigNumObject[3].setProperty(hmUI.prop.SRC, "time_" + parseInt(second_value / 10) + ".png")
          bigNumObject[4].setProperty(hmUI.prop.SRC, "time_" + parseInt(second_value % 10) + ".png")

          hmFS.SysProSetInt("t3", parseInt(second_value / 10));
          hmFS.SysProSetInt("t4", parseInt(second_value % 10));


        }
        function setfen(t) {
          if (min_value > 59) {
            min_value = 59
          }
          // console.log(parseInt(min_value / 10) + 'hhhhh')
          // console.log(parseInt(min_value % 10) + '%%%%%')
          bigNumObject[0].setProperty(hmUI.prop.SRC, "time_" + parseInt(min_value / 10) + ".png")
          bigNumObject[1].setProperty(hmUI.prop.SRC, "time_" + parseInt(min_value % 10) + ".png")

          hmFS.SysProSetInt("t0", parseInt(min_value / 10));
          hmFS.SysProSetInt("t1", parseInt(min_value % 10));
        }
        function timerSample() {
          //console.log('999999')
          hsTimer = timer.createTimer(
            10, 10, setHaomiao
            , {})
          sTimer = timer.createTimer(
            1000, 1000, setmiao
            , {})
        }
		
		let panel_visible = false;
            
            gr_panels.createWidget(hmUI.widget.BUTTON, {
              x: 365,
              y: 55,
              w: 50,
              h: 50,
              radius: 25,
              text: 'X',
              normal_color: 0x992255,
              press_color: 0xfeb4a8,
              click_func: () => {

                vibro(24);
                panel_visible = !panel_visible;
                gr_panels.setProperty(hmUI.prop.VISIBLE, panel_visible);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

           
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 295,
              y: 293,
              w: 85,
              h: 60,
              text: '',
              normal_src: 'Empty.png',
              press_src: 'Empty.png',
              click_func: () => {
                vibro();
                panel_visible = !panel_visible;
                gr_panels.setProperty(hmUI.prop.VISIBLE, panel_visible);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
				autoToggleBg();
                text_update();
                if (compass && screenType == hmSetting.screen_type.WATCHFACE) compass.start();

              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (compass) compass.stop();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}