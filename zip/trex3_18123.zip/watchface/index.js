﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block
        const batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
        //dynamic modify start
        let currentTheme = hmFS.SysProGetInt('WatchTheme') ?? 1; 
        // Sleep
        let sleep = null;
        let cachedSleepText = "00:00";
        let lastSleepDate = null;
        let lastShownSleepText = "--";
        let sleep_time_txt = null;
        let lastTotalMinutes = 0;
        let lastSleepUpdateMs = 0;
        const SLEEP_THROTTLE_MS = 15 * 60 * 1000; 
        
        let normal_background_bg_img1 = ''
        let normal_background_bg_img2 = ''
        let normal_background_bg_img3 = ''
        let normal_step_circle_scale = ''
        let normal_image_img1 = ''
        let normal_image_img2 = ''
        let normal_image_img3 = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_current_text_font = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_font = ''
        let normal_day_text_font = ''
        let normal_date_img_date_week_img1 = ''
        let normal_date_img_date_week_img2 = ''
        let normal_date_img_date_week_img3 = ''
        let normal_readiness_current_text_font = ''
        let normal_heart_rate_text_font = ''        
        let normal_step_current_text_font = ''
        let normal_digital_clock_img_time_AmPm = ''

        let minute_tens1 = ''
        let minute_tens2 = ''
        let minute_tens3 = ''
        //let minute_tens4 = ''        
        let minute_units1 = ''
        let minute_units2 = ''
        let minute_units3 = ''
        //let minute_units4 = ''
        let hour_tens = ''
        let hour_units = ''
                                
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_pro_second_pointer_img1 = ''
        let normal_analog_clock_pro_second_pointer_img2 = ''
        let normal_analog_clock_pro_second_pointer_img3 = ''
        let normal_timerUpdateSec = undefined;
        let normal_uvi_icon_img = ''
        let idle_background_bg_img1 = ''
        let idle_background_bg_img2 = ''
        let idle_background_bg_img3 = ''
        let idle_step_circle_scale = ''
        let idle_image_img1 = ''
        let idle_image_img2 = ''
        let idle_image_img3 = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_current_text_font = ''
        let idle_weather_image_progress_img_level = ''
        let idle_temperature_current_text_font = ''
        let idle_day_text_font = ''
        let idle_date_img_date_week_img1 = ''
        let idle_date_img_date_week_img2 = ''
        let idle_date_img_date_week_img3 = ''
        let idle_heart_rate_text_font = ''        
        let idle_step_current_text_font = ''
        let idle_digital_clock_img_time_AmPm = ''

        let idle_minute_tens1 = ''
        let idle_minute_tens2 = ''
        let idle_minute_tens3 = ''
        //let idle_minute_tens4 = ''        
        let idle_minute_units1 = ''
        let idle_minute_units2 = ''
        let idle_minute_units3 = ''
        //let idle_minute_units4 = ''
        let idle_hour_tens = ''
        let idle_hour_units = ''

        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_uvi_icon_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_readiness_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = '';

            // Sleep helpers 1.1
            try {
                sleep = hmSensor.createSensor(hmSensor.id.SLEEP);
                sleep.onSleepStateChange = () => {
                    if (sleep.state === hmSensor.sleep_state.END) {
                        calculateAndCacheRealSleep(true);
                    }
                };

            } catch (e) {
                console.log("Sleep sensor init failed:", e);
                sleep = null;
            }
            function formatMinutes(mins) {
                if (!mins || mins <= 0) return "00:00";

                const h = Math.floor(mins / 60);
                const m = mins % 60;
                return String(h).padStart(2, "0") + ":" + String(m).padStart(2, "0");
            }
            function calculateAndCacheRealSleep(force = false) {
                if (!sleep) {
                    cachedSleepText = "00:00";
                    updateSleepText();
                    return;
                }
                
                try {
                    const now = Date.now();
                    const today = new Date().toDateString();
                    
                    if (!force && (now - lastSleepUpdateMs < SLEEP_THROTTLE_MS) && lastSleepDate === today) {
                        updateSleepText();
                        return;
                    }

                    let currentTotal = sleep.getTotalTime();
                    
                    if (!force && lastSleepDate === today && currentTotal === lastTotalMinutes) {
                        lastSleepUpdateMs = now;
                        updateSleepText();
                        return;
                    }

                    sleep.updateInfo();
                    currentTotal = sleep.getTotalTime();

                    const info = sleep.getBasicInfo();
                    if (!info || info.startTime === 0 || currentTotal <= 0) {
                        cachedSleepText = "00:00";
                        lastTotalMinutes = 0;
                        updateSleepText();
                        return;
                    }

                    let totalMinutes = currentTotal;

                    if (totalMinutes > 1080) totalMinutes = 0;

                    if (totalMinutes > 90) {
                        try {
                            const stages = sleep.getSleepStageData();
                            const model = sleep.getSleepStageModel();
                            let wakeMinutes = 0;
                            for (let i = 0, len = stages.length; i < len; i++) {
                                const st = stages[i];
                                if (st.model === model.WAKE_STAGE) {
                                    wakeMinutes += (st.stop + 1 - st.start);
                                }
                            }
                            totalMinutes -= wakeMinutes;
                        } catch (e) {}
                    }

                    cachedSleepText = formatMinutes(totalMinutes);
                    lastSleepDate = today;
                    lastTotalMinutes = currentTotal;
                    lastSleepUpdateMs = now;
                    updateSleepText();
                } catch (e) {
                    console.log("calculateAndCacheRealSleep error:", e);
                    cachedSleepText = "00:00";
                    updateSleepText();
                }
            }
            function updateSleepText() {
                if (!sleep_time_txt) return;
                if (hmSetting.getScreenType() === hmSetting.screen_type.AOD) return;
                if (lastShownSleepText !== cachedSleepText) {
                    try {
                        sleep_time_txt.setProperty(hmUI.prop.TEXT, cachedSleepText);
                    } catch (e) { }
                    lastShownSleepText = cachedSleepText;
                }
            } 
        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Q5.ttf; FontSize: 45
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 651,
              h: 75,
              text_size: 45,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Q5.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Q5.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 429,
              h: 50,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Q5.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Q5.ttf; FontSize: 35
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 502,
              h: 57,
              text_size: 35,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Q5.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            normal_background_bg_img1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_background_bg_img2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); 
            normal_background_bg_img3 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });                       

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -2,
              end_angle: -148,
              radius: 228,
              line_width: 12,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_circle_scale.setAlpha(160);
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });            

            normal_image_img1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_image_img2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });    
            normal_image_img3 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });                    

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 345,
              y: 115,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 80,
              y: 329,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 47,
              y: 207,
              w: 150,
              h: 50,
              text_size: 45,
              char_space: 0,
              font: 'fonts/Q5.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 313,
              y: 150,
              image_array: ["wt_0.png","wt_1.png","wt_2.png","wt_3.png","wt_4.png","wt_5.png","wt_6.png","wt_7.png","wt_8.png","wt_9.png","wt_10.png","wt_11.png","wt_12.png","wt_13.png","wt_14.png","wt_15.png","wt_16.png","wt_17.png","wt_18.png","wt_19.png","wt_20.png","wt_21.png","wt_22.png","wt_23.png","wt_24.png","wt_25.png","wt_26.png","wt_27.png","wt_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 295,
              y: 245,
              w: 150,
              h: 50,
              text_size: 45,
              char_space: 0,
              font: 'fonts/Q5.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });
         

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 7,
              y: 7,
              w: 466,
              h: 466,
              text_size: 30,
              char_space: 0,
              font: 'fonts/Q5.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -17,
              end_angle: 50,
              mode: 0,
              // radius: 233,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img1 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["D1_0.png","D1_1.png","D1_2.png","D1_3.png","D1_4.png","D1_5.png","D1_6.png"],
              week_tc: ["D1_0.png","D1_1.png","D1_2.png","D1_3.png","D1_4.png","D1_5.png","D1_6.png"],
              week_sc: ["D1_0.png","D1_1.png","D1_2.png","D1_3.png","D1_4.png","D1_5.png","D1_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_date_img_date_week_img2 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["D2_0.png","D2_1.png","D2_2.png","D2_3.png","D2_4.png","D2_5.png","D2_6.png"],
              week_tc: ["D2_0.png","D2_1.png","D2_2.png","D2_3.png","D2_4.png","D2_5.png","D2_6.png"],
              week_sc: ["D2_0.png","D2_1.png","D2_2.png","D2_3.png","D2_4.png","D2_5.png","D2_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });    
            normal_date_img_date_week_img3 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["D3_0.png","D3_1.png","D3_2.png","D3_3.png","D3_4.png","D3_5.png","D3_6.png"],
              week_tc: ["D3_0.png","D3_1.png","D3_2.png","D3_3.png","D3_4.png","D3_5.png","D3_6.png"],
              week_sc: ["D3_0.png","D3_1.png","D3_2.png","D3_3.png","D3_4.png","D3_5.png","D3_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });                     

            sleep_time_txt = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 2,
              y: 2,
              w: 476,
              h: 476,
              text_size: 30,
              char_space: 0,
              font: 'fonts/Q5.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 0,
              end_angle: 210,
              mode: 1,
              // radius: 238,
              align_h: hmUI.align.CENTER_H,
              text: "00:00",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            calculateAndCacheRealSleep(true);  

            normal_readiness_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 2,
              y: 2,
              w: 476,
              h: 476,
              text_size: 30,
              char_space: 0,
              font: 'fonts/Q5.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: 100,
              end_angle: 229,
              mode: 1,
              // radius: 238,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 38,
              y: 149,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 0,
              font: 'fonts/Q5.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -148,
              // end_angle: -2,
              // radius: 234,
              // line_width: 12,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 160,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 167,
              y: 95,
              w: 150,
              h: 50,
              text_size: 45,
              char_space: 0,
              font: 'fonts/Q5.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 59,
              am_y: 284,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 59,
              pm_y: 284,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });       
            
            timeSensor.addEventListener(timeSensor.event.HOUR12, function() {
                time_update(true, true);    
            });             

            minute_tens1 = hmUI.createWidget(hmUI.widget.IMG, {    
              x: 272,
              y: 313,
              src: 'MM1_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); 
            minute_units1 = hmUI.createWidget(hmUI.widget.IMG, {   
              x: 322,          
              y: 308,          
              src: 'MB1_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); 
            minute_tens2 = hmUI.createWidget(hmUI.widget.IMG, {    
              x: 272,
              y: 313,
              src: 'MM2_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); 
            minute_units2 = hmUI.createWidget(hmUI.widget.IMG, {   
              x: 322,          
              y: 308,          
              src: 'MB2_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });    
            minute_tens3 = hmUI.createWidget(hmUI.widget.IMG, {    
              x: 272,
              y: 313,
              src: 'MM3_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); 
            minute_units3 = hmUI.createWidget(hmUI.widget.IMG, {   
              x: 322,          
              y: 308,          
              src: 'MB3_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });             
            
            hour_tens = hmUI.createWidget(hmUI.widget.IMG, {     
              x: 115,
              y: 297,
              src: 'HM_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });  
            hour_units = hmUI.createWidget(hmUI.widget.IMG, {     
              x: 188,           
              y: 295,          
              src: 'HB_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });                                            

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 31,
              hour_posY: 210,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Minn.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 31,
              minute_posY: 203,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
        

            normal_analog_clock_pro_second_pointer_img1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 203,
              pos_y: 240 - 236,
              center_x: 240,
              center_y: 240,
              src: 'Sekk_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_analog_clock_pro_second_pointer_img2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 203,
              pos_y: 240 - 236,
              center_x: 240,
              center_y: 240,
              src: 'Sekk_2.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });     
            normal_analog_clock_pro_second_pointer_img3 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 203,
              pos_y: 240 - 236,
              center_x: 240,
              center_y: 240,
              src: 'Sekk_3.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });                   

            normal_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 193,
              y: 189,
              src: 'centr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_background_bg_img2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            }); 
            idle_background_bg_img3 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });                       

            idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -2,
              end_angle: -148,
              radius: 228,
              line_width: 12,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_circle_scale.setAlpha(160);            

            idle_image_img1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zaplAOD_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_image_img2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zaplAOD_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });     
            idle_image_img3 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zaplAOD_3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });                   

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 345,
              y: 115,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 80,
              y: 329,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 47,
              y: 207,
              w: 150,
              h: 50,
              text_size: 45,
              char_space: 0,
              font: 'fonts/Q5.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 313,
              y: 150,
              image_array: ["wt_0.png","wt_1.png","wt_2.png","wt_3.png","wt_4.png","wt_5.png","wt_6.png","wt_7.png","wt_8.png","wt_9.png","wt_10.png","wt_11.png","wt_12.png","wt_13.png","wt_14.png","wt_15.png","wt_16.png","wt_17.png","wt_18.png","wt_19.png","wt_20.png","wt_21.png","wt_22.png","wt_23.png","wt_24.png","wt_25.png","wt_26.png","wt_27.png","wt_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 295,
              y: 245,
              w: 150,
              h: 50,
              text_size: 45,
              char_space: 0,
              font: 'fonts/Q5.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 7,
              y: 7,
              w: 466,
              h: 466,
              text_size: 30,
              char_space: 0,
              font: 'fonts/Q5.ttf',
              color: 0xFFFFFFFF,
              // use_text_circle: true,
              start_angle: -17,
              end_angle: 50,
              mode: 0,
              // radius: 233,
              align_h: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img1 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["D1_0.png","D1_1.png","D1_2.png","D1_3.png","D1_4.png","D1_5.png","D1_6.png"],
              week_tc: ["D1_0.png","D1_1.png","D1_2.png","D1_3.png","D1_4.png","D1_5.png","D1_6.png"],
              week_sc: ["D1_0.png","D1_1.png","D1_2.png","D1_3.png","D1_4.png","D1_5.png","D1_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_date_img_date_week_img2 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["D2_0.png","D2_1.png","D2_2.png","D2_3.png","D2_4.png","D2_5.png","D2_6.png"],
              week_tc: ["D2_0.png","D2_1.png","D2_2.png","D2_3.png","D2_4.png","D2_5.png","D2_6.png"],
              week_sc: ["D2_0.png","D2_1.png","D2_2.png","D2_3.png","D2_4.png","D2_5.png","D2_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });      
            idle_date_img_date_week_img3 = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["D3_0.png","D3_1.png","D3_2.png","D3_3.png","D3_4.png","D3_5.png","D3_6.png"],
              week_tc: ["D3_0.png","D3_1.png","D3_2.png","D3_3.png","D3_4.png","D3_5.png","D3_6.png"],
              week_sc: ["D3_0.png","D3_1.png","D3_2.png","D3_3.png","D3_4.png","D3_5.png","D3_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });                   

            idle_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 38,
              y: 149,
              w: 150,
              h: 50,
              text_size: 35,
              char_space: 0,
              font: 'fonts/Q5.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -148,
              // end_angle: -2,
              // radius: 234,
              // line_width: 12,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 160,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 167,
              y: 95,
              w: 150,
              h: 50,
              text_size: 45,
              char_space: 0,
              font: 'fonts/Q5.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 59,
              am_y: 284,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 59,
              pm_y: 284,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_minute_tens1 = hmUI.createWidget(hmUI.widget.IMG, {    
              x: 272,
              y: 313,
              src: 'MM1_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            }); 
            idle_minute_units1 = hmUI.createWidget(hmUI.widget.IMG, {   
              x: 322,          
              y: 308,          
              src: 'MB1_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            }); 
            idle_minute_tens2 = hmUI.createWidget(hmUI.widget.IMG, {    
              x: 272,
              y: 313,
              src: 'MM2_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            }); 
            idle_minute_units2 = hmUI.createWidget(hmUI.widget.IMG, {   
              x: 322,          
              y: 308,          
              src: 'MB2_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });    
            idle_minute_tens3 = hmUI.createWidget(hmUI.widget.IMG, {    
              x: 272,
              y: 313,
              src: 'MM3_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            }); 
            idle_minute_units3 = hmUI.createWidget(hmUI.widget.IMG, {   
              x: 322,          
              y: 308,          
              src: 'MB3_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });                      
            idle_hour_tens = hmUI.createWidget(hmUI.widget.IMG, {     
              x: 115,
              y: 297,
              src: 'HM_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });  
            idle_hour_units = hmUI.createWidget(hmUI.widget.IMG, {     
              x: 188,           
              y: 295,          
              src: 'HB_0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });             

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 31,
              hour_posY: 210,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Minn.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 31,
              minute_posY: 203,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 193,
              y: 189,
              src: 'centr.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            applyTheme(currentTheme);


            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 199,
              y: 100,
              w: 80,
              h: 55,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 82,
              y: 123,
              w: 61,
              h: 67,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 80,
              y: 219,
              w: 75,
              h: 40,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 333,
              y: 206,
              w: 65,
              h: 80,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 155,
              y: 334,
              w: 78,
              h: 77,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 311,
              y: 328,
              w: 66,
              h: 49,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 90,
              y: 331,
              w: 40,
              h: 40,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 418,
              y: 262,
              w: 55,
              h: 73,
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_readiness_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 262,
              y: 424,
              w: 69,
              h: 49,
              type: hmUI.data_type.BIO_CHARGE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 58,
              y: 281,
              w: 64,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'FlashLightScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 285,
              y: 12,
              w: 64,
              h: 59,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const themeButton = hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 200,          // центр
                y: 200,
                w: 80,
                h: 80,
                text: '',
                press_src: 'clean.png',
                normal_src: 'clean.png',
                click_func: () => {
                    currentTheme = (currentTheme % 3) + 1;  
                    applyTheme(currentTheme);
                    hmUI.showToast({ text: `Тема ${currentTheme}` });
                },
                show_level: hmUI.show_level.ONLY_NORMAL,  
            });              

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let rawHour = timeSensor.hour; 
              let minute = timeSensor.minute;
              //let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;
                                                        
              let is12Hour = false;                
              if (typeof timeSensor.format_hour !== "undefined" && timeSensor.format_hour === 1) {
                  is12Hour = true;
              }                
              else if (typeof timeSensor.is24Hour !== "undefined" && timeSensor.is24Hour === false) {
                  is12Hour = true;
              }                                
              let displayHour = rawHour;
              if (is12Hour) {
                  displayHour = rawHour % 12;
                  if (displayHour === 0) displayHour = 12;  
              }
              // === ОБНОВЛЕНИЕ ВРЕМЕНИ ===
              if (updateMinute) {
                    let h_tens = Math.floor(displayHour / 10);
                    let h_units = displayHour % 10;
                    let m_tens = Math.floor(minute / 10);
                    let m_units = minute % 10;
                    // Normal экран
                    hour_tens.setProperty(hmUI.prop.SRC, `HM_${h_tens}.png`);
                    hour_units.setProperty(hmUI.prop.SRC, `HB_${h_units}.png`);                    
                    minute_tens1.setProperty(hmUI.prop.SRC, `MM1_${m_tens}.png`);
                    minute_tens2.setProperty(hmUI.prop.SRC, `MM2_${m_tens}.png`);
                    minute_tens3.setProperty(hmUI.prop.SRC, `MM3_${m_tens}.png`);
                    //minute_tens4.setProperty(hmUI.prop.SRC, `HK_${m_tens}.png`);
                    minute_units1.setProperty(hmUI.prop.SRC, `MB1_${m_units}.png`);
                    minute_units2.setProperty(hmUI.prop.SRC, `MB2_${m_units}.png`);                    
                    minute_units3.setProperty(hmUI.prop.SRC, `MB3_${m_units}.png`);
                    //minute_units4.setProperty(hmUI.prop.SRC, `MB4_${m_units}.png`);

                    // AOD экран
                    idle_hour_tens.setProperty(hmUI.prop.SRC, `HM_${h_tens}.png`);
                    idle_hour_units.setProperty(hmUI.prop.SRC, `HB_${h_units}.png`);                    
                    idle_minute_tens1.setProperty(hmUI.prop.SRC, `MM1_${m_tens}.png`);
                    idle_minute_tens2.setProperty(hmUI.prop.SRC, `MM2_${m_tens}.png`);
                    idle_minute_tens3.setProperty(hmUI.prop.SRC, `MM3_${m_tens}.png`);
                    //idle_minute_tens4.setProperty(hmUI.prop.SRC, `HK_${m_tens}.png`);
                    idle_minute_units1.setProperty(hmUI.prop.SRC, `MB1_${m_units}.png`);
                    idle_minute_units2.setProperty(hmUI.prop.SRC, `MB2_${m_units}.png`);                    
                    idle_minute_units3.setProperty(hmUI.prop.SRC, `MB3_${m_units}.png`);
                    //idle_minute_units4.setProperty(hmUI.prop.SRC, `MB4_${m_units}.png`);
              }              

              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };              

              // === ПЛАВНАЯ СЕКУНДНАЯ СТРЕЛКА ===
              if (hmSetting.getScreenType() === hmSetting.screen_type.WATCHFACE) {
                  const batteryLevel = (batterySensor && batterySensor.current) ? batterySensor.current : 100;
                  const second = timeSensor.second;
                  let angle;

                  if (batteryLevel <= 10) {
                      angle = second * 6;                    
                  } else {
                      const now = Date.now();
                      const ms = now % 1000;
                      angle = (second * 6) + (ms * 0.006);   
                  }

                  // Обновляем все три варианта стрелок
                  if (normal_analog_clock_pro_second_pointer_img1) 
                      normal_analog_clock_pro_second_pointer_img1.setProperty(hmUI.prop.ANGLE, angle);
                  if (normal_analog_clock_pro_second_pointer_img2) 
                      normal_analog_clock_pro_second_pointer_img2.setProperty(hmUI.prop.ANGLE, angle);
                  if (normal_analog_clock_pro_second_pointer_img3) 
                      normal_analog_clock_pro_second_pointer_img3.setProperty(hmUI.prop.ANGLE, angle);
              }             

            };

            function applyTheme(theme) {
                console.log(`Применяем тему ${theme}`);

                // Normal
                normal_background_bg_img1.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_background_bg_img2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_background_bg_img3.setProperty(hmUI.prop.VISIBLE, theme === 3);
                normal_image_img1.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_image_img2.setProperty(hmUI.prop.VISIBLE, theme ===2);
                normal_image_img3.setProperty(hmUI.prop.VISIBLE, theme === 3);  
                normal_date_img_date_week_img1.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_date_img_date_week_img2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_date_img_date_week_img3.setProperty(hmUI.prop.VISIBLE, theme === 3);                             
                minute_tens1.setProperty(hmUI.prop.VISIBLE, theme === 1);
                minute_tens2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                minute_tens3.setProperty(hmUI.prop.VISIBLE, theme === 3);
                minute_units1.setProperty(hmUI.prop.VISIBLE, theme === 1);
                minute_units2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                minute_units3.setProperty(hmUI.prop.VISIBLE, theme === 3);
                normal_analog_clock_pro_second_pointer_img1.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_analog_clock_pro_second_pointer_img2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_analog_clock_pro_second_pointer_img3.setProperty(hmUI.prop.VISIBLE, theme === 3);

                // AOD
                idle_background_bg_img1.setProperty(hmUI.prop.VISIBLE, theme === 1);
                idle_background_bg_img2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                idle_background_bg_img3.setProperty(hmUI.prop.VISIBLE, theme === 3);
                idle_image_img1.setProperty(hmUI.prop.VISIBLE, theme === 1);
                idle_image_img2.setProperty(hmUI.prop.VISIBLE, theme ===2);
                idle_image_img3.setProperty(hmUI.prop.VISIBLE, theme === 3);  
                idle_date_img_date_week_img1.setProperty(hmUI.prop.VISIBLE, theme === 1);
                idle_date_img_date_week_img2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                idle_date_img_date_week_img3.setProperty(hmUI.prop.VISIBLE, theme === 3);                             
                idle_minute_tens1.setProperty(hmUI.prop.VISIBLE, theme === 1);
                idle_minute_tens2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                idle_minute_tens3.setProperty(hmUI.prop.VISIBLE, theme === 3);
                idle_minute_units1.setProperty(hmUI.prop.VISIBLE, theme === 1);
                idle_minute_units2.setProperty(hmUI.prop.VISIBLE, theme === 2);
                idle_minute_units3.setProperty(hmUI.prop.VISIBLE, theme === 3);                
                

                // Сохраняем выбор
                hmFS.SysProSetInt('WatchTheme', theme);
            }              

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -2,
                      end_angle: -148,
                      radius: 228,
                      line_width: 12,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = 1 - progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_step * 100);
                  if (idle_step_circle_scale) {
                    idle_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -2,
                      end_angle: -148,
                      radius: 228,
                      line_width: 12,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                calculateAndCacheRealSleep();
                
                if (hmSetting.getScreenType() === hmSetting.screen_type.WATCHFACE) {
                    if (normal_timerUpdateSec) {
                        timer.stopTimer(normal_timerUpdateSec);
                    }
                    const batteryLevel = (batterySensor && batterySensor.current) ? batterySensor.current : 100;
                    const interval = batteryLevel <= 10 ? 1000 : 250;

                    normal_timerUpdateSec = timer.createTimer(
                        0,
                        interval,
                        () => time_update(false, false)
                    );
                }
              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                    timer.stopTimer(normal_timerUpdateSec);
                    normal_timerUpdateSec = undefined;
                }
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                if (normal_timerUpdateSec) {
                    timer.stopTimer(normal_timerUpdateSec);
                    normal_timerUpdateSec = undefined;
                }              
                if (sleep) {
                    sleep = null;
                }  

                // Правильная очистка
                try {
                    cachedSleepText = "--";
                    lastSleepDate = null;
                    lastShownSleepText = null;
                } catch (e) {}                  

                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}