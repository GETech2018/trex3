﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        let smoothSecondTimer = null;    

        let normal_background_bg_img = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        //let normal_timerUpdateSec = undefined;
        let normal_digital_clock_img_time_hour = ''
        let normal_image_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_circle_scale_2 = ''        
        let normal_step_circle_scale = ''        
        let normal_temperature_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_alarm_clock_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_battery_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let timeSensor = '';

        // Запуск плавного движения        
        function startSmoothSecond() {
            if (smoothSecondTimer) return;
            smoothSecondTimer = timer.createTimer(
                0,
                250,   
                () => {
                    if (hmSetting.getScreenType() === hmSetting.screen_type.AOD) return;
                    const sec = timeSensor.second; 
                    const ms = Date.now() % 1000;                    
                    const angle = sec * 6 + (ms / 1000) * 6;
                    if (normal_analog_clock_pro_second_pointer_img) {
                        normal_analog_clock_pro_second_pointer_img.setProperty(
                            hmUI.prop.ANGLE,
                            angle
                        );
                    }                    

                }
            );
        }
        function stopSmoothSecond() {
            if (smoothSecondTimer) {
                timer.stopTimer(smoothSecondTimer);
                smoothSecondTimer = null;
            }
        }
        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Minn_OSN.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 240,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);

            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 240,
              pos_y: 240 - 237,
              center_x: 240,
              center_y: 240,
              src: 'Sekk_OSN.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 269,
              hour_startY: 215,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_tc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              week_sc: ["D_0.png","D_1.png","D_2.png","D_3.png","D_4.png","D_5.png","D_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'bt_nap.png',
              center_x: 240,
              center_y: 240,
              x: 11,
              y: 245,
              start_angle: 151,
              end_angle: 270,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 33,
              day_startY: 166,
              day_sc_array: ["minA_0.png","minA_1.png","minA_2.png","minA_3.png","minA_4.png","minA_5.png","minA_6.png","minA_7.png","minA_8.png","minA_9.png"],
              day_tc_array: ["minA_0.png","minA_1.png","minA_2.png","minA_3.png","minA_4.png","minA_5.png","minA_6.png","minA_7.png","minA_8.png","minA_9.png"],
              day_en_array: ["minA_0.png","minA_1.png","minA_2.png","minA_3.png","minA_4.png","minA_5.png","minA_6.png","minA_7.png","minA_8.png","minA_9.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale_2 = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -232,
              end_angle: 54,
              radius: 57,
              line_width: 9,
              corner_flag: 0,
              type: hmUI.data_type.HEART,
              color: 0xFFFFFFFF,
              // mirror: False,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: -244,
              // end_angle: 64,
              // radius: 82,
              // line_width: 9,
              // line_cap: Rounded,
              // color: 0xFFFFFFFF,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: -244,
              end_angle: 64,
              radius: 78,
              line_width: 9,
              corner_flag: 0,
              color: 0xFFFFFFFF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });


            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 239,
              y: 150,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 122,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: -4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 54,
              y: 125,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'data_gr.png',
              unit_tc: 'data_gr.png',
              unit_en: 'data_gr.png',
              negative_image: 'data_min.png',
              invalid_image: 'data_zn.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_clock_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 135,
              y: 223,
              font_array: ["data_0.png","data_1.png","data_2.png","data_3.png","data_4.png","data_5.png","data_6.png","data_7.png","data_8.png","data_9.png"],
              padding: true,
              h_space: -3,
              invalid_image: 'alarm_off.png',
              dot_image: 'data_dv.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 225,
              y: 240,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 223,
              y: 209,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 269,
              hour_startY: 215,
              hour_array: ["H_0.png","H_1.png","H_2.png","H_3.png","H_4.png","H_5.png","H_6.png","H_7.png","H_8.png","H_9.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 349,
              minute_startY: 222,
              minute_array: ["minA_0.png","minA_1.png","minA_2.png","minA_3.png","minA_4.png","minA_5.png","minA_6.png","minA_7.png","minA_8.png","minA_9.png"],
              minute_zero: 1,
              minute_space: -3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 168,
              y: 115,
              w: 70,
              h: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 242,
              y: 144,
              w: 54,
              h: 44,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 104,
              y: 389,
              w: 60,
              h: 60,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 53,
              y: 119,
              w: 60,
              h: 40,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 268,
              y: 214,
              w: 70,
              h: 50,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 349,
              y: 221,
              w: 50,
              h: 40,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 145,
              y: 217,
              w: 70,
              h: 45,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 30,
              y: 166,
              w: 60,
              h: 40,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              // Second Pointer
              const screenType = hmSetting.getScreenType();
              const isAOD = screenType === hmSetting.screen_type.AOD;
              if (!isAOD) {                                       
                  startSmoothSecond();
              } else {
                  stopSmoothSecond();
              }

            };

            //#endregion
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: -244,
                      end_angle: 64,
                      radius: 78,
                      line_width: 9,
                      corner_flag: 0,
                      color: 0xFFFFFFFF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType !== hmSetting.screen_type.AOD) {
                    startSmoothSecond();
                } else {
                    stopSmoothSecond();
                }                


              }),
              pause_call: (function () {
                stopSmoothSecond();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}