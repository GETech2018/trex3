/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_animation1 = '';
		let normal_battery_imageset3 = '';
		let normal_battery_imagecombo4 = '';
		let normal_hour_imagecombo6 = '';
		let normal_minute_imagecombo7 = '';
		let normal_second_imagecombo8 = '';
		let normal_img9 = '';
		let timeInterval;
		let normal_ampm24_imageset10 = '';
		let normal_ampm24_imageset10_array = ['0081.png','0082.png','0083.png'];
		let normal_date_imagecombo12 = '';
		let normal_month_imageset13 = '';
		let normal_heartrate_linegraph15 = '';
		let normal_img16 = '';
		let normal_heart_current_imagecombo17 = '';
		let normal_heart_min_imagecombo18 = new Array(3);
		let normal_heart_min_imagecombo18_padding = false;
		let normal_heart_min_imagecombo18_array = ['0118.png','0119.png','0120.png','0121.png','0122.png','0123.png','0124.png','0125.png','0126.png','0127.png','0128.png'];
		let normal_heart_max_imagecombo19 = new Array(3);
		let normal_heart_max_imagecombo19_padding = false;
		let normal_heart_max_imagecombo19_array = ['0118.png','0119.png','0120.png','0121.png','0122.png','0123.png','0124.png','0125.png','0126.png','0127.png','0129.png'];
		let normal_img20 = '';
		let normal_img21 = '';
		let normal_steps_imagecombo23 = '';
		let normal_img25 = '';
		let normal_distance_imagecombo26 = '';
		let normal_img28 = '';
		let normal_calories_progress29 = '';
		let normal_calories_imagecombo30 = '';
		let normal_img31 = '';
		let normal_temperature_current_imagecombo33 = '';
		let normal_weather_imageset34 = '';
		let normal_animation36 = '';
		let idle_hour_imagecombo39 = '';
		let idle_img40 = '';
		let idle_minute_imagecombo41 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				const timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
				const calorieSensor = hmSensor.createSensor(hmSensor.id.CALORIE);
				const heartSensor = hmSensor.createSensor(hmSensor.id.HEART);
				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_animation1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
					x: 0,
					y: 0,
					anim_path: '',
					anim_prefix: '1736983560910',
					anim_ext: 'png',
					anim_fps: 15,
					anim_size: 35,
					anim_repeat: true,
					repeat_count: 0,
					anim_status: hmUI.anim_status.START,
					display_on_restart: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});
				normal_battery_imageset3 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 72,
					y: 79,
					image_array: ["0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png"],
					image_length: 11,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imagecombo4 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 276,
					y: 80,
					font_array: ["0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png"],
					padding: false,
					h_space: 0,
					unit_sc: '0059.png',
					unit_tc: '0059.png',
					unit_en: '0059.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.BATTERY,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo6 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 191,
					hour_startY: 122,
					hour_array: ["0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.RIGHT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo7 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 299,
					minute_startY: 122,
					minute_array: ["0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_second_imagecombo8 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					second_startX: 428,
					second_startY: 217,
					second_array: ["0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png","0079.png"],
					second_zero: true,
					second_space: 0,
					second_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img9 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 283,
					y: 132,
					w: 12,
					h: 75,
					src: '0080.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_ampm24_imageset10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 347,
					y: 96,
					w: 347,
					h: 96,
					src: '0083.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				})

				normal_date_imagecombo12 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					day_startX: 178,
					day_startY: 38,
					day_sc_array: ["0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png"],
					day_tc_array: ["0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png"],
					day_en_array: ["0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png","0092.png","0093.png"],
					day_zero: false,
					day_space: 0,
					day_align: hmUI.align.RIGHT,
					day_is_character: false,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_month_imageset13 = hmUI.createWidget(hmUI.widget.IMG_DATE, {
					month_startX: 220,
					month_startY: 41,
					month_sc_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
					month_tc_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
					month_en_array: ["0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png","0101.png","0102.png","0103.png","0104.png","0105.png"],
					month_is_character: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heartrate_linegraph15 = hmUI.createWidget(hmUI.widget.GRADKIENT_POLYLINE, {
					x: 217,
					y: 301,
					w: 186,
					h: 55,
					line_color: 0x002a9e,
					line_width: 1,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img16 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 217,
					y: 291,
					w: 27,
					h: 21,
					src: '0106.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo17 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 298,
					y: 275,
					font_array: ["0107.png","0108.png","0109.png","0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png"],
					padding: false,
					h_space: 0,
					invalid_image: '0117.png',
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				for (let i = 0; i < normal_heart_min_imagecombo18.length; i++) {
					normal_heart_min_imagecombo18[i] = hmUI.createWidget(hmUI.widget.IMG, {
						x: 260 + i * 10,
						y: 288,
						w: 10,
						h: 26,
						enable: false,
						show_level: hmUI.show_level.ONLY_NORMAL,
					})

				}

				for (let i = 0; i < normal_heart_max_imagecombo19.length; i++) {
					normal_heart_max_imagecombo19[i] = hmUI.createWidget(hmUI.widget.IMG, {
						x: 361 + i * 10,
						y: 288,
						w: 10,
						h: 26,
						enable: false,
						show_level: hmUI.show_level.ONLY_NORMAL,
					})

				}

				normal_img20 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 257,
					y: 265,
					w: 25,
					h: 22,
					src: '0130.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img21 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 364,
					y: 265,
					w: 29,
					h: 22,
					src: '0131.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo23 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 216,
					y: 217,
					font_array: ["0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png"],
					padding: true,
					h_space: 0,
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img25 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 176,
					y: 217,
					w: 30,
					h: 26,
					src: '0142.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_distance_imagecombo26 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 337,
					y: 217,
					font_array: ["0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png"],
					padding: false,
					h_space: 0,
					dot_image: '0153.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.DISTANCE,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img28 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 300,
					y: 217,
					w: 34,
					h: 34,
					src: '0154.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				if (screenType != hmSetting.screen_type.AOD) {
					normal_calories_progress29 = hmUI.createWidget(hmUI.widget.ARC, {
						enable: false,
					});
				}

				normal_calories_imagecombo30 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 59,
					y: 237,
					font_array: ["0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img31 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 66,
					y: 188,
					w: 35,
					h: 35,
					src: '0165.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_temperature_current_imagecombo33 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 118,
					y: 382,
					font_array: ["0166.png","0167.png","0168.png","0169.png","0170.png","0171.png","0172.png","0173.png","0174.png","0175.png"],
					padding: false,
					h_space: 0,
					unit_sc: ["0177.png"],
					unit_tc: ["0177.png"],
					unit_en: ["0177.png"],
					negative_image: ["0176.png"],
					invalid_image: ["0176.png"],
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.WEATHER_CURRENT,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_weather_imageset34 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 111,
					y: 313,
					image_array: ["0178.png","0179.png","0180.png","0181.png","0182.png","0183.png","0180.png","0184.png","0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png","0192.png","0193.png","0194.png","0195.png","0196.png","0197.png","0184.png","0198.png","0199.png","0200.png","0201.png","0202.png","0203.png","0204.png"],
					image_length: 29,
					type: hmUI.data_type.WEATHER_CURRENT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_animation36 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
					x: 29,
					y: 286,
					anim_path: '',
					anim_prefix: '1736983354800',
					anim_ext: 'png',
					anim_fps: 20,
					anim_size: 18,
					anim_repeat: true,
					repeat_count: 0,
					anim_status: hmUI.anim_status.START,
					display_on_restart: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});
				idle_hour_imagecombo39 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 109,
					hour_startY: 181,
					hour_array: ["0223.png","0224.png","0225.png","0226.png","0227.png","0228.png","0229.png","0230.png","0231.png","0232.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.RIGHT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img40 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 230,
					y: 182,
					w: 19,
					h: 120,
					src: '0233.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo41 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 253,
					minute_startY: 181,
					minute_array: ["0223.png","0224.png","0225.png","0226.png","0227.png","0228.png","0229.png","0230.png","0231.png","0232.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				function updateTime() {
					normal_ampm24_imageset10.setProperty(hmUI.prop.MORE, {
						src: normal_ampm24_imageset10_array[(hmSetting.getTimeFormat() == 0 ? (timeSensor.hour >= 0 && timeSensor.hour < 12 ? 0 : 1) : 2)]
					})
				}

				function updateCalories() {
					var current_normal_calories_progress29 = calorieSensor.current;
					var target_normal_calories_progress29 = calorieSensor.target;
					var progress_normal_calories_progress29 = current_normal_calories_progress29 / target_normal_calories_progress29;

					if (progress_normal_calories_progress29 > 1) {
						progress_normal_calories_progress29 = 1;
					}

					var pcs_normal_calories_progress29 = progress_normal_calories_progress29;

					if (screenType != hmSetting.screen_type.AOD) {
						// initial parameters
						var sa_normal_calories_progress29 = -220;
						var ea_normal_calories_progress29 = 40;
						var cx_normal_calories_progress29 = 83;
						var cy_normal_calories_progress29 = 208;
						var r_normal_calories_progress29 = 58;
						var lw_normal_calories_progress29 = 17;
						var c_normal_calories_progress29 = 0xFF0095FF;

						// calculated parameters
						var ax_normal_calories_progress29 = cx_normal_calories_progress29 - r_normal_calories_progress29;
						var ay_normal_calories_progress29 = cy_normal_calories_progress29 - r_normal_calories_progress29;
						var cw_normal_calories_progress29 = 2 * r_normal_calories_progress29;
						var ao_normal_calories_progress29 = ea_normal_calories_progress29 - sa_normal_calories_progress29;
						ao_normal_calories_progress29 = ao_normal_calories_progress29 * pcs_normal_calories_progress29;
						var ea_normal_calories_progress29_draw = sa_normal_calories_progress29 + ao_normal_calories_progress29;

						normal_calories_progress29.setProperty(hmUI.prop.MORE, {
							x: ax_normal_calories_progress29,
							y: ay_normal_calories_progress29,
							w: cw_normal_calories_progress29,
							h: cw_normal_calories_progress29,
							start_angle: sa_normal_calories_progress29,
							end_angle: ea_normal_calories_progress29_draw,
							color: c_normal_calories_progress29,
							line_width: lw_normal_calories_progress29,
						});
					};

				}

				function updateHeart() {
					let normal_heart_min_imagecombo18_current = Math.min(...heartSensor.today);
					if (normal_heart_min_imagecombo18_padding) {
						normal_heart_min_imagecombo18_current = normal_heart_min_imagecombo18_current.toString().padStart(normal_heart_min_imagecombo18.length, '0');
					}
					for (let i = 0; i < normal_heart_min_imagecombo18.length; i++) {
						if ((normal_heart_min_imagecombo18.length-normal_heart_min_imagecombo18_current.length) < i && normal_heart_min_imagecombo18_padding === false) {
							normal_heart_min_imagecombo18[i].setProperty(hmUI.prop.VISIBLE, false);
						} else {
							normal_heart_min_imagecombo18[i].setProperty(hmUI.prop.VISIBLE, true);
							normal_heart_min_imagecombo18[i].setProperty(hmUI.prop.SRC, normal_heart_min_imagecombo18_array[normal_heart_min_imagecombo18_current.toString().charAt(i)]);
						}
					}
					let normal_heart_max_imagecombo19_current = Math.max(...heartSensor.today);
					if (normal_heart_max_imagecombo19_padding) {
						normal_heart_max_imagecombo19_current = normal_heart_max_imagecombo19_current.toString().padStart(normal_heart_max_imagecombo19.length, '0');
					}
					for (let i = 0; i < normal_heart_max_imagecombo19.length; i++) {
						if ((normal_heart_max_imagecombo19.length-normal_heart_max_imagecombo19_current.length) < i && normal_heart_max_imagecombo19_padding === false) {
							normal_heart_max_imagecombo19[i].setProperty(hmUI.prop.VISIBLE, false);
						} else {
							normal_heart_max_imagecombo19[i].setProperty(hmUI.prop.VISIBLE, true);
							normal_heart_max_imagecombo19[i].setProperty(hmUI.prop.SRC, normal_heart_max_imagecombo19_array[normal_heart_max_imagecombo19_current.toString().charAt(i)]);
						}
					}
				}

				timeSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateTime();
				});

				calorieSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateCalories();
				});

				heartSensor.addEventListener(hmSensor.event.CHANGE, function() {
					updateHeart();
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						normal_animation1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
						normal_animation36.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
						updateTime();
						updateCalories();
						updateHeart();
						timeInterval = setInterval(updateTime, 1000);
					}),
					pause_call: (function () {
						normal_animation1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
						normal_animation36.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
						clearInterval(timeInterval);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
						normal_animation1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
						normal_animation36.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
		},
	});	})()
} catch (e) {
	console.log(e)
}