﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

////////////////////////////////////////////////////////////////////////////////////////////////// 

        let deviceInfoS = hmSetting.getDeviceInfo();

let time24 = hmSensor.createSensor(hmSensor.id.TIME);
let normal_24Hcheck =''

function check24h(){
if (time24.is24Hour){
normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, true);
}

if (!time24.is24Hour){
normal_24Hcheck.setProperty(hmUI.prop.VISIBLE, false);
}

}

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start change color ALL
        let colornumber_mainA = 1
        let totalcolors_mainA = 7
        let namecolor_mainA = ''

        function click_ColorA() {
            if(colornumber_mainA>=totalcolors_mainA) {
            colornumber_mainA=1;
                }
            else {
                colornumber_mainA=colornumber_mainA+1;
            }

if ( colornumber_mainA == 1) { namecolor_mainA = "GREEN"}
if ( colornumber_mainA == 2) { namecolor_mainA = "YELLOW"}
if ( colornumber_mainA == 3) { namecolor_mainA = "RED"}
if ( colornumber_mainA == 4) { namecolor_mainA = "ORANGE"}
if ( colornumber_mainA == 5) { namecolor_mainA = "BLUE"}
if ( colornumber_mainA == 6) { namecolor_mainA = "MAGENTA"}
if ( colornumber_mainA == 7) { namecolor_mainA = "WHITE"}
hmUI.showToast({text: namecolor_mainA });




        normal_date_day_separator_img.setProperty(hmUI.prop.SRC, "Top" + parseInt(colornumber_mainA) + ".png");
        

        normal_battery_icon_img.setProperty(hmUI.prop.SRC, "Mid_L_" + parseInt(colornumber_mainA) + ".png");
            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: "Pointer" + parseInt(colornumber_mainA) + ".png",
              center_x: deviceInfoS.width / 480 * 131,
              center_y: deviceInfoS.height / 480 * 275,
              x: deviceInfoS.width / 480 * 19,
              y: deviceInfoS.height / 480 * 77,
              start_angle:  269,
              end_angle:  451,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


        normal_step_icon_img.setProperty(hmUI.prop.SRC, "Mid_R_" + parseInt(colornumber_mainA) + ".png");
            normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: "Pointer" + parseInt(colornumber_mainA) + ".png",
              center_x: deviceInfoS.width / 480 * 349,
              center_y: deviceInfoS.height / 480 * 275,
              x: deviceInfoS.width / 480 * 19,
              y: deviceInfoS.width / 480 * 77,
              start_angle: 270,
              end_angle:  453,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


        normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "under" + parseInt(colornumber_mainA) + ".png");

                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start change color TOP
        let colornumber_mainT = 1
        let totalcolors_mainT = 7
        let namecolor_mainT = ''

        function click_ColorT() {
            if(colornumber_mainT>=totalcolors_mainT) {
            colornumber_mainT=1;
                }
            else {
                colornumber_mainT=colornumber_mainT+1;
            }

if ( colornumber_mainT == 1) { namecolor_mainT = "GREEN"}
if ( colornumber_mainT == 2) { namecolor_mainT = "YELLOW"}
if ( colornumber_mainT == 3) { namecolor_mainT = "RED"}
if ( colornumber_mainT == 4) { namecolor_mainT = "ORANGE"}
if ( colornumber_mainT == 5) { namecolor_mainT = "BLUE"}
if ( colornumber_mainT == 6) { namecolor_mainT = "MAGENTA"}
if ( colornumber_mainT == 7) { namecolor_mainT = "WHITE"}
hmUI.showToast({text: namecolor_mainT });




        normal_date_day_separator_img.setProperty(hmUI.prop.SRC, "Top" + parseInt(colornumber_mainT) + ".png");
        normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "Hand_S" + parseInt(colornumber_mainT) + ".png");

                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start change color midL
        let colornumber_mainL = 1
        let totalcolors_mainL = 7
        let namecolor_mainL = ''

        function click_ColorL() {
            if(colornumber_mainL>=totalcolors_mainL) {
            colornumber_mainL=1;
                }
            else {
                colornumber_mainL=colornumber_mainL+1;
            }

if ( colornumber_mainL == 1) { namecolor_mainL = "GREEN"}
if ( colornumber_mainL == 2) { namecolor_mainL = "YELLOW"}
if ( colornumber_mainL == 3) { namecolor_mainL = "RED"}
if ( colornumber_mainL == 4) { namecolor_mainL = "ORANGE"}
if ( colornumber_mainL == 5) { namecolor_mainL = "BLUE"}
if ( colornumber_mainL == 6) { namecolor_mainL = "MAGENTA"}
if ( colornumber_mainL == 7) { namecolor_mainL = "WHITE"}
hmUI.showToast({text: namecolor_mainL });



        normal_battery_icon_img.setProperty(hmUI.prop.SRC, "Mid_L_" + parseInt(colornumber_mainL) + ".png");
            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: "Pointer" + parseInt(colornumber_mainL) + ".png",
              center_x: deviceInfoS.width / 480 * 131,
              center_y: deviceInfoS.height / 480 * 275,
              x: deviceInfoS.width / 480 * 19,
              y: deviceInfoS.height / 480 * 77,
              start_angle:  269,
              end_angle:  451,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start change color MidR
        let colornumber_mainR = 1
        let totalcolors_mainR = 7
        let namecolor_mainR = ''

        function click_ColorR() {
            if(colornumber_mainR>=totalcolors_mainR) {
            colornumber_mainR=1;
                }
            else {
                colornumber_mainR=colornumber_mainR+1;
            }

if ( colornumber_mainR == 1) { namecolor_mainR = "GREEN"}
if ( colornumber_mainR == 2) { namecolor_mainR = "YELLOW"}
if ( colornumber_mainR == 3) { namecolor_mainR = "RED"}
if ( colornumber_mainR == 4) { namecolor_mainR = "ORANGE"}
if ( colornumber_mainR == 5) { namecolor_mainR = "BLUE"}
if ( colornumber_mainR == 6) { namecolor_mainR = "MAGENTA"}
if ( colornumber_mainR == 7) { namecolor_mainR = "WHITE"}
hmUI.showToast({text: namecolor_mainR });



        normal_step_icon_img.setProperty(hmUI.prop.SRC, "Mid_R_" + parseInt(colornumber_mainR) + ".png");
            normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: "Pointer" + parseInt(colornumber_mainR) + ".png",
              center_x: deviceInfoS.width / 480 * 349,
              center_y: deviceInfoS.height / 480 * 275,
              x: deviceInfoS.width / 480 * 19,
              y: deviceInfoS.width / 480 * 77,
              start_angle: 270,
              end_angle: 453,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start change color Weahter icon
        let colornumber_mainW = 1
        let totalcolors_mainW = 7
        let namecolor_mainW = ''

        function click_ColorW() {
            if(colornumber_mainW>=totalcolors_mainW) {
            colornumber_mainW=1;
                }
            else {
                colornumber_mainW=colornumber_mainW+1;
            }

if ( colornumber_mainW == 1) { namecolor_mainW = "GREEN"}
if ( colornumber_mainW == 2) { namecolor_mainW = "YELLOW"}
if ( colornumber_mainW == 3) { namecolor_mainW = "RED"}
if ( colornumber_mainW == 4) { namecolor_mainW = "ORANGE"}
if ( colornumber_mainW == 5) { namecolor_mainW = "BLUE"}
if ( colornumber_mainW == 6) { namecolor_mainW = "MAGENTA"}
if ( colornumber_mainW == 7) { namecolor_mainW = "WHITE"}
hmUI.showToast({text: namecolor_mainW });

        normal_temperature_icon_img.setProperty(hmUI.prop.SRC, "under" + parseInt(colornumber_mainW) + ".png");

                           
        }

/////////////////////////////////////////////////////////////////////////////////////////////////
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_system_clock_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_target_text_img = ''
        let normal_step_target_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_hour = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_battery_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''
        let Button_4 = ''
        let Button_5 = ''
        let Button_6 = ''
        let Button_7 = ''
        let Button_8 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 346,
              y: 396,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 347,
              y: 55,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 32,
              y: 164,
              src: 'Mid_L_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer1.png',
              center_x: 131,
              center_y: 275,
              x: 19,
              y: 77,
              start_angle: 269,
              end_angle: 451,
              invalid_visible: false,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 180,
              y: 192,
              font_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Batt_unit.png',
              unit_tc: 'Batt_unit.png',
              unit_en: 'Batt_unit.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 81,
              y: 362,
              font_array: ["Act_D_0.png","Act_D_1.png","Act_D_2.png","Act_D_3.png","Act_D_4.png","Act_D_5.png","Act_D_6.png","Act_D_7.png","Act_D_8.png","Act_D_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'cal_unit.png',
              unit_tc: 'cal_unit.png',
              unit_en: 'cal_unit.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 281,
              y: 362,
              font_array: ["Act_D_0.png","Act_D_1.png","Act_D_2.png","Act_D_3.png","Act_D_4.png","Act_D_5.png","Act_D_6.png","Act_D_7.png","Act_D_8.png","Act_D_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Dis_KM.png',
              unit_tc: 'Dis_KM.png',
              unit_en: 'Dis_KM.png',
              imperial_unit_sc: 'Dis_Mi.png',
              imperial_unit_tc: 'Dis_Mi.png',
              imperial_unit_en: 'Dis_Mi.png',
              dot_image: 'Dis_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 177,
              y: 409,
              src: 'under1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 175,
              y: 406,
              image_array: ["W_Weather_icons_01.png","W_Weather_icons_02.png","W_Weather_icons_03.png","W_Weather_icons_04.png","W_Weather_icons_05.png","W_Weather_icons_06.png","W_Weather_icons_07.png","W_Weather_icons_08.png","W_Weather_icons_09.png","W_Weather_icons_10.png","W_Weather_icons_11.png","W_Weather_icons_12.png","W_Weather_icons_13.png","W_Weather_icons_14.png","W_Weather_icons_15.png","W_Weather_icons_16.png","W_Weather_icons_17.png","W_Weather_icons_18.png","W_Weather_icons_19.png","W_Weather_icons_20.png","W_Weather_icons_21.png","W_Weather_icons_22.png","W_Weather_icons_23.png","W_Weather_icons_24.png","W_Weather_icons_25.png","W_Weather_icons_26.png","W_Weather_icons_27.png","W_Weather_icons_28.png","W_Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 414,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Temp_unit.png',
              unit_tc: 'Temp_unit.png',
              unit_en: 'Temp_unit.png',
              imperial_unit_sc: 'Temp_unit.png',
              imperial_unit_tc: 'Temp_unit.png',
              imperial_unit_en: 'Temp_unit.png',
              negative_image: 'Temp_Error.png',
              invalid_image: 'Temp_Error.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const temperatureUnit = hmSetting.getTemperatureUnit();
            //start of ignored block
            if (temperatureUnit == 1) {
              normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
                x: 227,
                y: 414,
                font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
                padding: false,
                h_space: 1,
                unit_sc: 'Temp_unit.png',
                unit_tc: 'Temp_unit.png',
                unit_en: 'Temp_unit.png',
                imperial_unit_sc: 'Temp_unit.png',
                imperial_unit_tc: 'Temp_unit.png',
                imperial_unit_en: 'Temp_unit.png',
                negative_image: 'Temp_Error.png',
                invalid_image: 'Temp_Error.png',
                align_h: hmUI.align.CENTER_H,
                type: hmUI.data_type.WEATHER_CURRENT,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
            };
            //end of ignored block

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 253,
              y: 164,
              src: 'Mid_R_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer1.png',
              center_x: 349,
              center_y: 275,
              x: 19,
              y: 77,
              start_angle: 270,
              end_angle: 453,
              invalid_visible: false,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_target_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 447,
              y: 2,
              font_array: ["Act_s_0.png","Act_s_1.png","Act_s_2.png","Act_s_3.png","Act_s_4.png","Act_s_5.png","Act_s_6.png","Act_s_7.png","Act_s_8.png","Act_s_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP_TARGET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_target_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 21,
              y: 249,
              src: 'Top_pointer.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 303,
              y: 307,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 307,
              font_array: ["Act_0.png","Act_1.png","Act_2.png","Act_3.png","Act_4.png","Act_5.png","Act_6.png","Act_7.png","Act_8.png","Act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 189,
              y: 316,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
			  invalid_visible: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 233,
              month_startY: 56,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 182,
              day_startY: 56,
              day_sc_array: ["Day0.png","Day1.png","Day2.png","Day3.png","Day4.png","Day5.png","Day6.png","Day7.png","Day8.png","Day9.png"],
              day_tc_array: ["Day0.png","Day1.png","Day2.png","Day3.png","Day4.png","Day5.png","Day6.png","Day7.png","Day8.png","Day9.png"],
              day_en_array: ["Day0.png","Day1.png","Day2.png","Day3.png","Day4.png","Day5.png","Day6.png","Day7.png","Day8.png","Day9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 146,
              y: 7,
              src: 'Top1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 204,
              y: 6,
              week_en: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_tc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_sc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('user_script.js');
            // start user_script.js
normal_24Hcheck = hmUI.createWidget(hmUI.widget.IMG, {
              x: deviceInfoS.width / 480 * 412,
              y: deviceInfoS.height / 480 * 193,
              src: 'Clock_24H.png',
            show_level: hmUI.show_level.ONLY_NORMAL,

            });
check24h()
            // end user_script.js

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 412,
              am_y: 193,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 412,
              pm_y: 193,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 320,
              second_startY: 97,
              second_array: ["Time_T_0.png","Time_T_1.png","Time_T_2.png","Time_T_3.png","Time_T_4.png","Time_T_5.png","Time_T_6.png","Time_T_7.png","Time_T_8.png","Time_T_9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 194,
              minute_startY: 99,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 66,
              hour_startY: 99,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 47,
              y: 91,
              src: 'Top_Digital.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 194,
              minute_startY: 209,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 318,
              y: 97,
              src: 'Aod_icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 66,
              hour_startY: 209,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 47,
              y: 91,
              src: 'Top_Digital.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 91,
              y: 180,
              w: 80,
              h: 50,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 259,
              y: 308,
              w: 150,
              h: 37,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 89,
              y: 308,
              w: 135,
              h: 35,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 93,
              y: 357,
              w: 116,
              h: 35,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 338,
              y: 391,
              w: 50,
              h: 50,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 152,
              y: 404,
              w: 174,
              h: 52,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 16,
              y: 308,
              w: 70,
              h: 35,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 209,
              y: 98,
              w: 70,
              h: 70,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 78,
              y: 98,
              w: 70,
              h: 70,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 338,
              y: 44,
              w: 50,
              h: 50,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 182,
              y: 44,
              w: 123,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 307,
              y: 180,
              w: 80,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 92,
              y: 394,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'Settings_homeScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_4 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 92,
              y: 44,
              w: 50,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_click.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // chang color all
                click_ColorA()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_5 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 338,
              y: 98,
              w: 70,
              h: 70,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_click.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // change color top
                click_ColorT()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_6 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 0,
              y: 186,
              w: 50,
              h: 77,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_click.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // change color mid. left
                click_ColorL()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_7 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 431,
              y: 186,
              w: 50,
              h: 77,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_click.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // change color mid. right
                click_ColorR()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_8 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 173,
              y: 405,
              w: 52,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_click.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                // change color weather icon
                click_ColorW()
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');

                console.log('resume_call.js');
                // start resume_call.js

check24h()
                // end resume_call.js

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}