﻿    /*
    ** Watch_Face_Editor tool v 18.0
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start
        let currentTheme = hmFS.SysProGetInt('WatchTheme') ?? 1;   // 1..4       
        let weatherImg, tempText, cityNameText;
        let weatherProvider = null;  
        
        let normal_background_bg_img = ''
        let normal_background_bg2_img = ''
        let normal_background_bg3_img = ''
        let normal_background_bg4_img = ''
        let normal_background_bg5_img = ''
        let normal_background_bg6_img = ''
        let normal_day_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_dayX_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_image_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_font = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_font = ''
        let normal_humidity_pointer_progress_img_pointer = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_time_pointer2_second = ''
        let normal_analog_clock_time_pointer3_second = ''
        let normal_analog_clock_time_pointer4_second = ''
        let normal_analog_clock_time_pointer5_second = ''
        let normal_analog_clock_time_pointer6_second = ''
        let idle_background_bg_img = ''
        let idle_background_bg2_img = ''
        let idle_background_bg3_img = '' 
        let idle_background_bg4_img = '' 
        let idle_background_bg5_img = '' 
        let idle_background_bg6_img = ''  
        let idle_day_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_dayX_icon_img = ''
        let idle_battery_circle_scale = ''
        let idle_image_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let timeSensor = '';

        // --------------------
        // WeatherProvider v5.1 —  T-Rex Ultra 2
        // --------------------
        class WeatherProvider {
                constructor(props = {}) {
                    this.iconMapService = {
                        1: 3, 2: 0, 3: 4, 4: 4, 5: 1, 6: 5, 7: 10, 8: 15,
                        9: 6, 10: 8, 11: 9, 12: 12, 13: 13, 14: 17
                    };

                    this.description = [
                        ['Облачно','Временами дождь','Временами снег','Ясно','Пасмурно','Слабый дождь','Слабый снег','Умеренный дождь','Умеренный снег','Сильный снегопад','Сильный дождь','Песчаная буря','Мокрый снег','Туман','Дымка','Дождь с грозой','Метель','Пыльно','Ливень','Дождь с градом','Сильный дождь с градом','Сильный дождь','Пыльная буря','Сильная песчаная буря','Сильный дождь','Обновите погоду','Облачно ночью','Дождливо ночью','Ясно ночью'],
                        ['Cloudy','Showers','Snow Showers','Sunny','Overcast','Light Rain','Light Snow','Moderate Rain','Moderate Snow','Heavy Snow','Heavy Rain','Sandstorm','Rain and Snow','Fog','Hazy','T-Storms','Snowstorm','Floating dust','Very Heavy Rainstorm','Rain and Hail','T-Storms and Hail','Heavy Rainstorm','Dust','Heavy sand storm','Rainstorm','Unknown','Cloudy Nighttime','Showers Nighttime','Sunny Nighttime']
                    ];

                    this.props = {
                        night_icons: [0, 1, 2, 3, 14],
                        index: hmFS.SysProGetInt('WeatherProviderIndex') ?? 0,
                        show_toast: true,
                        temp_widget: null,
                        temp_max_widget: null,
                        temp_min_widget: null,
                        temp_feels_widget: null,
                        description_widget: null,
                        cityName_widget: null,
                        icon_widget: null,
                        time_sensor: true,
                        weather_sensor: null,
                        lang: (hmSetting.getLanguage() === 4 ? 0 : 1),
                        ...props
                    };

                    this.providers = [
                        { name: ['Zepp','Zepp'], appId: null },
                        { name: ['Погодный сервис','Weather service'], appId: 1065824 }
                    ];

                    this.last = {
                        weatherIcon: 25,
                        displayedIcon: '25',
                        weatherDescription: 'Нет данных',
                        temperature: '--',
                        temperatureFeels: '--',
                        temperatureMax: '--',
                        temperatureMin: '--',
                        cityName: '--',
                        modTime: null,
                        sunriseMins: 360,
                        sunsetMins: 1200
                    };

                    this._THROTTLE_MS = 6 * 60 * 1000;
                    this._lastUpdateMs = hmFS.SysProGetInt64("weatherLastUpdateMs") || 0;
                    this._isUpdating = false;

                    if (!this.props.time_sensor) this.props.time_sensor = curTime;

                    if (!this.props.weather_sensor) {
                        try {
                            this.props.weather_sensor = hmSensor.createSensor(hmSensor.id.WEATHER);
                        } catch (e) {
                            console.log('WEATHER sensor creation failed:', e);
                            this.props.weather_sensor = null;
                        }
                    }

                    if (isFinite(this.props.index)) {
                        hmFS.SysProSetInt('WeatherProviderIndex', this.props.index);
                    }
                }

                update(force = false) {
                    if (this._isUpdating) return;

                    const nowMs = Date.now();
                    const isTimeout = (nowMs - this._lastUpdateMs >= this._THROTTLE_MS);

                    if (!force && !isTimeout) return;

                    this._isUpdating = true;

                    const prov = this.providers[this.props.index];
                    const isZepp = prov.appId === null;

                    let shouldApply = force;

                    if (isZepp) {
                        shouldApply = isTimeout || force;
                    } else {                        
                        const modTime = this.getFileModTime(prov.appId);
                        if (force || !modTime || modTime !== this.last.modTime) {
                            this.last.modTime = modTime;
                            shouldApply = true;
                        } else if (isTimeout) {
                            shouldApply = true;
                        }
                    }

                    if (shouldApply) {
                        const newData = this.getWeatherData(prov.appId);
                        this._applyWeatherData(newData);
                    }

                    this._lastUpdateMs = nowMs;
                    hmFS.SysProSetInt64("weatherLastUpdateMs", nowMs);

                    this._isUpdating = false;
                }

                _applyWeatherData(newData) {
                    
                    const tVal = this.tempWithSign(newData.temperature);
                    if (tVal !== this.last.temperature) {
                        this.last.temperature = tVal;
                        this.props.temp_widget?.setProperty(hmUI.prop.TEXT, tVal);
                    }

                    const tMax = this.tempWithSign(newData.temperatureMax);
                    if (tMax !== this.last.temperatureMax) {
                        this.last.temperatureMax = tMax;
                        this.props.temp_max_widget?.setProperty(hmUI.prop.TEXT, tMax);
                    }

                    const tMin = this.tempWithSign(newData.temperatureMin);
                    if (tMin !== this.last.temperatureMin) {
                        this.last.temperatureMin = tMin;
                        this.props.temp_min_widget?.setProperty(hmUI.prop.TEXT, tMin);
                    }

                    const tFeels = this.tempWithSign(newData.temperatureFeels);
                    if (tFeels !== this.last.temperatureFeels) {
                        this.last.temperatureFeels = tFeels;
                        this.props.temp_feels_widget?.setProperty(hmUI.prop.TEXT, tFeels);
                    }

                    if (newData.cityName !== this.last.cityName) {
                        this.last.cityName = newData.cityName;
                        this.props.cityName_widget?.setProperty(hmUI.prop.TEXT, newData.cityName);
                    }

                    if (newData.weatherDescription !== this.last.weatherDescription) {
                        this.last.weatherDescription = newData.weatherDescription;
                        this.props.description_widget?.setProperty(hmUI.prop.TEXT, newData.weatherDescription);
                    }
                    
                    let curIcon = parseInt(newData.weatherIcon);
                    let iconSuffix = (this.props.night_icons.includes(curIcon) && !this.isDayNow()) ? 'n' : '';
                    const finalIconStr = `${curIcon}${iconSuffix}`;

                    if (finalIconStr !== this.last.displayedIcon) {
                        this.last.displayedIcon = finalIconStr;
                        this.last.weatherIcon = curIcon;
                        this.props.icon_widget?.setProperty(hmUI.prop.SRC, `W_${finalIconStr}.png`);
                    }
                }

                tempWithSign(val) {
                    let fVal = parseFloat(val);
                    if (isNaN(fVal) || !isFinite(fVal)) return '--';
                    return (fVal > 0 ? '+' : '') + Math.round(fVal) + '°';
                }

                isDayNow() {
                    const ts = this.props.time_sensor;
                    let curMins;

                    if (ts && typeof ts.hour === 'number' && typeof ts.minute === 'number') {
                        curMins = ts.hour * 60 + ts.minute;
                    } else {
                        const now = new Date();
                        curMins = now.getHours() * 60 + now.getMinutes();
                    }

                    if (isNaN(this.last.sunriseMins) || isNaN(this.last.sunsetMins)) {
                        return true;
                    }

                    return curMins >= this.last.sunriseMins && curMins < this.last.sunsetMins;
                }

                getWeatherData(app_id = null) {
                    return !app_id ? this.getZeppWeatherData() : this.getAppWeatherData(app_id);
                }

                getZeppWeatherData() {
                    try {
                        const ws = this.props.weather_sensor;
                        if (!ws) throw new Error("No Sensor");

                        const fw = ws.getForecastWeather ? ws.getForecastWeather() : null;
                        const cityName = fw ? fw.cityName : '--';
                        const iconIndex = ws.curAirIconIndex ?? 25;

                        if (fw && fw.forecastData && fw.forecastData.count > 0) {
                            const today = fw.forecastData.data[0];
                            if (today.sunrise && today.sunset) {
                                const riseHour = parseInt(today.sunrise.hour);
                                const riseMin = parseInt(today.sunrise.minute);
                                const setHour = parseInt(today.sunset.hour);
                                const setMin = parseInt(today.sunset.minute);

                                if (!isNaN(riseHour) && !isNaN(riseMin) && !isNaN(setHour) && !isNaN(setMin)) {
                                    this.last.sunriseMins = riseHour * 60 + riseMin;
                                    this.last.sunsetMins = setHour * 60 + setMin;
                                    this.last.sunData = this.props.time_sensor ? this.props.time_sensor.day : new Date().getDate();
                                }
                            }
                        }

                        return {
                            weatherIcon: iconIndex,
                            weatherDescription: this.description[this.props.lang][iconIndex] || 'Нет данных',
                            temperature: ws.current ?? '--',
                            temperatureFeels: ws.feelsLike ?? '--',
                            temperatureMax: ws.high ?? '--',
                            temperatureMin: ws.low ?? '--',
                            cityName: cityName
                        };
                    } catch (e) {
                        console.log('getZeppWeatherData error:', e);
                        return { weatherIcon:25, weatherDescription:'Нет данных', temperature:'--', temperatureFeels:'--', temperatureMax:'--', temperatureMin:'--', cityName:'--' };
                    }
                }

                getAppWeatherData(app_id) {
                    const data = { weatherIcon: 25, weatherDescription: 'Нет данных', temperature: '--', temperatureFeels: '--', temperatureMax: '--', temperatureMin: '--', cityName: '--' };
                    const weather_str = this.readFile(app_id);
                    if (!weather_str) return data;

                    try {
                        const weatherJson = JSON.parse(weather_str);
                        if (weatherJson) {
                            data.weatherIcon = this.getZeppIconIndex(parseInt(weatherJson.weatherIcon || 25), app_id);

                            if (weatherJson.weatherDescriptionExtended) {
                                const desc = weatherJson.weatherDescriptionExtended;
                                data.weatherDescription = desc.charAt(0).toUpperCase() + desc.slice(1);
                            } else {
                                data.weatherDescription = this.description[this.props.lang][data.weatherIcon] || 'Нет данных';
                            }

                            data.temperature = weatherJson.temperature ?? '--';
                            data.temperatureFeels = weatherJson.temperatureFeels ?? '--';
                            data.temperatureMax = weatherJson.temperatureMax ?? '--';
                            data.temperatureMin = weatherJson.temperatureMin ?? '--';
                            data.cityName = weatherJson.city || '--';
                        }
                    } catch (e) {
                        console.log('JSON Parse error in getAppWeatherData:', e);
                    }
                    return data;
                }

                getZeppIconIndex(index, app_id = null) {
                    if (!app_id) return index;
                    if (app_id === 1065824) return this.iconMapService[index] ?? 25;
                    if (app_id === 1066654) return index - 1;
                    return index;
                }

                readFile(app_id) {
                    if (!app_id) return null;
                    try {
                        const [fs_stat, err] = hmFS.stat('weather.json', { appid: app_id });
                        if (err === 0 && fs_stat.size > 0) {
                            const fh = hmFS.open('weather.json', hmFS.O_RDONLY, { appid: app_id });
                            const array_buffer = new ArrayBuffer(fs_stat.size);
                            hmFS.read(fh, array_buffer, 0, fs_stat.size);
                            hmFS.close(fh);
                            return this.arrayBufferToCyrillic(array_buffer);
                        }
                    } catch (e) {
                        console.log('readFile error:', e);
                    }
                    return null;
                }

                getFileModTime(app_id) {
                    if (!app_id) return null;
                    try {
                        const [fs_stat, err] = hmFS.stat('weather.json', { appid: app_id });
                        if (err === 0) return fs_stat.mtime;
                    } catch (e) {}
                    return null;
                }

                arrayBufferToCyrillic(buffer) {
                    let result = '';
                    const bytes = new Uint8Array(buffer);
                    for (let i = 0; i < bytes.length;) {
                        let byte1 = bytes[i++];
                        if (byte1 < 0x80) {
                            result += String.fromCharCode(byte1);
                        } else if (byte1 >= 0xC0 && byte1 < 0xE0) {
                            let byte2 = bytes[i++];
                            result += String.fromCharCode(((byte1 & 0x1F) << 6) | (byte2 & 0x3F));
                        } else if (byte1 >= 0xE0 && byte1 < 0xF0) {
                            let byte2 = bytes[i++];
                            let byte3 = bytes[i++];
                            result += String.fromCharCode(((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F));
                        }
                    }
                    return result;
                }

                next(show_toast = this.props.show_toast) {
                    this.props.index = (this.props.index + 1) % this.providers.length;
                    hmFS.SysProSetInt('WeatherProviderIndex', this.props.index);
                    this.last.modTime = 0;                    
                    if (show_toast) hmUI.showToast({ text: this.providers[this.props.index].name[this.props.lang] });
                    this.update(true);
                }

                prev(show_toast = this.props.show_toast) {
                    this.props.index = (this.props.index - 1 + this.providers.length) % this.providers.length;
                    hmFS.SysProSetInt('WeatherProviderIndex', this.props.index);
                    this.last.modTime = 0;                    
                    if (show_toast) hmUI.showToast({ text: this.providers[this.props.index].name[this.props.lang] });
                    this.update(true);
                }

                get cityName() { return this.last.cityName ?? '--'; }
                get temperature() { return this.last.temperature ?? '--'; }
                get temperatureFeels() { return this.last.temperatureFeels ?? '--'; }
                get temperatureMax() { return this.last.temperatureMax ?? '--'; }
                get temperatureMin() { return this.last.temperatureMin ?? '--'; }
                get weatherDescription() { return this.last.weatherDescription ?? 'Нет данных'; }
                get weatherIcon() { return this.last.weatherIcon ?? 25; }

                delete() {
                    this._isUpdating = false;
                    this.props = null;
                    this.last = null;
                    this.description = null;
                    this.iconMapService = null;
                    this.providers = null;
                }
        }
      

       
        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: 101.ttf; FontSize: 30
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 339,
              h: 42,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/101.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 101.ttf; FontSize: 23; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 27,
              h: 27,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              font: 'fonts/101.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: 101.ttf; FontSize: 28
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 478,
              y: 478,
              w: 297,
              h: 37,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/101.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_background_bg2_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });   
            
            normal_background_bg3_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_background_bg4_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });        
            
            normal_background_bg5_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });  
            
            normal_background_bg6_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_6.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); 

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });            

            normal_day_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'data_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 0,
              month_startY: 0,
              month_sc_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_tc_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_en_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_dayX_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'dayX_28.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 40,
              // end_angle: 318,
              // radius: 174,
              // line_width: 24,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 160,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 318,
              end_angle: 40,
              radius: 162,
              line_width: 24,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_circle_scale.setAlpha(160);
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 140,
              // center_y: 239,
              // start_angle: -141,
              // end_angle: 141,
              // radius: 46,
              // line_width: 7,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 165,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 140,
              center_y: 239,
              start_angle: 141,
              end_angle: -141,
              radius: 43,
              line_width: 7,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_circle_scale.setAlpha(165);
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 65,
              y: 224,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              font: 'fonts/101.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 338,
              // center_y: 239,
              // start_angle: -141,
              // end_angle: 141,
              // radius: 46,
              // line_width: 7,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 165,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 338,
              center_y: 239,
              start_angle: 141,
              end_angle: -141,
              radius: 43,
              line_width: 7,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_circle_scale.setAlpha(165);
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 265,
              y: 224,
              w: 150,
              h: 40,
              text_size: 30,
              char_space: 0,
              font: 'fonts/101.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'vl.png',
              center_x: 239,
              center_y: 332,
              x: 10,
              y: 52,
              start_angle: -129,
              end_angle: 130,
              invalid_visible: false,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const weatherInfo = hmUI.createWidget(hmUI.widget.GROUP, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
            });


            cityNameText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 162,
              y: 105,
              w: 158,
              h: 30,
              text_size: 23,
              char_space: 0,
              font: 'fonts/101.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              text: "--",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            weatherImg = weatherInfo.createWidget(hmUI.widget.IMG, {
              x: 225,
              y: 354,
              w: 80,
              h: 80,
              src: 'W_25.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            tempText = weatherInfo.createWidget(hmUI.widget.TEXT, {
              x: 168,
              y: 318,
              w: 150,
              h: 40,
              text_size: 28,
              char_space: 0,
              font: 'fonts/101.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              text: '--',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            weatherProvider = new WeatherProvider({
                temp_widget: tempText,
                cityName_widget: cityNameText,
                icon_widget: weatherImg,
                night_icons: [0, 1, 2, 3, 14],
                show_toast: true
            });
            weatherProvider.update(true);              

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 157,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 197,
              hour_startY: 129,
              hour_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 245,
              minute_startY: 129,
              minute_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 16,
              hour_posY: 187,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minn_1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 16,
              minute_posY: 187,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sekk_1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 16,
              second_posY: 187,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer2_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sekk_2.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 16,
              second_posY: 187,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });    
            
            normal_analog_clock_time_pointer3_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sekk_3.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 16,
              second_posY: 187,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });  
            
            normal_analog_clock_time_pointer4_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sekk_4.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 16,
              second_posY: 187,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });     
            
            normal_analog_clock_time_pointer5_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sekk_5.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 16,
              second_posY: 187,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });      
            
            normal_analog_clock_time_pointer6_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sekk_6.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 16,
              second_posY: 187,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });            

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_background_bg2_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });   
            
            idle_background_bg3_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });  
            
            idle_background_bg4_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_4.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });      
            
            idle_background_bg5_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_5.png',
              show_level: hmUI.show_level.ONLY_AOD,
            }); 
            
            idle_background_bg6_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'osn_6.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });  

            idle_day_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'data_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 0,
              month_startY: 0,
              month_sc_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_tc_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_en_array: ["mon_0.png","mon_1.png","mon_2.png","mon_3.png","mon_4.png","mon_5.png","mon_6.png","mon_7.png","mon_8.png","mon_9.png","mon_10.png","mon_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_tc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              week_sc: ["day_0.png","day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_dayX_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'dayX_28.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 40,
              // end_angle: 318,
              // radius: 174,
              // line_width: 24,
              // line_cap: Flat,
              // color: 0xFF000000,
              // mirror: False,
              // inversion: True,
              // alpha: 160,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 240,
              center_y: 240,
              start_angle: 318,
              end_angle: 40,
              radius: 162,
              line_width: 24,
              corner_flag: 3,
              color: 0xFF000000,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_circle_scale.setAlpha(160);

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'zapl_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 157,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 197,
              hour_startY: 129,
              hour_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              hour_zero: 1,
              hour_space: -1,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 245,
              minute_startY: 129,
              minute_array: ["d_0.png","d_1.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png","d_8.png","d_9.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 16,
              hour_posY: 187,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'minn_1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 16,
              minute_posY: 187,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            applyTheme(currentTheme);            

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 309,
              y: 219,
              w: 60,
              h: 45,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 110,
              y: 216,
              w: 60,
              h: 45,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 208,
              y: 304,
              w: 60,
              h: 45,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 182,
              y: 124,
              w: 50,
              h: 35,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 248,
              y: 124,
              w: 50,
              h: 35,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 222,
              y: 164,
              w: 35,
              h: 35,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 208,
              y: 359,
              w: 60,
              h: 45,
              text: '',
              text_size: 25,
              color: 0xFFFF8C00,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: () => {
                weatherProvider.prev(true);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });  
            
            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 208,
              y: 430,
              w: 60,
              h: 45,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'clean.png',
              normal_src: 'clean.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1065824, url: 'page/index', params: { from_wf: true} });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button    
            
            const themeButton = hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 212,          // центр
                y: 216,
                w: 50,
                h: 50,
                text: '',
                press_src: 'clean.png',
                normal_src: 'clean.png',
                click_func: () => {
                    currentTheme = (currentTheme % 6) + 1;  
                    applyTheme(currentTheme);
                    hmUI.showToast({ text: `Тема ${currentTheme}` });
                },
                show_level: hmUI.show_level.ONLY_NORMAL,  
            });             
                                    
            //#region time_update
            function time_update(updateHour = false, updateMinute = false) {
              if (updateHour) {                
                updateDateWidgets();
              }
            };          
            //#endregion

            function updateDateWidgets() {
              if (!timeSensor) return;
              let day = timeSensor.day;
              let month = timeSensor.month;
              let year = timeSensor.year;
              let daySrc = `data_${day}.png`;

              if (normal_day_img && normal_day_img.setProperty) normal_day_img.setProperty(hmUI.prop.SRC, daySrc);
              if (idle_day_img && idle_day_img.setProperty) idle_day_img.setProperty(hmUI.prop.SRC, daySrc);

              let daysInMonth = new Date(year, month, 0).getDate();
              let dayXSrc = `dayX_${daysInMonth}.png`;

              if (normal_dayX_icon_img && normal_dayX_icon_img.setProperty) normal_dayX_icon_img.setProperty(hmUI.prop.SRC, dayXSrc);
              if (idle_dayX_icon_img && idle_dayX_icon_img.setProperty) idle_dayX_icon_img.setProperty(hmUI.prop.SRC, dayXSrc);
            }          

            function scale_call() {
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = 1 - progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 318,
                      end_angle: 40,
                      radius: 162,
                      line_width: 24,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 184;
                let progressHeartRate = (valueHeartRate - 30)/(targetHeartRate - 30);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = 1 - progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_heart_rate * 100);
                  if (normal_heart_rate_circle_scale) {
                    normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 140,
                      center_y: 239,
                      start_angle: 141,
                      end_angle: -141,
                      radius: 43,
                      line_width: 7,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = 1 - progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 338,
                      center_y: 239,
                      start_angle: 141,
                      end_angle: -141,
                      radius: 43,
                      line_width: 7,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };


                let progress_cs_idle_battery = 1 - progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_idle_battery * 100);
                  if (idle_battery_circle_scale) {
                    idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 240,
                      center_y: 240,
                      start_angle: 318,
                      end_angle: 40,
                      radius: 162,
                      line_width: 24,
                      corner_flag: 3,
                      color: 0xFF000000,
                      show_level: hmUI.show_level.ONLY_AOD,
                      level: level,
                    });
                  };
                };

            };

            function applyTheme(theme) {
                // Normal
                normal_background_bg_img.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_background_bg2_img.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_background_bg3_img.setProperty(hmUI.prop.VISIBLE, theme === 3);  
                normal_background_bg4_img.setProperty(hmUI.prop.VISIBLE, theme === 4); 
                normal_background_bg5_img.setProperty(hmUI.prop.VISIBLE, theme === 5);
                normal_background_bg6_img.setProperty(hmUI.prop.VISIBLE, theme === 6);

                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, theme === 1);
                normal_analog_clock_time_pointer2_second.setProperty(hmUI.prop.VISIBLE, theme === 2);
                normal_analog_clock_time_pointer3_second.setProperty(hmUI.prop.VISIBLE, theme === 3);  
                normal_analog_clock_time_pointer4_second.setProperty(hmUI.prop.VISIBLE, theme === 4); 
                normal_analog_clock_time_pointer5_second.setProperty(hmUI.prop.VISIBLE, theme === 5);
                normal_analog_clock_time_pointer6_second.setProperty(hmUI.prop.VISIBLE, theme === 6);                
                                           
                // AOD
                idle_background_bg_img.setProperty(hmUI.prop.VISIBLE, theme === 1);
                idle_background_bg2_img.setProperty(hmUI.prop.VISIBLE, theme === 2);
                idle_background_bg3_img.setProperty(hmUI.prop.VISIBLE, theme === 3);
                idle_background_bg4_img.setProperty(hmUI.prop.VISIBLE, theme === 4);
                idle_background_bg5_img.setProperty(hmUI.prop.VISIBLE, theme === 5);
                idle_background_bg6_img.setProperty(hmUI.prop.VISIBLE, theme === 6);                                           
                // Сохраняем выбор
                hmFS.SysProSetInt('WatchTheme', theme);
            }            

            updateDateWidgets();            

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                time_update(true, true);
                if (weatherProvider) {
                    weatherProvider.update(false);
                }                  
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
                if (weatherProvider) {
                    weatherProvider.delete();
                    weatherProvider = null;
                }                
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}