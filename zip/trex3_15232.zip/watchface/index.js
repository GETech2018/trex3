/*
** Facemaker bundle tool v0.0.3
* *huamiOS watchface js version v4.0.1
* *Copyright © Huami. All Rights Reserved
*/


try {
	(() => {
		var __$$app$$__ = __$$hmAppManager$$__.currentApp;
		var __$$module$$__ = __$$app$$__.current;

		//drink is a name,can modify
		var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

		'use strict';

		//dynamic modify start
		let normal_img0 = '';
		let normal_img1 = '';
		let normal_img2 = '';
		let normal_img3 = '';
		let normal_animation4 = '';
		let normal_animation5 = '';
		let normal_animation6 = '';
		let normal_img7 = '';
		let normal_img8 = '';
		let normal_img9 = '';
		let normal_img10 = '';
		let normal_img11 = '';
		let normal_img12 = '';
		let normal_img13 = '';
		let normal_hour_imagecombo15 = '';
		let normal_minute_imagecombo16 = '';
		let normal_img18 = '';
		let normal_heart_current_imagecombo19 = '';
		let normal_steps_imagecombo21 = '';
		let normal_battery_imageset23 = '';
		let normal_calories_imagecombo25 = '';
		let normal_img26 = '';
		let idle_hour_imagecombo29 = '';
		let idle_minute_imagecombo30 = '';
		let idle_img31 = '';
		//dynamic modify end

		//not required
		const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

		__$$module$$__.module = DeviceRuntimeCore.WatchFace({
			init_view() {

				let screenType = hmSetting.getScreenType();

				normal_img0 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0002.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img1 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 107,
					y: 318,
					w: 130,
					h: 130,
					src: '0003.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img2 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 113,
					y: 57,
					w: 353,
					h: 353,
					src: '0004.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img3 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 0,
					y: 0,
					w: 480,
					h: 480,
					src: '0005.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_animation4 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
					x: 20,
					y: 110,
					anim_path: '',
					anim_prefix: '1737838358532',
					anim_ext: 'png',
					anim_fps: 25,
					anim_size: 25,
					anim_repeat: true,
					repeat_count: 0,
					anim_status: hmUI.anim_status.START,
					display_on_restart: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});
				normal_animation5 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
					x: 95,
					y: 304,
					anim_path: '',
					anim_prefix: '1737838446764',
					anim_ext: 'png',
					anim_fps: 25,
					anim_size: 48,
					anim_repeat: true,
					repeat_count: 0,
					anim_status: hmUI.anim_status.START,
					display_on_restart: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});
				normal_animation6 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
					x: 144,
					y: 34,
					anim_path: '',
					anim_prefix: '1737838410027',
					anim_ext: 'png',
					anim_fps: 25,
					anim_size: 48,
					anim_repeat: true,
					repeat_count: 0,
					anim_status: hmUI.anim_status.START,
					display_on_restart: true,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});
				normal_img7 = hmUI.createWidget(hmUI.widget.IMG, {
					x: -10,
					y: -10,
					w: 500,
					h: 500,
					src: '0127.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img8 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 211,
					y: 14,
					w: 95,
					h: 95,
					src: '0128.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img9 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 179,
					y: 374,
					w: 95,
					h: 95,
					src: '0128.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img10 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 241,
					y: 32,
					w: 35,
					h: 57,
					src: '0129.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img11 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 205,
					y: 401,
					w: 42,
					h: 40,
					src: '0130.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img12 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 264,
					y: 309,
					w: 156,
					h: 32,
					src: '0131.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img13 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 422,
					y: 305,
					w: 27,
					h: 42,
					src: '0132.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_hour_imagecombo15 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 241,
					hour_startY: 197,
					hour_array: ["0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.RIGHT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_minute_imagecombo16 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 361,
					minute_startY: 197,
					minute_array: ["0133.png","0134.png","0135.png","0136.png","0137.png","0138.png","0139.png","0140.png","0141.png","0142.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img18 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 337,
					y: 188,
					w: 17,
					h: 92,
					src: '0143.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_heart_current_imagecombo19 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 289,
					y: 405,
					font_array: ["0144.png","0145.png","0146.png","0147.png","0148.png","0149.png","0150.png","0151.png","0152.png","0153.png"],
					padding: true,
					h_space: 0,
					invalid_image: '0154.png',
					align_h: hmUI.align.LEFT,
					type: hmUI.data_type.HEART,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_steps_imagecombo21 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 127,
					y: 46,
					font_array: ["0155.png","0156.png","0157.png","0158.png","0159.png","0160.png","0161.png","0162.png","0163.png","0164.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.STEP,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_battery_imageset23 = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
					x: 264,
					y: 309,
					image_array: ["0165.png","0166.png","0167.png","0168.png","0169.png","0170.png","0165.png","0166.png","0167.png","0171.png","0172.png"],
					image_length: 11,
					type: hmUI.data_type.BATTERY,
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_calories_imagecombo25 = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
					x: 18,
					y: 241,
					font_array: ["0173.png","0174.png","0175.png","0176.png","0177.png","0178.png","0179.png","0180.png","0181.png","0182.png"],
					padding: false,
					h_space: 0,
					align_h: hmUI.align.CENTER_H,
					type: hmUI.data_type.CAL,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				normal_img26 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 42,
					y: 193,
					w: 43,
					h: 43,
					src: '0183.png',
					enable: false,
					show_level: hmUI.show_level.ONLY_NORMAL,
				});

				idle_hour_imagecombo29 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					hour_startX: 101,
					hour_startY: 181,
					hour_array: ["0184.png","0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png","0192.png","0193.png"],
					hour_zero: true,
					hour_space: 0,
					hour_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_minute_imagecombo30 = hmUI.createWidget(hmUI.widget.IMG_TIME, {
					minute_startX: 263,
					minute_startY: 181,
					minute_array: ["0184.png","0185.png","0186.png","0187.png","0188.png","0189.png","0190.png","0191.png","0192.png","0193.png"],
					minute_zero: true,
					minute_space: 0,
					minute_align: hmUI.align.LEFT,
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				idle_img31 = hmUI.createWidget(hmUI.widget.IMG, {
					x: 230,
					y: 169,
					w: 21,
					h: 120,
					src: '0194.png',
					enable: false,
					show_level: hmUI.show_level.ONAL_AOD,
				});

				const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						normal_animation4.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
						normal_animation5.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
						normal_animation6.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
					}),
					pause_call: (function () {
						normal_animation4.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
						normal_animation5.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
						normal_animation6.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
					}),
				})
			},

		onInit() {
			console.log('index page.js on init invoke')
			this.init_view()
		},
		onReady() {
			console.log('index page.js on ready invoke')
		},
		onShow() {
			console.log('index page.js on show invoke')
		},
		onHide() {
			console.log('index page.js on hide invoke')
		},
		onDestroy() {
			console.log('index page.js on destroy invoke')
						normal_animation4.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
						normal_animation5.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
						normal_animation6.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
		},
	});	})()
} catch (e) {
	console.log(e)
}